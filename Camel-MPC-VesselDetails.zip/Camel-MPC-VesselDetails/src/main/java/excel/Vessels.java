package excel;

public class Vessels {

  private VoyageDetails voyageDetails;

  private AisVoyage aisVoyage;

  private GeoDetails geoDetails;

  private AisStatic aisStatic;

  private AisPosition aisPosition;

  public VoyageDetails getVoyageDetails() {
    return voyageDetails;
  }

  public void setVoyageDetails(VoyageDetails voyageDetails) {
    this.voyageDetails = voyageDetails;
  }

  public AisVoyage getAisVoyage() {
    return aisVoyage;
  }

  public void setAisVoyage(AisVoyage aisVoyage) {
    this.aisVoyage = aisVoyage;
  }

  public GeoDetails getGeoDetails() {
    return geoDetails;
  }

  public void setGeoDetails(GeoDetails geoDetails) {
    this.geoDetails = geoDetails;
  }

  public AisStatic getAisStatic() {
    return aisStatic;
  }

  public void setAisStatic(AisStatic aisStatic) {
    this.aisStatic = aisStatic;
  }

  public AisPosition getAisPosition() {
    return aisPosition;
  }

  public void setAisPosition(AisPosition aisPosition) {
    this.aisPosition = aisPosition;
  }
}
