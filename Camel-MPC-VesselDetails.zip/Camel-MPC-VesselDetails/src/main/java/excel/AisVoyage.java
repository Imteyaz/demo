package excel;

public class AisVoyage {

  private String eta;

  private String dest;

  private String source;

  private String updateTime;

  private String draught;

  public String getEta() {
    return eta;
  }

  public void setEta(String eta) {
    this.eta = eta;
  }

  public String getDest() {
    return dest;
  }

  public void setDest(String dest) {
    this.dest = dest;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(String updateTime) {
    this.updateTime = updateTime;
  }

  public String getDraught() {
    return draught;
  }

  public void setDraught(String draught) {
    this.draught = draught;
  }

}
