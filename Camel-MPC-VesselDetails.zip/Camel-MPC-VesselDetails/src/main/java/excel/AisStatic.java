package excel;

public class AisStatic {

  private String dimB;

  private String imo;

  private String dimC;

  private String dimA;

  private String updateTime;

  private String dimD;

  private String width;

  private String name;

  private String length;

  private String aisShiptype;

  private String callsign;

  private String mmsi;

  public String getDimB() {
    return dimB;
  }

  public void setDimB(String dimB) {
    this.dimB = dimB;
  }

  public String getImo() {
    return imo;
  }

  public void setImo(String imo) {
    this.imo = imo;
  }

  public String getDimC() {
    return dimC;
  }

  public void setDimC(String dimC) {
    this.dimC = dimC;
  }

  public String getDimA() {
    return dimA;
  }

  public void setDimA(String dimA) {
    this.dimA = dimA;
  }

  public String getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(String updateTime) {
    this.updateTime = updateTime;
  }

  public String getDimD() {
    return dimD;
  }

  public void setDimD(String dimD) {
    this.dimD = dimD;
  }

  public String getWidth() {
    return width;
  }

  public void setWidth(String width) {
    this.width = width;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLength() {
    return length;
  }

  public void setLength(String length) {
    this.length = length;
  }

  public String getAisShiptype() {
    return aisShiptype;
  }

  public void setAisShiptype(String aisShiptype) {
    this.aisShiptype = aisShiptype;
  }

  public String getCallsign() {
    return callsign;
  }

  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }

  public String getMmsi() {
    return mmsi;
  }

  public void setMmsi(String mmsi) {
    this.mmsi = mmsi;
  }
}
