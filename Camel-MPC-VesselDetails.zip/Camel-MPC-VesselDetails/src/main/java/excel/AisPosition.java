package excel;

public class AisPosition {

  private String sog;

  private String lon;

  private String rot;

  private String cog;

  private String timeReceived;

  private String hdg;

  private String src;

  private String lat;

  private String navStatus;

  public String getSog() {
    return sog;
  }

  public void setSog(String sog) {
    this.sog = sog;
  }

  public String getLon() {
    return lon;
  }

  public void setLon(String lon) {
    this.lon = lon;
  }

  public String getRot() {
    return rot;
  }

  public void setRot(String rot) {
    this.rot = rot;
  }

  public String getCog() {
    return cog;
  }

  public void setCog(String cog) {
    this.cog = cog;
  }

  public String getTimeReceived() {
    return timeReceived;
  }

  public void setTimeReceived(String timeReceived) {
    this.timeReceived = timeReceived;
  }

  public String getHdg() {
    return hdg;
  }

  public void setHdg(String hdg) {
    this.hdg = hdg;
  }

  public String getSrc() {
    return src;
  }

  public void setSrc(String src) {
    this.src = src;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getNavStatus() {
    return navStatus;
  }

  public void setNavStatus(String navStatus) {
    this.navStatus = navStatus;
  }
}
