package excel;

public class VoyageDetails {

  private String portCountry;

  private String calculatedEta;

  private String locode;

  private String destination;

  public String getPortCountry() {
    return portCountry;
  }

  public void setPortCountry(String portCountry) {
    this.portCountry = portCountry;
  }

  public String getCalculatedEta() {
    return calculatedEta;
  }

  public void setCalculatedEta(String calculatedEta) {
    this.calculatedEta = calculatedEta;
  }

  public String getLocode() {
    return locode;
  }

  public void setLocode(String locode) {
    this.locode = locode;
  }

  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

}
