package excel;

public class Container {

  private String message;

  private String numVessels;

  private String returnCode;

  private String numberOfResults;

  private String timeCreated;

  private Vessels[] vessels;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getNumVessels() {
    return numVessels;
  }

  public void setNumVessels(String numVessels) {
    this.numVessels = numVessels;
  }

  public String getReturnCode() {
    return returnCode;
  }

  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  public String getNumberOfResults() {
    return numberOfResults;
  }

  public void setNumberOfResults(String numberOfResults) {
    this.numberOfResults = numberOfResults;
  }

  public String getTimeCreated() {
    return timeCreated;
  }

  public void setTimeCreated(String timeCreated) {
    this.timeCreated = timeCreated;
  }

  public Vessels[] getVessels() {
    return vessels;
  }

  public void setVessels(Vessels[] vessels) {
    this.vessels = vessels;
  }
}
