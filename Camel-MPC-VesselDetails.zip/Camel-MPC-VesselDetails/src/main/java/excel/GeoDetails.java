package excel;

public class GeoDetails {

  private String status;

  private String portCountry;

  private String currentBerth;

  private String currentPort;

  private String timeOfATChange;

  private String currentPortLocode;

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getPortCountry() {
    return portCountry;
  }

  public void setPortCountry(String portCountry) {
    this.portCountry = portCountry;
  }

  public String getCurrentBerth() {
    return currentBerth;
  }

  public void setCurrentBerth(String currentBerth) {
    this.currentBerth = currentBerth;
  }

  public String getCurrentPort() {
    return currentPort;
  }

  public void setCurrentPort(String currentPort) {
    this.currentPort = currentPort;
  }

  public String getTimeOfATChange() {
    return timeOfATChange;
  }

  public void setTimeOfATChange(String timeOfATChange) {
    this.timeOfATChange = timeOfATChange;
  }

  public String getCurrentPortLocode() {
    return currentPortLocode;
  }

  public void setCurrentPortLocode(String currentPortLocode) {
    this.currentPortLocode = currentPortLocode;
  }

}
