package com.dpworld.mpc.camel.cxfrs.model;

public class TerminalVisit {

  private String actualBerthCode;
  private String actualBerthName;
  private Double arrivalAfterDraft;
  private Double arrivalForwardDraft;
  private Integer deadShipFlag;
  private Double deadWeight;
  private Long estimatedDischargeMoves;
  private Long estimatedLoadMoves;
  private Long estimatedOtherMoves;
  private Integer gasFlag;
  private Integer inertedFlag;
  private Integer isActive;
  private String laybyFromBerth;
  private Integer loadedShipFlag;
  private Long noOfCranes;
  private String noOfHatches;
  private String operationTypeCode;
  private String operationTypeName;
  private String preferredBerthCode;
  private String preferredBerthName;
  private Double priority;
  private String repairCompany;
  private Double sailAftDraft;
  private Double sailForwardDraft;
  private String sustainedGears;
  private String terminal;
  private String terminalName;
  private String vesselPositionCode;
  private String vesselPositionName;
  private Long visitId;
  private String visitReasonCode;
  private String visitReasonName;
  private String visitRemarks;
  private Integer visitSeq;
  private String visitTypeCode;
  private String visitTypeName;

  private String actualArrivalTime;
  private String actualBerthTime;
  private String actualDepartTime;
  private String estimatedArrivalTime;
  private String estimatedBerthTime;
  private String estimatedDepartTime;
  private String loadCutoffTime;
  private String unBerthingTime;
  private String workEndDate;
  private String workStartDate;
  


  public String getActualArrivalTime() {
    return actualArrivalTime;
  }

  public void setActualArrivalTime(String actualArrivalTime) {
    this.actualArrivalTime = actualArrivalTime;
  }

  public String getActualBerthTime() {
    return actualBerthTime;
  }

  public void setActualBerthTime(String actualBerthTime) {
    this.actualBerthTime = actualBerthTime;
  }

  public String getActualDepartTime() {
    return actualDepartTime;
  }

  public void setActualDepartTime(String actualDepartTime) {
    this.actualDepartTime = actualDepartTime;
  }

  public String getEstimatedArrivalTime() {
    return estimatedArrivalTime;
  }

  public void setEstimatedArrivalTime(String estimatedArrivalTime) {
    this.estimatedArrivalTime = estimatedArrivalTime;
  }

  public String getEstimatedBerthTime() {
    return estimatedBerthTime;
  }

  public void setEstimatedBerthTime(String estimatedBerthTime) {
    this.estimatedBerthTime = estimatedBerthTime;
  }

  public String getEstimatedDepartTime() {
    return estimatedDepartTime;
  }

  public void setEstimatedDepartTime(String estimatedDepartTime) {
    this.estimatedDepartTime = estimatedDepartTime;
  }

  public String getLoadCutoffTime() {
    return loadCutoffTime;
  }

  public void setLoadCutoffTime(String loadCutoffTime) {
    this.loadCutoffTime = loadCutoffTime;
  }

  public String getUnBerthingTime() {
    return unBerthingTime;
  }

  public void setUnBerthingTime(String unBerthingTime) {
    this.unBerthingTime = unBerthingTime;
  }

  public String getWorkEndDate() {
    return workEndDate;
  }

  public void setWorkEndDate(String workEndDate) {
    this.workEndDate = workEndDate;
  }

  public String getWorkStartDate() {
    return workStartDate;
  }

  public void setWorkStartDate(String workStartDate) {
    this.workStartDate = workStartDate;
  }

  public String getActualBerthCode() {
    return actualBerthCode;
  }

  public void setActualBerthCode(String actualBerthCode) {
    this.actualBerthCode = actualBerthCode;
  }

  public String getActualBerthName() {
    return actualBerthName;
  }

  public void setActualBerthName(String actualBerthName) {
    this.actualBerthName = actualBerthName;
  }

  public Double getArrivalAfterDraft() {
    return arrivalAfterDraft;
  }

  public void setArrivalAfterDraft(Double arrivalAfterDraft) {
    this.arrivalAfterDraft = arrivalAfterDraft;
  }

  public Double getArrivalForwardDraft() {
    return arrivalForwardDraft;
  }

  public void setArrivalForwardDraft(Double arrivalForwardDraft) {
    this.arrivalForwardDraft = arrivalForwardDraft;
  }

  public Integer getDeadShipFlag() {
    return deadShipFlag;
  }

  public void setDeadShipFlag(Integer deadShipFlag) {
    this.deadShipFlag = deadShipFlag;
  }

  public Double getDeadWeight() {
    return deadWeight;
  }

  public void setDeadWeight(Double deadWeight) {
    this.deadWeight = deadWeight;
  }

  public Long getEstimatedDischargeMoves() {
    return estimatedDischargeMoves;
  }

  public void setEstimatedDischargeMoves(Long estimatedDischargeMoves) {
    this.estimatedDischargeMoves = estimatedDischargeMoves;
  }

  public Long getEstimatedLoadMoves() {
    return estimatedLoadMoves;
  }

  public void setEstimatedLoadMoves(Long estimatedLoadMoves) {
    this.estimatedLoadMoves = estimatedLoadMoves;
  }

  public Long getEstimatedOtherMoves() {
    return estimatedOtherMoves;
  }

  public void setEstimatedOtherMoves(Long estimatedOtherMoves) {
    this.estimatedOtherMoves = estimatedOtherMoves;
  }

  public Integer getGasFlag() {
    return gasFlag;
  }

  public void setGasFlag(Integer gasFlag) {
    this.gasFlag = gasFlag;
  }

  public Integer getInertedFlag() {
    return inertedFlag;
  }

  public void setInertedFlag(Integer inertedFlag) {
    this.inertedFlag = inertedFlag;
  }

  public Integer getIsActive() {
    return isActive;
  }

  public void setIsActive(Integer isActive) {
    this.isActive = isActive;
  }

  public String getLaybyFromBerth() {
    return laybyFromBerth;
  }

  public void setLaybyFromBerth(String laybyFromBerth) {
    this.laybyFromBerth = laybyFromBerth;
  }

  public Integer getLoadedShipFlag() {
    return loadedShipFlag;
  }

  public void setLoadedShipFlag(Integer loadedShipFlag) {
    this.loadedShipFlag = loadedShipFlag;
  }

  public Long getNoOfCranes() {
    return noOfCranes;
  }

  public void setNoOfCranes(Long noOfCranes) {
    this.noOfCranes = noOfCranes;
  }

  public String getNoOfHatches() {
    return noOfHatches;
  }

  public void setNoOfHatches(String noOfHatches) {
    this.noOfHatches = noOfHatches;
  }

  public String getOperationTypeCode() {
    return operationTypeCode;
  }

  public void setOperationTypeCode(String operationTypeCode) {
    this.operationTypeCode = operationTypeCode;
  }

  public String getOperationTypeName() {
    return operationTypeName;
  }

  public void setOperationTypeName(String operationTypeName) {
    this.operationTypeName = operationTypeName;
  }

  public String getPreferredBerthCode() {
    return preferredBerthCode;
  }

  public void setPreferredBerthCode(String preferredBerthCode) {
    this.preferredBerthCode = preferredBerthCode;
  }

  public String getPreferredBerthName() {
    return preferredBerthName;
  }

  public void setPreferredBerthName(String preferredBerthName) {
    this.preferredBerthName = preferredBerthName;
  }

  public Double getPriority() {
    return priority;
  }

  public void setPriority(Double priority) {
    this.priority = priority;
  }

  public String getRepairCompany() {
    return repairCompany;
  }

  public void setRepairCompany(String repairCompany) {
    this.repairCompany = repairCompany;
  }

  public Double getSailAftDraft() {
    return sailAftDraft;
  }

  public void setSailAftDraft(Double sailAftDraft) {
    this.sailAftDraft = sailAftDraft;
  }

  public Double getSailForwardDraft() {
    return sailForwardDraft;
  }

  public void setSailForwardDraft(Double sailForwardDraft) {
    this.sailForwardDraft = sailForwardDraft;
  }

  public String getSustainedGears() {
    return sustainedGears;
  }

  public void setSustainedGears(String sustainedGears) {
    this.sustainedGears = sustainedGears;
  }

  public String getTerminal() {
    return terminal;
  }

  public void setTerminal(String terminal) {
    this.terminal = terminal;
  }

  public String getTerminalName() {
    return terminalName;
  }

  public void setTerminalName(String terminalName) {
    this.terminalName = terminalName;
  }

  public String getVesselPositionCode() {
    return vesselPositionCode;
  }

  public void setVesselPositionCode(String vesselPositionCode) {
    this.vesselPositionCode = vesselPositionCode;
  }

  public String getVesselPositionName() {
    return vesselPositionName;
  }

  public void setVesselPositionName(String vesselPositionName) {
    this.vesselPositionName = vesselPositionName;
  }

  public Long getVisitId() {
    return visitId;
  }

  public void setVisitId(Long visitId) {
    this.visitId = visitId;
  }

  public String getVisitReasonCode() {
    return visitReasonCode;
  }

  public void setVisitReasonCode(String visitReasonCode) {
    this.visitReasonCode = visitReasonCode;
  }

  public String getVisitReasonName() {
    return visitReasonName;
  }

  public void setVisitReasonName(String visitReasonName) {
    this.visitReasonName = visitReasonName;
  }

  public String getVisitRemarks() {
    return visitRemarks;
  }

  public void setVisitRemarks(String visitRemarks) {
    this.visitRemarks = visitRemarks;
  }

  public Integer getVisitSeq() {
    return visitSeq;
  }

  public void setVisitSeq(Integer visitSeq) {
    this.visitSeq = visitSeq;
  }

  public String getVisitTypeCode() {
    return visitTypeCode;
  }

  public void setVisitTypeCode(String visitTypeCode) {
    this.visitTypeCode = visitTypeCode;
  }

  public String getVisitTypeName() {
    return visitTypeName;
  }

  public void setVisitTypeName(String visitTypeName) {
    this.visitTypeName = visitTypeName;
  }

  @Override
public String toString() {
	return "TerminalVisit [actualBerthCode=" + actualBerthCode
			+ ", actualBerthName=" + actualBerthName + ", arrivalAfterDraft="
			+ arrivalAfterDraft + ", arrivalForwardDraft="
			+ arrivalForwardDraft + ", deadShipFlag=" + deadShipFlag
			+ ", deadWeight=" + deadWeight + ", estimatedDischargeMoves="
			+ estimatedDischargeMoves + ", estimatedLoadMoves="
			+ estimatedLoadMoves + ", estimatedOtherMoves="
			+ estimatedOtherMoves + ", gasFlag=" + gasFlag + ", inertedFlag="
			+ inertedFlag + ", isActive=" + isActive + ", laybyFromBerth="
			+ laybyFromBerth + ", loadedShipFlag=" + loadedShipFlag
			+ ", noOfCranes=" + noOfCranes + ", noOfHatches=" + noOfHatches
			+ ", operationTypeCode=" + operationTypeCode
			+ ", operationTypeName=" + operationTypeName
			+ ", preferredBerthCode=" + preferredBerthCode
			+ ", preferredBerthName=" + preferredBerthName + ", priority="
			+ priority + ", repairCompany=" + repairCompany + ", sailAftDraft="
			+ sailAftDraft + ", sailForwardDraft=" + sailForwardDraft
			+ ", sustainedGears=" + sustainedGears + ", terminal=" + terminal
			+ ", terminalName=" + terminalName + ", vesselPositionCode="
			+ vesselPositionCode + ", vesselPositionName=" + vesselPositionName
			+ ", visitId=" + visitId + ", visitReasonCode=" + visitReasonCode
			+ ", visitReasonName=" + visitReasonName + ", visitRemarks="
			+ visitRemarks + ", visitSeq=" + visitSeq + ", visitTypeCode="
			+ visitTypeCode + ", visitTypeName=" + visitTypeName
			+ ", actualArrivalTime=" + actualArrivalTime + ", actualBerthTime="
			+ actualBerthTime + ", actualDepartTime=" + actualDepartTime
			+ ", estimatedArrivalTime=" + estimatedArrivalTime
			+ ", estimatedBerthTime=" + estimatedBerthTime
			+ ", estimatedDepartTime=" + estimatedDepartTime
			+ ", loadCutoffTime=" + loadCutoffTime + ", unBerthingTime="
			+ unBerthingTime + ", workEndDate=" + workEndDate
			+ ", workStartDate=" + workStartDate + "]";
}

  

}
