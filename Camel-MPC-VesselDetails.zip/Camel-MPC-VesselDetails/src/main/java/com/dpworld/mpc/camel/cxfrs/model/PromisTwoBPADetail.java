package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.util.StringUtils;

public class PromisTwoBPADetail implements Serializable,
		Comparable<PromisTwoBPADetail> {

	private static final long serialVersionUID = -2697750527722624552L;

	private String containerNumber;
	private String portCode;
	private String rotation;
	private String berthPosition;
	private String craneAssigned;
	private String berth;
	private String fromBollard;
	private String berthCode;
	private String toBollard;
	private String fromMetermark;
	private String toMetermark;
	private String etc;
	private String vesselMovesTogo;
	private String longCraneNo;
	private String longCranemovesToGo;
	private String noOfCranes;

	private String vesselName;
	private String berthDate;
	private String sailDate;
	private String status;
	private String etaDate;
	private String etbDate;
	private String etdDate;

	private Date etaDateObject;
	private Date etbDateObject;
	private Date etdDateObject;
	private Date anchorageDateObject;
	private Date berthDateObject;
	private Date sailDateObject;

	private String anchorageDate;
	private String voyageNumber;
	private String outvoyageNumber;
	private String voyageRoute;
	private String voyageType;
	private String arrFm;
	private String callReason;
	private String callType;
	private String callDescr;
	private String planMoves;
	private String lineCode;
	private String inVesselService;
	private String arrDraft;
	private String sailDraft;
	private String dualBerth;
	private String terminalId;
	private String loadTerminalId;
	private String callSign;
	private String loa;
	private String imoCode;
	private String vesselType;
	private String serviceType;
	private String serviceTypeDesc;
	private String sourceSystem;
	private String currentPOS;

	private int order;
	private String priority;
	private Long hhMTG;
	private String description;
	private String maneuverStatus;
	private String et;
	private String fromLocation;
	private String toLocation;
	private String berthingPOS;
	private String swap;

	private Long ttMTG;
	private Long qcAlloc;
	private Long qcWorking;
	private String hhCrane;
	private String newETA;
	private Date priorityDate;

	private String bpaTerminalId;
	private String bpaPortCode;
	private String bpaSourceSystem;
	private String quay;
	private String promisTerminalId;
	private String bpaIsValid;
	private String remarks;
	private List<TerminalVisit> terminalVisitList;
	private List<String> dropDownTypes;
	private String slaStatus;
	private String proforma;
	private String IS_SLA;
	
	
	
	

	// ais details
	private String aisVslOprEta;
	private String aisAvgSpeed;
	private String aisVesselOperator;
	private String aisUpdateTime;
	private String aisEta;
	private String aisPreviousAtd;
	private String aisDistanceToNextPort;
	private String aisNextPort;
	private String aisPrevPort;
	// New Added
	private String aisLocation;
	private String aisError;
	private Long doneMoves;
	private String plannedBerth;
	private String currentBerth;

	private String longitude;
	private String latitude;
	
	/*tariq voyage details*/
	//private List<voyage> terminalVisitList;
	private String berthbookingnumber;  //new for marineJoblist
	private String agentCode; 
	

	

	

	protected Long id;
	 // protected String vesselName;
	  protected Long visitId;
	  protected Integer visitSeq;
	  protected String visitTypeCode;
	  protected String visitTypeName;
	  private String heaveUpTime;
	
	
	
	

	/*tariq Cbbsdetails*/
	private String voyage_id;


	private String rotn;
	private String voyage_ref;
	private String booking_type;
	private String port_code;
	private String port_eta;
	private String port_etd;
	private String port_berth_date;
	private String port_sail_daet;
	private String visit_id;
	private String visit_seq_no;
	private String visit_terminal;
	private String visit_type;
	private String visit_eta;
	private String visit_etb;
	private String visit_etd;
	private Integer maxVisitSeqNo;

	private String visit_berth_date;
	private String visit_sail_date;
	private String etmstr;
	private int timedifForBerthingExpected;
	private String port_arr_date;
	private String berthedFrom;
	
	

	public String getIS_SLA() {
		return IS_SLA;
	}

	public void setIS_SLA(String iS_SLA) {
		IS_SLA = iS_SLA;
	}

	
	public String getHeaveUpTime() {
		return heaveUpTime;
	}

	public void setHeaveUpTime(String heaveUpTime) {
		this.heaveUpTime = heaveUpTime;
	}
	
	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getPort_arr_date() {
		return port_arr_date;
	}

	public void setPort_arr_date(String port_arr_date) {
		this.port_arr_date = port_arr_date;
	}

	public String getEtmstr() {
		return etmstr;
	}

	public void setEtmstr(String etmstr) {
		this.etmstr = etmstr;
	}

	public int getTimedifForBerthingExpected() {
		return timedifForBerthingExpected;
	}

	public void setTimedifForBerthingExpected(int timedifForBerthingExpected) {
		this.timedifForBerthingExpected = timedifForBerthingExpected;
	}


	public String getVisit_berth_date() {
		return visit_berth_date;
	}

	public void setVisit_berth_date(String visit_berth_date) {
		this.visit_berth_date = visit_berth_date;
	}

	public String getVisit_sail_date() {
		return visit_sail_date;
	}

	public void setVisit_sail_date(String visit_sail_date) {
		this.visit_sail_date = visit_sail_date;
	}

	
	
	
	/*Voyage*/
	  public String getBerthbookingnumber() {
			return berthbookingnumber;
		}

		public void setBerthbookingnumber(String berthbookingnumber) {
			this.berthbookingnumber = berthbookingnumber;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Long getVisitId() {
			return visitId;
		}

		public void setVisitId(Long visitId) {
			this.visitId = visitId;
		}

		public Integer getVisitSeq() {
			return visitSeq;
		}

		public void setVisitSeq(Integer visitSeq) {
			this.visitSeq = visitSeq;
		}

		public String getVisitTypeCode() {
			return visitTypeCode;
		}

		public void setVisitTypeCode(String visitTypeCode) {
			this.visitTypeCode = visitTypeCode;
		}

		public String getVisitTypeName() {
			return visitTypeName;
		}

		public void setVisitTypeName(String visitTypeName) {
			this.visitTypeName = visitTypeName;
		}
	
	/*CBBS*/
	public String getVoyage_id() {
		return voyage_id;
	}

	public void setVoyage_id(String voyage_id) {
		this.voyage_id = voyage_id;
	}

	public String getRotn() {
		return rotn;
		
	}

	public void setRotn(String rotn) {
		this.rotn = rotn;
	}

	public String getVoyage_ref() {
		return voyage_ref;
	}

	public void setVoyage_ref(String voyage_ref) {
		this.voyage_ref = voyage_ref;
	}

	public String getBooking_type() {
		return booking_type;
	}

	public void setBooking_type(String booking_type) {
		this.booking_type = booking_type;
	}

	public String getPort_code() {
		return port_code;
	}

	public void setPort_code(String port_code) {
		this.port_code = port_code;
	}

	public String getPort_eta() {
		return port_eta;
	}

	public void setPort_eta(String port_eta) {
		this.port_eta = port_eta;
	}

	public String getPort_etd() {
		return port_etd;
	}

	public void setPort_etd(String port_etd) {
		this.port_etd = port_etd;
	}

	public String getPort_berth_date() {
		return port_berth_date;
	}

	public void setPort_berth_date(String port_berth_date) {
		this.port_berth_date = port_berth_date;
	}

	public String getPort_sail_daet() {
		return port_sail_daet;
	}

	public void setPort_sail_daet(String port_sail_daet) {
		this.port_sail_daet = port_sail_daet;
	}

	public String getVisit_id() {
		return visit_id;
	}

	public void setVisit_id(String visit_id) {
		this.visit_id = visit_id;
	}

	public String getVisit_seq_no() {
		return visit_seq_no;
	}

	public void setVisit_seq_no(String visit_seq_no) {
		this.visit_seq_no = visit_seq_no;
	}

	public String getVisit_terminal() {
		return visit_terminal;
	}

	public void setVisit_terminal(String visit_terminal) {
		this.visit_terminal = visit_terminal;
	}

	public String getVisit_type() {
		return visit_type;
	}

	public void setVisit_type(String visit_type) {
		this.visit_type = visit_type;
	}

	public String getVisit_eta() {
		return visit_eta;
	}

	public void setVisit_eta(String visit_eta) {
		this.visit_eta = visit_eta;
	}

	public String getVisit_etb() {
		return visit_etb;
	}

	public void setVisit_etb(String visit_etb) {
		this.visit_etb = visit_etb;
	}

	public String getVisit_etd() {
		return visit_etd;
	}

	public void setVisit_etd(String visit_etd) {
		this.visit_etd = visit_etd;
	}
	
	/*tariq end*/

	public String getVesselLocation() {
		return vesselLocation;
	}

	public void setVesselLocation(String vesselLocation) {
		this.vesselLocation = vesselLocation;
	}

	private String vesselLocation;

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getPlannedBerth() {
		return plannedBerth;
	}

	public void setPlannedBerth(String plannedBerth) {
		this.plannedBerth = plannedBerth;
	}

	public String getCurrentBerth() {
		return currentBerth;
	}

	public void setCurrentBerth(String currentBerth) {
		this.currentBerth = currentBerth;
	}

	public Long getDoneMoves() {
		return doneMoves;
	}

	public void setDoneMoves(Long doneMoves) {
		this.doneMoves = doneMoves;
	}

	public List<String> getDropDownTypes() {
		return dropDownTypes;
	}

	public void setDropDownTypes(List<String> dropDownTypes) {
		this.dropDownTypes = dropDownTypes;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getNewETA() {
		return newETA;
	}

	public void setNewETA(String newETA) {
		this.newETA = newETA;
	}

	public String getHhCrane() {
		return hhCrane;
	}

	public void setHhCrane(String hhCrane) {
		this.hhCrane = hhCrane;
	}

	public String getContainerNumber() {
		return containerNumber;
	}

	public void setContainerNumber(String containerNumber) {
		this.containerNumber = containerNumber;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getRotation() {
		return rotation;
	}

	public void setRotation(String rotation) {
		this.rotation = rotation;
	}

	public String getBerthPosition() {
		return berthPosition;
	}

	public void setBerthPosition(String berthPosition) {
		this.berthPosition = berthPosition;
	}

	public String getCraneAssigned() {
		return craneAssigned;
	}

	public void setCraneAssigned(String craneAssigned) {
		this.craneAssigned = craneAssigned;
	}

	public String getBerth() {
		return berth;
	}

	public void setBerth(String berth) {
		this.berth = berth;
	}

	public String getFromBollard() {
		return fromBollard;
	}

	public void setFromBollard(String fromBollard) {
		this.fromBollard = fromBollard;
	}

	public String getBerthCode() {
		return berthCode;
	}

	public void setBerthCode(String berthCode) {
		this.berthCode = berthCode;
	}

	public String getToBollard() {
		return toBollard;
	}

	public void setToBollard(String toBollard) {
		this.toBollard = toBollard;
	}

	public String getFromMetermark() {
		return fromMetermark;
	}

	public void setFromMetermark(String fromMetermark) {
		this.fromMetermark = fromMetermark;
	}

	public String getToMetermark() {
		return toMetermark;
	}

	public void setToMetermark(String toMetermark) {
		this.toMetermark = toMetermark;
	}

	public String getEtc() {
		return etc;
	}

	public void setEtc(String etc) {
		this.etc = etc;
	}

	public String getVesselMovesTogo() {
		return vesselMovesTogo;
	}

	public void setVesselMovesTogo(String vesselMovesTogo) {
		this.vesselMovesTogo = vesselMovesTogo;
	}

	public String getLongCraneNo() {
		return longCraneNo;
	}

	public void setLongCraneNo(String longCraneNo) {
		this.longCraneNo = longCraneNo;
	}

	public String getLongCranemovesToGo() {
		return longCranemovesToGo;
	}

	public void setLongCranemovesToGo(String longCranemovesToGo) {
		this.longCranemovesToGo = longCranemovesToGo;
	}

	public String getNoOfCranes() {
		return noOfCranes;
	}

	public void setNoOfCranes(String noOfCranes) {
		this.noOfCranes = noOfCranes;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getBerthDate() {
		return (String) (StringUtils.isEmpty(berthDateObject) ? berthDateObject
				: berthDate);
	}

	public void setBerthDate(String berthDate) {
		this.berthDate = berthDate;
	}

	public String getSailDate() {
		return sailDate;
	}

	public void setSailDate(String sailDate) {
		this.sailDate = sailDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEtaDate() {
		return etaDate ==null ? this.visit_eta:etaDate;
	}

	public void setEtaDate(String etaDate) {
		this.etaDate = etaDate;
	}

	public String getEtbDate() {
		return etbDate;
	}

	public void setEtbDate(String etbDate) {
		this.etbDate = etbDate;
	}

	public String getEtdDate() {
		return etdDate;
	}

	public Long getQcAlloc() {
		return qcAlloc;
	}

	public void setQcAlloc(Long qcAlloc) {
		this.qcAlloc = qcAlloc;
	}

	public Long getQcWorking() {
		return qcWorking;
	}

	public void setQcWorking(Long qcWorking) {
		this.qcWorking = qcWorking;
	}

	public void setEtdDate(String etdDate) {
		this.etdDate = etdDate;
	}

	public String getAnchorageDate() {
		return anchorageDate;
	}

	public void setAnchorageDate(String anchorageDate) {
		this.anchorageDate = anchorageDate;
	}

	public String getVoyageNumber() {
		return voyageNumber;
	}

	public void setVoyageNumber(String voyageNumber) {
		this.voyageNumber = voyageNumber;
	}

	public String getOutvoyageNumber() {
		return outvoyageNumber;
	}

	public void setOutvoyageNumber(String outvoyageNumber) {
		this.outvoyageNumber = outvoyageNumber;
	}

	public String getVoyageRoute() {
		return voyageRoute;
	}

	public void setVoyageRoute(String voyageRoute) {
		this.voyageRoute = voyageRoute;
	}

	public String getVoyageType() {
		return voyageType;
	}

	public void setVoyageType(String voyageType) {
		this.voyageType = voyageType;
	}

	public String getArrFm() {
		return arrFm;
	}

	public void setArrFm(String arrFm) {
		this.arrFm = arrFm;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public Long getHhMTG() {
		return hhMTG;
	}

	public void setHhMTG(Long hhMTG) {
		this.hhMTG = hhMTG;
	}

	public Long getTtMTG() {
		return ttMTG;
	}

	public void setTtMTG(Long ttMTG) {
		this.ttMTG = ttMTG;
	}

	public String getCallDescr() {
		return callDescr;
	}

	public void setCallDescr(String callDescr) {
		this.callDescr = callDescr;
	}

	public String getPlanMoves() {
		return planMoves;
	}

	public void setPlanMoves(String planMoves) {
		this.planMoves = planMoves;
	}

	public String getLineCode() {
		return lineCode;
	}

	public void setLineCode(String lineCode) {
		this.lineCode = lineCode;
	}

	public String getInVesselService() {
		return inVesselService;
	}

	public void setInVesselService(String inVesselService) {
		this.inVesselService = inVesselService;
	}

	public String getArrDraft() {
		return arrDraft;
	}

	public void setArrDraft(String arrDraft) {
		this.arrDraft = arrDraft;
	}

	public String getSailDraft() {
		return sailDraft;
	}

	public void setSailDraft(String sailDraft) {
		this.sailDraft = sailDraft;
	}

	public String getDualBerth() {
		return dualBerth;
	}

	public void setDualBerth(String dualBerth) {
		this.dualBerth = dualBerth;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getLoadTerminalId() {
		return loadTerminalId;
	}

	public void setLoadTerminalId(String loadTerminalId) {
		this.loadTerminalId = loadTerminalId;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getCallSign() {
		return callSign;
	}

	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}

	public String getLoa() {
		return loa;
	}

	public void setLoa(String loa) {
		this.loa = loa;
	}

	public String getImoCode() {
		return imoCode;
	}

	public String getVesselType() {
		return vesselType;
	}

	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}

	public void setImoCode(String imoCode) {
		this.imoCode = imoCode;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getManeuverStatus() {
		return maneuverStatus;
	}

	public void setManeuverStatus(String maneuverStatus) {
		this.maneuverStatus = maneuverStatus;
	}

	public String getEt() {
		return et;
	}

	public void setEt(String et) {
		this.et = et;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getBerthingPOS() {
		return berthingPOS;
	}

	public void setBerthingPOS(String berthingPOS) {
		this.berthingPOS = berthingPOS;
	}

	public String getSwap() {
		return swap;
	}

	public void setSwap(String swap) {
		this.swap = swap;
	}

	public String getCurrentPOS() {
		return currentPOS;
	}

	public void setCurrentPOS(String currentPOS) {
		this.currentPOS = currentPOS;
	}

	public Date getEtaDateObject() {
		return etaDateObject;
	}

	public void setEtaDateObject(Date etaDateObject) {
		this.etaDateObject = etaDateObject;
	}

	public Date getEtbDateObject() {
		return etbDateObject;
	}

	public void setEtbDateObject(Date etbDateObject) {
		this.etbDateObject = etbDateObject;
	}

	public Date getEtdDateObject() {
		return etdDateObject;
	}

	public void setEtdDateObject(Date etdDateObject) {
		this.etdDateObject = etdDateObject;
	}

	public Date getPriorityDate() {
		return priorityDate;
	}

	public void setPriorityDate(Date priorityDate) {
		this.priorityDate = priorityDate;
	}

	public Date getAnchorageDateObject() {
		return anchorageDateObject;
	}

	public void setAnchorageDateObject(Date anchorageDateObject) {
		this.anchorageDateObject = anchorageDateObject;
	}

	public Date getBerthDateObject() {
		return berthDateObject;
	}

	public void setBerthDateObject(Date berthDateObject) {
		this.berthDateObject = berthDateObject;
	}

	public Date getSailDateObject() {
		return sailDateObject;
	}

	public void setSailDateObject(Date sailDateObject) {
		this.sailDateObject = sailDateObject;
	}

	public String getBpaTerminalId() {
		return bpaTerminalId;
	}

	public void setBpaTerminalId(String bpaTerminalId) {
		this.bpaTerminalId = bpaTerminalId;
	}

	public String getBpaPortCode() {
		return bpaPortCode;
	}

	public void setBpaPortCode(String bpaPortCode) {
		this.bpaPortCode = bpaPortCode;
	}

	public String getBpaSourceSystem() {
		return bpaSourceSystem;
	}

	public void setBpaSourceSystem(String bpaSourceSystem) {
		this.bpaSourceSystem = bpaSourceSystem;
	}

	public String getQuay() {
		return quay;
	}

	public void setQuay(String quay) {
		this.quay = quay;
	}

	public String getPromisTerminalId() {
		return promisTerminalId;
	}

	public void setPromisTerminalId(String promisTerminalId) {
		this.promisTerminalId = promisTerminalId;
	}

	public String getBpaIsValid() {
		return bpaIsValid;
	}

	public void setBpaIsValid(String bpaIsValid) {
		this.bpaIsValid = bpaIsValid;
	}

	public List<TerminalVisit> getTerminalVisitList() {
		return terminalVisitList;
	}

	public void setTerminalVisitList(List<TerminalVisit> terminalVisitList) {
		this.terminalVisitList = terminalVisitList;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceTypeDesc() {
		return serviceTypeDesc;
	}

	public void setServiceTypeDesc(String serviceTypeDesc) {
		this.serviceTypeDesc = serviceTypeDesc;
	}

	public String getSlaStatus() {
		return slaStatus;
	}

	public void setSlaStatus(String slaStatus) {
		this.slaStatus = slaStatus;
	}

	public String getProforma() {
		return proforma;
	}

	public void setProforma(String proforma) {
		this.proforma = proforma;
	}

	public String getAisVslOprEta() {
		return aisVslOprEta;
	}

	public void setAisVslOprEta(String aisVslOprEta) {
		this.aisVslOprEta = aisVslOprEta;
	}

	public String getAisAvgSpeed() {
		return aisAvgSpeed;
	}

	public void setAisAvgSpeed(String aisAvgSpeed) {
		this.aisAvgSpeed = aisAvgSpeed;
	}

	public String getAisVesselOperator() {
		return aisVesselOperator;
	}

	public void setAisVesselOperator(String aisVesselOperator) {
		this.aisVesselOperator = aisVesselOperator;
	}

	public String getAisUpdateTime() {
		return aisUpdateTime;
	}

	public void setAisUpdateTime(String aisUpdateTime) {
		this.aisUpdateTime = aisUpdateTime;
	}

	public String getAisEta() {
		return aisEta;
	}

	public void setAisEta(String aisEta) {
		this.aisEta = aisEta;
	}

	public String getAisPreviousAtd() {
		return aisPreviousAtd;
	}

	public void setAisPreviousAtd(String aisPreviousAtd) {
		this.aisPreviousAtd = aisPreviousAtd;
	}

	public String getAisDistanceToNextPort() {
		return aisDistanceToNextPort;
	}

	public void setAisDistanceToNextPort(String aisDistanceToNextPort) {
		this.aisDistanceToNextPort = aisDistanceToNextPort;
	}

	public String getAisNextPort() {
		return aisNextPort;
	}

	public void setAisNextPort(String aisNextPort) {
		this.aisNextPort = aisNextPort;
	}

	public String getAisPrevPort() {
		return aisPrevPort;
	}

	public void setAisPrevPort(String aisPrevPort) {
		this.aisPrevPort = aisPrevPort;
	}

	public String getAisLocation() {
		return aisLocation;
	}

	public void setAisLocation(String aisLocation) {
		this.aisLocation = aisLocation;
	}

	public String getAisError() {
		return aisError;
	}

	public void setAisError(String aisError) {
		this.aisError = aisError;
	}
	
	

	public Integer getMaxVisitSeqNo() {
		return maxVisitSeqNo;
	}

	public void setMaxVisitSeqNo(Integer maxVisitSeqNo) {
		this.maxVisitSeqNo = maxVisitSeqNo;
	}

	@Override
	public String toString() {
		return "PromisTwoBPADetail [containerNumber=" + containerNumber + ", portCode=" + portCode + ", rotation="
				+ rotation + ", berthPosition=" + berthPosition + ", craneAssigned=" + craneAssigned + ", berth="
				+ berth + ", fromBollard=" + fromBollard + ", berthCode=" + berthCode + ", toBollard=" + toBollard
				+ ", fromMetermark=" + fromMetermark + ", toMetermark=" + toMetermark + ", etc=" + etc
				+ ", vesselMovesTogo=" + vesselMovesTogo + ", longCraneNo=" + longCraneNo + ", longCranemovesToGo="
				+ longCranemovesToGo + ", noOfCranes=" + noOfCranes + ", vesselName=" + vesselName + ", berthDate="
				+ berthDate + ", sailDate=" + sailDate + ", status=" + status + ", etaDate=" + etaDate + ", etbDate="
				+ etbDate + ", etdDate=" + etdDate + ", etaDateObject=" + etaDateObject + ", etbDateObject="
				+ etbDateObject + ", etdDateObject=" + etdDateObject + ", anchorageDateObject=" + anchorageDateObject
				+ ", berthDateObject=" + berthDateObject + ", sailDateObject=" + sailDateObject + ", anchorageDate="
				+ anchorageDate + ", voyageNumber=" + voyageNumber + ", outvoyageNumber=" + outvoyageNumber
				+ ", voyageRoute=" + voyageRoute + ", voyageType=" + voyageType + ", arrFm=" + arrFm + ", callReason="
				+ callReason + ", callType=" + callType + ", callDescr=" + callDescr + ", planMoves=" + planMoves
				+ ", lineCode=" + lineCode + ", inVesselService=" + inVesselService + ", arrDraft=" + arrDraft
				+ ", sailDraft=" + sailDraft + ", dualBerth=" + dualBerth + ", terminalId=" + terminalId
				+ ", loadTerminalId=" + loadTerminalId + ", callSign=" + callSign + ", loa=" + loa + ", imoCode="
				+ imoCode + ", vesselType=" + vesselType + ", serviceType=" + serviceType + ", serviceTypeDesc="
				+ serviceTypeDesc + ", sourceSystem=" + sourceSystem + ", currentPOS=" + currentPOS + ", order=" + order
				+ ", priority=" + priority + ", hhMTG=" + hhMTG + ", description=" + description + ", maneuverStatus="
				+ maneuverStatus + ", et=" + et + ", fromLocation=" + fromLocation + ", toLocation=" + toLocation
				+ ", berthingPOS=" + berthingPOS + ", swap=" + swap + ", ttMTG=" + ttMTG + ", qcAlloc=" + qcAlloc
				+ ", qcWorking=" + qcWorking + ", hhCrane=" + hhCrane + ", newETA=" + newETA + ", priorityDate="
				+ priorityDate + ", bpaTerminalId=" + bpaTerminalId + ", bpaPortCode=" + bpaPortCode
				+ ", bpaSourceSystem=" + bpaSourceSystem + ", quay=" + quay + ", promisTerminalId=" + promisTerminalId
				+ ", bpaIsValid=" + bpaIsValid + ", remarks=" + remarks + ", terminalVisitList=" + terminalVisitList
				+ ", dropDownTypes=" + dropDownTypes + ", slaStatus=" + slaStatus + ", proforma=" + proforma
				+ ", IS_SLA=" + IS_SLA + ", aisVslOprEta=" + aisVslOprEta + ", aisAvgSpeed=" + aisAvgSpeed
				+ ", aisVesselOperator=" + aisVesselOperator + ", aisUpdateTime=" + aisUpdateTime + ", aisEta=" + aisEta
				+ ", aisPreviousAtd=" + aisPreviousAtd + ", aisDistanceToNextPort=" + aisDistanceToNextPort
				+ ", aisNextPort=" + aisNextPort + ", aisPrevPort=" + aisPrevPort + ", aisLocation=" + aisLocation
				+ ", aisError=" + aisError + ", doneMoves=" + doneMoves + ", plannedBerth=" + plannedBerth
				+ ", currentBerth=" + currentBerth + ", longitude=" + longitude + ", latitude=" + latitude
				+ ", berthbookingnumber=" + berthbookingnumber + ", agentCode=" + agentCode + ", id=" + id
				+ ", visitId=" + visitId + ", visitSeq=" + visitSeq + ", visitTypeCode=" + visitTypeCode
				+ ", visitTypeName=" + visitTypeName + ", heaveUpTime=" + heaveUpTime + ", voyage_id=" + voyage_id
				+ ", rotn=" + rotn + ", voyage_ref=" + voyage_ref + ", booking_type=" + booking_type + ", port_code="
				+ port_code + ", port_eta=" + port_eta + ", port_etd=" + port_etd + ", port_berth_date="
				+ port_berth_date + ", port_sail_daet=" + port_sail_daet + ", visit_id=" + visit_id + ", visit_seq_no="
				+ visit_seq_no + ", visit_terminal=" + visit_terminal + ", visit_type=" + visit_type + ", visit_eta="
				+ visit_eta + ", visit_etb=" + visit_etb + ", visit_etd=" + visit_etd + ", maxVisitSeqNo="
				+ maxVisitSeqNo + ", visit_berth_date=" + visit_berth_date + ", visit_sail_date=" + visit_sail_date
				+ ", etmstr=" + etmstr + ", timedifForBerthingExpected=" + timedifForBerthingExpected
				+ ", port_arr_date=" + port_arr_date + ", berthedFrom=" + berthedFrom + ", vesselLocation="
				+ vesselLocation + "]";
	}

	@Override
	public int compareTo(PromisTwoBPADetail bpaDetail) {
		if (this != null && bpaDetail != null && this.getPriorityDate() != null
				&& bpaDetail.getPriorityDate() != null) {
			return this.getPriorityDate()
					.compareTo(bpaDetail.getPriorityDate());
		}
		if (this == null || this.getPriorityDate() == null) {
			return 1;
		}
		if (bpaDetail == null || bpaDetail.getPriorityDate() == null) {
			return -1;
		}
		return 1;
	}

	@Override
	public boolean equals(Object obj) {
		if (this != null
				&& obj != null
				&& obj instanceof PromisTwoBPADetail
				&& this.getPriorityDate() != null
				&& ((PromisTwoBPADetail) obj).getPriorityDate() != null
				&& this.getPriorityDate().compareTo(
						((PromisTwoBPADetail) obj).getPriorityDate()) == 0) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		try {
			if (rotation != null) {
				return new Integer(rotation).intValue();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public String getBerthedFrom() {
		return berthedFrom;
	}

	public void setBerthedFrom(String berthedFrom) {
		this.berthedFrom = berthedFrom;
	}

}
