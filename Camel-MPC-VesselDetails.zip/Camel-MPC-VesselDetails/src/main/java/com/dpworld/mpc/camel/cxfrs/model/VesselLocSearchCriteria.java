package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;

public class VesselLocSearchCriteria implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -5102353753959269450L;

  private String vesselName;
  private String imoCode;

  public VesselLocSearchCriteria() {
    super();
  }

  /**
   * Constructor with fields
   * 
   * @param vesselName
   * @param imoCode
   */
  public VesselLocSearchCriteria(String vesselName, String imoCode) {
    this.vesselName = vesselName;
    this.imoCode = imoCode;
  }


  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoCode() {
    return imoCode;
  }

  public void setImoCode(String imoCode) {
    this.imoCode = imoCode;
  }

  @Override
  public String toString() {
    return "VesselLocSearchCriteria [vesselName=" + vesselName + ", imoCode=" + imoCode + "]";
  }
  
  

}
