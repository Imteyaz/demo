package com.dpworld.mpc.camel.cxfrs.processor;

import java.io.Serializable;
import java.util.List;

import com.dpworld.mpc.camel.cxfrs.model.TerminalVisit;

/**
 * 
 * 
 * 
 */

public class BPARequest implements Serializable {

	private static final long serialVersionUID = -3657608475330194182L;

	private String rotationNumber;
	private List<String> rotationNumerList;
	private String vesselName;

	private List<String> vesselList;

	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public List<String> getRotationNumerList() {
		return rotationNumerList;
	}

	public void setRotationNumerList(List<String> rotationNumerList) {
		this.rotationNumerList = rotationNumerList;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	private List<TerminalVisit> terminalListConstructed;

	public List<TerminalVisit> getTerminalListConstructed() {
		return terminalListConstructed;
	}

	public void setTerminalListConstructed(
			List<TerminalVisit> terminalListConstructed) {
		this.terminalListConstructed = terminalListConstructed;
	}

	/**
	 * @return the vesselList
	 */
	public List<String> getVesselList() {
		return vesselList;
	}

	/**
	 * @param vesselList
	 *            the vesselList to set
	 */
	public void setVesselList(List<String> vesselList) {
		this.vesselList = vesselList;
	}

	@Override
	public String toString() {
		return "BPARequest [rotationNumber=" + rotationNumber
				+ ", rotationNumerList=" + rotationNumerList + ", vesselName="
				+ vesselName + ", vesselList=" + vesselList
				+ ", terminalListConstructed=" + terminalListConstructed + "]";
	}
}
