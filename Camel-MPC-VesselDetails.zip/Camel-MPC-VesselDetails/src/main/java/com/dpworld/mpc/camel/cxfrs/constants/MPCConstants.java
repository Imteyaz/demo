package com.dpworld.mpc.camel.cxfrs.constants;

import java.io.Serializable;

public class MPCConstants implements Serializable {
	

  private static final long serialVersionUID = 7413082401062823646L;

  public final static String BPA_ACCESS_TOKEN = "BPA-ACCESS-TOKEN";
  public final static String VESSEL_ETA_PATH = "/cxf/mpc/vessel/vesselListETAs";

  public final static String STATUS_PLANNED = "PLANNED";
  public final static String STATUS_UNPLANNED = "UNPLANNED";
  public final static String STATUS_BERTHED = "Berthed";

  public static final String APP_CONFIG_FILE = "file:etc/mpc-config.properties";
  public static final String CBBS_ACCESS_KEY = "CBBSAccessKey";
  public static final String SYSTEM_MPC = "MPC";
  // Constants for SLA/NON SLA
  public static final String STATUS_SLA = "SLA";
  public static final String STATUS_NONSLA = "NONSLA";
  public static final String SLA_FLAG = "Y";
  public static final String ZERO = "0";
  
  public static final String DATE_FORMAT_VSL_LOC_TBL = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  public static final String DATE_TIME_FORMAT_DEFAULT = "dd-MMM-yyyy HH:mm";
  public static final String DATE_TIME_FORMAT_AIS = "dd/MM/yyyy HH:mm";
  

  
  
  
	public static final String PAGE_MAP_DISPLAY = "map_disply";
	public static final String PAGE_WORKORDER_LIST = "worklist_disply";
	public static final String PAGE_VESSEL_LIST = "vessel_list";
	public static final String PAGE_DASHBOARD_DISPLAY = "dashboard_disply";
	public static final String MPC_FUSE_URL = "fuseurl";
	// MPC constants for purging tables.
	public static final String MPC_INT_VSL_PLAN = "MPC_INT_VSL_PLAN";
	public static final String MPC_VSL_LOCS = "MPC_VSL_LOCS";
	public static final String MPC_INT_VSL = "MPC_INT_VSL";
	public static final String MPC_INT_VSL_QC = "MPC_INT_VSL_QC";
	public static final String MPC_GEOFENCE_DATA = "MPC_GEOFENCE_DATA";

	// MPC Phase 2 Constants
	public static final String PAGE_MPC_SCORE_LIST = "maintain_score";
	public static final String PAGE_SysParam = "sysParam_list";
	public static final String ACTIVE = "Active";
	public static final String INACTIVE = "Inactive";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String ANCHORAGE_COORDINATE_ONE ="ACH1";
	  public static final String ANCHORAGE_COORDINATE_TWO ="ACH2";
	  public static final String ANCHORAGE_COORDINATE_THREE ="ACH3";
	  public static final String ANCHORAGE_COORDINATE_FOUR ="ACH4";
	  public static final String ANCHORAGE="ANCHOR";
	  public static final String BREAK_WATER="BREAK WATER";
	  public static final String PILOT_STATION_1="P_S_ONE";
	  public static final String PILOT_STATION_2="P_S_TWO";
	  public static final String TWO_HOURS="2HRS";
	  public static final String FOUR_HOURS="4HRS";
	  public static final String SIX_HOURS="6HRS";
	  public static final String EIGHT_HOURS="8HRS";
	  public static final String HIGH_SEA="HIGH SEA";
	  public static final String BREAK_WATER_TWO="B_W_2";
	  public static final String BREAK_WATER_ONE="B_W_1";
	  public static final String EMPTY_STRING = "";
	  public static final String DATE_TIME_FORMAT = "dd/MM/yyyy HH:mm:ss";
	  public static final String SEMICOLON =";";
	  public static final String OPERATING = "OPERATING";
	  public static final String COMPLETED = "COMPLETED";
	  public static final String SAILING = "SAILING";
	  public static final String SHIFTING = "SHIFTING";
	  public static final String INCOMING = "INCOMING";
	  public static final String DIRECT = "DIRECT";
		// Web Service URL
		public static final String CODE_WS_URL = "codewsurl";
		public static final String VESSEL_TYPE = "VESSEL%20TYPE";
		public static final String SERVICE_TYPE = "SERVICE%20TYPE";
		
		// Vessel List/ Work List Filter
		public static final String VESSEL_STATUS = "VESSEL_STATUS";
		public static final String TERMINAL = "TERMINAL";
		public static final String GEOFENCE_CODE = "GF_CODE";
		public static final String DUAL_CALL = "DUAL_CALL";
		
		public static final String SOURCE_SYS = "MPC";
		
	    public static final String PAGE_GEOFENCE_MASTER = "manage_geofence_master";
		public static final String PAGE_GEOFENCE_VIEW = "geofence_view";
		//For MPC MAP VIEW
		public static final String TERMINAL1 = "Terminal 1";
		public static final String TERMINAL2 = "Terminal 2";
		public static final String TERMINAL3 = "Terminal 3";
		public static final String T1 = "T1";
		public static final String T2 = "T2";
		public static final String T3 = "T3";
		
		//For MPC PIE CHARTS 
		public static final String TWOHR = "2HRS";
		public static final String FOURHR = "4HRS";
		public static final String SIXHR = "6HRS";
		public static final String EIGHTHR = "8HRS";
		public static final String HIGHSEA = "HIGH SEA";
		public static final String BERTHED = "BERTHED";
		public static final String ANCHOR = "ANCHORAGE";
		public static final String BASIN = "BASIN";
  


}
