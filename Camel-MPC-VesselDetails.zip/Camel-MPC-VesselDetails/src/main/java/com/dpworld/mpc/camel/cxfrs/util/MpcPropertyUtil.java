/**
 * 
 */
package com.dpworld.mpc.camel.cxfrs.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;


/**
 * @author Srinivas.Mandadi
 * 
 */
public final class MpcPropertyUtil {

  private static Logger logger = LoggerFactory.getLogger(MpcPropertyUtil.class);


  private MpcPropertyUtil() {
    // No Object to be created my any party
  }

  public static String getPropertyFromConfiguration(String key) {
    Properties prop = new Properties();
    InputStream input = null;
    Resource resource = null;
    try {
      resource = new UrlResource(MPCConstants.APP_CONFIG_FILE);
      input = resource.getInputStream();
      if (input == null) {
        throw new IllegalStateException("No Configuration Find");
      }
      if (key == null || "".equals(key)) {
        throw new IllegalArgumentException("Invalid source system");
      }
      prop.load(input);
      return (String) prop.get(key);
    } catch (IOException ex) {
      logger.error(ex.getMessage(), ex);
      throw new IllegalStateException("No Configuration Find");
    } finally {
      if (input != null) {
        try {
          input.close();
        } catch (IOException e) {
          logger.error(e.getMessage(), e);
        }
      }
    }
  }


}
