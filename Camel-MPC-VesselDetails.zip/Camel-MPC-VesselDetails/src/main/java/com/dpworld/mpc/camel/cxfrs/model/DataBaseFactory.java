package com.dpworld.mpc.camel.cxfrs.model;

import java.io.IOException;
import java.io.Serializable;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dpworld.mpc.camel.cxfrs.service.helper.PromisBPAServiceHelper;

public class DataBaseFactory implements Serializable {

  private static final long serialVersionUID = -7097951485549638099L;
  
  private static Logger log = LoggerFactory.getLogger(DataBaseFactory.class);

  private SqlSessionFactory factoryCbbsCAM,factoryPromis,factoryPromisUm,factoryPromisD, factoryMPC, factoryBPA, factoryBPA2MPC = null;

  public final static String DB_CBBSCAM = "CBBS_CAMDB";
  public final static String DB_PROMIS = "PromisDB";
  public final static String DB_PROMIS_UM = "PromisDBUm";
  public final static String DB_BPA = "BPADB";
  public final static String DB_MPC = "MPCDB";
  public final static String BPA2_MPC = "BPA2MPC";
  public final static String DB_PROMISD = "PromisD";

  private static DataBaseFactory dataBaseFactory;

  /**
   * Singleton Class
   * 
   * @throws IOException
   * @author Itpeople.Muthukumar
   */
  private DataBaseFactory() throws IOException {
	  factoryCbbsCAM = new SqlSessionFactoryBuilder().build(
		        Resources.getResourceAsReader("SqlMapConfig.xml"), DB_CBBSCAM);
    factoryPromis = new SqlSessionFactoryBuilder().build(
        Resources.getResourceAsReader("SqlMapConfig.xml"), DB_PROMIS);
    factoryPromisUm = new SqlSessionFactoryBuilder().build(
            Resources.getResourceAsReader("SqlMapConfig.xml"), DB_PROMIS_UM);
    factoryPromisD = new SqlSessionFactoryBuilder().build(
            Resources.getResourceAsReader("SqlMapConfig.xml"), DB_PROMISD);
    factoryMPC = new SqlSessionFactoryBuilder().build(
        Resources.getResourceAsReader("SqlMapConfig.xml"), DB_MPC);
    factoryBPA = new SqlSessionFactoryBuilder().build(
        Resources.getResourceAsReader("SqlMapConfig.xml"), DB_BPA);
    factoryBPA2MPC = new SqlSessionFactoryBuilder().build(
            Resources.getResourceAsReader("SqlMapConfig.xml"), BPA2_MPC);
    
  }
  

  /**
   * Object creation from the outside classes.
   * 
   * @return
   * @throws IOException
   * @author Itpeople.Muthukumar
   */
  public static DataBaseFactory getInstance() throws IOException {
    if (dataBaseFactory == null) {
      dataBaseFactory = new DataBaseFactory();
    }
    return dataBaseFactory;
  }

  /**
   * Providing the session based on the databaseName parameter.
   * 
   * @param databaseName
   * @return
   * @author Itpeople.Muthukumar
   */
  public SqlSession getSession(String databaseName) {
    if (DB_PROMIS.equalsIgnoreCase(databaseName)) {
      return factoryPromis.openSession();

    }else if (DB_PROMIS_UM.equalsIgnoreCase(databaseName)) {
        return factoryPromisUm.openSession();

      }else if (DB_PROMISD.equalsIgnoreCase(databaseName)) {
          return factoryPromisD.openSession();

        } 
    else if (DB_BPA.equalsIgnoreCase(databaseName)) {
      return factoryBPA.openSession();

    } else if (DB_MPC.equalsIgnoreCase(databaseName)) {
      return factoryMPC.openSession();
    } else if(BPA2_MPC.equalsIgnoreCase(databaseName)){
    	return factoryBPA2MPC.openSession();
    }
    else if(DB_CBBSCAM.equalsIgnoreCase(databaseName)){
    	return factoryCbbsCAM.openSession();
    }
    else {
      return null;
    }

  }

  /**
   * Provides the Promis database
   * 
   * @author Itpeople.Muthukumar
   * @return
   */
  public SqlSession getSessionForcbbsCam() {
    return factoryCbbsCAM.openSession();
  }
  public SqlSession getSessionForPromis() {
	    return factoryPromis.openSession();
	  }
  public SqlSession getSessionForPromisUm() {
	    return factoryPromisUm.openSession();
	  }
  public SqlSession getSessionForPromisD() {
	    return factoryPromisD.openSession();
	  }
  /**
   * Provides the BPA Database
   * 
   * @return
   */
  public SqlSession getSessionForBPA() {
    return factoryBPA.openSession();
  }

  /**
   * Provides the MPC Database
   * 
   * @return
   */
  public SqlSession getSessionForMPC() {
    return factoryMPC.openSession();
  }

  public SqlSession getSessionForMPCBPA2() {
	    return factoryBPA2MPC.openSession();
	  }
}
