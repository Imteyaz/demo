package com.dpworld.mpc.camel.cxfrs.util;


import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.ANCHORAGE;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.ANCHORAGE_COORDINATE_FOUR;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.ANCHORAGE_COORDINATE_ONE;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.ANCHORAGE_COORDINATE_THREE;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.ANCHORAGE_COORDINATE_TWO;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.BREAK_WATER;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.BREAK_WATER_ONE;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.BREAK_WATER_TWO;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.EIGHT_HOURS;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.FOUR_HOURS;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.HIGH_SEA;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.PILOT_STATION_1;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.PILOT_STATION_2;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.SIX_HOURS;
import static com.dpworld.mpc.camel.cxfrs.constants.MPCConstants.TWO_HOURS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;
import com.dpworld.mpc.camel.cxfrs.model.PromisBPADetail;
/**
 * @author Sapcle.Srinivas
 *
 */
public class VesselDataCalcHelper {

	private static final Logger logger = LoggerFactory
			.getLogger(VesselDataCalcHelper.class);



	public enum VesselStatus {
		BERTHED("BERTHED"), OPERATING("OPERATING"), COMPLETED("COMPLETED"), SHIFTING(
				"SHIFTING"), INCOMING("INCOMING"), ANCHORAGE("ANCHORAGE"), SAILING(
				"SAILING");

		private String value;

		VesselStatus(final String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

		@Override
		public String toString() {
			return this.getValue();
		}
	}

	/**
	 * @param vesselDetailsDTO
	 * @return
	 */
	public String computeVesselStatus(PromisBPADetail vesselDetailsDTO) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm");

		Date date = new Date();
		Date berthTime = null;
		try {
			if (vesselDetailsDTO.getBerthDate() != null)
				berthTime = sdf.parse(vesselDetailsDTO.getBerthDate());
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		String sailDate = vesselDetailsDTO.getSailDate();
		String dualcall = vesselDetailsDTO.getDualBerth();
		String status = null;
		Date etcDateFromDB = null;
		String expectedTimeOfComplete = null;
		Long movesToGo = null;
		Long doneMoves = null;
		
		if (sailDate != null) {
			status = VesselStatus.SAILING.getValue();
			return status;
		}

		if (berthTime != null) {
			// status = VesselStatus.BERTHED.getValue();
			if(vesselDetailsDTO.getTtMTG() ==null)
				movesToGo=0L;
			else
				movesToGo = vesselDetailsDTO.getTtMTG();
			
			if(vesselDetailsDTO.getDoneMoves()==null)
				  doneMoves=0L;
			else
				doneMoves = vesselDetailsDTO.getDoneMoves();
			if (vesselDetailsDTO.getEtc() != null) {
				expectedTimeOfComplete = vesselDetailsDTO.getEtc();
			}
			try {
				if (expectedTimeOfComplete != null)
					etcDateFromDB = (Date) sdf.parse(expectedTimeOfComplete);
			} catch (ParseException e) {
				e.printStackTrace();
			}

			if (doneMoves != null && movesToGo != null && doneMoves > 0
					&& movesToGo > 0) {
				status = VesselStatus.OPERATING.getValue();
				return status;
			}

			if (dualcall != null && dualcall == "Y" && movesToGo != null
					&& movesToGo < 1) {
				status = VesselStatus.SHIFTING.getValue();
				return status;
			}

			if (movesToGo != null
					&& movesToGo < 1
					|| (etcDateFromDB != null && etcDateFromDB.compareTo(date) < 0)) {
				status = VesselStatus.COMPLETED.getValue();
				return status;
			}

			if ( doneMoves < 1) {
				status = VesselStatus.BERTHED.getValue();
				return status;
			}
			 

		}
		if (berthTime == null && sailDate == null) {
			status = VesselStatus.INCOMING.getValue();
			return status;
		}
		if (status == null)
			status = VesselStatus.INCOMING.getValue();
		return status;
	}

	/**
	 * @param status
	 * @return
	 */
	public String returnStatus(String status) {
		return status;
	}

	/**
	 * @param geofenceMasterData
	 * @param vesslatitude
	 * @param vessLongitude
	 * @return
	 */
	public static String getVesselGeoLocation(
			 List<GeoFenceData> geofenceMasterData,
			Double vesslatitude, Double vessLongitude) {


		String[] geoCodeArray = { TWO_HOURS, FOUR_HOURS, SIX_HOURS,
				EIGHT_HOURS, PILOT_STATION_1, PILOT_STATION_2, BREAK_WATER_ONE,
				BREAK_WATER_TWO, ANCHORAGE_COORDINATE_ONE,
				ANCHORAGE_COORDINATE_TWO, ANCHORAGE_COORDINATE_THREE,
				ANCHORAGE_COORDINATE_FOUR };

		for (GeoFenceData data : geofenceMasterData) {
			if (Arrays.asList(geoCodeArray).contains(data.getGeoCode())) {
				Double distance = VesselLocationCalculator.computeGeoDistance(
						data.getLat(), data.getLng(), vesslatitude,
						vessLongitude);
				if (distance >= 80)
					return HIGH_SEA;
				if (distance < 80 && distance > 60)
					return EIGHT_HOURS;
				if (distance <= 60 && distance > 40)
					return SIX_HOURS;
				if (distance <= 40 && distance > 20)
					return FOUR_HOURS;
				if (distance <= 20 && distance > 4.3)
					return TWO_HOURS;
				if (VesselLocationCalculator.isVesselExistInAnchorage(
						geofenceMasterData, vesslatitude, vessLongitude))
					return MPCConstants.ANCHOR;
				if (VesselLocationCalculator.isVesselExistInBreakWater(
						geofenceMasterData, vesslatitude, vessLongitude))
					return BREAK_WATER;
				if (distance <= 1.5)
					return PILOT_STATION_1;
				if (distance <= 4.3)
					return PILOT_STATION_2;

			}
		}
		return null;
	}



}
