/**
 * @copyright 2014 DP World. All rights reserved.
 * @Description Date Utils
 * @author    <i>Srinivas mandadi</i>
 * @version 1.0
 *
 */
package com.dpworld.mpc.camel.cxfrs.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.springframework.util.StringUtils;

import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;

public class DateUtilities {

  private static final String DATE_FORMAT = "dd-MM-yyyy";
  private static final String DATETIME_FORMAT = "dd-MM-yyyy HH:mm";
  private static final String TIME_FORMAT = "HH:mm";
  public static final String DATETIME_FORMAT1 = "dd-MMM-yy HH:mm";
  public static final String DATETIME_FORMAT_DD_MMM_YYYY_HH_MM = "dd-MMM-yyyy HH:mm";
  
  
  private DateUtilities() {
    
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Date getFirstHour(Date date) {
    if (date == null) {
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();

    calendar.setTime(date);
    calendar.set(Calendar.HOUR, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param hour
   * @return
   */
  public static Date setHour(Date date, int hour) {
    if (date == null) {
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();

    calendar.setTime(date);
    calendar.set(Calendar.HOUR, hour);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Date getLastHour(Date date) {
    if (date == null) {
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.HOUR, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param hours
   * @return
   */
  public static Date addHoursToDate(Date date, Integer hours) {
    if (date == null) {
      return null;
    } 
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, hours);
    return calendar.getTime();
  }
  
  public static Date convertUtilDateToMPCFormat(Date date) throws ParseException{
	    SimpleDateFormat sdf = new SimpleDateFormat(DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		  if(StringUtils.isEmpty(date)){
		      return null;
		    }
		    return sdf.parse(sdf.format(date));
		  }

  /**
   * 
   * @param date
   * @param days
   * @return
   */
  public static Date addDaysToDate(Date date, Integer days) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, days * 24);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Integer getHoursFromDate(Date date) {
    if (date == null){
      return null;
    }
    SimpleDateFormat sdf = new SimpleDateFormat("H");
    return Integer.valueOf(sdf.format(date));
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Integer getMinutesFromDate(Date date) {
    if (date == null){
      return null;
    }
    SimpleDateFormat sdf = new SimpleDateFormat("mm");
    return Integer.valueOf(sdf.format(date));
  }

  /**
   * 
   * @param date
   * @param hours
   * @param minutes
   * @return
   */
  public static Date addHoursAndMinutesToDate(Date date, Integer hours, Integer minutes) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, hours);
    calendar.add(Calendar.MINUTE, minutes);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param hours
   * @return
   */
  public static Date subtractHoursFromDate(Date date, Integer hours) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, -1 * hours);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param months
   * @return
   */
  public static Date subtractMonths(Date date, Integer months) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, -1 * months * 30 * 24);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param days
   * @return
   */
  public static Date subtractDays(Date date, Integer days) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.DATE, -1 * days);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param minutes
   * @return
   */
  public static Date subtractMinutesFromDate(Date date, Integer minutes) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.MINUTE, -1 * minutes);
    return calendar.getTime();
  }

  /**
   * 
   * @param date
   * @param hours
   * @param minutes
   * @return
   */
  public static Date subtractHoursAndMinutesFromDate(Date date, Integer hours, Integer minutes) {
    if (date == null){
      return null;
    }
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR, -1 * hours);
    calendar.add(Calendar.MINUTE, -1 * minutes);
    return calendar.getTime();
  }

  /**
   * 
   * @param firstDate
   * @param secondDate
   * @return
   */
  public static double daysBetween2Dates(Date firstDate, Date secondDate) {
    Calendar c1 = GregorianCalendar.getInstance();
    Calendar c2 = GregorianCalendar.getInstance();
    if(firstDate != null && secondDate != null){
      c1.setTime(firstDate);
      c2.setTime(secondDate);
      return (double) (c2.getTime().getTime() - c1.getTime().getTime()) / (24 * 3600 * 1000);
    }
    return 0;
  }

  /**
   * 
   * @param firstDate
   * @param secondDate
   * @return
   */
  public static double hoursBetween2Dates(Date firstDate, Date secondDate) {
    Calendar c1 = GregorianCalendar.getInstance();
    Calendar c2 = GregorianCalendar.getInstance();
    c1.setTime(firstDate);
    c2.setTime(secondDate);
    return (double) (c2.getTime().getTime() - c1.getTime().getTime()) / (3600 * 1000);
  }

  /**
   * 
   * @param firstDate
   * @param secondDate
   * @return
   */
  public static double minutesBetween2Dates(Date firstDate, Date secondDate) {
    Calendar c1 = GregorianCalendar.getInstance();
    Calendar c2 = GregorianCalendar.getInstance();
    c1.setTime(firstDate);
    c2.setTime(secondDate);
    return (double) (c2.getTime().getTime() - c1.getTime().getTime()) / (60 * 1000);
  }

  /**
   * 
   * @param date
   * @return
   */
  public static int daysInMonth(Date date) {
    Calendar c1 = GregorianCalendar.getInstance();
    c1.setTime(date);
    int year = c1.get(Calendar.YEAR);
    int[] daysInMonths = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    daysInMonths[1] += DateUtilities.isLeapYear(year) ? 1 : 0;
    return daysInMonths[c1.get(Calendar.MONTH)];
  }

  /**
   * 
   * @param year
   * @return
   */
  public static boolean isLeapYear(int year) {
    if ((year % 100 != 0) || (year % 400 == 0)) {
      return true;
    }
    return false;
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Date parseDate(String date) {
    return parseDate(date, DATE_FORMAT);
  }

  /**
   * 
   * @param date
   * @return
   */
  public static Date parseTime(String date) {
    return parseDate(date, DATETIME_FORMAT);
  }

  /**
   * 
   * @param date
   * @param pattern
   * @return
   */
  public static Date parseDate(String date, String pattern) {
    SimpleDateFormat parser = new SimpleDateFormat(pattern);
    parser.setLenient(false);
    try {

      return parser.parse(date);
    } catch (ParseException e) {
      throw new IllegalArgumentException(e);

    }
  }

  /**
   * 
   * @param date
   * @param pattern
   * @return
   */
  public static String formatDate(Date date, String pattern) {
    if (date == null){
      return null;
    }
    SimpleDateFormat parser = new SimpleDateFormat(pattern);
    parser.setLenient(false);
    return parser.format(date);
  }

  /**
   * 
   * @param date
   * @return
   */
  public static String formatDate(Date date) {
    if (date == null){
      return null;
    }
    SimpleDateFormat parser = new SimpleDateFormat(DATETIME_FORMAT);
    parser.setLenient(false);
    return parser.format(date);
  }

  /**
   * 
   * @param date
   * @return
   */
  public static String formatTime(Date date) {
    if (date == null){
      return null;
    }
    SimpleDateFormat parser = new SimpleDateFormat(TIME_FORMAT);
    parser.setLenient(false);
    return parser.format(date);
  }

  /**
   * 
   * @param date
   * @param firstDate
   * @param secondDate
   * @return
   */
  public static boolean isBetweenDates(Date date, Date firstDate, Date secondDate) {
    if (date == null){
      return false;
    }
    return firstDate.equals(date) || secondDate.equals(date) || (firstDate.before(date) && secondDate.after(date));
  }

  /**
   * 
   * @param date
   * @param minutes
   * @return
   */
  public static Date setMinutes(Date date, Integer minutes) {
    Calendar calendar = GregorianCalendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.MINUTE, minutes);
    return calendar.getTime();
  }

  /**
   * 
   * @param firstDate
   * @return
   */
  public static Date getNextDate(Date firstDate) {

    Calendar cal = GregorianCalendar.getInstance();
    cal.setTime(firstDate);
    cal.add(Calendar.DAY_OF_MONTH, 1);
    return cal.getTime();
  }

  /**
   * 
   * @param firstDate
   * @return
   */
  public static Date getNextDate(String firstDate) {
    Date d1 = parseDate(firstDate);
    Calendar cal = GregorianCalendar.getInstance();
    cal.setTime(d1);
    cal.add(Calendar.DAY_OF_MONTH, 1);
    return cal.getTime();
  }

  /**
   * 
   * @param fromDate
   * @param toDate
   * @return
   */
  public static Date[] getAllDates(String fromDate, String toDate) {

    Date d1 = parseDate(fromDate);
    Date d2 = parseDate(toDate);


    int length = (int) (daysBetween2Dates(d1, d2)) + 1;
    Date[] dateArray = new Date[length];

    Date currentDate = d1;
    dateArray[0] = d1;
    for (int i = 1; i < length; i++) {
      currentDate = getNextDate(currentDate);
      dateArray[i] = currentDate;
    }
    return dateArray;
  }

  /**
   * Compares two dates. If date1 is before date2 it return -1. if date1 is
   * after date2 it return 1. If date1 is equal to date2 it will return 0.
   * 
   * @param date1 first date
   * @param date2 second date
   * @return int values (1, 0, -1)
   */
  public static int compare(Date firstDate, Date secondDate) {
    if(firstDate == null && secondDate == null){
      return 0;
    }else if(firstDate == null || secondDate == null){
      return -1;
    }
    
    Calendar c1 = GregorianCalendar.getInstance();
    Calendar c2 = GregorianCalendar.getInstance();
    c1.setTime(firstDate);
    c2.setTime(secondDate);
    return c1.compareTo(c2);
  }

  /**
   * Returns current date as per application default format
   * 
   * @return date current date.
   */
  public static Date getCurrentDate() {
    Calendar c1 = GregorianCalendar.getInstance();
    Date dateType = c1.getTime();
    return DateUtilities.parseDate(DateUtilities.formatDate(dateType), DATE_FORMAT);
  }

  /**
   * Returns Month of the date
   * 
   * @param date Date
   * @return date
   */
  public static int getMonth(Date date) {
    Calendar cal = GregorianCalendar.getInstance();
    cal.setTime(date);
    return cal.get(Calendar.MONTH);
  }

  /**
   * Returns the year
   * 
   * @param date Date
   * @return date
   */
  public static int getYear(Date date) {
    Calendar cal = GregorianCalendar.getInstance();
    cal.setTime(date);
    return cal.get(Calendar.YEAR);
  }

  /**
   * Returns Next Month start date from given date.
   * 
   * @param date Date
   * @return Date
   */
  public static Date getNextMonthStartDate(Date date) {
    Calendar cal = GregorianCalendar.getInstance();
    cal.setTime(date);
    cal.add(Calendar.MONTH, 1);
    cal.set(Calendar.DATE, 1);
    cal.set(Calendar.HOUR, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    return cal.getTime();
  }

  /**
   * Get date part only by truncating time
   * 
   * @param date Date
   * @return Date without time.
   */
  public static Date getDateOnly(Date date) {
    if (date == null){
      return null;
    }
    String strDate = DateUtilities.formatDate(date, DATE_FORMAT);
    return DateUtilities.parseDate(strDate, DATE_FORMAT);
  }

  /**
   * Getting the max date from two dates.
   * 
   * @param date1 Date
   * @param date2 Date
   * @return Date max date
   */
  public static Date getMaxDate(Date date1, Date date2) {
    if (date1 != null && date2 != null) {
      if (compare(date1, date2) > 0) {
        return date1;
      } else{
        return date2;
      } 
    } else if (date2 != null) {
      return date2;
    }
    return date1;
  }
  
  /**
   * 
   * @param date
   * @return
   */
  public static String convertDateFormat(String date,String sourceFormat,String destinationFormat){
    if(StringUtils.isEmpty(date)){
      return date;
    }
    return formatDate(parseDate(date, sourceFormat),destinationFormat); 
  }
  
}
