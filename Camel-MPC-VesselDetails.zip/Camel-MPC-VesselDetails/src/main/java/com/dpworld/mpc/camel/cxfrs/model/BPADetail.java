package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.Date;

public class BPADetail implements Serializable {

  private static final long serialVersionUID = -4705674028463143428L;

  private String rotationNumber;
  private String berthPosition;
  private String fromBollard;
  private String toBollard;
  private String terminal;
  private String portCode;

  private Long ttMTG;
  private Long qcAlloc;
  private Long qcWorking;
  private Long hhMTG;
  private String hhCrane;

  private String qc;
  private Long movesToGo;
  private Long planMoves;
  private Long doneMoves;
  private String etc;
  private Date etcDateObject;
  private Long qcPty;

  private String sourceSystem;

  private String moveKind;
  private String messageType;

  private String pointOfWork;
  private String quay;
  private String vesselName;
  private String remarks;
  private String dropDownLocation;
  private String visitrecordId;
  private String IS_SLA;
  private String berthedFrom;
  public String getIS_SLA() {
	return IS_SLA;
}

public void setIS_SLA(String iS_SLA) {
	IS_SLA = iS_SLA;
}


  public String getVisitrecordId() {
	return visitrecordId;
}

public void setVisitrecordId(String visitrecordId) {
	this.visitrecordId = visitrecordId;
}




  public String getRemarks() {
    return remarks;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }

  public String getRotationNumber() {
    return rotationNumber;
  }

  public void setRotationNumber(String rotationNumber) {
    this.rotationNumber = rotationNumber;
  }

  public String getBerthPosition() {
    return berthPosition;
  }

  public void setBerthPosition(String berthPosition) {
    this.berthPosition = berthPosition;
  }

  public String getFromBollard() {
    return fromBollard;
  }

  public void setFromBollard(String fromBollard) {
    this.fromBollard = fromBollard;
  }

  public String getToBollard() {
    return toBollard;
  }

  public void setToBollard(String toBollard) {
    this.toBollard = toBollard;
  }

  public String getTerminal() {
    return terminal;
  }

  public void setTerminal(String terminal) {
    this.terminal = terminal;
  }

  public String getPortCode() {
    return portCode;
  }

  public void setPortCode(String portCode) {
    this.portCode = portCode;
  }

  public String getHhCrane() {
    return hhCrane;
  }

  public String getQc() {
    return qc;
  }

  public void setQc(String qc) {
    this.qc = qc;
  }

  public void setHhCrane(String hhCrane) {
    this.hhCrane = hhCrane;
  }

  public Long getMovesToGo() {
    return movesToGo;
  }

  public void setMovesToGo(Long movesToGo) {
    this.movesToGo = movesToGo;
  }

  public Long getPlanMoves() {
    return planMoves;
  }

  public void setPlanMoves(Long planMoves) {
    this.planMoves = planMoves;
  }

  public Long getDoneMoves() {
    return doneMoves;
  }

  public void setDoneMoves(Long doneMoves) {
    this.doneMoves = doneMoves;
  }

  public Long getQcAlloc() {
    return qcAlloc;
  }

  public void setQcAlloc(Long qcAlloc) {
    this.qcAlloc = qcAlloc;
  }

  public Long getQcWorking() {
    return qcWorking;
  }

  public void setQcWorking(Long qcWorking) {
    this.qcWorking = qcWorking;
  }

  public Long getTtMTG() {
    return ttMTG;
  }

  public void setTtMTG(Long ttMTG) {
    this.ttMTG = ttMTG;
  }

  public Long getHhMTG() {
    return hhMTG;
  }

  public void setHhMTG(Long hhMTG) {
    this.hhMTG = hhMTG;
  }

  public String getEtc() {
    return etc;
  }

  public void setEtc(String etc) {
    this.etc = etc;
  }

  public Long getQcPty() {
    return qcPty;
  }

  public void setQcPty(Long qcPty) {
    this.qcPty = qcPty;
  }

  public String getMoveKind() {
    return moveKind;
  }

  public void setMoveKind(String moveKind) {
    this.moveKind = moveKind;
  }

  public String getMessageType() {
    return messageType;
  }

  public void setMessageType(String messageType) {
    this.messageType = messageType;
  }

  public String getPointOfWork() {
    return pointOfWork;
  }

  public void setPointOfWork(String pointOfWork) {
    this.pointOfWork = pointOfWork;
  }

  public String getQuay() {
    return quay;
  }

  public void setQuay(String quay) {
    this.quay = quay;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public Date getEtcDateObject() {
    return etcDateObject;
  }

  public void setEtcDateObject(Date etcDateObject) {
    this.etcDateObject = etcDateObject;
  }


  public String getDropDownLocation() {
    return dropDownLocation;
  }

  public void setDropDownLocation(String dropDownLocation) {
    this.dropDownLocation = dropDownLocation;
  }
  public String getBerthedFrom() {
		return berthedFrom;
	}

	public void setBerthedFrom(String berthedFrom) {
		this.berthedFrom = berthedFrom;
	}
  @Override
public String toString() {
	return "BPADetail [rotationNumber=" + rotationNumber + ", berthPosition=" + berthPosition + ", fromBollard="
			+ fromBollard + ", toBollard=" + toBollard + ", terminal=" + terminal + ", portCode=" + portCode
			+ ", ttMTG=" + ttMTG + ", qcAlloc=" + qcAlloc + ", qcWorking=" + qcWorking + ", hhMTG=" + hhMTG
			+ ", hhCrane=" + hhCrane + ", qc=" + qc + ", movesToGo=" + movesToGo + ", planMoves=" + planMoves
			+ ", doneMoves=" + doneMoves + ", etc=" + etc + ", etcDateObject=" + etcDateObject + ", qcPty=" + qcPty
			+ ", sourceSystem=" + sourceSystem + ", moveKind=" + moveKind + ", messageType=" + messageType
			+ ", pointOfWork=" + pointOfWork + ", quay=" + quay + ", vesselName=" + vesselName + ", remarks=" + remarks
			+ ", dropDownLocation=" + dropDownLocation + ", visitrecordId=" + visitrecordId + ", IS_SLA=" + IS_SLA
			+ ", berthedFrom=" + berthedFrom + "]";
}




}
