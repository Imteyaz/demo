/**
 * 
 */
package com.dpworld.mpc.camel.cxfrs.service.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dpworld.mpc.camel.cxfrs.model.PromisBPADetail;


public class PromiseBPAServiceTask {

	public enum TaskCompletionStatus  {RUNNING,SUCCEEDED,FAILED,CANCELLED,PAUSED}
	
	private PromisBPADetail promisBPADetailObject;

        private List<PromisBPADetail> promisBPADetailObjectList = new ArrayList<PromisBPADetail>();
	
        private volatile TaskCompletionStatus taskStatus;
	
	private long totalTimeInMillis = 0;
	
	private Object lock = new Object();
	
	private static Logger log = LoggerFactory.getLogger(PromiseBPAServiceTask.class); 
	       
        public List<PromisBPADetail> getPromisBPADetailObjectList() {
          return promisBPADetailObjectList;
        }

        public void setPromisBPADetailObjectList(List<PromisBPADetail> promisBPADetailObjectList) {
          this.promisBPADetailObjectList = promisBPADetailObjectList;
        }

        
	  public PromisBPADetail getPromisBPADetailObject() {
	    return promisBPADetailObject;
	  }

	  
	  public void setPromisBPADetailObject(PromisBPADetail promisBPADetailObject) {
	    this.promisBPADetailObject = promisBPADetailObject;
	  }
	
	/**
	 * @return the taskStatus
	 */
	public TaskCompletionStatus getTaskStatus() {
		return taskStatus;
	}

	/**
	 * @param taskStatus the taskStatus to set
	 */
	public void setTaskStatus(TaskCompletionStatus taskStatus) {
		this.taskStatus = taskStatus;
	}

	/**
	 * @return the totalTimeInMillis
	 */
	public long getTotalTimeInMillis() {
		return totalTimeInMillis;
	}

	/**
	 * @param totalTimeInMillis the totalTimeInMillis to set
	 */
	public void setTotalTimeInMillis(long totalTimeInMillis) {
		this.totalTimeInMillis = totalTimeInMillis;
	}

	/**
	 * @return the continueTask
	 */
	public boolean isContinueTask() {
		if(TaskCompletionStatus.RUNNING == taskStatus){
			return true;
		}
		return false;
	}

	/**
	 * @return the endTask
	 */
	public boolean isEndTask() {
		if(TaskCompletionStatus.CANCELLED == taskStatus)
			return true;
		return false;
	}
	
	public void resumeTask(){
		if (log.isDebugEnabled()) {
			log.debug( "Resuming Signal recevied..setting the flag to true"
					);
		}

		// if the task is pasued then resume otherwise ignore
		if(taskStatus == TaskCompletionStatus.PAUSED){
			synchronized(lock){
				taskStatus = TaskCompletionStatus.RUNNING;
			}
			notify();
		}
	}
	
	public void stopTask() {
		if (log.isDebugEnabled()) {
			log.debug( "Received StopTask Signal..resetting flag"
					);
		}
		
		if(taskStatus == TaskCompletionStatus.RUNNING || taskStatus == TaskCompletionStatus.PAUSED){
			synchronized (lock) {
				taskStatus = TaskCompletionStatus.CANCELLED;
			}
		}
		
	}


	public void pauseTask() {
		if (log.isDebugEnabled()) {
			log.debug("Received PauseTask Signal..resetting flag"
					);
		}
		if(taskStatus == TaskCompletionStatus.RUNNING){
			synchronized (lock) {
				taskStatus = TaskCompletionStatus.PAUSED;
			}
		}
	}



}
