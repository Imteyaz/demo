package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.List;

public class FilterCriteria implements Serializable {

  private static final long serialVersionUID = 5466202311142514198L;

  private String rotationNumbers;
  private String terminalId;
  private String vesselName;
  private String imoCode;
  private String pNam;
  private List<String> listRotations;
  private List<String> listTerminals;

  private List<String> vesselList;

  private String vsrc; // Vessel Service Code
  private String veta; // Vessel ETA
  private String scoreAttrVslType;
  private String scoreAttrSrvType;
  private String scoreAttrSlaType;
  private String scoreAttrPrfmType;
  private String scoreAttrCurrStatus;
  private String proforma;
  private String fromSailDate;
  private String toSailDate;
  private String visitId;


  public String getVisitId() {
	return visitId;
}

public void setVisitId(String visitId) {
	this.visitId = visitId;
}

public String getTerminalId() {
    return terminalId;
  }

  public void setTerminalId(String terminalId) {
    this.terminalId = terminalId;
  }

  public String getRotationNumbers() {
    return rotationNumbers;
  }

  public void setRotationNumbers(String rotationNumbers) {
    this.rotationNumbers = rotationNumbers;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoCode() {
    return imoCode;
  }

  public void setImoCode(String imoCode) {
    this.imoCode = imoCode;
  }

  public String getpNam() {
    return pNam;
  }

  public void setpNam(String pNam) {
    this.pNam = pNam;
  }

  public List<String> getListRotations() {
    return listRotations;
  }

  public void setListRotations(List<String> listRotations) {
    this.listRotations = listRotations;
  }

  public List<String> getListTerminals() {
    return listTerminals;
  }

  public void setListTerminals(List<String> listTerminals) {
    this.listTerminals = listTerminals;
  }

  public List<String> getVesselList() {
    return vesselList;
  }

  public void setVesselList(List<String> vesselList) {
    this.vesselList = vesselList;
  }

  public String getVsrc() {
    return vsrc;
  }

  public void setVsrc(String vsrc) {
    this.vsrc = vsrc;
  }

  public String getVeta() {
    return veta;
  }

  public void setVeta(String veta) {
    this.veta = veta;
  }


  public String getScoreAttrVslType() {
    return scoreAttrVslType;
  }

  public void setScoreAttrVslType(String scoreAttrVslType) {
    this.scoreAttrVslType = scoreAttrVslType;
  }

  public String getScoreAttrSrvType() {
    return scoreAttrSrvType;
  }

  public void setScoreAttrSrvType(String scoreAttrSrvType) {
    this.scoreAttrSrvType = scoreAttrSrvType;
  }

  public String getScoreAttrSlaType() {
    return scoreAttrSlaType;
  }

  public void setScoreAttrSlaType(String scoreAttrSlaType) {
    this.scoreAttrSlaType = scoreAttrSlaType;
  }

  public String getScoreAttrPrfmType() {
    return scoreAttrPrfmType;
  }

  public void setScoreAttrPrfmType(String scoreAttrPrfmType) {
    this.scoreAttrPrfmType = scoreAttrPrfmType;
  }


  public String getScoreAttrCurrStatus() {
    return scoreAttrCurrStatus;
  }

  public void setScoreAttrCurrStatus(String scoreAttrCurrStatus) {
    this.scoreAttrCurrStatus = scoreAttrCurrStatus;
  }

  public String getProforma() {
    return proforma;
  }

  public void setProforma(String proforma) {
    this.proforma = proforma;
  }

  public String getFromSailDate() {
	return fromSailDate;
}

public void setFromSailDate(String fromSailDate) {
	this.fromSailDate = fromSailDate;
}

public String getToSailDate() {
	return toSailDate;
}

public void setToSailDate(String toSailDate) {
	this.toSailDate = toSailDate;
}

@Override
public String toString() {
	return "FilterCriteria [rotationNumbers=" + rotationNumbers
			+ ", terminalId=" + terminalId + ", vesselName=" + vesselName
			+ ", imoCode=" + imoCode + ", pNam=" + pNam + ", listRotations="
			+ listRotations + ", listTerminals=" + listTerminals
			+ ", vesselList=" + vesselList + ", vsrc=" + vsrc + ", veta="
			+ veta + ", scoreAttrVslType=" + scoreAttrVslType
			+ ", scoreAttrSrvType=" + scoreAttrSrvType + ", scoreAttrSlaType="
			+ scoreAttrSlaType + ", scoreAttrPrfmType=" + scoreAttrPrfmType
			+ ", scoreAttrCurrStatus=" + scoreAttrCurrStatus + ", proforma="
			+ proforma + "]";
}

}
