package com.dpworld.mpc.camel.cxfrs.interceptors;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.cxf.helpers.CastUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;
import com.dpworld.mpc.camel.cxfrs.util.MpcPropertyUtil;

public class AuthenticationInterceptor extends AbstractPhaseInterceptor<Message> {

  private static Properties properties = new Properties();

  /**
   * Phase.RECEIVE is right phase to read the headers.
   * 
   * @author Itpeople.Muthukumar
   */
  public AuthenticationInterceptor() {
    super(Phase.RECEIVE);
  }


  /**
   * Handles the message. This method authenticate the user using the header
   * value.
   * 
   * @param message
   * @throws Fault
   * 
   */
  public void handleMessage(Message message) throws Fault {

    String bpaAccessValue = null;

    if (properties != null && properties.contains(MPCConstants.BPA_ACCESS_TOKEN)) {
      bpaAccessValue = properties.getProperty(MPCConstants.BPA_ACCESS_TOKEN);
    } else {
      bpaAccessValue = MpcPropertyUtil.getPropertyFromConfiguration(MPCConstants.BPA_ACCESS_TOKEN);
    }

    if (MPCConstants.VESSEL_ETA_PATH.equalsIgnoreCase(message.get(Message.PATH_INFO).toString())) {

      Map<String, List<String>> headers = CastUtils.cast((Map) message.get(Message.PROTOCOL_HEADERS));

      if (headers != null && headers.containsKey(MPCConstants.BPA_ACCESS_TOKEN)
          && bpaAccessValue != null) {
        List<String> listAuthKey = headers.get(MPCConstants.BPA_ACCESS_TOKEN);
        if (listAuthKey != null && listAuthKey.size() > 0
            && listAuthKey.get(0).trim().equalsIgnoreCase(bpaAccessValue)) {
        } else {
          throw new SecurityException("Authentication Failed.");
        }
      } else {
        throw new SecurityException("Authentication Failed.");
      }
    }
  }

}
