package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.Date;

public class VesselDetail implements Serializable {


  private static final long serialVersionUID = 3514373179146727289L;

  private String vesselName;
  private String imoNumber;
  private String sourceSystem;
  private String cog;
  private String sog;
  private String heading;
  private String altitude;
  private String latitude;
  private String longitude;
  private String lloydsShipType;
  private String length;
  private String width;
  private String callSign;
  private String mmsi;
  private String draught;
  private String eta;
  private String destinationName;
  private Long txnId;
  private Date txnDate;
  private String valid;
  private String calETA;
  private String slaStatus;
 
  private String score;
  


  public String getValid() {
    return valid;
  }

  public void setValid(String valid) {
    this.valid = valid;
  }

  public Long getTxnId() {
    return txnId;
  }

  public void setTxnId(Long txnId) {
    this.txnId = txnId;
  }

  public Date getTxnDate() {
    return txnDate;
  }

  public void setTxnDate(Date txnDate) {
    this.txnDate = txnDate;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoNumber() {
    return imoNumber;
  }

  public void setImoNumber(String imoNumber) {
    this.imoNumber = imoNumber;
  }

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public String getCog() {
    return cog;
  }

  public void setCog(String cog) {
    this.cog = cog;
  }

  public String getSog() {
    return sog;
  }

  public void setSog(String sog) {
    this.sog = sog;
  }

  public String getHeading() {
    return heading;
  }

  public void setHeading(String heading) {
    this.heading = heading;
  }

  public String getAltitude() {
    return altitude;
  }

  public void setAltitude(String altitude) {
    this.altitude = altitude;
  }

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getLloydsShipType() {
    return lloydsShipType;
  }

  public void setLloydsShipType(String lloydsShipType) {
    this.lloydsShipType = lloydsShipType;
  }

  public String getLength() {
    return length;
  }

  public void setLength(String length) {
    this.length = length;
  }

  public String getWidth() {
    return width;
  }

  public void setWidth(String width) {
    this.width = width;
  }

  public String getCallSign() {
    return callSign;
  }

  public void setCallSign(String callSign) {
    this.callSign = callSign;
  }

  public String getMmsi() {
    return mmsi;
  }

  public void setMmsi(String mmsi) {
    this.mmsi = mmsi;
  }

  public String getDraught() {
    return draught;
  }

  public void setDraught(String draught) {
    this.draught = draught;
  }

  public String getEta() {
    return eta;
  }

  public void setEta(String eta) {
    this.eta = eta;
  }

  public String getDestinationName() {
    return destinationName;
  }

  public void setDestinationName(String destinationName) {
    this.destinationName = destinationName;
  }

  public String getCalETA() {
    return calETA;
  }

  public void setCalETA(String calETA) {
    this.calETA = calETA;
  }

  public String getSlaStatus() {
    return slaStatus;
  }

  public void setSlaStatus(String slaStatus) {
    this.slaStatus = slaStatus;
  }

  public String getScore() {
    return score;
  }

  public void setScore(String score) {
    this.score = score;
  }

}
