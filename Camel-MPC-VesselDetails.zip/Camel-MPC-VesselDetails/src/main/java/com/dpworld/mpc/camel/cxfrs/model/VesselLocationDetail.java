package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.Date;

public class VesselLocationDetail implements Serializable {


  private static final long serialVersionUID = 3514373179146727289L;

  private String vesselName;
  private String imoNumber;
  private String sourceSystem;
  private String cog;
  private String sog;
  private String heading;
  private String altitude;
  private String latitude;
  private String longitude;
  private String lloydsShipType;
  private String length;
  private String width;
  private String callSign;
  private String mmsi;
  private String draught;
  private String eta;
  private String destinationName;
  private Long txnId;
  private Date txnDate;
  private String valid;
  private String calETA;
  private String slaStatus;
  private String score;
  
 // ais specific
  private String aisVslOprEta;
  private String aisAvgSpeed;
  private String aisVesselOperator;
  private String aisUpdateTime;
  private String aisEta;
  private String aisPreviousAtd;
  private String aisDistanceToNextPort;
  private String aisNextPort;
  private String aisPrevPort;
  // New Added
  private String aisLocation;
  private String aisError;
  private String source;
  


  public String getValid() {
    return valid;
  }

  public void setValid(String valid) {
    this.valid = valid;
  }

  public Long getTxnId() {
    return txnId;
  }

  public void setTxnId(Long txnId) {
    this.txnId = txnId;
  }

  public Date getTxnDate() {
    return txnDate;
  }

  public void setTxnDate(Date txnDate) {
    this.txnDate = txnDate;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoNumber() {
    return imoNumber;
  }

  public void setImoNumber(String imoNumber) {
    this.imoNumber = imoNumber;
  }

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public String getCog() {
    return cog;
  }

  public void setCog(String cog) {
    this.cog = cog;
  }

  public String getSog() {
    return sog;
  }

  public void setSog(String sog) {
    this.sog = sog;
  }

  public String getHeading() {
    return heading;
  }

  public void setHeading(String heading) {
    this.heading = heading;
  }

  public String getAltitude() {
    return altitude;
  }

  public void setAltitude(String altitude) {
    this.altitude = altitude;
  }

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getLloydsShipType() {
    return lloydsShipType;
  }

  public void setLloydsShipType(String lloydsShipType) {
    this.lloydsShipType = lloydsShipType;
  }

  public String getLength() {
    return length;
  }

  public void setLength(String length) {
    this.length = length;
  }

  public String getWidth() {
    return width;
  }

  public void setWidth(String width) {
    this.width = width;
  }

  public String getCallSign() {
    return callSign;
  }

  public void setCallSign(String callSign) {
    this.callSign = callSign;
  }

  public String getMmsi() {
    return mmsi;
  }

  public void setMmsi(String mmsi) {
    this.mmsi = mmsi;
  }

  public String getDraught() {
    return draught;
  }

  public void setDraught(String draught) {
    this.draught = draught;
  }

  public String getEta() {
    return eta;
  }

  public void setEta(String eta) {
    this.eta = eta;
  }

  public String getDestinationName() {
    return destinationName;
  }

  public void setDestinationName(String destinationName) {
    this.destinationName = destinationName;
  }

  public String getCalETA() {
    return calETA;
  }

  public void setCalETA(String calETA) {
    this.calETA = calETA;
  }

  public String getSlaStatus() {
    return slaStatus;
  }

  public void setSlaStatus(String slaStatus) {
    this.slaStatus = slaStatus;
  }

  public String getScore() {
    return score;
  }

  public void setScore(String score) {
    this.score = score;
  }

public String getAisVslOprEta() {
	return aisVslOprEta;
}

public void setAisVslOprEta(String aisVslOprEta) {
	this.aisVslOprEta = aisVslOprEta;
}

public String getAisAvgSpeed() {
	return aisAvgSpeed;
}

public void setAisAvgSpeed(String aisAvgSpeed) {
	this.aisAvgSpeed = aisAvgSpeed;
}

public String getAisVesselOperator() {
	return aisVesselOperator;
}

public void setAisVesselOperator(String aisVesselOperator) {
	this.aisVesselOperator = aisVesselOperator;
}

public String getAisUpdateTime() {
	return aisUpdateTime;
}

public void setAisUpdateTime(String aisUpdateTime) {
	this.aisUpdateTime = aisUpdateTime;
}

public String getAisEta() {
	return aisEta;
}

public void setAisEta(String aisEta) {
	this.aisEta = aisEta;
}

public String getAisPreviousAtd() {
	return aisPreviousAtd;
}

public void setAisPreviousAtd(String aisPreviousAtd) {
	this.aisPreviousAtd = aisPreviousAtd;
}

public String getAisDistanceToNextPort() {
	return aisDistanceToNextPort;
}

public void setAisDistanceToNextPort(String aisDistanceToNextPort) {
	this.aisDistanceToNextPort = aisDistanceToNextPort;
}

public String getAisNextPort() {
	return aisNextPort;
}

public void setAisNextPort(String aisNextPort) {
	this.aisNextPort = aisNextPort;
}

public String getAisPrevPort() {
	return aisPrevPort;
}

public void setAisPrevPort(String aisPrevPort) {
	this.aisPrevPort = aisPrevPort;
}

public String getAisLocation() {
	return aisLocation;
}

public void setAisLocation(String aisLocation) {
	this.aisLocation = aisLocation;
}

public String getAisError() {
	return aisError;
}

public void setAisError(String aisError) {
	this.aisError = aisError;
}

public String getSource() {
	return source;
}

public void setSource(String source) {
	this.source = source;
}



@Override
public String toString() {
	return "VesselDetail [vesselName=" + vesselName + ", imoNumber="
			+ imoNumber + ", sourceSystem=" + sourceSystem + ", cog=" + cog
			+ ", sog=" + sog + ", heading=" + heading + ", altitude="
			+ altitude + ", latitude=" + latitude + ", longitude=" + longitude
			+ ", lloydsShipType=" + lloydsShipType + ", length=" + length
			+ ", width=" + width + ", callSign=" + callSign + ", mmsi=" + mmsi
			+ ", draught=" + draught + ", eta=" + eta + ", destinationName="
			+ destinationName + ", txnId=" + txnId + ", txnDate=" + txnDate
			+ ", valid=" + valid + ", calETA=" + calETA + ", slaStatus="
			+ slaStatus + ", score=" + score + ", aisVslOprEta=" + aisVslOprEta
			+ ", aisAvgSpeed=" + aisAvgSpeed + ", aisVesselOperator="
			+ aisVesselOperator + ", aisUpdateTime=" + aisUpdateTime
			+ ", aisEta=" + aisEta + ", aisPreviousAtd=" + aisPreviousAtd
			+ ", aisDistanceToNextPort=" + aisDistanceToNextPort
			+ ", aisNextPort=" + aisNextPort + ", aisPrevPort=" + aisPrevPort
			+ ", aisLocation=" + aisLocation + ", aisError=" + aisError + "]";
}



}
