package com.dpworld.mpc.camel.cxfrs.service;

import java.util.Collection;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.dpworld.mpc.camel.cxfrs.model.BPADetail;
import com.dpworld.mpc.camel.cxfrs.model.CbbsDetails;
import com.dpworld.mpc.camel.cxfrs.model.PromisBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.PromisTwoBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.TimeDetails;
import com.dpworld.mpc.camel.cxfrs.model.UserDetails;
import com.dpworld.mpc.camel.cxfrs.model.VesselLocationDetail;
import com.dpworld.mpc.camel.cxfrs.service.helper.PromisBPAServiceHelper;

@Path("/vessel")
public interface PromisBPAService {


  @Path("/vesselListETAs")
  @GET
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public List<VesselLocationDetail> getVesselListETA(@QueryParam("list") List<String> list) throws Exception;

  @Path("/vesselList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<PromisBPADetail> getVesselList() throws Exception;
  
  
  @Path("/workOrderList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<PromisBPADetail> getworkOrderList() throws Exception;
  
  @Path("/marineJobList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<PromisTwoBPADetail> getmarineJobList() throws Exception;

  @Path("/vesselDeatils")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public Collection<VesselLocationDetail> getVesselDtlFromAIS() throws Exception;


  @Path("/saveVesselDetails")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public VesselLocationDetail saveVesselDetails() throws Exception;
  
  @Path("/cbbsData")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes({"text/plain,text/html"})
  public PromisBPADetail getCBBSData(@QueryParam("rotationNumber") String rotationNumber) throws Exception;
  
  
  
  


  @Path("/userList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<UserDetails> getUserList() throws Exception;
  
  @Path("/roleList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<UserDetails> getRoleList() throws Exception;
  
  @Path("/bpaList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<BPADetail> getBPADetails(@QueryParam("detailsList") List<PromisBPADetail> detailsList) throws Exception;
  
  @Path("/getSailedVesselsDetails")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<PromisBPADetail> getSailedVesselsDetails(@QueryParam("fromSailDate") String fromSailDate,@QueryParam("toSailDate") String toSailDate,@QueryParam("rotnNumber") String rotnNumber) throws Exception;
 
  @Path("/getTimeDetails")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes({"text/plain,text/html"})
  public List<TimeDetails> getTimeDetails(@QueryParam("rotationNumber") String rotationNumber) throws Exception;
  
  @Path("/getCBBSCAM")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<CbbsDetails> getCBBSCAM() throws Exception;
	/*tariq*/
  @Path("/CBBSDataformarineJoBList")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes({"text/plain,text/html"})
  public PromisTwoBPADetail getCBBSDataformarineJoBList(@QueryParam("rotationNumber") String rotationNumber,@QueryParam("visit_id") String visit_id) throws Exception;

}
