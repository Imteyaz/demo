package com.dpworld.mpc.camel.cxfrs.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;

public class VesselLocationCalculator {
	@Autowired
	private static final Logger logger = LoggerFactory
			.getLogger(VesselLocationCalculator.class);

	/**
	 * @param lat1
	 * @param lon1
	 * @param lat2
	 * @param lon2
	 * @return
	 */
	public static double computeGeoDistance(double lat1, double lon1,
			double lat2, double lon2) {
		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
				+ Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2))
				* Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515;
		dist = dist * 0.8684;
		return (dist);
	}

	/**
	 * @param deg
	 * @return
	 */
	private static double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	/**
	 * @param rad
	 * @return
	 */
	private static double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}

	/**
	 * @param xa
	 * @param ya
	 * @param xb
	 * @param yb
	 * @param px
	 * @param py
	 * @return
	 */
	public static double areaOfTriangle(Double xa, Double ya, Double xb,
			Double yb, Double px, Double py) {
		double side1 = Math.sqrt(Math.pow(Math.abs(ya - yb), 2)
				+ Math.pow(Math.abs(xa - xb), 2));
		double side2 = Math.sqrt(Math.pow(Math.abs(ya - py), 2)
				+ Math.pow(Math.abs(xa - px), 2));
		double side3 = Math.sqrt(Math.pow(Math.abs(yb - py), 2)
				+ Math.pow(Math.abs(xb - px), 2));

		double semi_perimeter = (side1 + side2 + side3) / 2;

		double area = Math.sqrt(semi_perimeter * (semi_perimeter - side1)
				* (semi_perimeter - side2) * (semi_perimeter - side3));

		return area;
	}

	/**
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @param x3
	 * @param y3
	 * @param x4
	 * @param y4
	 * @return
	 */
	public static double areaOfRect(Double x1, Double y1, Double x2, Double y2,
			Double x3, Double y3, Double x4, Double y4) {

		double side1 = Math.sqrt(Math.pow(Math.abs(y1 - y2), 2)
				+ Math.pow(Math.abs(x1 - x2), 2));
		double side2 = Math.sqrt(Math.pow(Math.abs(y2 - y3), 2)
				+ Math.pow(Math.abs(x2 - x3), 2));

		double area = side1 * side2;

		return area;

	}

	/**
	 * @param geofenceData
	 * @param vesslatitude
	 * @param vessLongitude
	 * @return
	 */
	public static boolean isVesselExistInBreakWater(
			List<GeoFenceData> geofenceData, Double vesslatitude,
			Double vessLongitude) {
		Double distanceFromBreakWaterOneToVessel = 0.0;
		Double distanceFromBreakWaterTwoToVessel = 0.0;
		Double distanceFromBW1toBW2 = 0.0;
		GeoFenceData bwEndA = null;
		GeoFenceData bwEndB = null;
		for (GeoFenceData data : geofenceData) {
			if (data.getGeoCode() != null
					&& data.getGeoCode().equals(MPCConstants.BREAK_WATER_ONE)
					|| data.getGeoCode() != null
					&& data.getGeoCode().equals(MPCConstants.BREAK_WATER_TWO)) {
				if (data.getGeoCode().equals(MPCConstants.BREAK_WATER_ONE)) {
					distanceFromBreakWaterOneToVessel = VesselLocationCalculator
							.computeGeoDistance(data.getLat(), data.getLng(),
									vesslatitude, vessLongitude);
					bwEndA = data;
				}
				if (data.getGeoCode().equals(MPCConstants.BREAK_WATER_TWO)) {
					distanceFromBreakWaterTwoToVessel = VesselLocationCalculator
							.computeGeoDistance(data.getLat(), data.getLng(),
									vesslatitude, vessLongitude);
					bwEndB = data;
				}
				if (bwEndA != null && bwEndB != null)
					distanceFromBW1toBW2 = VesselLocationCalculator
							.computeGeoDistance(bwEndA.getLat(),
									bwEndA.getLng(), bwEndB.getLat(),
									bwEndB.getLng());
				if (distanceFromBW1toBW2 <= distanceFromBreakWaterOneToVessel
						+ distanceFromBreakWaterTwoToVessel)
					return true;
			}
		}

		return false;
	}

	// New method
	public static boolean isVesselExistInAnchorage(
			List<GeoFenceData> geofenceData, Double inputLatitude,
			Double inputLongitude) {
		List<GeogatePoint> anchorageCoordinateList = new ArrayList<GeogatePoint>();

		Double x1 = 0.0, y1 = 0.0, x2 = 0.0, y2 = 0.0, x3 = 0.0, y3 = 0.0, x4 = 0.0, y4 = 0.0;
		for (GeoFenceData data : geofenceData) {
			switch (data.getGeoCode()) {
			case MPCConstants.ANCHORAGE_COORDINATE_ONE:
				x1 = new Double(data.getLat());
				y1 = new Double(data.getLng());
				GeogatePoint geogatePointOne = new GeogatePoint();
				geogatePointOne.setLat(x1);
				geogatePointOne.setLang(y1);
				anchorageCoordinateList.add(geogatePointOne);
				break;
			case MPCConstants.ANCHORAGE_COORDINATE_TWO:
				x2 = new Double(data.getLat());
				y2 = new Double(data.getLng());
				GeogatePoint geogatePointTwo = new GeogatePoint();
				geogatePointTwo.setLat(x2);
				geogatePointTwo.setLang(y2);
				anchorageCoordinateList.add(geogatePointTwo);
				break;
			case MPCConstants.ANCHORAGE_COORDINATE_THREE:
				x3 = new Double(data.getLat());
				y3 = new Double(data.getLng());
				GeogatePoint geogatePointThree = new GeogatePoint();
				geogatePointThree.setLat(x3);
				geogatePointThree.setLang(y3);
				anchorageCoordinateList.add(geogatePointThree);
				break;
			case MPCConstants.ANCHORAGE_COORDINATE_FOUR:
				x4 = new Double(data.getLat());
				y4 = new Double(data.getLng());
				GeogatePoint geogatePointFour = new GeogatePoint();
				geogatePointFour.setLat(x4);
				geogatePointFour.setLang(y4);
				anchorageCoordinateList.add(geogatePointFour);
				break;
			default:
				break;
			}

		}
		boolean c = false;
		for (GeogatePoint point : anchorageCoordinateList) {
			if (point.lat != null && point.lon != null && inputLatitude != null
					&& inputLongitude != null) {
				double lat_i = inputLatitude;
				double lon_i = inputLongitude;
				double lat_j = point.lat;
				double lon_j = point.lon;
				if ((lat_i > inputLatitude) != (lat_j > inputLatitude)
						&& (inputLatitude < (lon_j - lon_i)
								* (inputLongitude - lat_i) / (lat_j - lat_i)
								+ lon_i))
					c = true;
			}
		}
		return c;
	}

	/**
	 * @param geofenceData
	 * @param vesselLat
	 * @param vesselLong
	 * @return
	 */
	/*
	 * public static boolean isVesselExistInAnchorage( List<GeoFenceData>
	 * geofenceData, Double vesselLat, Double vesselLong) { Double x1 = 0.0, y1
	 * = 0.0, x2 = 0.0, y2 = 0.0, x3 = 0.0, y3 = 0.0, x4 = 0.0, y4 = 0.0; for
	 * (GeoFenceData data : geofenceData) { switch (data.getGeoCode()) { case
	 * ANCHORAGE_COORDINATE_ONE: x1 = new Double(data.getLat()); y1 = new
	 * Double(data.getLng()); break; case ANCHORAGE_COORDINATE_TWO: x2 = new
	 * Double(data.getLat()); y2 = new Double(data.getLng()); break; case
	 * ANCHORAGE_COORDINATE_THREE: x3 = new Double(data.getLat()); y3 = new
	 * Double(data.getLng()); break; case ANCHORAGE_COORDINATE_FOUR: x4 = new
	 * Double(data.getLat()); y4 = new Double(data.getLng()); break; default:
	 * break; }
	 * 
	 * } double trinagle1Area = VesselLocationCalculator.areaOfTriangle(x1, y1,
	 * x2, y2, vesselLat, vesselLong); double trinagle2Area =
	 * VesselLocationCalculator.areaOfTriangle(x2, y2, x3, y3, vesselLat,
	 * vesselLong); double trinagle3Area =
	 * VesselLocationCalculator.areaOfTriangle(x3, y3, x4, y4, vesselLat,
	 * vesselLong); double trinagle4Area =
	 * VesselLocationCalculator.areaOfTriangle(x4, y4, x1, y1, vesselLat,
	 * vesselLong);
	 * 
	 * double rectArea = VesselLocationCalculator.areaOfRect(x1, y1, x2, y2, x3,
	 * y3, x4, y4);
	 * 
	 * double triangleAreaSum = (trinagle1Area + trinagle2Area + trinagle3Area +
	 * trinagle4Area);
	 * 
	 * if (triangleAreaSum % (Math.pow(10, 14)) >= 0.999999999999999) {
	 * triangleAreaSum = Math.ceil(triangleAreaSum); }
	 * 
	 * if (triangleAreaSum == rectArea) return true; else return false; }
	 */
	/**
	 * @param geofenceData
	 * @param vesselLat
	 * @param vesselLong
	 * @return
	 */
	public static boolean isVesselExistInRectangle(Double coordinateOneLat,
			Double coordinateOneLng, Double coordinateTwoLat,
			Double coordinateTwoLng, Double coordinateThreeLat,
			Double coordinateThreeLng, Double coordinateFourLat,
			Double coordinateFourLng, Double vesselLat, Double vesselLng) {

		double trinagle1Area = VesselLocationCalculator.areaOfTriangle(
				coordinateOneLat, coordinateOneLng, coordinateTwoLat,
				coordinateTwoLng, vesselLat, vesselLng);
		double trinagle2Area = VesselLocationCalculator.areaOfTriangle(
				coordinateTwoLat, coordinateTwoLng, coordinateThreeLat,
				coordinateThreeLng, vesselLat, vesselLng);
		double trinagle3Area = VesselLocationCalculator.areaOfTriangle(
				coordinateThreeLat, coordinateThreeLng, coordinateThreeLng,
				coordinateFourLng, vesselLat, vesselLng);
		double trinagle4Area = VesselLocationCalculator.areaOfTriangle(
				coordinateFourLat, coordinateFourLng, coordinateOneLat,
				coordinateOneLng, vesselLat, vesselLng);

		double rectArea = VesselLocationCalculator.areaOfRect(coordinateOneLat,
				coordinateOneLng, coordinateTwoLat, coordinateTwoLng,
				coordinateThreeLat, coordinateThreeLng, coordinateFourLat,
				coordinateFourLng);

		double triangleAreaSum = (trinagle1Area + trinagle2Area + trinagle3Area + trinagle4Area);

		if (triangleAreaSum % (Math.pow(10, 14)) >= 0.999999999999999) {
			triangleAreaSum = Math.ceil(triangleAreaSum);
			logger.debug("Sum of the Area : " + triangleAreaSum);
		}

		if (triangleAreaSum == rectArea)
			return true;
		else
			return false;
	}

	public String getTerminalQ(Double vesslatitude, Double vessLongitude) {

		if (isInT1Q0(vesslatitude, vessLongitude))
			return "T1Q0";
		if (isInT1Q1(vesslatitude, vessLongitude))
			return "T1Q1";
		if (isInT1Q2(vesslatitude, vessLongitude))
			return "T1Q2";
		if (isInT1Q2(vesslatitude, vessLongitude))
			return "T1Q2";
		if (isInT1Q3(vesslatitude, vessLongitude))
			return "T1Q3";
		if (isInT1Q4(vesslatitude, vessLongitude))
			return "T1Q4";
		if (isInT1Q5(vesslatitude, vessLongitude))
			return "T1Q5";
		if (isInT1Q6(vesslatitude, vessLongitude))
			return "T1Q6";
		if (isInT1Q7(vesslatitude, vessLongitude))
			return "T1Q7";
		if (isInT1Q8(vesslatitude, vessLongitude))
			return "T1Q8";
		if (isInT1Q9(vesslatitude, vessLongitude))
			return "T1Q9";
		if (isInT2Q1(vesslatitude, vessLongitude))
			return "T2Q1";
		if (isInT3Q1(vesslatitude, vessLongitude))
			return "T3Q1";
		if (isInTNK1(vesslatitude, vessLongitude))
			return "TNK1";
		if (isInTNK2(vesslatitude, vessLongitude))
			return "TNK2";
		if (isVesselExistInBasinOne(vesslatitude, vessLongitude))
			return "BASIN_ONE";
		if (isVesselExistInBasinTwo(vesslatitude, vessLongitude))
			return "BASIN_TWO";
		return null;
	}

	public boolean isVesselExistInBasinOne(Double vesslatitude,
			Double vessLongitude) {
		if (isVesselExistInRectangle(vesslatitude, vessLongitude, new Double(
				24.9941876272237), new Double(55.055193901062), new Double(
				25.0082672993759), new Double(55.0716733932495), new Double(
				25.0047280860999), new Double(55.075364112854), new Double(
				24.9889851302634), new Double(55.0575649738311)))
			return true;
		return false;
	}

	public boolean isVesselExistInBasinTwo(Double vesslatitude,
			Double vessLongitude) {
		if (isVesselExistInRectangle(vesslatitude, vessLongitude, new Double(
				24.9746017547699), new Double(55.0531768798828), new Double(
				24.9973965342348), new Double(55.0791406631469), new Double(
				24.9949461037152), new Double(55.0816941261291), new Double(
				24.9721897732364), new Double(55.0556230545043)))
			return true;

		return false;
	}

	public boolean isInT1Q0(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q0AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0028223136379), new Double(
						55.0503873825073), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q0BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9943626606757), new Double(
						55.0552582740783), vesslatitude, vessLongitude);
		Double distanceBetweeT1Q0AtoT1Q0B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0028223136379), new Double(
						55.0503873825073), new Double(24.9943626606757),
						new Double(55.0552582740783));

		if ((distanceBetweeT1Q0AtoT1Q0B) != null
				&& distanceBetweenT1Q0AtoVessel != null
				&& distanceBetweenT1Q0BtoVessel != null
				&& (distanceBetweeT1Q0AtoT1Q0B + 0.00539957 >= distanceBetweenT1Q0AtoVessel
						+ distanceBetweenT1Q0BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q1(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q1AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9943626606757), new Double(
						55.0552582740783), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q1BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0085006505138), new Double(
						55.0717163085937), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q1AtoT1Q1B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9943626606757), new Double(
						55.0552582740783), new Double(25.0085006505138),
						new Double(55.0717163085937));

		if ((distanceBetweenT1Q1AtoT1Q1B) != null
				&& distanceBetweenT1Q1AtoVessel != null
				&& distanceBetweenT1Q1BtoVessel != null
				&& (distanceBetweenT1Q1AtoT1Q1B + 0.00539957 >= distanceBetweenT1Q1AtoVessel
						+ distanceBetweenT1Q1BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q2(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q2AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0085006505138), new Double(
						55.0717163085937), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q2BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0047086395914), new Double(
						55.0756859779357), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q2AtoT1Q2B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0085006505138), new Double(
						55.0717163085937), new Double(25.0047086395914),
						new Double(55.0756859779357));

		if ((distanceBetweenT1Q2AtoT1Q2B) != null
				&& distanceBetweenT1Q2AtoVessel != null
				&& distanceBetweenT1Q2BtoVessel != null
				&& (distanceBetweenT1Q2AtoT1Q2B + 0.00539957 >= distanceBetweenT1Q2AtoVessel
						+ distanceBetweenT1Q2BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q3(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q3AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0047086395914), new Double(
						55.0756859779357), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q3BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9888976097398), new Double(
						55.0576400756835), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q3AtoT1Q3B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0047086395914), new Double(
						55.0756859779357), new Double(24.9888976097398),
						new Double(55.0576400756835));

		if ((distanceBetweenT1Q3AtoT1Q3B) != null
				&& distanceBetweenT1Q3AtoVessel != null
				&& distanceBetweenT1Q3BtoVessel != null
				&& (distanceBetweenT1Q3AtoT1Q3B + 0.00539957 >= distanceBetweenT1Q3AtoVessel
						+ distanceBetweenT1Q3BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q4(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q4AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9888976097398), new Double(
						55.0576400756835), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q4BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9817571837976), new Double(
						55.0606226921081), vesslatitude, vessLongitude);
		Double distanceBetweeT1Q4AtoT1Q4B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9888976097398), new Double(
						55.0576400756835), new Double(24.9817571837976),
						new Double(55.0606226921081));

		if ((distanceBetweeT1Q4AtoT1Q4B) != null
				&& distanceBetweenT1Q4AtoVessel != null
				&& distanceBetweenT1Q4BtoVessel != null
				&& (distanceBetweeT1Q4AtoT1Q4B + 0.00539957 >= distanceBetweenT1Q4AtoVessel
						+ distanceBetweenT1Q4BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q5(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q5AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9817693401356), new Double(
						55.0606951117515), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q5BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.997532667831), new Double(
						55.0791406631469), vesslatitude, vessLongitude);
		Double distanceBetweeT1Q5AtoT1Q5B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9817693401356), new Double(
						55.0606951117515), new Double(24.997532667831),
						new Double(55.0791406631469));

		if ((distanceBetweeT1Q5AtoT1Q5B) != null
				&& distanceBetweenT1Q5AtoVessel != null
				&& distanceBetweenT1Q5BtoVessel != null
				&& (distanceBetweeT1Q5AtoT1Q5B + 0.00539957 >= distanceBetweenT1Q5AtoVessel
						+ distanceBetweenT1Q5BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q6(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q6AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.997532667831), new Double(
						55.0791406631469), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q6BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9949509657289), new Double(
						55.0818818807601), vesslatitude, vessLongitude);
		Double distanceBetweeT1Q6AtoT1Q6B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.997532667831), new Double(
						55.0791406631469), new Double(24.9949509657289),
						new Double(55.0818818807601));

		if ((distanceBetweeT1Q6AtoT1Q6B) != null
				&& distanceBetweenT1Q6AtoVessel != null
				&& distanceBetweenT1Q6BtoVessel != null
				&& (distanceBetweeT1Q6AtoT1Q6B + 0.00539957 >= distanceBetweenT1Q6AtoVessel
						+ distanceBetweenT1Q6BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q7(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q7AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9949509657289), new Double(
						55.0818818807601), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q7BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9720536115784), new Double(
						55.0555801391601), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q7AtoT1Q7B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9949509657289), new Double(
						55.0818818807601), new Double(24.9720536115784),
						new Double(55.0555801391601));

		if ((distanceBetweenT1Q7AtoT1Q7B) != null
				&& distanceBetweenT1Q7AtoVessel != null
				&& distanceBetweenT1Q7BtoVessel != null
				&& (distanceBetweenT1Q7AtoT1Q7B + 0.00539957 >= distanceBetweenT1Q7AtoVessel
						+ distanceBetweenT1Q7BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q8(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q8AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9720536115784), new Double(
						55.0555801391601), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q8BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9769164345137), new Double(
						55.0502264499664), vesslatitude, vessLongitude);
		Double distanceBetweeT1Q8AtoT1Q8B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9720536115784), new Double(
						55.0555801391601), new Double(24.9769164345137),
						new Double(55.0502264499664));

		if ((distanceBetweeT1Q8AtoT1Q8B) != null
				&& distanceBetweenT1Q8AtoVessel != null
				&& distanceBetweenT1Q8BtoVessel != null
				&& (distanceBetweeT1Q8AtoT1Q8B + 0.00539957 >= distanceBetweenT1Q8AtoVessel
						+ distanceBetweenT1Q8BtoVessel))
			return true;

		return false;
	}

	public boolean isInT1Q9(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT1Q9AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9769164345137), new Double(
						55.0502264499664), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q9BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9812830856798), new Double(
						55.0549525022506), vesslatitude, vessLongitude);
		Double distanceBetweenT1Q9AtoT1Q9B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9769164345137), new Double(
						55.0502264499664), new Double(24.9812830856798),
						new Double(55.0549525022506));

		if ((distanceBetweenT1Q9AtoT1Q9B) != null
				&& distanceBetweenT1Q9AtoVessel != null
				&& distanceBetweenT1Q9BtoVessel != null
				&& (distanceBetweenT1Q9AtoT1Q9B + 0.00539957 >= distanceBetweenT1Q9AtoVessel
						+ distanceBetweenT1Q9BtoVessel))
			return true;

		return false;
	}

	public boolean isInT2Q1(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT2Q1AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0218106543445), new Double(
						55.0438427925109), vesslatitude, vessLongitude);
		Double distanceBetweenT2Q1BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0267590021724), new Double(
						55.0720918178558), vesslatitude, vessLongitude);
		Double distanceBetweenT2Q1AtoT2Q1B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0218106543445), new Double(
						55.0438427925109), new Double(25.0267590021724),
						new Double(55.0720918178558));

		if ((distanceBetweenT2Q1AtoT2Q1B) != null
				&& distanceBetweenT2Q1AtoVessel != null
				&& distanceBetweenT2Q1BtoVessel != null
				&& (distanceBetweenT2Q1AtoT2Q1B + 0.00539957 >= distanceBetweenT2Q1AtoVessel
						+ distanceBetweenT2Q1BtoVessel))
			return true;

		return false;
	}

	public boolean isInT3Q1(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenT3Q1AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9812830856798), new Double(
						55.0549525022506), vesslatitude, vessLongitude);
		Double distanceBetweenT3Q1BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9971826097075), new Double(
						55.0483274459838), vesslatitude, vessLongitude);
		Double distanceBetweenT3Q1AtoT3Q1B = VesselLocationCalculator
				.computeGeoDistance(new Double(24.9812830856798), new Double(
						55.0549525022506), new Double(24.9971826097075),
						new Double(55.0483274459838));

		if ((distanceBetweenT3Q1AtoT3Q1B) != null
				&& distanceBetweenT3Q1AtoVessel != null
				&& distanceBetweenT3Q1BtoVessel != null
				&& (distanceBetweenT3Q1AtoT3Q1B + 0.00539957 >= distanceBetweenT3Q1AtoVessel
						+ distanceBetweenT3Q1BtoVessel))
			return true;

		return false;
	}

	public boolean isInTNK1(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenTNK1AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0196232071436), new Double(
						55.0457954406738), vesslatitude, vessLongitude);
		Double distanceBetweenTNK1BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0053892655564), new Double(
						55.0521039962768), vesslatitude, vessLongitude);
		Double distanceBetweenTNK1AtoTNK1B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0196232071436), new Double(
						55.0457954406738), new Double(25.0053892655564),
						new Double(55.0521039962768));

		if ((distanceBetweenTNK1AtoTNK1B) != null
				&& distanceBetweenTNK1AtoVessel != null
				&& distanceBetweenTNK1BtoVessel != null
				&& (distanceBetweenTNK1AtoTNK1B + 0.00539957 >= distanceBetweenTNK1AtoVessel
						+ distanceBetweenTNK1BtoVessel))
			return true;

		return false;
	}

	public boolean isInTNK2(Double vesslatitude, Double vessLongitude) {
		Double distanceBetweenTNK2AtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0053892655564), new Double(
						55.0521039962768), vesslatitude, vessLongitude);
		Double distanceBetweenTNK2BtoVessel = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0028223136379), new Double(
						55.0503873825073), vesslatitude, vessLongitude);
		Double distanceBetweenTNK2AtoTNK2B = VesselLocationCalculator
				.computeGeoDistance(new Double(25.0053892655564), new Double(
						55.0521039962768), new Double(25.0028223136379),
						new Double(55.0503873825073));

		if ((distanceBetweenTNK2AtoTNK2B) != null
				&& distanceBetweenTNK2AtoVessel != null
				&& distanceBetweenTNK2BtoVessel != null
				&& (distanceBetweenTNK2AtoTNK2B + 0.00539957 >= distanceBetweenTNK2AtoVessel
						+ distanceBetweenTNK2BtoVessel))
			return true;

		return false;
	}

	public static boolean isVesselExistinTerminal(
			List<GeoFenceData> geofenceData, Double vesslatitude,
			Double vessLongitude) {
		Double distanceBetweenT1Q3AtoVessel = null;
		Double distanceBetweenT1Q3BtoVessel = null;
		Double distanceBetweenT1Q3AtoT1Q3B = null;
		GeoFenceData endA = null;
		GeoFenceData endB = null;
		for (GeoFenceData data : geofenceData) {
			if (data.getGeoCode() != null) {

				if (data.getGeoCode().equals("T1Q1A")) {
					distanceBetweenT1Q3AtoVessel = VesselLocationCalculator
							.computeGeoDistance(data.getLat(), data.getLng(),
									vesslatitude, vessLongitude);
					endA = data;
					logger.debug("Distance Between T1Q0A and Vessel : "
							+ distanceBetweenT1Q3AtoVessel);
				}
				if (data.getGeoCode().equals("T1Q1B")) {
					distanceBetweenT1Q3BtoVessel = VesselLocationCalculator
							.computeGeoDistance(data.getLat(), data.getLng(),
									vesslatitude, vessLongitude);
					endB = data;
					logger.debug("Distance Between T1Q0B and Vessel : "
							+ distanceBetweenT1Q3BtoVessel);
				}
				if (endA != null && endB != null) {
					distanceBetweenT1Q3AtoT1Q3B = VesselLocationCalculator
							.computeGeoDistance(endA.getLat(), endA.getLng(),
									endB.getLat(), endB.getLng());
					logger.debug("Distance Between T3Q1A and T3Q1B : "
							+ distanceBetweenT1Q3AtoT1Q3B);
				}

				if (distanceBetweenT1Q3AtoT1Q3B != null
						&& distanceBetweenT1Q3AtoVessel != null
						&& distanceBetweenT1Q3BtoVessel != null
						&& (distanceBetweenT1Q3AtoT1Q3B + 0.00539957) >= (distanceBetweenT1Q3AtoVessel + distanceBetweenT1Q3BtoVessel)) {
					Float bufferDistance = new Float(0.00539957);
					// 0.00539957 nm is nothing but 10 meters
					logger.debug("distanceBetweenT1Q5AtoT1Q3B( "
							+ distanceBetweenT1Q3AtoT1Q3B
							+ " )- "
							+ "distanceBetweenT1Q3AtoVessel("
							+ distanceBetweenT1Q3AtoVessel
							+ ")+distanceBetweenT1Q3BtoVessel("
							+ distanceBetweenT1Q3BtoVessel
							+ " )"
							+ " < ="
							+ bufferDistance
							+ "==>"
							+ ((distanceBetweenT1Q3AtoT1Q3B)
									- (distanceBetweenT1Q3AtoVessel + distanceBetweenT1Q3BtoVessel) <= 0.00539957));
					return true;
				}
			}

		}
		return false;
	}

	static class GeogatePoint {

		public static GeogatePoint getInstance() {
			return new GeogatePoint();
		}

		public Double getLat() {
			return lat;
		}

		public void setLat(Double lat) {
			this.lat = lat;
		}

		public Double getLang() {
			return lon;
		}

		public void setLang(Double lon) {
			this.lon = lon;
		}

		Double lat;
		Double lon;

		@Override
		public String toString() {
			return "GeogatePoint [lat=" + lat + ", lang=" + lon + "]";
		}

	}
}
