package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;

public class UserDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	private String terminalCode;
	private String portCode;
	private String roleName;
	private String userId;
	private String employeeNumber;
	private String empName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String domainId;
	private String emailId;
	private String phoneNo;
	private String preferredTerminalId;
	private String appDescription;
	private String description;
	
	public String getTerminalCode() {
		return terminalCode;
	}
	public void setTerminalCode(String terminalCode) {
		this.terminalCode = terminalCode;
	}
	public String getPortCode() {
		return portCode;
	}
	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDomainId() {
		return domainId;
	}
	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPreferredTerminalId() {
		return preferredTerminalId;
	}
	public void setPreferredTerminalId(String preferredTerminalId) {
		this.preferredTerminalId = preferredTerminalId;
	}
	public String getAppDescription() {
		return appDescription;
	}
	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "UserDetails [terminalCode=" + terminalCode + ", portCode="
				+ portCode + ", roleName=" + roleName + ", userId=" + userId
				+ ", employeeNumber=" + employeeNumber + ", empName=" + empName
				+ ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", domainId=" + domainId
				+ ", emailId=" + emailId + ", phoneNo=" + phoneNo
				+ ", preferredTerminalId=" + preferredTerminalId
				+ ", appDescription=" + appDescription + ", description="
				+ description + "]";
	}
	
	

}
