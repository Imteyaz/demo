package com.dpworld.mpc.camel.cxfrs.service;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.dpworld.mpc.camel.cxfrs.model.BPADetail;
import com.dpworld.mpc.camel.cxfrs.model.CbbsDetails;
import com.dpworld.mpc.camel.cxfrs.model.PromisBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.PromisTwoBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.TimeDetails;
import com.dpworld.mpc.camel.cxfrs.model.UserDetails;
import com.dpworld.mpc.camel.cxfrs.model.VesselLocationDetail;
import com.dpworld.mpc.camel.cxfrs.service.helper.PromisBPAServiceHelper;

/**
 * This Rest Webserice class.
 * 
 * @author Muthukumar Chellappa
 * 
 */

public class PromisBPAServiceImpl implements PromisBPAService, Serializable {

  private static final long serialVersionUID = -1576920629547034946L;
  private static Logger log = LoggerFactory.getLogger(PromisBPAServiceImpl.class);
  /**
   * Web service method implementation This method is used to get the Vessel
   * Details from AIS
   * 
   * @param request
   * @return Vessel Details
   * @author Itpeople.Muthukumar
   * @throws IOException
   * @throws UnknownHostException
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws XPathExpressionException
   */
  public Collection<VesselLocationDetail> getVesselDtlFromAIS() throws UnknownHostException, IOException,
      ParserConfigurationException, XPathExpressionException, SAXException {
    return PromisBPAServiceHelper.getVesselDetails();
  }

  /**
   * Web service method implementation This method is used to get the Vessel
   * List ETA
   * 
   * @throws IOException
   * @param request
   * @return List of Vessel Details
   * @author Itpeople.Muthukumar
   */
  public List<VesselLocationDetail> getVesselListETA(List<String> request) throws IOException {
    return PromisBPAServiceHelper.getVesselsETA(request);
  }
  

  /**
   * Web service method implementation This method is used to get the Vessel
   * List.
   * 
   * @return List of Promis and BPA details
   * @throws IOException
   * @author Itpeople.Muthukumar
   */
	public List<PromisBPADetail> getVesselList() throws Exception {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside getVesselList API with start time :" + startTime);
		List<PromisBPADetail> result = PromisBPAServiceHelper
				.getPromisDetails(false,true);
		long endTime = System.currentTimeMillis();
		log.info("getVesselList End Time : " + endTime);
		log.info("Time Taken by getVesselList in milli seconds : "
				+ (endTime - startTime));
		if(log.isDebugEnabled())
		log.debug("Time Taken by getVesselList Result of FUse :"+result);
		return result;

	}


  /**
   * Web service method implementation This method is used to save the Vessel
   * List for Alerts and communication
   * 
   * @return List of Promis and BPA details
   * @throws IOException
   * @author Itpeople.Muthukumar
   */
  public VesselLocationDetail saveVesselDetails() throws Exception {
    PromisBPAServiceHelper.saveVesselDetails();
    return new VesselLocationDetail();
  }
  
  
  /**
   * Web service method implementation This method is used to get the Vessel
   * List.
   * 
   * @return List of Promis and BPA details
   * @throws IOException
   * @author Itpeople.Muthukumar
   */
	public List<PromisBPADetail> getworkOrderList() throws Exception {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside getworkOrderList API with start time :" + startTime);
		List<PromisBPADetail> result = PromisBPAServiceHelper
				.getPromisDetails(false,false); 
		long endTime = System.currentTimeMillis();
		log.info("getworkOrderList End Time : " + endTime);
		log.info("Time Taken by getworkOrderList in milli seconds : "
				+ (endTime - startTime));
		if(log.isDebugEnabled())
		log.debug("Time Taken by getworkOrderList Result of FUse :"+result);
		return result;

	}
	
	//tariqMArine
	/**
	 * This method is called from Blueprint.xml. The below task are done in this
	 * method.
	 * 
	 * 1) Fetching Promis Details 2) Fetching Terminals from MPC 3) Fetching New
	 * ETA from MPC 4) Grouping Terminals 5) Fetching Data from BPA 6)
	 * Constructing final object. 7) Set into the exchange body.
	 * 
	   * @author sapcle.mohammed
	   */
	
	public List<PromisTwoBPADetail> getmarineJobList() throws Exception {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside getworkOrderList API with start time :" + startTime);
		List<PromisTwoBPADetail> result = PromisBPAServiceHelper
				.getPromisTwoDetails(false,false); 
		long endTime = System.currentTimeMillis();
		log.info("getworkOrderList End Time : " + endTime);
		log.info("Time Taken by getworkOrderList in milli seconds : "
				+ (endTime - startTime));
		if(log.isDebugEnabled())
		log.debug("Time Taken by getworkOrderList Result of FUse :"+result);
		return result;

	}
	
	
	/*public List<PromisTwoBPADetail> getmarineJobList() throws Exception {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside getworkOrderList API with start time :" + startTime);
		List<PromisTwoBPADetail> result=new <PromisTwoBPADetail>ArrayList();
		//fetchTerminals(result);
		//fetchETA(result);
		PromisBPAServiceImpl service=new PromisBPAServiceImpl();
		List<CbbsDetails> cbbsdata= service.getCBBSCAM();
		if(cbbsdata !=null){
		for (CbbsDetails  cbbsdatafromservice : cbbsdata) {

			if (cbbsdatafromservice != null) {
				
				String rotationNumber=cbbsdatafromservice.getRotn();
				String visit_id=cbbsdatafromservice.getVisit_id();
				PromisTwoBPADetail bpadetails	=service.getCBBSDataformarineJoBList(rotationNumber, visit_id);
				bpadetails.setRotation(cbbsdatafromservice.getRotn());
				bpadetails.setVisit_id(cbbsdatafromservice.getVisit_id());
				bpadetails.setVisit_terminal(cbbsdatafromservice.getVisit_terminal());
				result.add(bpadetails);
				
				
				
			

			}

		}
		}
		
		
		
		//List<PromisTwoBPADetail> result = PromisBPAServiceHelper.getPromisDetails(false,false);
		long endTime = System.currentTimeMillis();
		log.info("getworkOrderList End Time : " + endTime);
		log.info("Time Taken by getworkOrderList in milli seconds : "
				+ (endTime - startTime));
		if(log.isDebugEnabled())
		log.debug("Time Taken by getworkOrderList Result of FUse :"+result);
		return result;

	}*/
	
	
	public List<CbbsDetails> getCBBSCAM() throws Exception {
		
		log.debug("Inside getCBBSCAM API with start time :");
		List<CbbsDetails> result = PromisBPAServiceHelper
				.getCBBSCAM();
	return result;

	}


	public PromisBPADetail getCBBSData(String rotationNumber) throws Exception{
        return PromisBPAServiceHelper.retriveCBBSData(rotationNumber);
 }
	/*tariq*/
	public PromisTwoBPADetail getCBBSDataformarineJoBList(String rotationNumber,String visit_id) throws Exception{
        return PromisBPAServiceHelper.retriveCBBSDataforMarineJoblist(rotationNumber,visit_id);
 }

	@Override
	public List<UserDetails> getUserList() throws Exception {
		
		return PromisBPAServiceHelper.getUserInfoList();
	}

	@Override
	public List<UserDetails> getRoleList() throws Exception {
		
		return PromisBPAServiceHelper.getRoleInfoList();
	}
	
	@Override
	public List<BPADetail> getBPADetails(List<PromisBPADetail> detailsList) throws Exception {
		
		return PromisBPAServiceHelper.groupTerminalsFetchBPADtls(detailsList, false);
	}
	
	
	 /**
	   * Web service method implementation This method is used to get the Vessel
	   * List.
	   * 
	   * @return List of Promis and BPA details
	   * @throws IOException
	   * @author Itpeople.Muthukumar
	   */
		public List<PromisBPADetail> getSailedVesselsDetails(String fromSailDate, String toSailDate, String rotnNumber) throws Exception {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside getSailedVesselsDetails API with start time :" + startTime);
			List<PromisBPADetail> result = PromisBPAServiceHelper
					.getSailedVesselsDetails(fromSailDate,toSailDate,rotnNumber);
			long endTime = System.currentTimeMillis();
			log.info("getSailedVesselsDetails End Time : " + endTime);
			log.info("Time Taken by getSailedVesselsDetails in milli seconds : "
					+ (endTime - startTime));
			if(log.isDebugEnabled())
			log.debug("getSailedVesselsDetails Result of Fuse :"+result);
			return result;

		}
		
		@Override
		public List<TimeDetails> getTimeDetails(String rotationNumber) throws Exception {
			
			return PromisBPAServiceHelper.getTimeDetails(rotationNumber);
		}

}
