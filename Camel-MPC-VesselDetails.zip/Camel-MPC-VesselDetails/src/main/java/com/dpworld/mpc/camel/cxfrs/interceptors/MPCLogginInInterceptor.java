package com.dpworld.mpc.camel.cxfrs.interceptors;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

public class MPCLogginInInterceptor extends AbstractPhaseInterceptor<Message> {

  public MPCLogginInInterceptor() {
    super(Phase.RECEIVE);
  }

  public void handleMessage(Message message) {

  }

}
