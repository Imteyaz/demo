package com.dpworld.mpc.camel.cxfrs.util;

import java.io.Serializable;

public class GeoFenceData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Float lat;
	private Float lng;
	private String geoCode;
	private Integer pointOrder;

	public Float getLat() {
		return lat;
	}

	public void setLat(Float lat) {
		this.lat = lat;
	}

	public Float getLng() {
		return lng;
	}

	public void setLng(Float lng) {
		this.lng = lng;
	}

	public String getGeoCode() {
		return geoCode;
	}

	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}

	public Integer getPointOrder() {
		return pointOrder;
	}

	public void setPointOrder(Integer pointOrder) {
		this.pointOrder = pointOrder;
	}

}
