package com.dpworld.mpc.camel.cxfrs.service.helper;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.xml.sax.SAXException;



import com.dpworld.camel.cxf.service.RotationCriteria;
import com.dpworld.camel.cxf.service.VesselVoyage;
import com.dpworld.camel.cxf.service.VoyageService;
import com.dpworld.camel.cxf.service.VoyageTerminalVisit;
import com.dpworld.mpc.camel.cxfrs.constants.MPCConstants;
import com.dpworld.mpc.camel.cxfrs.model.BPADetail;
import com.dpworld.mpc.camel.cxfrs.model.CbbsDetails;
import com.dpworld.mpc.camel.cxfrs.model.DataBaseFactory;
import com.dpworld.mpc.camel.cxfrs.model.FilterCriteria;
import com.dpworld.mpc.camel.cxfrs.model.PromisBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.PromisTwoBPADetail;
import com.dpworld.mpc.camel.cxfrs.model.TerminalVisit;
import com.dpworld.mpc.camel.cxfrs.model.TimeDetails;
import com.dpworld.mpc.camel.cxfrs.model.UserDetails;
import com.dpworld.mpc.camel.cxfrs.model.VesselLocationDetail;
import com.dpworld.mpc.camel.cxfrs.service.PromisBPAServiceImpl;
import com.dpworld.mpc.camel.cxfrs.service.helper.PromiseBPAServiceTask.TaskCompletionStatus;
import com.dpworld.mpc.camel.cxfrs.util.DateUtilities;
import com.dpworld.mpc.camel.cxfrs.util.GeoFenceData;
import com.dpworld.mpc.camel.cxfrs.util.MpcPropertyUtil;
import com.dpworld.mpc.camel.cxfrs.util.VesselDataCalcHelper;
import com.dpworld.mpc.camel.cxfrs.util.VesselIconsPointsHolder;
import com.dpworld.mpc.camel.cxfrs.util.VesselLocationCalculator;
//import com.dpworld.mpcsystem.common.utility.MarineJoblistVesselDataCalcHelper.VesselStatus;
//import com.dpworld.mpcsystem.common.utility.pojo.MarineJoblistDetailsDTO;

public class PromisBPAServiceHelper {

	private static Logger log = LoggerFactory
			.getLogger(PromisBPAServiceHelper.class);
	private final static String TERMINAL_1 = "T1";
	private final static String TERMINAL_2 = "T2";
	private final static String TERMINAL_3 = "T3";
	private final static String TERMINAL_4 = "T4";
	private final static String GENERAL_CARGO = "GC";
	private final static String SELECT_ONE = "ONE";
	private final static String SELECT_LIST = "LIST";
	private final static String INSERT_LIST = "INSERT";

	private final static String FECTH_ETA = "fetchETA";
	private final static String FETCH_CBBS_DATA = "fetchCBBSData";
	private final static String CONSTRUCT_BPA_STATUS = "constructBPAStatus";
	private final static String CONSTRUCT_PRIORITY_DATE = "constructPriorityDate";
	private final static String LOAD_DROP_DOWN_VALUES = "loadDropDownValues";
	private final static String FETCH_SCORING = "fetchScoring";
	private final static String GROUP_TERMINAL_BPA = "groupTerminalBPA";

	private static DataBaseFactory dataBaseFactory = null;

	/** The MAXTHREADS. */
	private static int MAX_THREADS = 7;
	static List<GeoFenceData> geofenceData = null;

	/**
	 * This method is used to initiate the Database connection factory
	 * 
	 * @throws IOException
	 * @author Itpeople.Muthukumar
	 */
	static void init() throws IOException {
		dataBaseFactory = DataBaseFactory.getInstance();
		geofenceData = (List<GeoFenceData>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_MPC, "getGeofenceData", null, null, null);
		// log.info("Geofense Master Data : "+geofenceData.size());

	}

	/**
	 * This method is used to get the Vessel Details.
	 * 
	 * @throws IOException
	 * @throws {@link XPathExpressionException}
	 * @throws ParserConfigurationException
	 * @throws {@link SAXException}
	 * @author Itpeople.Muthukumar
	 * @return VesselDetail
	 */
	public static Collection<VesselLocationDetail> getVesselDetails()
			throws IOException, XPathExpressionException,
			ParserConfigurationException, SAXException {
		return null;
	}

	/**
	 * Formating the date field.
	 * 
	 * @param terminalVisit
	 * @param promisVisit
	 * @author Itpeople.Muthukumar
	 */
	private static void setDateFields(VoyageTerminalVisit terminalVisit,
			TerminalVisit promisVisit) {

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm");

		if (terminalVisit.getActualArrivalTime() != null) {
			promisVisit.setActualArrivalTime(dateFormat.format(terminalVisit
					.getActualArrivalTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getActualBerthTime() != null) {
			promisVisit.setActualBerthTime(dateFormat.format(terminalVisit
					.getActualBerthTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getActualDepartTime() != null) {
			promisVisit.setActualDepartTime(dateFormat.format(terminalVisit
					.getActualDepartTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getEstimatedArrivalTime() != null) {
			promisVisit
					.setEstimatedArrivalTime(dateFormat.format(terminalVisit
							.getEstimatedArrivalTime().toGregorianCalendar()
							.getTime()));
		}

		if (terminalVisit.getEstimatedBerthTime() != null) {
			promisVisit.setEstimatedBerthTime(dateFormat.format(terminalVisit
					.getEstimatedBerthTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getEstimatedDepartTime() != null) {
			promisVisit.setEstimatedDepartTime(dateFormat.format(terminalVisit
					.getEstimatedDepartTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getLoadCutoffTime() != null) {
			promisVisit.setLoadCutoffTime(dateFormat.format(terminalVisit
					.getLoadCutoffTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getUnBerthingTime() != null) {
			promisVisit.setUnBerthingTime(dateFormat.format(terminalVisit
					.getUnBerthingTime().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getWorkEndDate() != null) {
			promisVisit.setWorkEndDate(dateFormat.format(terminalVisit
					.getWorkEndDate().toGregorianCalendar().getTime()));
		}

		if (terminalVisit.getWorkStartDate() != null) {
			promisVisit.setWorkStartDate(dateFormat.format(terminalVisit
					.getWorkStartDate().toGregorianCalendar().getTime()));
		}
	}

	/**
	 * Constructing the Rotation criteria filter.
	 * 
	 * @param rotation
	 * @param terminalId
	 * @return
	 */
	private static RotationCriteria constructRotationCriteria(String rotation,
			String terminalId) {

		RotationCriteria criteria = new RotationCriteria();
		criteria.setRotationNumber(rotation);
		criteria.setSourceSystem(MPCConstants.SYSTEM_MPC);
		criteria.setPrivateKey(MpcPropertyUtil
				.getPropertyFromConfiguration(MPCConstants.CBBS_ACCESS_KEY));
		// criteria.setTerminal(terminalId);
		return criteria;

	}

	/**
	 * This method is used to get the Vessels ETA.
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static List<VesselLocationDetail> getVesselsETA(
			List<String> requestList) throws IOException {
		// if(dataBaseFactory !=null)
		init();
		log.debug("Inside the getVesselsETA API --------- " + requestList);
		FilterCriteria criteria = new FilterCriteria();
		List<VesselLocationDetail> vesselDetail = new ArrayList<VesselLocationDetail>();
		VesselLocationDetail vessel = null;
		if (requestList != null) {
			for (String request : requestList) {
				log.debug("INSIDE FOR LOOP WITH VESSEL : " + request);
				criteria.setVesselName(request);
				vessel = (VesselLocationDetail) crudOperation(SELECT_ONE,
						DataBaseFactory.DB_MPC, "getVesselDetails", null, null,
						request);
				log.debug("Returned VESSEL from DB : " + vessel);
				if (vessel != null
						&& (vessel.getAisEta() == null || vessel.getAisEta()
								.isEmpty()) && vessel.getEta() != null) {
					
					if (vessel.getAisVslOprEta() != null)
						vessel.setAisEta(vessel.getAisVslOprEta());
					else if (vessel.getEta() != null)
						vessel.setAisEta(vessel.getEta());
					
					//vessel.getAisVslOprEta();
					log.debug("AIS ETA IS NULL HENCE SETTING VTS ETA ");
				}
				vesselDetail.add(vessel);
			}
		}
		return vesselDetail;

	}

	
	public static List<PromisTwoBPADetail> getPromisTwoDetails(
			final boolean isSaveRequired, final boolean isCBBSRequired)
			throws Exception {
		// Getting the Database Factory which contains BPA, Promis, MPC Database
		// Connection
		CustomThreadFactory cFactory = new CustomThreadFactory(
				"PROMIS-THREAD-POOL", Thread.MAX_PRIORITY);
		ExecutorService bpaServiceThreadPool = Executors.newFixedThreadPool(
				MAX_THREADS, cFactory);
		init();
		PromisBPAServiceHelper helper = new PromisBPAServiceHelper();
		// helper.initThreadPool();
		Long startTime = System.currentTimeMillis();
		List<FutureTask<PromiseBPAServiceTask>> runningTaskList = new ArrayList<FutureTask<PromiseBPAServiceTask>>();

		// Retrieving Promis Details
		final List<PromisTwoBPADetail> bpaDetails = fetchPromisTwoDetails();

		//fetchTerminalsforBPATwo(bpaDetails);
		fetchETAforPromisTwo(bpaDetails);
		
		if (log.isDebugEnabled())
			log.debug("getPromisDetails API invokation Start Time : "
					+ startTime);
		// Start thread for fetchETA
		/*
		 * FutureTask<PromiseBPAServiceTask> futureTask_1 = helper.processTask(
		 * bpaDetails, FECTH_ETA, isSaveRequired,isCBBSRequired);
		 * runningTaskList.add(futureTask_1);
		 * bpaServiceThreadPool.submit(futureTask_1);
		 */

		// Start thread for fetchCBBSData
		FutureTask<PromiseBPAServiceTask> futureTask_2 = helper.processTaskTwo(
				bpaDetails, FETCH_CBBS_DATA, isSaveRequired, isCBBSRequired); // FETCH_CBBS_DATA
		runningTaskList.add(futureTask_2);
		bpaServiceThreadPool.submit(futureTask_2);

		FutureTask<PromiseBPAServiceTask> futureTask_31 = helper.processTaskTwo(
				bpaDetails, GROUP_TERMINAL_BPA, isSaveRequired, isCBBSRequired);// changed
		runningTaskList.add(futureTask_31);
		bpaServiceThreadPool.submit(futureTask_31);

		// Group the Terminals and Fetch BPA Details
		FutureTask<PromiseBPAServiceTask> futureTask_32 = helper.processTaskTwo(
				bpaDetails, FETCH_SCORING, isSaveRequired, isCBBSRequired);
		runningTaskList.add(futureTask_32);
		bpaServiceThreadPool.submit(futureTask_32);

		// Start thread for constructBPAStatus
		FutureTask<PromiseBPAServiceTask> futureTask_4 = helper.processTaskTwo(
				bpaDetails, CONSTRUCT_BPA_STATUS, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_4);
		bpaServiceThreadPool.submit(futureTask_4);

		// Start thread for constructPriorityDate
		FutureTask<PromiseBPAServiceTask> futureTask_5 = helper.processTaskTwo(
				bpaDetails, CONSTRUCT_PRIORITY_DATE, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_5);
		bpaServiceThreadPool.submit(futureTask_5);

		// Start thread for loadDropDownValues
		FutureTask<PromiseBPAServiceTask> futureTask_6 = helper.processTaskTwo(
				bpaDetails, LOAD_DROP_DOWN_VALUES, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_6);
		bpaServiceThreadPool.submit(futureTask_6);

		/*
		 * // Start thread for loadDropDownValues
		 * FutureTask<PromiseBPAServiceTask> futureTask_7 =
		 * helper.processTask(bpaDetails, APPLY_SORTING, false);
		 * runningTaskList.add(futureTask_7);
		 * bpaServiceThreadPool.submit(futureTask_7);
		 */

		int counter = 0;
		for (; counter < runningTaskList.size(); counter++) {
			try {
				PromiseBPAServiceTask task = runningTaskList.get(counter).get();

				if (task.getTaskStatus() == TaskCompletionStatus.SUCCEEDED
						|| task.getTaskStatus() == TaskCompletionStatus.FAILED) {
					runningTaskList.remove(counter);
					counter--;
				} else if (task.getTaskStatus() == TaskCompletionStatus.CANCELLED) {
					runningTaskList.remove(counter);
					counter--;
				}
			} catch (Exception e) {

			}
		}
		Long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("getPromiseDetails API completion time : " + endTime);
		if (log.isInfoEnabled())
			log.info("Time Taken by getPromiseDetails api in milli seconds: "
					+ (endTime - startTime) + " and in sec :"
					+ (endTime - startTime) / 1000L);
		// bpaServiceThreadPool.getQueue().clear();
		bpaServiceThreadPool.shutdown();
		bpaServiceThreadPool.awaitTermination(10, TimeUnit.SECONDS);
		log.info("Brought down the thread pool successfully ..");
		if (!bpaServiceThreadPool.awaitTermination(60, TimeUnit.SECONDS)) {
			log.info("Wait a while for existing tasks to terminate");
			bpaServiceThreadPool.shutdownNow();
			log.debug("After shutdownNow API ");
		}
		helper.shutdownAndAwaitTermination(bpaServiceThreadPool);
		//applySorting(bpaDetails);
		return bpaDetails;
	}
	
	


	
	/**
	 * This method is called from Blueprint.xml. The below task are done in this
	 * method.
	 * 
	 * 1) Fetching Promis Details 2) Fetching Terminals from MPC 3) Fetching New
	 * ETA from MPC 4) Grouping Terminals 5) Fetching Data from BPA 6)
	 * Constructing final object. 7) Set into the exchange body.
	 * 
	 * @param request
	 * @param exchange
	 * @throws Exception
	 * @author [Muthukumar Chellappa]
	 */
	public static List<PromisBPADetail> getPromisDetails(
			final boolean isSaveRequired, final boolean isCBBSRequired)
			throws Exception {
		// Getting the Database Factory which contains BPA, Promis, MPC Database
		// Connection
		CustomThreadFactory cFactory = new CustomThreadFactory(
				"PROMIS-THREAD-POOL", Thread.MAX_PRIORITY);
		ExecutorService bpaServiceThreadPool = Executors.newFixedThreadPool(
				MAX_THREADS, cFactory);
		init();
		PromisBPAServiceHelper helper = new PromisBPAServiceHelper();
		// helper.initThreadPool();
		Long startTime = System.currentTimeMillis();
		List<FutureTask<PromiseBPAServiceTask>> runningTaskList = new ArrayList<FutureTask<PromiseBPAServiceTask>>();

		// Retrieving Promis Details
		final List<PromisBPADetail> bpaDetails = fetchPromisDetails();

		fetchTerminals(bpaDetails);
		fetchETA(bpaDetails);
		if (log.isDebugEnabled())
			log.debug("getPromisDetails API invokation Start Time : "
					+ startTime);
		// Start thread for fetchETA
		/*
		 * FutureTask<PromiseBPAServiceTask> futureTask_1 = helper.processTask(
		 * bpaDetails, FECTH_ETA, isSaveRequired,isCBBSRequired);
		 * runningTaskList.add(futureTask_1);
		 * bpaServiceThreadPool.submit(futureTask_1);
		 */

		// Start thread for fetchCBBSData
		FutureTask<PromiseBPAServiceTask> futureTask_2 = helper.processTask(
				bpaDetails, FETCH_CBBS_DATA, isSaveRequired, isCBBSRequired); // FETCH_CBBS_DATA
		runningTaskList.add(futureTask_2);
		bpaServiceThreadPool.submit(futureTask_2);

		FutureTask<PromiseBPAServiceTask> futureTask_31 = helper.processTask(
				bpaDetails, GROUP_TERMINAL_BPA, isSaveRequired, isCBBSRequired);// changed
		runningTaskList.add(futureTask_31);
		bpaServiceThreadPool.submit(futureTask_31);

		// Group the Terminals and Fetch BPA Details
		FutureTask<PromiseBPAServiceTask> futureTask_32 = helper.processTask(
				bpaDetails, FETCH_SCORING, isSaveRequired, isCBBSRequired);
		runningTaskList.add(futureTask_32);
		bpaServiceThreadPool.submit(futureTask_32);

		// Start thread for constructBPAStatus
		FutureTask<PromiseBPAServiceTask> futureTask_4 = helper.processTask(
				bpaDetails, CONSTRUCT_BPA_STATUS, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_4);
		bpaServiceThreadPool.submit(futureTask_4);

		// Start thread for constructPriorityDate
		FutureTask<PromiseBPAServiceTask> futureTask_5 = helper.processTask(
				bpaDetails, CONSTRUCT_PRIORITY_DATE, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_5);
		bpaServiceThreadPool.submit(futureTask_5);

		// Start thread for loadDropDownValues
		FutureTask<PromiseBPAServiceTask> futureTask_6 = helper.processTask(
				bpaDetails, LOAD_DROP_DOWN_VALUES, isSaveRequired,
				isCBBSRequired);
		runningTaskList.add(futureTask_6);
		bpaServiceThreadPool.submit(futureTask_6);

		/*
		 * // Start thread for loadDropDownValues
		 * FutureTask<PromiseBPAServiceTask> futureTask_7 =
		 * helper.processTask(bpaDetails, APPLY_SORTING, false);
		 * runningTaskList.add(futureTask_7);
		 * bpaServiceThreadPool.submit(futureTask_7);
		 */

		int counter = 0;
		for (; counter < runningTaskList.size(); counter++) {
			try {
				PromiseBPAServiceTask task = runningTaskList.get(counter).get();

				if (task.getTaskStatus() == TaskCompletionStatus.SUCCEEDED
						|| task.getTaskStatus() == TaskCompletionStatus.FAILED) {
					runningTaskList.remove(counter);
					counter--;
				} else if (task.getTaskStatus() == TaskCompletionStatus.CANCELLED) {
					runningTaskList.remove(counter);
					counter--;
				}
			} catch (Exception e) {

			}
		}
		Long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("getPromiseDetails API completion time : " + endTime);
		if (log.isInfoEnabled())
			log.info("Time Taken by getPromiseDetails api in milli seconds: "
					+ (endTime - startTime) + " and in sec :"
					+ (endTime - startTime) / 1000L);
		// bpaServiceThreadPool.getQueue().clear();
		bpaServiceThreadPool.shutdown();
		bpaServiceThreadPool.awaitTermination(10, TimeUnit.SECONDS);
		log.info("Brought down the thread pool successfully ..");
		if (!bpaServiceThreadPool.awaitTermination(60, TimeUnit.SECONDS)) {
			log.info("Wait a while for existing tasks to terminate");
			bpaServiceThreadPool.shutdownNow();
			log.debug("After shutdownNow API ");
		}
		helper.shutdownAndAwaitTermination(bpaServiceThreadPool);
		applySorting(bpaDetails);
		return bpaDetails;
	}
	


	void shutdownAndAwaitTermination(ExecutorService pool) {
		log.info("Inside the shutdownAndAwaitTermination API");
		try {
			if (!pool.awaitTermination(60, TimeUnit.SECONDS))
				log.info("Pool did not terminate");
			else
				log.info("Pool Terminated Successfully!");
		} catch (InterruptedException ie) {
			pool.shutdownNow();
			Thread.currentThread().interrupt();
			log.error("Brought down the pool forcefully !");
		}
	}

	/**
	 * This method is used to retrieve the drop down values from Database. This
	 * values are show in the location drop down box
	 * 
	 * @param bpaDetails
	 * @author Itpeople.Muthukumar
	 */
	private static void loadDropDownValues(List<PromisBPADetail> bpaDetails) {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside loadDropDownValues API with start time :"
					+ startTime);
		List<BPADetail> dtoList = (List<BPADetail>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_PROMIS, "getLocationDesc", null, null, null);

		if (dtoList != null && !dtoList.isEmpty() && bpaDetails != null
				&& !bpaDetails.isEmpty()) {

			PromisBPADetail bpaDetail = bpaDetails.get(0);
			List<String> dropDownList = new ArrayList<String>();
			bpaDetail.setDropDownTypes(dropDownList);

			for (BPADetail detail : dtoList) {
				if (detail != null && detail.getDropDownLocation() != null) {
					bpaDetail.getDropDownTypes().add(
							detail.getDropDownLocation());
				}
			}
		}
		long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("loadDropDownValues End Time : " + endTime);
		log.info("Time Taken by loadDropDownValues API in milli seconds : "
				+ (endTime - startTime));
	}

	/**
	 * Sorting based on Priority date.
	 * 
	 * @param bpaDetails
	 */
	private static void applySorting(List<PromisBPADetail> bpaDetails) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside applySorting API with start time :" + startTime);
		if (bpaDetails != null) {
			Collections.sort(bpaDetails);

			int i = 1;
			for (PromisBPADetail bpaDetail : bpaDetails) {
				if (bpaDetail != null) {
					bpaDetail.setOrder(i++);
					if (bpaDetail.getBerthDateObject() != null) {
						bpaDetail.setBerthDate(dateFormat.format(bpaDetail
								.getBerthDateObject()));
					}
				}
			}
		}
		long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug(" applySorting End Time : " + endTime);
		log.info("Time Taken by applySorting API in milli seconds : "
				+ (endTime - startTime));
	}

	/**
	 * Construct Priority date based on status, Berthed, Planned or Unplanned.
	 * if Berthed, ETC is considered as priority date. if Planned or Unplanned,
	 * new eta has value, it is considered as Priority date. else original eta
	 * is considered as priority date.
	 * 
	 * @param bpaDetails
	 * @throws ParseException
	 */
	private static void constructPriorityDate(List<PromisBPADetail> bpaDetails)
			throws ParseException {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside constructPriorityDate API with start time :"
					+ startTime);
		if (bpaDetails != null) {

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-yyyy HH:mm");

			for (PromisBPADetail bpaDetail : bpaDetails) {
				if (bpaDetail != null && bpaDetail.getStatus() != null) {

					if (bpaDetail.getStatus().trim()
							.equalsIgnoreCase("BERTHED")) {

						if (bpaDetail.getEtc() != null
								&& bpaDetail.getEtc().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getEtc()));
						}

					} else if (bpaDetail.getStatus().trim()
							.equalsIgnoreCase("UNPLANNED")
							|| bpaDetail.getStatus().trim()
									.equalsIgnoreCase("PLANNED")) {

						if (bpaDetail.getNewETA() != null
								&& bpaDetail.getNewETA().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getNewETA()));
						} else if (bpaDetail.getEtaDate() != null
								&& bpaDetail.getEtaDate().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getEtaDate()));
						}
					}
				}
			}
		}
		long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug(" constructPriorityDate End Time : " + endTime);
		log.info("Time Takne by constructPriorityDate API in milli seconds : "
				+ (endTime - startTime));
	}
	/*tariq*/
	private static void constructPriorityDateTwo(List<PromisTwoBPADetail> bpaDetails)
			throws ParseException {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside constructPriorityDate API with start time :"
					+ startTime);
		if (bpaDetails != null) {

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-yyyy HH:mm");

			for (PromisTwoBPADetail bpaDetail : bpaDetails) {
				if (bpaDetail != null && bpaDetail.getStatus() != null) {

					if (bpaDetail.getStatus().trim()
							.equalsIgnoreCase("BERTHED")) {

						if (bpaDetail.getEtc() != null
								&& bpaDetail.getEtc().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getEtc()));
						}

					} else if (bpaDetail.getStatus().trim()
							.equalsIgnoreCase("UNPLANNED")
							|| bpaDetail.getStatus().trim()
									.equalsIgnoreCase("PLANNED")) {

						if (bpaDetail.getNewETA() != null
								&& bpaDetail.getNewETA().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getNewETA()));
						} else if (bpaDetail.getEtaDate() != null
								&& bpaDetail.getEtaDate().trim().length() > 0) {
							bpaDetail.setPriorityDate(dateFormat
									.parse(bpaDetail.getEtaDate()));
						}
					}
				}
			}
		}
		long endTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug(" constructPriorityDate End Time : " + endTime);
		log.info("Time Takne by constructPriorityDate API in milli seconds : "
				+ (endTime - startTime));
	}
	/*tariq*/

	/**
	 * This method is used to get the ETA from the MPC
	 * 
	 * @param bpaDetails
	 */
	@SuppressWarnings("unchecked")
	private static void fetchETA(List<PromisBPADetail> bpaDetails) {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside fetchETA API with start time :" + startTime);
			List<VesselLocationDetail> vessel = null;
			FilterCriteria criteria = null;
			for (PromisBPADetail bpaDetail : bpaDetails) {
				// VTS ETA
				criteria = new FilterCriteria();
				criteria.setVesselName(bpaDetail.getVesselName());
				criteria.setImoCode(bpaDetail.getImoCode());
				vessel = (List<VesselLocationDetail>) crudOperation(
						SELECT_LIST, DataBaseFactory.DB_MPC,
						"getVtsAndAisDetail", criteria, null, null);
				for (VesselLocationDetail vesselLocationDetail : vessel) {
					if (vesselLocationDetail.getLatitude() != null
							&& !vesselLocationDetail.getLatitude().trim()
									.isEmpty()) {
						bpaDetail.setLatitude(vesselLocationDetail
								.getLatitude());
					}
					if (vesselLocationDetail.getLongitude() != null
							&& !vesselLocationDetail.getLongitude().trim()
									.isEmpty()) {
						bpaDetail.setLongitude(vesselLocationDetail
								.getLongitude());
					}
					if (vesselLocationDetail.getSourceSystem() != null
							&& "AIS".equalsIgnoreCase(vesselLocationDetail
									.getSourceSystem().trim())
							) {
						
						bpaDetail.setAisVslOprEta(vesselLocationDetail.getAisVslOprEta());
						bpaDetail.setAisAvgSpeed(vesselLocationDetail.getAisAvgSpeed());          
						bpaDetail.setAisVesselOperator(vesselLocationDetail.getAisVesselOperator());
						bpaDetail.setAisUpdateTime(vesselLocationDetail.getAisUpdateTime());
						bpaDetail.setAisEta(vesselLocationDetail.getEta());
						bpaDetail.setAisPreviousAtd(vesselLocationDetail.getAisPreviousAtd());
						
						bpaDetail.setAisDistanceToNextPort(vesselLocationDetail.getAisDistanceToNextPort());
						bpaDetail.setAisNextPort(vesselLocationDetail.getAisNextPort());
						bpaDetail.setAisPrevPort(vesselLocationDetail.getAisPrevPort());
						
						bpaDetail.setAisLocation(vesselLocationDetail.getAisLocation());
						bpaDetail.setAisError(vesselLocationDetail.getAisError());
						
						

						
					}
					if (vesselLocationDetail.getSourceSystem() != null
							&& "VTS".equalsIgnoreCase(vesselLocationDetail
									.getSourceSystem().trim())
							&& vesselLocationDetail.getEta() != null) {
						// New Added- Convert Date Format
						bpaDetail.setNewETA(DateUtilities.convertDateFormat(
								vesselLocationDetail.getEta(),
								MPCConstants.DATE_FORMAT_VSL_LOC_TBL,
								MPCConstants.DATE_TIME_FORMAT_DEFAULT));
					}

					if (bpaDetail.getNewETA() != null && log.isDebugEnabled())
						log.info(" VTS ETA : " + bpaDetail.getNewETA());

					if (bpaDetail.getAisEta() != null && log.isDebugEnabled())
						log.info("AIS ETA : " + bpaDetail.getAisEta());
					
					

				}

				geofenceData = (List<GeoFenceData>) crudOperation(SELECT_LIST,
						DataBaseFactory.DB_MPC, "getGeofenceData", null, null,
						null);

				setVesselLocation(bpaDetail, geofenceData);
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("fetchETA End Time : " + endTime);
			log.info("Time Taken by fetchETA API in milli seconds : "
					+ (endTime - startTime));
		}

		catch (Exception e) {
			log.info("Exception insid fetchETA API :" + stackTraceToString(e));
		}
	}
/*tariq*/
	@SuppressWarnings("unchecked")
	private static void fetchETAforPromisTwo(List<PromisTwoBPADetail> bpaDetails) {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside fetchETA API with start time :" + startTime);
			List<VesselLocationDetail> vessel = null;
			FilterCriteria criteria = null;
			for (PromisTwoBPADetail bpaDetail : bpaDetails) {
				// VTS ETA
				
				criteria = new FilterCriteria();
				criteria.setVesselName(bpaDetail.getVesselName());
				criteria.setImoCode(bpaDetail.getImoCode());
				vessel = (List<VesselLocationDetail>) crudOperation(
						SELECT_LIST, DataBaseFactory.DB_MPC,
						"getVtsAndAisDetail", criteria, null, null);
				for (VesselLocationDetail vesselLocationDetail : vessel) {
					if (vesselLocationDetail.getLatitude() != null
							&& !vesselLocationDetail.getLatitude().trim()
									.isEmpty()) {
						bpaDetail.setLatitude(vesselLocationDetail
								.getLatitude());
					}
					if (vesselLocationDetail.getLongitude() != null
							&& !vesselLocationDetail.getLongitude().trim()
									.isEmpty()) {
						bpaDetail.setLongitude(vesselLocationDetail
								.getLongitude());
					}
					if (vesselLocationDetail.getSourceSystem() != null
							&& "AIS".equalsIgnoreCase(vesselLocationDetail
									.getSourceSystem().trim())
							) {
						
						bpaDetail.setAisVslOprEta(vesselLocationDetail.getAisVslOprEta());
						bpaDetail.setAisAvgSpeed(vesselLocationDetail.getAisAvgSpeed());          
						bpaDetail.setAisVesselOperator(vesselLocationDetail.getAisVesselOperator());
						bpaDetail.setAisUpdateTime(vesselLocationDetail.getAisUpdateTime());
						bpaDetail.setAisEta(vesselLocationDetail.getEta());
						
						
						
						bpaDetail.setAisPreviousAtd(vesselLocationDetail.getAisPreviousAtd());
						
						bpaDetail.setAisDistanceToNextPort(vesselLocationDetail.getAisDistanceToNextPort());
						bpaDetail.setAisNextPort(vesselLocationDetail.getAisNextPort());
						bpaDetail.setAisPrevPort(vesselLocationDetail.getAisPrevPort());
						
						bpaDetail.setAisLocation(vesselLocationDetail.getAisLocation());
						bpaDetail.setAisError(vesselLocationDetail.getAisError());
						
						

						
					}
					if (vesselLocationDetail.getSourceSystem() != null
							&& "VTS".equalsIgnoreCase(vesselLocationDetail
									.getSourceSystem().trim())
							&& vesselLocationDetail.getEta() != null) {
						// New Added- Convert Date Format
						bpaDetail.setNewETA(DateUtilities.convertDateFormat(
								vesselLocationDetail.getEta(),
								MPCConstants.DATE_FORMAT_VSL_LOC_TBL,
								MPCConstants.DATE_TIME_FORMAT_DEFAULT));
					}

					if (bpaDetail.getNewETA() != null && log.isDebugEnabled())
						log.debug(" VTS ETA : " + bpaDetail.getNewETA());

					if (bpaDetail.getAisEta() != null && log.isDebugEnabled())
						log.debug("AIS ETA : " + bpaDetail.getAisEta());
					
					
				}

				geofenceData = (List<GeoFenceData>) crudOperation(SELECT_LIST,
						DataBaseFactory.DB_MPC, "getGeofenceData", null, null,
						null);

				setVesselLocationforPromis2(bpaDetail, geofenceData);
			
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("fetchETA End Time : " + endTime);
			log.info("Time Taken by fetchETA API in milli seconds : "
					+ (endTime - startTime));
		}

		catch (Exception e) {
			log.info("Exception insid fetchETA API :" + stackTraceToString(e));
		}
	}
	
	/**
	 * This method is used to construct the Work list Score for each Vessel
	 * 
	 * @param bpaDetails
	 * @author Vinculum.Ashok
	 * @throws ParseException
	 */

	private static void ConstructWLScoreTwo(List<PromisTwoBPADetail> bpaDetails)
			throws ParseException {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isInfoEnabled()) {
				log.info("Inside ConstructWLScore API with start time :"
						+ startTime);
			}
			FilterCriteria criteria = new FilterCriteria();
			for (PromisTwoBPADetail bpaDetail : bpaDetails) {
				criteria.setVesselName(bpaDetail.getVesselName());

				// Get SLA Status

				VesselLocationDetail vesselSla = (VesselLocationDetail) crudOperation(
						SELECT_ONE, DataBaseFactory.DB_MPC,
						"getVslSlaStatusByVslName", criteria, null, null);
				if (vesselSla != null) {
					String slaStatus = vesselSla.getSlaStatus();
					if (slaStatus != null
							&& slaStatus
									.equalsIgnoreCase(MPCConstants.SLA_FLAG)) {
						bpaDetail.setSlaStatus(MPCConstants.STATUS_SLA);
					} else {
						bpaDetail.setSlaStatus(MPCConstants.STATUS_NONSLA);
					}
				} else {
					bpaDetail.setSlaStatus(MPCConstants.STATUS_NONSLA);
				}
				if (log.isDebugEnabled())
					log.debug("SLA   for vessel " + bpaDetail.getVesselName()
							+ " IS :" + bpaDetail.getSlaStatus());

				// Get Proforma
				SimpleDateFormat format1 = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
				
				
				
				criteria.setVeta(bpaDetail.getNewETA() != null ? format
						.format(format1.parse(bpaDetail.getNewETA())) : format
						.format(bpaDetail.getEtaDateObject()));
				try {
					criteria.setScoreAttrVslType(bpaDetail.getVesselType());
					criteria.setScoreAttrSrvType(bpaDetail.getServiceType());
					criteria.setScoreAttrSlaType(bpaDetail.getSlaStatus());
					criteria.setScoreAttrPrfmType(bpaDetail.getProforma());
					criteria.setScoreAttrCurrStatus(bpaDetail.getStatus());
					criteria.setTerminalId(bpaDetail.getVisit_terminal());

					VesselLocationDetail vesselScore = (VesselLocationDetail) crudOperation(
							"ONE", "MPCDB", "getVessslScoreTwo", criteria, null,
							null);
					if (vesselScore != null) {
						bpaDetail.setPriority(vesselScore.getScore());
					} else {
						bpaDetail.setPriority("0");
					}
					if (log.isDebugEnabled())
						log.debug("PRIORITY  for vessel "
								+ bpaDetail.getVesselName() + " IS :"
								+ bpaDetail.getPriority());
				}

				catch (Exception er) {
					log.error("Exception Priority  : " + stackTraceToString(er));
				}

				try {
					log.debug("Calling getProforma stored procedure : "
							+ bpaDetail.getVesselName());
					Boolean proforma_flag = true;
					proforma_flag = Boolean.parseBoolean(MpcPropertyUtil.getPropertyFromConfiguration("proforma_flag"));
					if(proforma_flag){
					log.info("proforma_flag value is :"+proforma_flag);
					criteria.setVsrc(bpaDetail.getInVesselService());
					crudOperation("ONE", "BPADB", "getProforma", criteria,
							null, null);
					bpaDetail.setProforma(criteria.getProforma());
					}else{
						log.info("proforma_flag value is :"+proforma_flag);
					}
					if (log.isDebugEnabled())
						log.debug("PROFORMA  for vessel "
								+ bpaDetail.getVesselName() + " IS :"
								+ bpaDetail.getProforma());
				} catch (Exception e) {
					log.error("Exception while setting Proforma for vessel : "
							+ bpaDetail.getVesselName() + " is : "
							+ e.getMessage());
					e.printStackTrace();
				}
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled()) {
				log.debug("ConstructWLScore End Time : " + endTime);
			}
			log.info("Time Taken by ConstructWLScore API in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception inside ConstructWLScore : "
					+ stackTraceToString(e));
			throw e;
		}
	}
	/*tariq*/
	
	/**
	 * This method is used to construct the Work list Score for each Vessel
	 * 
	 * @param bpaDetails
	 * @author Vinculum.Ashok
	 * @throws ParseException
	 */

	private static void ConstructWLScore(List<PromisBPADetail> bpaDetails)
			throws ParseException {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isInfoEnabled()) {
				log.info("Inside ConstructWLScore API with start time :"
						+ startTime);
			}
			FilterCriteria criteria = new FilterCriteria();
			for (PromisBPADetail bpaDetail : bpaDetails) {
				criteria.setVesselName(bpaDetail.getVesselName());

				// Get SLA Status

				VesselLocationDetail vesselSla = (VesselLocationDetail) crudOperation(
						SELECT_ONE, DataBaseFactory.DB_MPC,
						"getVslSlaStatusByVslName", criteria, null, null);
				if (vesselSla != null) {
					String slaStatus = vesselSla.getSlaStatus();
					if (slaStatus != null
							&& slaStatus
									.equalsIgnoreCase(MPCConstants.SLA_FLAG)) {
						bpaDetail.setSlaStatus(MPCConstants.STATUS_SLA);
					} else {
						bpaDetail.setSlaStatus(MPCConstants.STATUS_NONSLA);
					}
				} else {
					bpaDetail.setSlaStatus(MPCConstants.STATUS_NONSLA);
				}
				if (log.isDebugEnabled())
					log.debug("SLA   for vessel " + bpaDetail.getVesselName()
							+ " IS :" + bpaDetail.getSlaStatus());

				// Get Proforma

				SimpleDateFormat format1 = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
				criteria.setVeta(bpaDetail.getNewETA() != null ? format
						.format(format1.parse(bpaDetail.getNewETA())) : format
						.format(bpaDetail.getEtaDateObject()));
				try {
					criteria.setScoreAttrVslType(bpaDetail.getVesselType());
					criteria.setScoreAttrSrvType(bpaDetail.getServiceType());
					criteria.setScoreAttrSlaType(bpaDetail.getSlaStatus());
					criteria.setScoreAttrPrfmType(bpaDetail.getProforma());
					criteria.setScoreAttrCurrStatus(bpaDetail.getStatus());
			

					VesselLocationDetail vesselScore = (VesselLocationDetail) crudOperation(
							"ONE", "MPCDB", "getVessslScore", criteria, null,
							null);
					if (vesselScore != null) {
						bpaDetail.setPriority(vesselScore.getScore());
					} else {
						bpaDetail.setPriority("0");
					}
					if (log.isDebugEnabled())
						log.debug("PRIORITY  for vessel "
								+ bpaDetail.getVesselName() + " IS :"
								+ bpaDetail.getPriority());
				}

				catch (Exception er) {
					log.error("Exception Priority  : " + stackTraceToString(er));
				}

				try {
					log.debug("Calling getProforma stored procedure : "
							+ bpaDetail.getVesselName());
					Boolean proforma_flag = true;
					proforma_flag = Boolean.parseBoolean(MpcPropertyUtil.getPropertyFromConfiguration("proforma_flag"));
					if(proforma_flag){
					log.info("proforma_flag value is :"+proforma_flag);
					criteria.setVsrc(bpaDetail.getInVesselService());
					crudOperation("ONE", "BPADB", "getProforma", criteria,
							null, null);
					bpaDetail.setProforma(criteria.getProforma());
					}else{
						log.info("proforma_flag value is :"+proforma_flag);
					}
					if (log.isDebugEnabled())
						log.debug("PROFORMA  for vessel "
								+ bpaDetail.getVesselName() + " IS :"
								+ bpaDetail.getProforma());
				} catch (Exception e) {
					log.error("Exception while setting Proforma for vessel : "
							+ bpaDetail.getVesselName() + " is : "
							+ e.getMessage());
					e.printStackTrace();
				}
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled()) {
				log.debug("ConstructWLScore End Time : " + endTime);
			}
			log.info("Time Taken by ConstructWLScore API in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception inside ConstructWLScore : "
					+ stackTraceToString(e));
			throw e;
		}
	}

	public static String stackTraceToString(Exception ex) {
		String result = ex.toString() + "\n";
		StackTraceElement[] trace = ex.getStackTrace();
		for (int i = 0; i < trace.length; i++) {
			result += trace[i].toString() + "\n";
		}
		return result;
	}

	/**
	 * This method used to construct the BPA Status.
	 * 
	 * @param promisList
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static void constructBPAStatus(List<PromisBPADetail> promisList,
			boolean isSaveRequired) throws ClassNotFoundException,
			ParseException, SQLException, IOException {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isInfoEnabled())
				log.info("Inside constructBPAStatus API with start time :"
						+ startTime);
			for (PromisBPADetail bpaDetail : promisList) {
				if (bpaDetail != null && bpaDetail.getSourceSystem() != null
						&& bpaDetail.getSourceSystem().contains("SPARCS")) {
					constructSparcsStatus(bpaDetail, isSaveRequired);
				} else {
					constructNonSparcsStatus(bpaDetail, isSaveRequired);
				}

			}

			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("constructBPAStatus End Time : " + endTime);
			log.info("Time Taken by constructBPAStatus API in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception inside constructBPAStatus : "
					+ stackTraceToString(e));
			throw e;
		}
	}
	
	
	private static void constructBPATWOStatus(List<PromisTwoBPADetail> promisList,
			boolean isSaveRequired) throws ClassNotFoundException,
			ParseException, SQLException, IOException {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isInfoEnabled())
				log.debug("Inside constructBPAStatus API with start time :"
						+ startTime);
			for (PromisTwoBPADetail bpaDetail : promisList) {
				if (bpaDetail != null && bpaDetail.getSourceSystem() != null
						&& bpaDetail.getSourceSystem().contains("SPARCS")) {
					log.debug("ETC sorce system===from constructBPATWOStatus"+bpaDetail.getSourceSystem());
					constructSparcsStatusBPATwo(bpaDetail, isSaveRequired);
					
				} else {
					log.debug("ETC inelse--constructNonSparcsStatusBPATwo()--");
					bpaDetail.setTerminalId(bpaDetail.getVisit_terminal());
					constructNonSparcsStatusBPATwo(bpaDetail, isSaveRequired);
				}

			}

			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("constructBPAStatus End Time : " + endTime);
			log.info("Time Taken by constructBPAStatus API in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception inside constructBPAStatus : "
					+ stackTraceToString(e));
			throw e;
		}
	}

	/**
	 * This method is used to constrct the Sparcs Status.
	 * 
	 * @param bpaDetail
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * @author [Muthukumar Chellappa]
	 */
	private static void constructSparcsStatus(PromisBPADetail bpaDetail,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException {
		try {
			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			criteria.setTerminalId(bpaDetail.getTerminalId());

			List<BPADetail> dtoList = (List<BPADetail>) crudOperation(
					SELECT_LIST, DataBaseFactory.BPA2_MPC,
					"getBPAMovesForNonSparcs", criteria, null, null);

			constructTotalMovesToGoForSparcs(bpaDetail, dtoList, isSaveRequired);
		} catch (Exception e) {
			log.error("Exception inside constructSparcsStatus API :"
					+ stackTraceToString(e));
			throw e;
		}
	}

	
	private static void constructSparcsStatusBPATwo(PromisTwoBPADetail bpaDetail,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException {
		try {
			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			criteria.setTerminalId(bpaDetail.getTerminalId());

			List<BPADetail> dtoList = (List<BPADetail>) crudOperation(
					SELECT_LIST, DataBaseFactory.BPA2_MPC,
					"getBPAMovesForNonSparcs", criteria, null, null);

			//constructTotalMovesToGoForSparcs(bpaDetail, dtoList, isSaveRequired);
			constructTotalMovesToGoForSparcsBPATwo(bpaDetail, dtoList, isSaveRequired);
		} catch (Exception e) {
			log.error("Exception inside constructSparcsStatus API :"
					+ stackTraceToString(e));
			throw e;
		}
	}
	/**
	 * This method is used to Constrct Non Sparcs Status.
	 * 
	 * @param bpaDetail
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 * @throws ParseException
	 */
	private static void constructNonSparcsStatus(PromisBPADetail bpaDetail,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException, ParseException {
		try {
			log.debug("Inside constructNonSparcsStatus with Rotation: "
					+ bpaDetail.getRotation());
			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			if (bpaDetail.getTerminalId() == null
					|| bpaDetail.getTerminalId().trim() != "") {
				criteria.setTerminalId(retriveTerminalId(bpaDetail));
				log.debug("INPUT TERMINAL ID IS NULL hence called and set for roation : "
						+ bpaDetail.getRotation()
						+ " new terminal Id --> "
						+ bpaDetail.getTerminalId());
			}
			List<BPADetail> dtoList = (List<BPADetail>) crudOperation(
					SELECT_LIST, DataBaseFactory.BPA2_MPC,
					"getBPAMovesForNonSparcs", criteria, null, null);
			constructTotalMovesToGoForNonSparcs(bpaDetail, dtoList,
					isSaveRequired);
		} catch (Exception e) {
			log.error("Exception inside constructNonSparcsStatus API :"
					+ stackTraceToString(e));
			throw e;
		}

	}
	
	
	private static void constructNonSparcsStatusBPATwo(PromisTwoBPADetail bpaDetail,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException, ParseException {
		try {
			bpaDetail.setTerminalId(bpaDetail.getVisit_terminal());
			log.info("Inside constructNonSparcsStatus with Rotation: "
					+ bpaDetail.getRotation()+"terminal="+bpaDetail.getTerminalId());
			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			if (bpaDetail.getTerminalId() == null
					|| bpaDetail.getTerminalId().trim() != "") {
				criteria.setTerminalId(retriveTerminalIdBPATwo(bpaDetail));
				log.info("INPUT TERMINAL ID IS NULL hence called and set for roation : "
						+ bpaDetail.getRotation()
						+ " new terminal Id --> "
						+ bpaDetail.getTerminalId()+"visit terminal=="+bpaDetail.getVisit_terminal());
			}
			List<BPADetail> dtoList = (List<BPADetail>) crudOperation(
					SELECT_LIST, DataBaseFactory.BPA2_MPC,
					"getBPAMovesForNonSparcs", criteria, null, null);
			log.info("ETC====: constructTotalMovesToGoForNonSparcsBPATwo=="
					+ dtoList.size()+"==="+dtoList);
			constructTotalMovesToGoForNonSparcsBPATwo(bpaDetail, dtoList,
					isSaveRequired);
		} catch (Exception e) {
			log.error("Exception inside constructNonSparcsStatus API :"
					+ stackTraceToString(e));
			throw e;
		}

	}

	/**
	 * This method is used to construct the Total moves to go for Non Sparcs.
	 * 
	 * @param bpaDetail
	 * @param dtoList
	 * 
	 * @author [Muthukumar Chellappa]
	 * @throws ParseException
	 */
	private static void constructTotalMovesToGoForNonSparcs(
			PromisBPADetail bpaDetail, List<BPADetail> dtoList,
			boolean isSaveRequired) throws ParseException {
		try {
			TreeSet<Long> treeset = new TreeSet<Long>();
			Map<Long, BPADetail> map = new HashMap<Long, BPADetail>();
			long totalMovesGo = 0;
			long qcWorking = 0;
			long doneMoves = 0;
			long highestMove = 0L;
			for (BPADetail bPADetail : dtoList) {

				treeset.add(bPADetail.getMovesToGo());
				map.put(bPADetail.getMovesToGo(), bPADetail);
				if (bPADetail.getMovesToGo() != null)
					totalMovesGo = totalMovesGo
							+ bPADetail.getMovesToGo().longValue();
				if (bPADetail.getDoneMoves() != null) {
					doneMoves = doneMoves
							+ bPADetail.getDoneMoves().longValue();
					if (bPADetail.getDoneMoves().longValue() > 0) {
						qcWorking = qcWorking + 1;
					}
				}
			}
			if (treeset.size() > 0)
				highestMove = treeset.last();

			bpaDetail.setTtMTG(totalMovesGo);
			bpaDetail.setDoneMoves(doneMoves);
			bpaDetail.setHhMTG(highestMove);
			bpaDetail.setQcAlloc(new Long(dtoList.size()));
			bpaDetail.setQcWorking(qcWorking);

			if (map.containsKey(highestMove)) {
				BPADetail detailDTO = map.get(highestMove);
				bpaDetail.setHhCrane(detailDTO.getQc());
				SimpleDateFormat dateFormat = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				SimpleDateFormat dateFormat1 = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date = dateFormat1.parse(detailDTO.getEtc());
				bpaDetail.setEtc(dateFormat.format(date));
			}

		} catch (Exception e) {
			log.error("Exception inside constructTotalMovesToGoForNonSparcs API "
					+ stackTraceToString(e));
			throw e;
		}
	}

	
	
	private static void constructTotalMovesToGoForNonSparcsBPATwo(
			PromisTwoBPADetail bpaDetail, List<BPADetail> dtoList,
			boolean isSaveRequired) throws ParseException {
		try {
			TreeSet<Long> treeset = new TreeSet<Long>();
			Map<Long, BPADetail> map = new HashMap<Long, BPADetail>();
			long totalMovesGo = 0;
			long qcWorking = 0;
			long doneMoves = 0;
			long highestMove = 0L;
			for (BPADetail bPADetail : dtoList) {

				treeset.add(bPADetail.getMovesToGo());
				map.put(bPADetail.getMovesToGo(), bPADetail);
				if (bPADetail.getMovesToGo() != null)
					totalMovesGo = totalMovesGo
							+ bPADetail.getMovesToGo().longValue();
				if (bPADetail.getDoneMoves() != null) {
					doneMoves = doneMoves
							+ bPADetail.getDoneMoves().longValue();
					if (bPADetail.getDoneMoves().longValue() > 0) {
						qcWorking = qcWorking + 1;
					}
				}
			}
			log.info("ETC===treeset.size() constructTotalMovesToGoForNonSparcsBPATwo"+treeset.size());
			if (treeset.size() > 0)
				highestMove = treeset.last();

			bpaDetail.setTtMTG(totalMovesGo);
			bpaDetail.setDoneMoves(doneMoves);
			bpaDetail.setHhMTG(highestMove);
			bpaDetail.setQcAlloc(new Long(dtoList.size()));
			bpaDetail.setQcWorking(qcWorking);

			if (map.containsKey(highestMove)) {
				BPADetail detailDTO = map.get(highestMove);
				bpaDetail.setHhCrane(detailDTO.getQc());
				SimpleDateFormat dateFormat = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				SimpleDateFormat dateFormat1 = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				log.info("ETC===from constructTotalMovesToGoForNonSparcsBPATwo"+detailDTO.getEtc());
				Date date = dateFormat1.parse(detailDTO.getEtc());
				bpaDetail.setEtc(dateFormat.format(date));
				
			}

		} catch (Exception e) {
			log.error("Exception inside constructTotalMovesToGoForNonSparcs API "
					+ stackTraceToString(e));
			throw e;
		}
	}
	/**
	 * This method is used to Construct Total MOves To Go For Sparcs.
	 * 
	 * @param promisBpaDetail
	 * @param dtoList
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static void constructTotalMovesToGoForSparcs(
			PromisBPADetail promisBpaDetail, List<BPADetail> dtoList,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException {
		try {

			if (dtoList != null && !dtoList.isEmpty()) {

				Long totalMovesGo = null;
				Long qcWorking = null;
				Long doneMoves = null;

				TreeSet<Long> treeset = new TreeSet<Long>();
				Map<Long, BPADetail> map = new HashMap<Long, BPADetail>();

				for (BPADetail bPADetail : dtoList) {

					Long movesToGo = new Long(0);

					if (bPADetail.getPlanMoves() != null
							&& bPADetail.getDoneMoves() != null) {
						movesToGo = (bPADetail.getPlanMoves() - bPADetail
								.getDoneMoves());
						totalMovesGo = totalMovesGo
								+ (bPADetail.getPlanMoves() - bPADetail
										.getDoneMoves());
					}

					treeset.add(movesToGo);

					map.put(movesToGo, bPADetail);

					if (bPADetail.getDoneMoves().longValue() > 0) {
						qcWorking = qcWorking + 1;
					}

					if (isSaveRequired) {
						FilterCriteria criteria = new FilterCriteria();
						criteria.setRotationNumbers(bPADetail
								.getRotationNumber());
						criteria.setpNam(bPADetail.getQc());
						criteria.setTerminalId(bPADetail.getTerminal());
						bPADetail.setEtcDateObject(retrieveETC(criteria,
								movesToGo));
					}
				}

				Long highestMove = treeset.last();

				promisBpaDetail.setTtMTG(totalMovesGo);

				promisBpaDetail.setHhMTG(highestMove);
				promisBpaDetail.setQcAlloc(new Long(dtoList.size()));
				promisBpaDetail.setQcWorking(qcWorking);

				if (map.containsKey(highestMove)) {
					BPADetail detailDTO = map.get(highestMove);
					promisBpaDetail.setHhCrane(detailDTO.getQc());
					
					promisBpaDetail.setEtc(detailDTO.getEtc());
				}

				fetchAndETC(promisBpaDetail, highestMove);

			}
		} catch (Exception e) {
			log.error("Exception inside constructTotalMovesToGoForSparcs API : "
					+ stackTraceToString(e));
			throw e;
		}
	}
	
	
	private static void constructTotalMovesToGoForSparcsBPATwo(
			PromisTwoBPADetail promisBpaDetail, List<BPADetail> dtoList,
			boolean isSaveRequired) throws ClassNotFoundException,
			SQLException, IOException {
		try {

			if (dtoList != null && !dtoList.isEmpty()) {

				Long totalMovesGo = null;
				Long qcWorking = null;
				Long doneMoves = null;

				TreeSet<Long> treeset = new TreeSet<Long>();
				Map<Long, BPADetail> map = new HashMap<Long, BPADetail>();

				for (BPADetail bPADetail : dtoList) {

					Long movesToGo = new Long(0);

					if (bPADetail.getPlanMoves() != null
							&& bPADetail.getDoneMoves() != null) {
						movesToGo = (bPADetail.getPlanMoves() - bPADetail
								.getDoneMoves());
						totalMovesGo = totalMovesGo
								+ (bPADetail.getPlanMoves() - bPADetail
										.getDoneMoves());
					}

					treeset.add(movesToGo);

					map.put(movesToGo, bPADetail);

					if (bPADetail.getDoneMoves().longValue() > 0) {
						qcWorking = qcWorking + 1;
					}

					if (isSaveRequired) {
						FilterCriteria criteria = new FilterCriteria();
						criteria.setRotationNumbers(bPADetail
								.getRotationNumber());
						criteria.setpNam(bPADetail.getQc());
						criteria.setTerminalId(bPADetail.getTerminal());
						bPADetail.setEtcDateObject(retrieveETC(criteria,
								movesToGo));
					}
				}

				Long highestMove = treeset.last();

				promisBpaDetail.setTtMTG(totalMovesGo);

				promisBpaDetail.setHhMTG(highestMove);
				promisBpaDetail.setQcAlloc(new Long(dtoList.size()));
				promisBpaDetail.setQcWorking(qcWorking);

				if (map.containsKey(highestMove)) {
					BPADetail detailDTO = map.get(highestMove);
					promisBpaDetail.setHhCrane(detailDTO.getQc());
					promisBpaDetail.setEtc(detailDTO.getEtc());
					log.info("detailDTO.getEtc() tariq : "
							+ detailDTO.getEtc());
				}

				log.info("detailDTO.getEtc() tariq : "+promisBpaDetail.getEtc() );
				fetchAndETCforBPATwo(promisBpaDetail, highestMove);

			}
		} catch (Exception e) {
			log.error("Exception inside constructTotalMovesToGoForSparcs API : "
					+ stackTraceToString(e));
			throw e;
		}
	}

	/**
	 * This method is used to fetch the ETC.
	 * 
	 * @param bpaDetail
	 * @param highestMove
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static void fetchAndETC(PromisBPADetail bpaDetail, Long highestMove)
			throws ClassNotFoundException, SQLException, IOException {
		try {
			long qcpty = 0;

			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			criteria.setpNam(bpaDetail.getHhCrane());
			criteria.setTerminalId(bpaDetail.getTerminalId());

			BPADetail detailDTO = (BPADetail) crudOperation(SELECT_ONE,
					DataBaseFactory.DB_BPA, "getQcPty", criteria, null, null);
			if (detailDTO != null && detailDTO.getQcPty() != null) {
				qcpty = detailDTO.getQcPty().longValue();
			}

			if (highestMove != null && qcpty > 0) {
				long value = ((highestMove.longValue() / qcpty) / 24);
				Date date = new Date();
				value = (value * 3600000) + date.getTime();
				date.setTime(value);
				SimpleDateFormat format = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				bpaDetail.setEtc(format.format(date));
				
				
				

			}
		} catch (Exception e) {
			log.error("Exception inside fetchAndETC API :"
					+ stackTraceToString(e));
			throw e;
		}
	}

	
	private static void fetchAndETCforBPATwo(PromisTwoBPADetail bpaDetail, Long highestMove)
			throws ClassNotFoundException, SQLException, IOException {
		try {
			long qcpty = 0;

			FilterCriteria criteria = new FilterCriteria();
			criteria.setRotationNumbers(bpaDetail.getRotation());
			criteria.setpNam(bpaDetail.getHhCrane());
			criteria.setTerminalId(bpaDetail.getTerminalId());

			BPADetail detailDTO = (BPADetail) crudOperation(SELECT_ONE,
					DataBaseFactory.DB_BPA, "getQcPty", criteria, null, null);
			if (detailDTO != null && detailDTO.getQcPty() != null) {
				qcpty = detailDTO.getQcPty().longValue();
			}

			if (highestMove != null && qcpty > 0) {
				long value = ((highestMove.longValue() / qcpty) / 24);
				Date date = new Date();
				value = (value * 3600000) + date.getTime();
				date.setTime(value);
				SimpleDateFormat format = new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm");
				bpaDetail.setEtc(format.format(date));
				log.info("bpaDetail.getEtc()---tariq2 :"
						+ bpaDetail.getEtc());

			}
		} catch (Exception e) {
			log.error("Exception inside fetchAndETC API :"
					+ stackTraceToString(e));
			throw e;
		}
	}
	/**
	 * This method is used to fetch the ETC.
	 * 
	 * @param bpaDetail
	 * @param highestMove
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static Date retrieveETC(FilterCriteria criteria, Long movesTogo)
			throws ClassNotFoundException, SQLException, IOException {
		try {
			long qcpty = 0;

			BPADetail detailDTO = (BPADetail) crudOperation(SELECT_ONE,
					DataBaseFactory.DB_BPA, "getQcPty", criteria, null, null);
			if (detailDTO != null && detailDTO.getQcPty() != null) {
				qcpty = detailDTO.getQcPty().longValue();
			}

			if (movesTogo != null && qcpty > 0) {
				long value = ((movesTogo.longValue() / qcpty) / 24);
				Date date = new Date();
				value = (value * 3600000) + date.getTime();
				date.setTime(value);
				return date;
			}
			return null;
		} catch (Exception e) {
			log.error("Exception inside retrieveETC API :"
					+ stackTraceToString(e));
			throw e;
		}
	}

	/**
	 * This method is used to Group Terminals and then Fetching BPA Details
	 * 
	 * @param bpaDetails
	 * @throws IOException
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	public static List<BPADetail> groupTerminalsFetchBPADtls(
			List<PromisBPADetail> bpaDetails, boolean isSaveRequired)
			throws IOException {
		List<BPADetail> insertBPADetailsList = null;
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside groupTerminalsFetchBPADtls API with start time :"
						+ startTime);
			HashMap<String, ArrayList<String>> terminalMap = new HashMap<String, ArrayList<String>>();
			terminalMap.put(TERMINAL_1, new ArrayList<String>());
			terminalMap.put(TERMINAL_2, new ArrayList<String>());
			terminalMap.put(TERMINAL_3, new ArrayList<String>());
			terminalMap.put(TERMINAL_4, new ArrayList<String>());
			terminalMap.put(GENERAL_CARGO, new ArrayList<String>());

			groupBasedOnTerminals(bpaDetails, terminalMap);

			Set<String> keySet = terminalMap.keySet();

			Iterator<String> keyIterator = keySet.iterator();

			List<BPADetail> bpaDetailDTODts = new ArrayList<BPADetail>();

			while (keyIterator.hasNext()) {

				String terminalId = keyIterator.next();

				if (terminalMap.get(terminalId) != null
						&& terminalMap.get(terminalId).size() > 0) {
					FilterCriteria filterCriteria = new FilterCriteria();
					filterCriteria.setTerminalId(terminalId);

					filterCriteria
							.setListRotations(terminalMap.get(terminalId));
                  //   log.info("-------------------- BEFOREAFTER CALLING THE getBPADetails API ------------------");
					List<BPADetail> dtos = (List<BPADetail>) crudOperation(
							SELECT_LIST, DataBaseFactory.DB_BPA,
							"getBPADetails", filterCriteria, null, null);
					//log.info("-------------------- BEFOREAFTER after CALLING THE getBPADetails API -----------------size is -"+dtos.size()); 
					// QTN: Why are we setting these values .Are we using
					// anywhere else.
					if (dtos != null && !dtos.isEmpty()) {
						bpaDetailDTODts.addAll(dtos);
					}

				}
			}

			insertBPADetailsList = new ArrayList<BPADetail>();

			for (PromisBPADetail bpaDetail : bpaDetails) {
				if (bpaDetail != null && bpaDetail.getRotation() != null) {
					BPADetail bpaDetailDTO = constructBPADetailDTOList(
							bpaDetail.getRotation(), bpaDetailDTODts);

					contructBPADTO(bpaDetail, bpaDetailDTO);
					constructBollardDetails(bpaDetail, bpaDetailDTO);
					if (bpaDetailDTO != null
							&& bpaDetailDTO.getRotationNumber() != null
							&& bpaDetailDTO.getRotationNumber().trim().length() > 0) {
						insertBPADetailsList.add(bpaDetailDTO);
					}
				}
			}

			if (isSaveRequired && ! insertBPADetailsList.isEmpty()) {
				crudOperation(INSERT_LIST, DataBaseFactory.DB_MPC,
						"insertBPADetails", null, insertBPADetailsList, null);
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("groupTerminalsFetchBPADtls End Time : " + endTime);
			log.info("Time Taken by groupTerminalsFetchBPADtls in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception while invoking groupTerminalsFetchBPADtls API "
					+ stackTraceToString(e));
			throw e;
		}
		return insertBPADetailsList;
	}
	
	public static List<BPADetail> groupTerminalsFetchBPADtlsTwo(
			List<PromisTwoBPADetail> bpaDetails, boolean isSaveRequired)
			throws IOException {
		List<BPADetail> insertBPADetailsList = null;
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside groupTerminalsFetchBPADtls API with start time :"
						+ startTime);
			HashMap<String, ArrayList<String>> terminalMap = new HashMap<String, ArrayList<String>>();
			terminalMap.put(TERMINAL_1, new ArrayList<String>());
			terminalMap.put(TERMINAL_2, new ArrayList<String>());
			terminalMap.put(TERMINAL_3, new ArrayList<String>());
			terminalMap.put(TERMINAL_4, new ArrayList<String>());
			terminalMap.put(GENERAL_CARGO, new ArrayList<String>());
			log.info("Inside groupTerminalsFetchBPADtls API   terminalMap.get(TERMINAL_1) :"
					+terminalMap.get("TERMINAL_1") );

		//	groupBasedOnTerminals(bpaDetails, terminalMap);
			groupBasedOnTerminalsTwo(bpaDetails, terminalMap);

			Set<String> keySet = terminalMap.keySet();

			Iterator<String> keyIterator = keySet.iterator();

			List<BPADetail> bpaDetailDTODts = new ArrayList<BPADetail>();

			while (keyIterator.hasNext()) {

				String terminalId = keyIterator.next();

				if (terminalMap.get(terminalId) != null
						&& terminalMap.get(terminalId).size() > 0) {
					FilterCriteria filterCriteria = new FilterCriteria();
					filterCriteria.setTerminalId(terminalId);
					//filterCriteria.setVisitId(visitId);

					filterCriteria
							.setListRotations(terminalMap.get(terminalId));
                     log.debug("-------------------- BEFOREAFTER CALLING THE getBPADetails API ------------------"+terminalMap.get(terminalId).toString()+"--terminalId=="+terminalId);
					List<BPADetail> dtos = (List<BPADetail>) crudOperation(
							SELECT_LIST, DataBaseFactory.DB_BPA,
							"getBPADetails", filterCriteria, null, null);
					log.debug("------------------- after CALLING THE getBPADetails API -----------------size is -"+dtos.size()); 
					// QTN: Why are we setting these values .Are we using
					// anywhere else.
					if (dtos != null && !dtos.isEmpty()) {
						bpaDetailDTODts.addAll(dtos);
					}

				}
			}


			insertBPADetailsList = new ArrayList<BPADetail>();
			
			for (PromisTwoBPADetail bpaDetail : bpaDetails) {
				if (bpaDetail != null && bpaDetail.getRotation() != null  ) {
					  log.info("-------------------- CHK2 ---------&& bpaDetail.getVisitId()---------");
					  		BPADetail bpaDetailDTO = constructBPADetailDTOListTwo(
							bpaDetail.getRotation(),bpaDetail.getVisit_id(), bpaDetailDTODts);

					contructBPADTOTwo(bpaDetail, bpaDetailDTO);
					constructBollardDetailsTwo(bpaDetail, bpaDetailDTO);
					if (bpaDetailDTO != null
							&& bpaDetailDTO.getRotationNumber() != null
							&& bpaDetailDTO.getRotationNumber().trim().length() > 0) {
						insertBPADetailsList.add(bpaDetailDTO);
					}
				}
			}

			if (isSaveRequired && ! insertBPADetailsList.isEmpty()) {
				crudOperation(INSERT_LIST, DataBaseFactory.DB_MPC,
						"insertBPADetails", null, insertBPADetailsList, null);
			}
			long endTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("groupTerminalsFetchBPADtls End Time : " + endTime);
			log.info("Time Taken by groupTerminalsFetchBPADtls in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception while invoking groupTerminalsFetchBPADtls API "
					+ stackTraceToString(e));
			throw e;
		}
		return insertBPADetailsList;
	}

	/**
	 * This method is used to Construct Bollard Details
	 * 
	 * @param bpaDetail
	 * @param bpaDetailDTO
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static void constructBollardDetails(PromisBPADetail bpaDetail,
			BPADetail bpaDetailDTO) {

		try {
			if (bpaDetail != null && bpaDetailDTO != null) {
				bpaDetail.setBerthPosition(bpaDetailDTO.getBerthPosition());
				bpaDetail.setFromBollard(bpaDetailDTO.getFromBollard());
				bpaDetail.setToBollard(bpaDetailDTO.getToBollard());
				bpaDetail.setBpaPortCode(bpaDetailDTO.getPortCode());
				bpaDetail.setBpaSourceSystem(bpaDetailDTO.getSourceSystem());
				bpaDetail.setBpaTerminalId(bpaDetailDTO.getTerminal());
				bpaDetail.setQuay(bpaDetailDTO.getQuay());
				bpaDetail.setBpaIsValid("1");
				bpaDetail.setRemarks(bpaDetailDTO.getRemarks());

				if (bpaDetailDTO.getFromBollard() != null
						&& bpaDetailDTO.getFromBollard().contains("*")) {
					bpaDetail
							.setCurrentPOS(bpaDetailDTO.getFromBollard()
									.substring(
											0,
											bpaDetailDTO.getFromBollard()
													.indexOf("*")));
					
				}
			}
		} catch (Exception e) {
			log.error("Exception inside constructBollardDetails API :"
					+ stackTraceToString(e));
			throw e;
		}

	}


private static void constructBollardDetailsTwo(PromisTwoBPADetail bpaDetail,
		BPADetail bpaDetailDTO) {

	try {
		if (bpaDetail != null && bpaDetailDTO != null) {
			bpaDetail.setBerthPosition(bpaDetailDTO.getBerthPosition());
			bpaDetail.setFromBollard(bpaDetailDTO.getFromBollard());
			bpaDetail.setToBollard(bpaDetailDTO.getToBollard());
			bpaDetail.setBpaPortCode(bpaDetailDTO.getPortCode());
			bpaDetail.setBpaSourceSystem(bpaDetailDTO.getSourceSystem());
			bpaDetail.setBpaTerminalId(bpaDetailDTO.getTerminal());
			bpaDetail.setQuay(bpaDetailDTO.getQuay());
			bpaDetail.setBpaIsValid("1");
			bpaDetail.setBerthedFrom(bpaDetailDTO.getBerthedFrom());
			bpaDetail.setRemarks(bpaDetailDTO.getRemarks());
			//bpaDetail.setSlaStatus(bpaDetailDTO.getIS_SLA());
			bpaDetail.setIS_SLA(bpaDetailDTO.getIS_SLA());
			//IS_SLA

			if (bpaDetailDTO.getFromBollard() != null
					&& bpaDetailDTO.getFromBollard().contains("*")) {
				bpaDetail
						.setCurrentPOS(bpaDetailDTO.getFromBollard()
								.substring(
										0,
										bpaDetailDTO.getFromBollard()
												.indexOf("*")));
				
			}
		}
	} catch (Exception e) {
		log.error("Exception inside constructBollardDetails API :"
				+ stackTraceToString(e));
		throw e;
	}

}
	/**
	 * This method is used to Construct BPA DTO.
	 * 
	 * @param promisBPADetail
	 * @param dto
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static void contructBPADTO(PromisBPADetail promisBPADetail,
			BPADetail dto) {
		if (promisBPADetail != null
				&& promisBPADetail.getStatus() != null
				&& MPCConstants.STATUS_BERTHED.equalsIgnoreCase(promisBPADetail
						.getStatus().trim())) {
		} else if (dto != null) {
			if (promisBPADetail.getStatus() == null
					|| promisBPADetail.getStatus().trim().length() <= 0) {
				if (dto.getFromBollard() != null
						&& dto.getFromBollard().trim().length() > 0) {
					promisBPADetail.setStatus(MPCConstants.STATUS_PLANNED);
				} else {
					promisBPADetail.setStatus(MPCConstants.STATUS_UNPLANNED);
				}
			}

		} else {
			promisBPADetail.setStatus(MPCConstants.STATUS_UNPLANNED);
		}

	}
	private static void contructBPADTOTwo(PromisTwoBPADetail promisBPADetail,
			BPADetail dto) {
		if (promisBPADetail != null
				&& promisBPADetail.getStatus() != null
				&& MPCConstants.STATUS_BERTHED.equalsIgnoreCase(promisBPADetail
						.getStatus().trim())) {
		} else if (dto != null) {
			if (promisBPADetail.getStatus() == null
					|| promisBPADetail.getStatus().trim().length() <= 0) {
				if (dto.getFromBollard() != null
						&& dto.getFromBollard().trim().length() > 0) {
					promisBPADetail.setStatus(MPCConstants.STATUS_PLANNED);
				} else {
					promisBPADetail.setStatus(MPCConstants.STATUS_UNPLANNED);
				}
			}

		} else {
			promisBPADetail.setStatus(MPCConstants.STATUS_UNPLANNED);
		}

	}

	/**
	 * This method is used to constructBPADetailDTOList
	 * 
	 * @param rotation
	 * @param bpaDetailDTODts
	 * @return BPADetail
	 * 
	 * @author [Muthukumar Chellappa]
	 */
	private static BPADetail constructBPADetailDTOList(String rotation,
			List<BPADetail> bpaDetailDTODts) {
		if (bpaDetailDTODts != null) {
			for (BPADetail dto : bpaDetailDTODts) {
				if (dto != null) {
					if (rotation.trim().equalsIgnoreCase(
							dto.getRotationNumber()  )) {
						return dto;
					}

				}
			}
		}

		return null;

	}
	
	private static BPADetail constructBPADetailDTOListTwo(String rotation,String visitrecordId,
			List<BPADetail> bpaDetailDTODts) {
		log.info("Inside constructBPADetailDTOListTwo rotn  : "+rotation+"=visitrecid="+ visitrecordId);
		if (bpaDetailDTODts != null) {
			for (BPADetail dto : bpaDetailDTODts) {
				if (dto != null) {
					
					log.info("TTTT rotn  : "+dto.getRotationNumber()+"==visitrecid"+dto.getVisitrecordId()+visitrecordId );
					
					if(dto.getVisitrecordId()!=null)
					{
					if (rotation.trim().equalsIgnoreCase(
							dto.getRotationNumber()  )  &&  visitrecordId.equals(dto.getVisitrecordId() )    ) {
						return dto;
					}
					}

				}
			}
		}

		return null;

	}


	/**
	 * This method is used to Group Data based on Terminals
	 * 
	 * @param bpaDetails
	 * @param terminalMap
	 * 
	 * @author Itpeople.Muthukumar
	 */
	private static void groupBasedOnTerminals(List<PromisBPADetail> bpaDetails,
			HashMap<String, ArrayList<String>> terminalMap) {
		for (PromisBPADetail bpaDetail : bpaDetails) {
			if (bpaDetail != null && bpaDetail.getTerminalId() != null
					&& bpaDetail.getTerminalId().trim().length() > 0) {
				ArrayList<String> listRotation = null;
				String terminalId = retriveTerminalId(bpaDetail);
				if (terminalId != null) {
					bpaDetail.setTerminalId(terminalId);
				}
				if (terminalId != null) {
					if (TERMINAL_1.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_1);
					} else if (TERMINAL_2.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_2);
					} else if (TERMINAL_3.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_3);
					} else if (TERMINAL_4.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_4);
					} else if (GENERAL_CARGO.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(GENERAL_CARGO);
					}
					listRotation.add(bpaDetail.getRotation());
				}
			} else {
				log.info("Terminal Id is NULL for vessel : "
						+ bpaDetail.getTerminalId());
			}
		}
	}
	
	
	private static void groupBasedOnTerminalsTwo(List<PromisTwoBPADetail> bpaDetails,
			HashMap<String, ArrayList<String>> terminalMap) {
		for (PromisTwoBPADetail bpaDetail : bpaDetails) {
			if (bpaDetail != null && bpaDetail.getTerminalId() != null
					&& bpaDetail.getTerminalId().trim().length() > 0) {
				ArrayList<String> listRotation = null;
				String terminalId = retriveTerminalIdTwo(bpaDetail);
				if (terminalId != null) {
					bpaDetail.setTerminalId(terminalId);
				}
				if (terminalId != null) {
					if (TERMINAL_1.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_1);
					} else if (TERMINAL_2.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_2);
					} else if (TERMINAL_3.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_3);
					} else if (TERMINAL_4.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(TERMINAL_4);
					} else if (GENERAL_CARGO.equalsIgnoreCase(terminalId)) {
						listRotation = terminalMap.get(GENERAL_CARGO);
					}
					listRotation.add(bpaDetail.getRotation());
				}
			} else {
				log.info("Terminal Id is NULL for vessel : "
						+ bpaDetail.getTerminalId());
			}
		}
	}
	
	
	private static String retriveTerminalIdTwo(PromisTwoBPADetail bpaDetail) {
		log.info("TERMINAAL Inside retriveTerminalId API for vessel : "
				+ bpaDetail.getVesselName() + " with rotation : "
				+ bpaDetail.getRotation() + " with Vessel Location : "
				+ bpaDetail.getVesselLocation());
		String terminalId = null;
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_1)) {
			return TERMINAL_1;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_2)) {
			return TERMINAL_2;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_3)) {
			return TERMINAL_3;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_4)) {
			return TERMINAL_4;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(GENERAL_CARGO)) {
			return GENERAL_CARGO;
		}

		if (null != bpaDetail.getTerminalId()
				&& !(bpaDetail.getTerminalId().trim().isEmpty())) {
			return bpaDetail.getTerminalId();
		}

		return terminalId;
	}

	private static String retriveTerminalId(PromisBPADetail bpaDetail) {
		log.info("TERMINAAL Inside retriveTerminalId API for vessel : "
				+ bpaDetail.getVesselName() + " with rotation : "
				+ bpaDetail.getRotation() + " with Vessel Location : "
				+ bpaDetail.getVesselLocation());
		String terminalId = null;
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_1)) {
			return TERMINAL_1;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_2)) {
			return TERMINAL_2;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_3)) {
			return TERMINAL_3;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_4)) {
			return TERMINAL_4;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(GENERAL_CARGO)) {
			return GENERAL_CARGO;
		}

		if (null != bpaDetail.getTerminalId()
				&& !(bpaDetail.getTerminalId().trim().isEmpty())) {
			return bpaDetail.getTerminalId();
		}

		return terminalId;
	}
	private static String retriveTerminalIdBPATwo(PromisTwoBPADetail bpaDetail) {
		log.info("TERMINAAL Inside retriveTerminalId API for vessel : "
				+ bpaDetail.getVesselName() + " with rotation : "
				+ bpaDetail.getRotation() + " with Vessel Location : "
				+ bpaDetail.getVesselLocation());
		String terminalId = null;
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_1)) {
			return TERMINAL_1;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_2)) {
			return TERMINAL_2;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_3)) {
			return TERMINAL_3;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(TERMINAL_4)) {
			return TERMINAL_4;
		}
		if (bpaDetail.getVesselLocation() != null
				&& bpaDetail.getVesselLocation().contains(GENERAL_CARGO)) {
			return GENERAL_CARGO;
		}

		if (null != bpaDetail.getTerminalId()
				&& !(bpaDetail.getTerminalId().trim().isEmpty())) {
			return bpaDetail.getTerminalId();
		}

		return terminalId;
	}

	/**
	 * This method is used to fetch Terminals.
	 * 
	 * @param bpaDetails
	 * @throws IOException
	 * 
	 * @author Itpeople.Muthukumar
	 */
	private static void fetchTerminals(List<PromisBPADetail> bpaDetails)
			throws IOException {
		try {
			long startTime = System.currentTimeMillis();
			if (bpaDetails != null && !bpaDetails.isEmpty()) {

				for (PromisBPADetail bpaDetail : bpaDetails) {

					FilterCriteria filterCriteria = new FilterCriteria();
					filterCriteria.setVesselName(bpaDetail.getVesselName());
					filterCriteria.setImoCode(bpaDetail.getImoCode());

					BPADetail mpcDetail = (BPADetail) crudOperation(SELECT_ONE,
							DataBaseFactory.DB_MPC, "getTerminals",
							filterCriteria, null, null);

					if (mpcDetail != null && mpcDetail.getTerminal() != null
							&& mpcDetail.getTerminal().trim().length() > 0) {

						if (mpcDetail.getTerminal().contains(TERMINAL_1)) {
							bpaDetail.setTerminalId(TERMINAL_1);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_2)) {
							bpaDetail.setTerminalId(TERMINAL_2);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_3)) {
							bpaDetail.setTerminalId(TERMINAL_3);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_4)) {
							bpaDetail.setTerminalId(TERMINAL_4);
						} else if (mpcDetail.getTerminal().contains(
								GENERAL_CARGO)) {
							bpaDetail.setTerminalId(GENERAL_CARGO);
						}

					}

					Date etaDate = bpaDetail.getEtaDateObject();
					Date etbDate = bpaDetail.getEtbDateObject();
					Date etdDate = bpaDetail.getEtdDateObject();

					SimpleDateFormat format = new SimpleDateFormat(
							"dd-MMM-yyyy HH:mm");

					if (etaDate != null)
						bpaDetail.setEtaDate(format.format(etaDate));
					if (etbDate != null)
						bpaDetail.setEtbDate(format.format(etbDate));
					if (etdDate != null)
						bpaDetail.setEtdDate(format.format(etdDate));

				}
				long endTime = System.currentTimeMillis();
				log.info("Time Taken by fetchTerminals in milli seconds :"
						+ (endTime - startTime));
			}
		} catch (Exception e) {
			log.error("Exception inside fetchTerminals fetchTerminals API : "
					+ stackTraceToString(e));
		}

	}
	
	private static void fetchTerminalsforBPATwo(List<PromisTwoBPADetail> bpaDetails)
			throws IOException {
		try {
			long startTime = System.currentTimeMillis();
			if (bpaDetails != null && !bpaDetails.isEmpty()) {
				

				for (PromisTwoBPADetail bpaDetail : bpaDetails) {

					bpaDetail.setTerminalId(bpaDetail.getVisit_terminal());
					FilterCriteria filterCriteria = new FilterCriteria();
					filterCriteria.setVesselName(bpaDetail.getVesselName());
					filterCriteria.setImoCode(bpaDetail.getImoCode());

					BPADetail mpcDetail = (BPADetail) crudOperation(SELECT_ONE,
							DataBaseFactory.DB_MPC, "getTerminals",
							filterCriteria, null, null);

					if (mpcDetail != null && mpcDetail.getTerminal() != null
							&& mpcDetail.getTerminal().trim().length() > 0) {

						if (mpcDetail.getTerminal().contains(TERMINAL_1)) {
							bpaDetail.setTerminalId(TERMINAL_1);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_2)) {
							bpaDetail.setTerminalId(TERMINAL_2);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_3)) {
							bpaDetail.setTerminalId(TERMINAL_3);
						} else if (mpcDetail.getTerminal().contains(TERMINAL_4)) {
							bpaDetail.setTerminalId(TERMINAL_4);
						} else if (mpcDetail.getTerminal().contains(
								GENERAL_CARGO)) {
							bpaDetail.setTerminalId(GENERAL_CARGO);
						}

					}

					Date etaDate = bpaDetail.getEtaDateObject();
					Date etbDate = bpaDetail.getEtbDateObject();
					Date etdDate = bpaDetail.getEtdDateObject();

					SimpleDateFormat format = new SimpleDateFormat(
							"dd-MMM-yyyy HH:mm");

					if (etaDate != null)
						bpaDetail.setEtaDate(format.format(etaDate));
					if (etbDate != null)
						bpaDetail.setEtbDate(format.format(etbDate));
					if (etdDate != null)
						bpaDetail.setEtdDate(format.format(etdDate));

				}
				long endTime = System.currentTimeMillis();
				log.info("Time Taken by fetchTerminals in milli seconds :"
						+ (endTime - startTime));
			}
		} catch (Exception e) {
			log.error("Exception inside fetchTerminals fetchTerminals API : "
					+ stackTraceToString(e));
		}

	}
	

	/**
	 * This method is used to fetch Data from Promis.
	 * 
	 * @return List of promisbpaDetails.
	 * 
	 * @author Itpeople.Muthukumar
	 */
	private static List<PromisBPADetail> fetchPromisDetails() {
		List<PromisBPADetail> bpaDetails = (List<PromisBPADetail>) crudOperation(
				SELECT_LIST, DataBaseFactory.DB_PROMIS,
				"bpaDetail.getPromisDetails", null, null, null);
		return bpaDetails;
	}
	public static List<PromisTwoBPADetail> fetchPromisTwoDetails() throws Exception {
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled())
			log.debug("Inside getworkOrderList API with start time :" + startTime);
		List<PromisTwoBPADetail> result=new <PromisTwoBPADetail>ArrayList();
	
		PromisBPAServiceImpl service=new PromisBPAServiceImpl();
		List<CbbsDetails> cbbsdata= service.getCBBSCAM();
	//	List<TerminalVisit> terminalVisits=null;
		if(cbbsdata !=null){
		for (CbbsDetails  cbbsdatafromservice : cbbsdata) {

			if (cbbsdatafromservice != null) {
				
				String rotationNumber=cbbsdatafromservice.getRotn();
				String visit_id=cbbsdatafromservice.getVisit_id();
				PromisTwoBPADetail bpadetails	=service.getCBBSDataformarineJoBList(rotationNumber, visit_id);
				bpadetails.setRotation(cbbsdatafromservice.getRotn());
				bpadetails.setVisit_id(cbbsdatafromservice.getVisit_id());
				bpadetails.setVisit_terminal(cbbsdatafromservice.getVisit_terminal());
				bpadetails.setTerminalId(cbbsdatafromservice.getVisit_terminal());
				bpadetails.setVisit_eta(cbbsdatafromservice.getVisit_eta());
				bpadetails.setMaxVisitSeqNo(cbbsdatafromservice.getMaxVisitSeqNo());
				bpadetails.setVisit_berth_date(cbbsdatafromservice.getVisit_berth_date());
				bpadetails.setVisit_sail_date(cbbsdatafromservice.getVisit_sail_date());
				bpadetails.setPort_eta(cbbsdatafromservice.getPort_eta());
				bpadetails.setVisit_seq_no(cbbsdatafromservice.getVisit_seq_no());	
				bpadetails.setPort_arr_date(cbbsdatafromservice.getPort_arr_date());
				bpadetails.setHeaveUpTime(cbbsdatafromservice.getHeaveUpTime());
				
				
			
				
				
				result.add(bpadetails);
				
			}

		}
		}
		
		
		
		long endTime = System.currentTimeMillis();
		log.info("getworkOrderList End Time : " + endTime);
		log.info("Time Taken by getworkOrderList in milli seconds : "
				+ (endTime - startTime));
		if(log.isDebugEnabled())
		log.debug("Time Taken by getworkOrderList Result of FUse :"+result);
		return result;

	}


	public static List<PromisBPADetail> getSailedVesselsDetails(
			String fromSailDate, String toSailDate, String rotnNumber)
			throws IOException {
		init();
		FilterCriteria filterCriteria = new FilterCriteria();
		filterCriteria.setFromSailDate(fromSailDate);
		filterCriteria.setToSailDate(toSailDate);
		filterCriteria.setRotationNumbers(rotnNumber);
		List<PromisBPADetail> bpaDetails = (List<PromisBPADetail>) crudOperation(
				SELECT_LIST, DataBaseFactory.DB_PROMIS,
				"bpaDetail.getSailedVesselsDetails", filterCriteria, null, null);
		return bpaDetails;
	}

	/**
	 * CRUD operation, select type parameter decides whether to retrieve or save
	 * data.
	 * 
	 * @param selectType
	 * @param dataBase
	 * @param queryName
	 * @param criteria
	 * @param vesselList
	 * @return Object
	 * @author Itpeople.Muthukumar
	 */
	private static Object crudOperation(String selectType, String dataBase,
			String queryName, FilterCriteria criteria, List vesselList,
			Object parameter) {

		if (selectType != null && dataBase != null) {

			SqlSession session = null;

			try {
				if (DataBaseFactory.DB_BPA.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForBPA();
				} else if (DataBaseFactory.DB_MPC.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForMPC();
				} else if (DataBaseFactory.DB_PROMIS.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForPromis();
				} else if (DataBaseFactory.DB_PROMIS_UM
						.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForPromisUm();
				} else if (DataBaseFactory.BPA2_MPC.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForMPCBPA2();
				} else if (DataBaseFactory.DB_PROMISD
						.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForPromisD();
				} else if (DataBaseFactory.DB_CBBSCAM.equalsIgnoreCase(dataBase)) {
					session = dataBaseFactory.getSessionForcbbsCam();
				}
				if (SELECT_ONE.equalsIgnoreCase(selectType)) {
					if (parameter != null) {
						return session.selectOne(queryName, parameter);
					} else if (criteria != null) {
						return session.selectOne(queryName, criteria);
					} else {
						return session.selectOne(queryName);
					}
				} else if (INSERT_LIST.equals(selectType)) {
					return session.insert(queryName, vesselList);
				} else {
					if (criteria != null) {
						return session.selectList(queryName, criteria);
					} else {
						return session.selectList(queryName);
					}
				}
			} finally {
				if (session != null) {
					session.commit();
					session.close();
				}
			}

		}

		return null;
	}

	/**
	 * 
	 * @param bpaDetails
	 * @param apiName
	 * @param flag
	 * @return
	 */
	public FutureTask<PromiseBPAServiceTask> processTask(
			final List<PromisBPADetail> bpaDetails, final String apiName,
			final boolean flag, final boolean isCBBSRequired) {
		// status tracking
		final PromiseBPAServiceTask status = new PromiseBPAServiceTask();
		// Start thread for fetchETA
		FutureTask<PromiseBPAServiceTask> futureTask = new FutureTask<PromiseBPAServiceTask>(
				new Callable<PromiseBPAServiceTask>() {

					@Override
					public PromiseBPAServiceTask call() throws ParseException {
						try {
							long startTime = System.currentTimeMillis();
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.RUNNING);
							// Fetch ETA details.
							switch (apiName) {
							/*
							 * case FECTH_ETA: fetchETA(bpaDetails); break;
							 */
							case FETCH_CBBS_DATA:
								if (isCBBSRequired)
									fetchCBBSData(bpaDetails);
								break;
							case CONSTRUCT_BPA_STATUS:
								constructBPAStatus(bpaDetails, flag);

								break;
							case CONSTRUCT_PRIORITY_DATE:
								constructPriorityDate(bpaDetails);
								break;
							case LOAD_DROP_DOWN_VALUES:
								loadDropDownValues(bpaDetails);
								break;
							case GROUP_TERMINAL_BPA:
								groupTerminalsFetchBPADtls(bpaDetails, flag);
								break;
							case FETCH_SCORING:
								ConstructWLScore(bpaDetails);
								break;
							/*
							 * case APPLY_SORTING: applySorting(bpaDetails);
							 * break;
							 */
							default:

							}
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.SUCCEEDED);
							long totalTimeInMillis = System.currentTimeMillis()
									- startTime;
							status.setTotalTimeInMillis(totalTimeInMillis);
						} catch (ParseException pe) {
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.FAILED);
						} catch (Exception e) {
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.FAILED);
						}

						return status;
					}
				});

		return futureTask;
	}
	
	/*tariq*/
	
	public FutureTask<PromiseBPAServiceTask> processTaskTwo(
			final List<PromisTwoBPADetail> bpaDetails, final String apiName,
			final boolean flag, final boolean isCBBSRequired) {
		// status tracking
		final PromiseBPAServiceTask status = new PromiseBPAServiceTask();
		// Start thread for fetchETA
		FutureTask<PromiseBPAServiceTask> futureTask = new FutureTask<PromiseBPAServiceTask>(
				new Callable<PromiseBPAServiceTask>() {

					@Override
					public PromiseBPAServiceTask call() throws ParseException {
						try {
							long startTime = System.currentTimeMillis();
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.RUNNING);
							// Fetch ETA details.
							switch (apiName) {
							/*
							 * case FECTH_ETA: fetchETA(bpaDetails); break;
							 */
							case FETCH_CBBS_DATA:
								if (isCBBSRequired)
									//fetchCBBSData(bpaDetails);
								break;
							case CONSTRUCT_BPA_STATUS:
								constructBPATWOStatus(bpaDetails, flag);
								//constructBPAStatus(bpaDetails, flag);

								break;
							case CONSTRUCT_PRIORITY_DATE:
								constructPriorityDateTwo(bpaDetails);
								break;
							case LOAD_DROP_DOWN_VALUES:
								//loadDropDownValues(bpaDetails);
								break;
							case GROUP_TERMINAL_BPA:
								groupTerminalsFetchBPADtlsTwo(bpaDetails, flag);
								break;
							case FETCH_SCORING:
								ConstructWLScoreTwo(bpaDetails);
								break;
							/*
							 * case APPLY_SORTING: applySorting(bpaDetails);
							 * break;
							 */
							default:

							}
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.SUCCEEDED);
							long totalTimeInMillis = System.currentTimeMillis()
									- startTime;
							status.setTotalTimeInMillis(totalTimeInMillis);
						} catch (ParseException pe) {
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.FAILED);
						} catch (Exception e) {
							status.setTaskStatus(PromiseBPAServiceTask.TaskCompletionStatus.FAILED);
						}

						return status;
					}
				});

		return futureTask;
	}
	/*tariq*/

	/**
	 * Save Vessel Details for Alerts.
	 * 
	 * @throws Exception
	 * @author Itpeople.Muthukumar
	 */
	public static void saveVesselDetails() throws Exception {
		init();
		getPromisDetails(true, true);
	}

	/*
	 * private void initThreadPool() {
	 * 
	 * log.info("Intializing Threadpool"); for (Thread t :
	 * Thread.getAllStackTraces().keySet()) { if
	 * (t.getState()==Thread.State.WAITING &&
	 * t.getName().contains("PromisBPAService-Thread")) {
	 * log.info("Interrupting the old threads..."+t.getName()); t.interrupt();
	 * //t.stop(); } } bpaServiceThreadPoolQueue = new
	 * LinkedBlockingQueue<Runnable>(); ThreadFactory bpaServiceThreadFactory =
	 * new CustomThreadFactory(BPA_SERVICE_THREAD_POOL_NAME,
	 * Thread.MAX_PRIORITY); // bpaService thread pool bpaServiceThreadPool =
	 * new CustomThreadPoolExecutor(CORE_THREADS, MAX_THREADS, 0L,
	 * TimeUnit.MILLISECONDS, bpaServiceThreadPoolQueue);
	 * bpaServiceThreadPool.setThreadFactory(bpaServiceThreadFactory);
	 * bpaServiceThreadPool.prestartAllCoreThreads();
	 * 
	 * if (log.isDebugEnabled()) { log.info("Intialized Threadpool"); }
	 * 
	 * }
	 */
	public static void setVesselLocation(PromisBPADetail dto,
			List<GeoFenceData> geofenceData) {
		VesselLocationCalculator locationCalculator = new VesselLocationCalculator();

		if (dto.getLatitude() != null && dto.getLongitude() != null) {
			log.debug("Calling getVesselGeoLocation API to calculate Vessel location  for vessel :"
					+ dto.getVesselName());
			String geoLocation = VesselDataCalcHelper.getVesselGeoLocation(
					geofenceData, Double.parseDouble(dto.getLatitude()),
					Double.parseDouble(dto.getLongitude()));
			if (geoLocation != null)
				dto.setVesselLocation(geoLocation);
			log.debug("Vessel location for vessel :" + dto.getVesselName()
					+ " during  Computation PORT TERMINAAL: "
					+ dto.getVesselLocation());
			log.debug("Vessel : " + dto.getVesselName()
					+ " with lat and lang PORT TERMINAAL : "
					+ dto.getLatitude() + " / " + dto.getLongitude());
			String geofenceArea = null;
			if (dto.getLatitude() != null & dto.getLongitude() != null)
				geofenceArea = locationCalculator.getTerminalQ(
						Double.parseDouble(dto.getLatitude()),
						Double.parseDouble(dto.getLongitude()));
			if (geofenceArea != null)
				dto.setVesselLocation(geofenceArea);

			String location = VesselIconsPointsHolder.getVesselGeofence(
					getGeoFenceData(geofenceData),
					Float.parseFloat(dto.getLatitude()),
					Float.parseFloat(dto.getLongitude()));
			if (location != null && !"".equalsIgnoreCase(location.trim()))
				dto.setVesselLocation(location);
			log.debug("Vessel location after performing computation TERMINAAL for vessel :"
					+ dto.getVesselName()
					+ " Location : "
					+ dto.getVesselLocation()
					+ " with rotation number : "
					+ dto.getRotation());
		} else {
			log.info("LAT/LNG is not available Hence setting Vessel with empty GF location for vessel TERMINAAL: "
					+ dto.getVesselName());
			log.info("Please check whether VTS Down/UP !");
			dto.setVesselLocation("");
		}
	}
	
	/*tariq*/
	public static void setVesselLocationforPromis2(PromisTwoBPADetail dto,
			List<GeoFenceData> geofenceData) {
		VesselLocationCalculator locationCalculator = new VesselLocationCalculator();

		if (dto.getLatitude() != null && dto.getLongitude() != null) {
			log.debug("Calling getVesselGeoLocation API to calculate Vessel location  for vessel :"
					+ dto.getVesselName());
			String geoLocation = VesselDataCalcHelper.getVesselGeoLocation(
					geofenceData, Double.parseDouble(dto.getLatitude()),
					Double.parseDouble(dto.getLongitude()));
			if (geoLocation != null)
				dto.setVesselLocation(geoLocation);
			log.debug("Vessel location for vessel :" + dto.getVesselName()
					+ " during  Computation PORT TERMINAAL: "
					+ dto.getVesselLocation());
			log.debug("Vessel : " + dto.getVesselName()
					+ " with lat and lang PORT TERMINAAL : "
					+ dto.getLatitude() + " / " + dto.getLongitude());
			String geofenceArea = null;
			if (dto.getLatitude() != null & dto.getLongitude() != null)
				geofenceArea = locationCalculator.getTerminalQ(
						Double.parseDouble(dto.getLatitude()),
						Double.parseDouble(dto.getLongitude()));
			if (geofenceArea != null)
				dto.setVesselLocation(geofenceArea);

			String location = VesselIconsPointsHolder.getVesselGeofence(
					getGeoFenceData(geofenceData),
					Float.parseFloat(dto.getLatitude()),
					Float.parseFloat(dto.getLongitude()));
			if (location != null && !"".equalsIgnoreCase(location.trim()))
				dto.setVesselLocation(location);
			log.debug("Vessel location after performing computation TERMINAAL for vessel :"
					+ dto.getVesselName()
					+ " Location : "
					+ dto.getVesselLocation()
					+ " with rotation number : "
					+ dto.getRotation());
		} else {
			log.info("LAT/LNG is not available Hence setting Vessel with empty GF location for vessel TERMINAAL: "
					+ dto.getVesselName());
			log.info("Please check whether VTS Down/UP !");
			dto.setVesselLocation("");
		}
	}
/*tariq*/

	public static Map<String, List<GeoFenceData>> getGeoFenceData(
			List<GeoFenceData> geofenceData) {

		Map<String, List<GeoFenceData>> geoFenceMap = new HashMap<String, List<GeoFenceData>>();
		try {

			if (geofenceData.size() > 0) {
				for (GeoFenceData geomaster : geofenceData) {
					List<GeoFenceData> geoFenceList = geoFenceMap.get(geomaster
							.getGeoCode());

					if (geoFenceList == null) {
						geoFenceList = new ArrayList<GeoFenceData>();
					}
					GeoFenceData geoFenceData = new GeoFenceData();
					geoFenceData.setGeoCode(geomaster.getGeoCode());
					geoFenceData.setLat(geomaster.getLat());
					geoFenceData.setLng(geomaster.getLng());
					geoFenceData.setPointOrder(geomaster.getPointOrder());
					geoFenceList.add(geoFenceData);
					geoFenceMap.put(geomaster.getGeoCode(), geoFenceList);
				}

				PointsOrderComparator pointsOrderComparator = new PointsOrderComparator();
				if (geoFenceMap.entrySet() != null) {
					for (Map.Entry<String, List<GeoFenceData>> entry : geoFenceMap
							.entrySet()) {
						Collections.sort(entry.getValue(),
								pointsOrderComparator);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return geoFenceMap;
	}

	public static PromisBPADetail retriveCBBSData(String rotationNumber) {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside retriveCBBSData API with start time :"
						+ startTime);
			PromisBPADetail detail = new PromisBPADetail();

			RotationCriteria criteria = constructRotationCriteria(
					rotationNumber, null);
			VoyageService service = new VoyageService();

			if (service.getVoyageServicePort() != null
					&& service.getVoyageServicePort().searchVesselVoyages(
							criteria) != null
					&& service.getVoyageServicePort()
							.searchVesselVoyages(criteria).getVesselVoyage() != null) {

				VesselVoyage vesselVoyage = service.getVoyageServicePort()
						.searchVesselVoyages(criteria).getVesselVoyage();
				if (vesselVoyage != null
						&& vesselVoyage.getTerminalVisits() != null
						&& !vesselVoyage.getTerminalVisits().isEmpty()) {

					List<VoyageTerminalVisit> terminalVisitList = vesselVoyage
							.getTerminalVisits();
					List<TerminalVisit> terminalListConstructed = new ArrayList<TerminalVisit>();
					for (VoyageTerminalVisit terminalVisit : terminalVisitList) {

						if (terminalVisit != null) {
							TerminalVisit promisVisit = new TerminalVisit();
							BeanUtils
									.copyProperties(terminalVisit, promisVisit);
							setDateFields(terminalVisit, promisVisit);
							terminalListConstructed.add(promisVisit);

						}

					}
					detail.setTerminalVisitList(terminalListConstructed);
					long endTime = System.currentTimeMillis();
					log.debug("fetchCBBSData End Time : " + endTime);
					log.info("Time Taken by fetchCBBSData in milli seconds : "
							+ (endTime - startTime));
					return detail;

				}
			}
			return detail;
		} catch (Exception e) {
			log.error("Exception inside fetchCBBSData API : "
					+ stackTraceToString(e));
			throw e;
		}
	}
	
	/*tariqmarine*/
	public static PromisTwoBPADetail retriveCBBSDataforMarineJoblist(String rotationNumber,String visit_id) {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside retriveCBBSData API with start time :"
						+ startTime);
			//PromisBPADetail detail = new PromisBPADetail();
			PromisTwoBPADetail detail= new PromisTwoBPADetail();

		//	RotationCriteria criteria = constructRotationCriteria(
		//			rotationNumber, null);
			
			RotationCriteria criteria = new RotationCriteria();
			criteria.setRotationNumber(rotationNumber);
			//criteria.setVisitId(visit_id);
		    criteria.setVisitId(Long.parseLong(visit_id));
			criteria.setSourceSystem(MPCConstants.SYSTEM_MPC);
			criteria.setPrivateKey(MpcPropertyUtil
					.getPropertyFromConfiguration(MPCConstants.CBBS_ACCESS_KEY));
			
			
			VoyageService service = new VoyageService();

			if (service.getVoyageServicePort() != null
					&& service.getVoyageServicePort().searchVesselVoyages(
							criteria) != null
					&& service.getVoyageServicePort()
							.searchVesselVoyages(criteria).getVesselVoyage() != null) {

				VesselVoyage vesselVoyage = service.getVoyageServicePort()
						.searchVesselVoyages(criteria).getVesselVoyage();
				if (vesselVoyage != null
						&& vesselVoyage.getTerminalVisits() != null
						&& !vesselVoyage.getTerminalVisits().isEmpty()) {
					
					List<TerminalVisit> terminalListConstructed=null;

					
					
				/*	List<VoyageTerminalVisit> terminalVisitList = vesselVoyage
							.getTerminalVisits();
					List<TerminalVisit> terminalListConstructed = new ArrayList<TerminalVisit>();
					for (VoyageTerminalVisit terminalVisit : terminalVisitList) {

						if (terminalVisit != null) {
							TerminalVisit promisVisit = new TerminalVisit();
							BeanUtils
									.copyProperties(terminalVisit, promisVisit);
							setDateFields(terminalVisit, promisVisit);
							terminalListConstructed.add(promisVisit);

						}

					}*/
					detail.setVesselName(vesselVoyage.getVesselName());  
					detail.setBerthbookingnumber(vesselVoyage.getId().toString());
					detail.setAgentCode(vesselVoyage.getAgentCode());
				    					
									
					detail.setVisit_id(vesselVoyage.getTerminalVisits().get(0).getVisitId().toString());
					detail.setVisit_seq_no(vesselVoyage.getTerminalVisits().get(0).getVisitSeq().toString());
					detail.setVisit_type(vesselVoyage.getTerminalVisits().get(0).getVisitTypeName().toString());
					
					
					//new code.
					
					RotationCriteria criteriaforrotation = new RotationCriteria();
					criteriaforrotation.setRotationNumber(rotationNumber);
					//criteria.setVisitId(visit_id);
				  //  criteria.setVisitId(Long.parseLong(visit_id));
					criteriaforrotation.setSourceSystem(MPCConstants.SYSTEM_MPC);
					criteriaforrotation.setPrivateKey(MpcPropertyUtil
							.getPropertyFromConfiguration(MPCConstants.CBBS_ACCESS_KEY));
					
					
					VoyageService serviceforrotation = new VoyageService();
					if (serviceforrotation.getVoyageServicePort() != null
							&& serviceforrotation.getVoyageServicePort().searchVesselVoyages(
									criteriaforrotation) != null
							&& serviceforrotation.getVoyageServicePort()
									.searchVesselVoyages(criteriaforrotation).getVesselVoyage() != null) {

						VesselVoyage vesselVoyageforVisitList = serviceforrotation.getVoyageServicePort()
								.searchVesselVoyages(criteriaforrotation).getVesselVoyage();
						
						
						if (vesselVoyageforVisitList != null
								&& vesselVoyageforVisitList.getTerminalVisits() != null
								&& !vesselVoyageforVisitList.getTerminalVisits().isEmpty()) {
							
							
							
							List<VoyageTerminalVisit> terminalVisitList = vesselVoyage
							.getTerminalVisits();
					 terminalListConstructed = new ArrayList<TerminalVisit>();
					for (VoyageTerminalVisit terminalVisit : terminalVisitList) {

						if (terminalVisit != null) {
							TerminalVisit promisVisit = new TerminalVisit();
							BeanUtils
									.copyProperties(terminalVisit, promisVisit);
							setDateFields(terminalVisit, promisVisit);
							terminalListConstructed.add(promisVisit);
					

						}

					}
							
						}
					
					
					}
					
					
					
					
					
					
					
					
					
					detail.setTerminalVisitList(terminalListConstructed);
					long endTime = System.currentTimeMillis();
					log.debug("fetchCBBSData End Time : " + endTime);
					log.info("Time Taken by fetchCBBSData in milli seconds : "
							+ (endTime - startTime));
					return detail;

				}
				
				
				
				
				
				
				
				
				
			}
			return detail;
		} catch (Exception e) {
			log.error("Exception inside fetchCBBSData API : "
					+ stackTraceToString(e));
			throw e;
		}
	}
	/*tariqmarine*/

	/**
	 * This method is used to fetch CBBSData
	 * 
	 * @param bpaDetails
	 * @author Itpeople.Muthukumar
	 * 
	 */
	private static void fetchCBBSData(List<PromisBPADetail> bpaDetails) {
		try {
			long startTime = System.currentTimeMillis();
			if (log.isDebugEnabled())
				log.debug("Inside fetchCBBSData API with start time :"
						+ startTime);
			if (bpaDetails != null && !bpaDetails.isEmpty()) {

				for (PromisBPADetail detail : bpaDetails) {

					if (detail != null) {

						RotationCriteria criteria = constructRotationCriteria(
								detail.getRotation(), detail.getTerminalId());
						VoyageService service = new VoyageService();

						if (service.getVoyageServicePort() != null
								&& service.getVoyageServicePort()
										.searchVesselVoyages(criteria) != null
								&& service.getVoyageServicePort()
										.searchVesselVoyages(criteria)
										.getVesselVoyage() != null) {

							VesselVoyage vesselVoyage = service
									.getVoyageServicePort()
									.searchVesselVoyages(criteria)
									.getVesselVoyage();
							if (vesselVoyage != null
									&& vesselVoyage.getTerminalVisits() != null
									&& !vesselVoyage.getTerminalVisits()
											.isEmpty()) {

								List<VoyageTerminalVisit> terminalVisitList = vesselVoyage
										.getTerminalVisits();
								List<TerminalVisit> terminalListConstructed = new ArrayList<TerminalVisit>();
								for (VoyageTerminalVisit terminalVisit : terminalVisitList) {

									if (terminalVisit != null) {
										TerminalVisit promisVisit = new TerminalVisit();
										BeanUtils.copyProperties(terminalVisit,
												promisVisit);
										setDateFields(terminalVisit,
												promisVisit);
										terminalListConstructed
												.add(promisVisit);

									}

								}
								detail.setTerminalVisitList(terminalListConstructed);

							}
						}
					}
				}
			}
			long endTime = System.currentTimeMillis();
			log.debug("fetchCBBSData End Time : " + endTime);
			log.info("Time Taken by fetchCBBSData in milli seconds : "
					+ (endTime - startTime));
		} catch (Exception e) {
			log.error("Exception inside fetchCBBSData API : "
					+ stackTraceToString(e));
			throw e;
		}
	}

	public static List<UserDetails> getUserInfoList() throws IOException {
		init();
		List userList = (List<UserDetails>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_PROMIS_UM, "getUserListData", null, null,
				null);
		return userList;
	}

	public static List<UserDetails> getRoleInfoList() throws IOException {
		init();
		List userList = (List<UserDetails>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_PROMIS_UM, "getRoleListData", null, null,
				null);
		return userList;
	}

	public static List<TimeDetails> getTimeDetails(String rotationNumber)
			throws IOException {
		init();
		FilterCriteria filterCriteria = new FilterCriteria();
		filterCriteria.setRotationNumbers(rotationNumber);
		List timeDetailsList = (List<TimeDetails>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_PROMISD, "getTimeDetailsListData",
				filterCriteria, null, null);
		return timeDetailsList;
	}
	
	public static List<CbbsDetails> getCBBSCAM() throws IOException {
		init();
		List cbbsDetailsList = (List<CbbsDetails>) crudOperation(SELECT_LIST,
				DataBaseFactory.DB_CBBSCAM, "getCbbsDetails", null, null,
				null);
		return cbbsDetailsList;
	}
}







class PointsOrderComparator implements Comparator<GeoFenceData> {

	public int compare(GeoFenceData d, GeoFenceData d1) {
		if (d != null && d1 != null
				&& (d.getPointOrder() != null && d1.getPointOrder() != null)) {
			if (d.getPointOrder() > d1.getPointOrder()) {
				return 1;
			} else if (d.getPointOrder() < d1.getPointOrder()) {
				return -1;
			} else {
				return 0;
			}
		}
		return 0;
	}

}

class PromisBPADetailComparator implements Comparator<PromisBPADetail> {

	@Override
	public int compare(PromisBPADetail d, PromisBPADetail d1) {
		if (d.getBerthDate() != null
				&& d1.getBerthDate() != null
				&& !d.getBerthDate().trim()
						.equalsIgnoreCase(d1.getBerthDate().trim())) {
			return -1;
		} else if (d.getSailDate() != null
				&& d1.getSailDate() != null
				&& !d.getSailDate().trim()
						.equalsIgnoreCase(d1.getSailDate().trim())) {
			return -1;
		} else if (d.getEtaDate() != null
				&& d1.getEtaDate() != null
				&& !d.getEtaDate().trim()
						.equalsIgnoreCase(d1.getEtaDate().trim())) {
			return -1;
		} else if (d.getEtbDate() != null
				&& d1.getEtbDate() != null
				&& !d.getEtbDate().trim()
						.equalsIgnoreCase(d1.getEtbDate().trim())) {
			return -1;
		} else if (d.getEtdDate() != null
				&& d1.getEtdDate() != null
				&& !d.getEtdDate().trim()
						.equalsIgnoreCase(d1.getEtdDate().trim())) {
			return -1;
		} else if (d.getVoyageNumber() != null
				&& d1.getVoyageNumber() != null
				&& !d.getVoyageNumber().trim()
						.equalsIgnoreCase(d1.getVoyageNumber().trim())) {
			return -1;
		} else if (d.getCallReason() != null
				&& d1.getCallReason() != null
				&& !d.getCallReason().trim()
						.equalsIgnoreCase(d1.getCallReason().trim())) {
			return -1;
		} else if (d.getCallType() != null
				&& d1.getCallType() != null
				&& !d.getCallType().trim()
						.equalsIgnoreCase(d1.getCallType().trim())) {
			return -1;
		} else if (d.getCallDescr() != null
				&& d1.getCallDescr() != null
				&& !d.getCallDescr().trim()
						.equalsIgnoreCase(d1.getCallDescr().trim())) {
			return -1;
		} else if (d.getPlanMoves() != null
				&& d1.getPlanMoves() != null
				&& !d.getPlanMoves().trim()
						.equalsIgnoreCase(d1.getPlanMoves().trim())) {
			return -1;
		} else if (d.getLineCode() != null
				&& d1.getLineCode() != null
				&& !d.getLineCode().trim()
						.equalsIgnoreCase(d1.getLineCode().trim())) {
			return -1;
		} else if (d.getInVesselService() != null
				&& d1.getInVesselService() != null
				&& !d.getInVesselService().trim()
						.equalsIgnoreCase(d1.getInVesselService().trim())) {
			return -1;
		} else if (d.getArrDraft() != null
				&& d1.getArrDraft() != null
				&& !d.getArrDraft().trim()
						.equalsIgnoreCase(d1.getArrDraft().trim())) {
			return -1;
		} else if (d.getSailDraft() != null
				&& d1.getSailDraft() != null
				&& !d.getSailDraft().trim()
						.equalsIgnoreCase(d1.getSailDraft().trim())) {
			return -1;
		} else if (d.getDualBerth() != null
				&& d1.getDualBerth() != null
				&& !d.getDualBerth().trim()
						.equalsIgnoreCase(d1.getDualBerth().trim())) {
			return -1;
		} else if (d.getPortCode() != null
				&& d1.getPortCode() != null
				&& !d.getPortCode().trim()
						.equalsIgnoreCase(d1.getPortCode().trim())) {
			return -1;
		} else if (d.getTerminalId() != null
				&& d1.getTerminalId() != null
				&& !d.getTerminalId().trim()
						.equalsIgnoreCase(d1.getTerminalId().trim())) {
			return -1;

		} else if (d.getLoadTerminalId() != null
				&& d1.getLoadTerminalId() != null
				&& !d.getLoadTerminalId().trim()
						.equalsIgnoreCase(d1.getLoadTerminalId().trim())) {
			return -1;
		} else if (d.getCallSign() != null
				&& d1.getCallSign() != null
				&& !d.getCallSign().trim()
						.equalsIgnoreCase(d1.getCallSign().trim())) {
			return -1;
		} else if (d.getImoCode() != null
				&& d1.getImoCode() != null
				&& !d.getImoCode().trim()
						.equalsIgnoreCase(d1.getImoCode().trim())) {
			return -1;
		} else if (d.getVesselType() != null
				&& d1.getVesselType() != null
				&& !d.getVesselType().trim()
						.equalsIgnoreCase(d1.getVesselType().trim())) {
			return -1;
		} else if (d.getVesselName() != null
				&& d1.getVesselName() != null
				&& !d.getVesselName().trim()
						.equalsIgnoreCase(d1.getVesselName().trim())) {
			return -1;
		} else if (d.getArrFm() != null && d1.getArrFm() != null
				&& !d.getArrFm().trim().equalsIgnoreCase(d1.getArrFm().trim())) {
			return -1;
		} else
			return 0;

	}

}