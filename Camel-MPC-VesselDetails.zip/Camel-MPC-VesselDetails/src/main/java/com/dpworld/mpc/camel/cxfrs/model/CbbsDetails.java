package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;

public class CbbsDetails implements Serializable {

	private static final long serialVersionUID = 1345830880470376447L;
	
	private String voyage_id;
	private String rotn;
	private String voyage_ref;
	private String booking_type;
	private String port_code;
	private String port_eta;
	private String port_etd;
	private String port_berth_date;
	private String port_sail_date;
	private String visit_id;
	private String visit_seq_no;
	private String visit_terminal;
	private String visit_type;
	private String visit_eta;
	private String visit_etb;
	private String visit_etd;
	private Integer maxVisitSeqNo;
	private String visit_berth_date;
	private String visit_sail_date;
	private String port_arr_date;
	private String heaveUpTime;
	
	
	
	public String getHeaveUpTime() {
		return heaveUpTime;
	}
	public void setHeaveUpTime(String heaveUpTime) {
		this.heaveUpTime = heaveUpTime;
	}
	public String getPort_arr_date() {
		return port_arr_date;
	}
	public void setPort_arr_date(String port_arr_date) {
		this.port_arr_date = port_arr_date;
	}
	public String getVisit_berth_date() {
		return visit_berth_date;
	}
	public void setVisit_berth_date(String visit_berth_date) {
		this.visit_berth_date = visit_berth_date;
	}
	public String getVisit_sail_date() {
		return visit_sail_date;
	}
	public void setVisit_sail_date(String visit_sail_date) {
		this.visit_sail_date = visit_sail_date;
	}
	
	
	
	
	public String getVoyage_id() {
		return voyage_id;
	}
	public void setVoyage_id(String voyage_id) {
		this.voyage_id = voyage_id;
	}
	public String getRotn() {
		return rotn;
	}
	public void setRotn(String rotn) {
		this.rotn = rotn;
	}
	public String getVoyage_ref() {
		return voyage_ref;
	}
	public void setVoyage_ref(String voyage_ref) {
		this.voyage_ref = voyage_ref;
	}
	public String getBooking_type() {
		return booking_type;
	}
	public void setBooking_type(String booking_type) {
		this.booking_type = booking_type;
	}
	public String getPort_code() {
		return port_code;
	}
	public void setPort_code(String port_code) {
		this.port_code = port_code;
	}
	public String getPort_eta() {
		return port_eta;
	}
	public void setPort_eta(String port_eta) {
		this.port_eta = port_eta;
	}
	public String getPort_etd() {
		return port_etd;
	}
	public void setPort_etd(String port_etd) {
		this.port_etd = port_etd;
	}
	public String getPort_berth_date() {
		return port_berth_date;
	}
	public void setPort_berth_date(String port_berth_date) {
		this.port_berth_date = port_berth_date;
	}
	public String getPort_sail_date() {
		return port_sail_date;
	}
	public void setPort_sail_date(String port_sail_date) {
		this.port_sail_date = port_sail_date;
	}
	public String getVisit_id() {
		return visit_id;
	}
	public void setVisit_id(String visit_id) {
		this.visit_id = visit_id;
	}
	public String getVisit_seq_no() {
		return visit_seq_no;
	}
	public void setVisit_seq_no(String visit_seq_no) {
		this.visit_seq_no = visit_seq_no;
	}
	public String getVisit_terminal() {
		return visit_terminal;
	}
	public void setVisit_terminal(String visit_terminal) {
		this.visit_terminal = visit_terminal;
	}
	public String getVisit_type() {
		return visit_type;
	}
	public void setVisit_type(String visit_type) {
		this.visit_type = visit_type;
	}
	public String getVisit_eta() {
		return visit_eta;
	}
	public void setVisit_eta(String visit_eta) {
		this.visit_eta = visit_eta;
	}
	public String getVisit_etb() {
		return visit_etb;
	}
	public void setVisit_etb(String visit_etb) {
		this.visit_etb = visit_etb;
	}
	public String getVisit_etd() {
		return visit_etd;
	}
	public void setVisit_etd(String visit_etd) {
		this.visit_etd = visit_etd;
	}
	
	public Integer getMaxVisitSeqNo() {
		return maxVisitSeqNo;
	}
	public void setMaxVisitSeqNo(Integer maxVisitSeqNo) {
		this.maxVisitSeqNo = maxVisitSeqNo;
	}
	@Override
	public String toString() {
		return "CbbsDetails [voyage_id=" + voyage_id + ", rotn=" + rotn + ", voyage_ref=" + voyage_ref
				+ ", booking_type=" + booking_type + ", port_code=" + port_code + ", port_eta=" + port_eta
				+ ", port_etd=" + port_etd + ", port_berth_date=" + port_berth_date + ", port_sail_date="
				+ port_sail_date + ", visit_id=" + visit_id + ", visit_seq_no=" + visit_seq_no + ", visit_terminal="
				+ visit_terminal + ", visit_type=" + visit_type + ", visit_eta=" + visit_eta + ", visit_etb="
				+ visit_etb + ", visit_etd=" + visit_etd + "]";
	}
	

}
