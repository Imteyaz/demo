/**
 * 
 */
package com.dpworld.mpc.camel.cxfrs.service.helper;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

public class CustomThreadFactory implements ThreadFactory {

	private String poolNamePrefix = null;

	private int priority = Thread.MAX_PRIORITY;

	private final AtomicLong count = new AtomicLong(0);

	/**
	 * 
	 */
	public CustomThreadFactory(String threadPoolName, int priority) {
		this.poolNamePrefix = threadPoolName;
		this.priority = priority;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.concurrent.ThreadFactory#newThread(java.lang.Runnable)
	 */
	@Override
	public Thread newThread(Runnable runnable) {
		Thread thread = new Thread(runnable);

		if (poolNamePrefix != null) {

			thread.setName(poolNamePrefix + "-" + count.getAndIncrement());

		}

		thread.setPriority(priority);

		return thread;
	}

}
