package com.dpworld.mpc.camel.cxfrs.model;

import java.io.Serializable;
import java.util.Date;

public class MPCGeoFenceMaster implements Serializable {

  private static final long serialVersionUID = 2919488112447888905L;

  private long mgmRecId;
  private Date mgmRecDate;
  private Integer terminalId;
  private String mgmGFCode;
  private Float mgmGFLat;
  private Float mgmGFLong;
  private Integer mgmGFSeqNo;
  private Integer isValid;
  private String srcSys;
  private String createdBy;
  private Date careatedDate;
  private String modifiedBy;
  private Date modifiedDate;

  public long getMgmRecId() {
    return mgmRecId;
  }

  public void setMgmRecId(long mgmRecId) {
    this.mgmRecId = mgmRecId;
  }

  public Date getMgmRecDate() {
    return mgmRecDate;
  }

  public void setMgmRecDate(Date mgmRecDate) {
    this.mgmRecDate = mgmRecDate;
  }

  public Integer getTerminalId() {
    return terminalId;
  }

  public void setTerminalId(Integer terminalId) {
    this.terminalId = terminalId;
  }

  public String getMgmGFCode() {
    return mgmGFCode;
  }

  public void setMgmGFCode(String mgmGFCode) {
    this.mgmGFCode = mgmGFCode;
  }

  public Float getMgmGFLat() {
    return mgmGFLat;
  }

  public void setMgmGFLat(Float mgmGFLat) {
    this.mgmGFLat = mgmGFLat;
  }

  public Float getMgmGFLong() {
    return mgmGFLong;
  }

  public void setMgmGFLong(Float mgmGFLong) {
    this.mgmGFLong = mgmGFLong;
  }

  public Integer getMgmGFSeqNo() {
    return mgmGFSeqNo;
  }

  public void setMgmGFSeqNo(Integer mgmGFSeqNo) {
    this.mgmGFSeqNo = mgmGFSeqNo;
  }

  public Integer getIsValid() {
    return isValid;
  }

  public void setIsValid(Integer isValid) {
    this.isValid = isValid;
  }

  public String getSrcSys() {
    return srcSys;
  }

  public void setSrcSys(String srcSys) {
    this.srcSys = srcSys;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCareatedDate() {
    return careatedDate;
  }

  public void setCareatedDate(Date careatedDate) {
    this.careatedDate = careatedDate;
  }

  public String getModifiedBy() {
    return modifiedBy;
  }

  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  public Date getModifiedDate() {
    return modifiedDate;
  }

  public void setModifiedDate(Date modifiedDate) {
    this.modifiedDate = modifiedDate;
  }

}
