package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>
 * Java class for rotationCriteria complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="rotationCriteria">
 *   &lt;complexContent>
 *     &lt;extension base="{http://service.cxf.camel.dpworld.com/}authInfo">
 *       &lt;sequence>
 *         &lt;element name="rotationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="terminal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="visitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rotationCriteria", propOrder = {"rotationNumber", "terminal", "visitId",
    "visitType", "voyageReferenceNumber"})
public class RotationCriteria extends AuthInfo {

  protected String rotationNumber;
  protected String terminal;
  protected Long visitId;
  protected String visitType;
  protected String voyageReferenceNumber;

  /**
   * Gets the value of the rotationNumber property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getRotationNumber() {
    return rotationNumber;
  }

  /**
   * Sets the value of the rotationNumber property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setRotationNumber(String value) {
    this.rotationNumber = value;
  }

  /**
   * Gets the value of the terminal property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getTerminal() {
    return terminal;
  }

  /**
   * Sets the value of the terminal property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setTerminal(String value) {
    this.terminal = value;
  }

  /**
   * Gets the value of the visitId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVisitId() {
    return visitId;
  }

  /**
   * Sets the value of the visitId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVisitId(Long value) {
    this.visitId = value;
  }

  /**
   * Gets the value of the visitType property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitType() {
    return visitType;
  }

  /**
   * Sets the value of the visitType property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitType(String value) {
    this.visitType = value;
  }

  /**
   * Gets the value of the voyageReferenceNumber property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageReferenceNumber() {
    return voyageReferenceNumber;
  }

  /**
   * Sets the value of the voyageReferenceNumber property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageReferenceNumber(String value) {
    this.voyageReferenceNumber = value;
  }

}
