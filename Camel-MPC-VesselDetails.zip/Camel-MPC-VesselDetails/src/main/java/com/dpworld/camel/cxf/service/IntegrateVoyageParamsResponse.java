package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>
 * Java class for integrateVoyageParamsResponse complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="integrateVoyageParamsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://service.cxf.camel.dpworld.com/}outputMessageResult" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "integrateVoyageParamsResponse", propOrder = {"_return"})
public class IntegrateVoyageParamsResponse {

  @XmlElement(name = "return")
  protected OutputMessageResult _return;

  /**
   * Gets the value of the return property.
   * 
   * @return possible object is {@link OutputMessageResult }
   * 
   */
  public OutputMessageResult getReturn() {
    return _return;
  }

  /**
   * Sets the value of the return property.
   * 
   * @param value allowed object is {@link OutputMessageResult }
   * 
   */
  public void setReturn(OutputMessageResult value) {
    this._return = value;
  }

}
