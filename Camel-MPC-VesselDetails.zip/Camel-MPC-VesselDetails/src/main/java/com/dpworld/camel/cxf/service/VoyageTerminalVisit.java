package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>
 * Java class for voyageTerminalVisit complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="voyageTerminalVisit">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="actualArrivalTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="actualBerthCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="actualBerthName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="actualBerthTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="actualDepartTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="arrivalAfterDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="arrivalForwardDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="deadShipFlag" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="deadWeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="estimatedArrivalTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="estimatedBerthTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="estimatedDepartTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="estimatedDischargeMoves" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="estimatedLoadMoves" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="estimatedOtherMoves" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="gasFlag" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="inertedFlag" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="isActive" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="laybyFromBerth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loadCutoffTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="loadedShipFlag" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="noOfCranes" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="noOfHatches" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="operationTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="operationTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="preferredBerthCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="preferredBerthName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="repairCompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sailAftDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="sailForwardDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="sustainedGears" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="terminal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="terminalName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unBerthingTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="vesselPositionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vesselPositionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="visitReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitReasonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitSeq" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="visitTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="workEndDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="workStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "voyageTerminalVisit", propOrder = {"actualArrivalTime", "actualBerthCode",
    "actualBerthName", "actualBerthTime", "actualDepartTime", "arrivalAfterDraft",
    "arrivalForwardDraft", "deadShipFlag", "deadWeight", "estimatedArrivalTime",
    "estimatedBerthTime", "estimatedDepartTime", "estimatedDischargeMoves", "estimatedLoadMoves",
    "estimatedOtherMoves", "gasFlag", "inertedFlag", "isActive", "laybyFromBerth",
    "loadCutoffTime", "loadedShipFlag", "noOfCranes", "noOfHatches", "operationTypeCode",
    "operationTypeName", "preferredBerthCode", "preferredBerthName", "priority", "repairCompany",
    "sailAftDraft", "sailForwardDraft", "sustainedGears", "terminal", "terminalName",
    "unBerthingTime", "vesselPositionCode", "vesselPositionName", "visitId", "visitReasonCode",
    "visitReasonName", "visitRemarks", "visitSeq", "visitTypeCode", "visitTypeName", "workEndDate",
    "workStartDate"})
public class VoyageTerminalVisit {

  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar actualArrivalTime;
  protected String actualBerthCode;
  protected String actualBerthName;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar actualBerthTime;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar actualDepartTime;
  protected Double arrivalAfterDraft;
  protected Double arrivalForwardDraft;
  protected Integer deadShipFlag;
  protected Double deadWeight;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar estimatedArrivalTime;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar estimatedBerthTime;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar estimatedDepartTime;
  protected Long estimatedDischargeMoves;
  protected Long estimatedLoadMoves;
  protected Long estimatedOtherMoves;
  protected Integer gasFlag;
  protected Integer inertedFlag;
  protected Integer isActive;
  protected String laybyFromBerth;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar loadCutoffTime;
  protected Integer loadedShipFlag;
  protected Long noOfCranes;
  protected String noOfHatches;
  protected String operationTypeCode;
  protected String operationTypeName;
  protected String preferredBerthCode;
  protected String preferredBerthName;
  protected Double priority;
  protected String repairCompany;
  protected Double sailAftDraft;
  protected Double sailForwardDraft;
  protected String sustainedGears;
  protected String terminal;
  protected String terminalName;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar unBerthingTime;
  protected String vesselPositionCode;
  protected String vesselPositionName;
  protected Long visitId;
  protected String visitReasonCode;
  protected String visitReasonName;
  protected String visitRemarks;
  protected Integer visitSeq;
  protected String visitTypeCode;
  protected String visitTypeName;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar workEndDate;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar workStartDate;

  /**
   * Gets the value of the actualArrivalTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getActualArrivalTime() {
    return actualArrivalTime;
  }

  /**
   * Sets the value of the actualArrivalTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setActualArrivalTime(XMLGregorianCalendar value) {
    this.actualArrivalTime = value;
  }

  /**
   * Gets the value of the actualBerthCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getActualBerthCode() {
    return actualBerthCode;
  }

  /**
   * Sets the value of the actualBerthCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setActualBerthCode(String value) {
    this.actualBerthCode = value;
  }

  /**
   * Gets the value of the actualBerthName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getActualBerthName() {
    return actualBerthName;
  }

  /**
   * Sets the value of the actualBerthName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setActualBerthName(String value) {
    this.actualBerthName = value;
  }

  /**
   * Gets the value of the actualBerthTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getActualBerthTime() {
    return actualBerthTime;
  }

  /**
   * Sets the value of the actualBerthTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setActualBerthTime(XMLGregorianCalendar value) {
    this.actualBerthTime = value;
  }

  /**
   * Gets the value of the actualDepartTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getActualDepartTime() {
    return actualDepartTime;
  }

  /**
   * Sets the value of the actualDepartTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setActualDepartTime(XMLGregorianCalendar value) {
    this.actualDepartTime = value;
  }

  /**
   * Gets the value of the arrivalAfterDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getArrivalAfterDraft() {
    return arrivalAfterDraft;
  }

  /**
   * Sets the value of the arrivalAfterDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setArrivalAfterDraft(Double value) {
    this.arrivalAfterDraft = value;
  }

  /**
   * Gets the value of the arrivalForwardDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getArrivalForwardDraft() {
    return arrivalForwardDraft;
  }

  /**
   * Sets the value of the arrivalForwardDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setArrivalForwardDraft(Double value) {
    this.arrivalForwardDraft = value;
  }

  /**
   * Gets the value of the deadShipFlag property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getDeadShipFlag() {
    return deadShipFlag;
  }

  /**
   * Sets the value of the deadShipFlag property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setDeadShipFlag(Integer value) {
    this.deadShipFlag = value;
  }

  /**
   * Gets the value of the deadWeight property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getDeadWeight() {
    return deadWeight;
  }

  /**
   * Sets the value of the deadWeight property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setDeadWeight(Double value) {
    this.deadWeight = value;
  }

  /**
   * Gets the value of the estimatedArrivalTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getEstimatedArrivalTime() {
    return estimatedArrivalTime;
  }

  /**
   * Sets the value of the estimatedArrivalTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setEstimatedArrivalTime(XMLGregorianCalendar value) {
    this.estimatedArrivalTime = value;
  }

  /**
   * Gets the value of the estimatedBerthTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getEstimatedBerthTime() {
    return estimatedBerthTime;
  }

  /**
   * Sets the value of the estimatedBerthTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setEstimatedBerthTime(XMLGregorianCalendar value) {
    this.estimatedBerthTime = value;
  }

  /**
   * Gets the value of the estimatedDepartTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getEstimatedDepartTime() {
    return estimatedDepartTime;
  }

  /**
   * Sets the value of the estimatedDepartTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setEstimatedDepartTime(XMLGregorianCalendar value) {
    this.estimatedDepartTime = value;
  }

  /**
   * Gets the value of the estimatedDischargeMoves property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getEstimatedDischargeMoves() {
    return estimatedDischargeMoves;
  }

  /**
   * Sets the value of the estimatedDischargeMoves property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setEstimatedDischargeMoves(Long value) {
    this.estimatedDischargeMoves = value;
  }

  /**
   * Gets the value of the estimatedLoadMoves property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getEstimatedLoadMoves() {
    return estimatedLoadMoves;
  }

  /**
   * Sets the value of the estimatedLoadMoves property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setEstimatedLoadMoves(Long value) {
    this.estimatedLoadMoves = value;
  }

  /**
   * Gets the value of the estimatedOtherMoves property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getEstimatedOtherMoves() {
    return estimatedOtherMoves;
  }

  /**
   * Sets the value of the estimatedOtherMoves property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setEstimatedOtherMoves(Long value) {
    this.estimatedOtherMoves = value;
  }

  /**
   * Gets the value of the gasFlag property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getGasFlag() {
    return gasFlag;
  }

  /**
   * Sets the value of the gasFlag property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setGasFlag(Integer value) {
    this.gasFlag = value;
  }

  /**
   * Gets the value of the inertedFlag property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getInertedFlag() {
    return inertedFlag;
  }

  /**
   * Sets the value of the inertedFlag property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setInertedFlag(Integer value) {
    this.inertedFlag = value;
  }

  /**
   * Gets the value of the isActive property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getIsActive() {
    return isActive;
  }

  /**
   * Sets the value of the isActive property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setIsActive(Integer value) {
    this.isActive = value;
  }

  /**
   * Gets the value of the laybyFromBerth property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getLaybyFromBerth() {
    return laybyFromBerth;
  }

  /**
   * Sets the value of the laybyFromBerth property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setLaybyFromBerth(String value) {
    this.laybyFromBerth = value;
  }

  /**
   * Gets the value of the loadCutoffTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getLoadCutoffTime() {
    return loadCutoffTime;
  }

  /**
   * Sets the value of the loadCutoffTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setLoadCutoffTime(XMLGregorianCalendar value) {
    this.loadCutoffTime = value;
  }

  /**
   * Gets the value of the loadedShipFlag property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getLoadedShipFlag() {
    return loadedShipFlag;
  }

  /**
   * Sets the value of the loadedShipFlag property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setLoadedShipFlag(Integer value) {
    this.loadedShipFlag = value;
  }

  /**
   * Gets the value of the noOfCranes property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getNoOfCranes() {
    return noOfCranes;
  }

  /**
   * Sets the value of the noOfCranes property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setNoOfCranes(Long value) {
    this.noOfCranes = value;
  }

  /**
   * Gets the value of the noOfHatches property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getNoOfHatches() {
    return noOfHatches;
  }

  /**
   * Sets the value of the noOfHatches property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setNoOfHatches(String value) {
    this.noOfHatches = value;
  }

  /**
   * Gets the value of the operationTypeCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getOperationTypeCode() {
    return operationTypeCode;
  }

  /**
   * Sets the value of the operationTypeCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setOperationTypeCode(String value) {
    this.operationTypeCode = value;
  }

  /**
   * Gets the value of the operationTypeName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getOperationTypeName() {
    return operationTypeName;
  }

  /**
   * Sets the value of the operationTypeName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setOperationTypeName(String value) {
    this.operationTypeName = value;
  }

  /**
   * Gets the value of the preferredBerthCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getPreferredBerthCode() {
    return preferredBerthCode;
  }

  /**
   * Sets the value of the preferredBerthCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setPreferredBerthCode(String value) {
    this.preferredBerthCode = value;
  }

  /**
   * Gets the value of the preferredBerthName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getPreferredBerthName() {
    return preferredBerthName;
  }

  /**
   * Sets the value of the preferredBerthName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setPreferredBerthName(String value) {
    this.preferredBerthName = value;
  }

  /**
   * Gets the value of the priority property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getPriority() {
    return priority;
  }

  /**
   * Sets the value of the priority property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setPriority(Double value) {
    this.priority = value;
  }

  /**
   * Gets the value of the repairCompany property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getRepairCompany() {
    return repairCompany;
  }

  /**
   * Sets the value of the repairCompany property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setRepairCompany(String value) {
    this.repairCompany = value;
  }

  /**
   * Gets the value of the sailAftDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getSailAftDraft() {
    return sailAftDraft;
  }

  /**
   * Sets the value of the sailAftDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setSailAftDraft(Double value) {
    this.sailAftDraft = value;
  }

  /**
   * Gets the value of the sailForwardDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getSailForwardDraft() {
    return sailForwardDraft;
  }

  /**
   * Sets the value of the sailForwardDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setSailForwardDraft(Double value) {
    this.sailForwardDraft = value;
  }

  /**
   * Gets the value of the sustainedGears property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSustainedGears() {
    return sustainedGears;
  }

  /**
   * Sets the value of the sustainedGears property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSustainedGears(String value) {
    this.sustainedGears = value;
  }

  /**
   * Gets the value of the terminal property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getTerminal() {
    return terminal;
  }

  /**
   * Sets the value of the terminal property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setTerminal(String value) {
    this.terminal = value;
  }

  /**
   * Gets the value of the terminalName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getTerminalName() {
    return terminalName;
  }

  /**
   * Sets the value of the terminalName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setTerminalName(String value) {
    this.terminalName = value;
  }

  /**
   * Gets the value of the unBerthingTime property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getUnBerthingTime() {
    return unBerthingTime;
  }

  /**
   * Sets the value of the unBerthingTime property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setUnBerthingTime(XMLGregorianCalendar value) {
    this.unBerthingTime = value;
  }

  /**
   * Gets the value of the vesselPositionCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVesselPositionCode() {
    return vesselPositionCode;
  }

  /**
   * Sets the value of the vesselPositionCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVesselPositionCode(String value) {
    this.vesselPositionCode = value;
  }

  /**
   * Gets the value of the vesselPositionName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVesselPositionName() {
    return vesselPositionName;
  }

  /**
   * Sets the value of the vesselPositionName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVesselPositionName(String value) {
    this.vesselPositionName = value;
  }

  /**
   * Gets the value of the visitId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVisitId() {
    return visitId;
  }

  /**
   * Sets the value of the visitId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVisitId(Long value) {
    this.visitId = value;
  }

  /**
   * Gets the value of the visitReasonCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitReasonCode() {
    return visitReasonCode;
  }

  /**
   * Sets the value of the visitReasonCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitReasonCode(String value) {
    this.visitReasonCode = value;
  }

  /**
   * Gets the value of the visitReasonName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitReasonName() {
    return visitReasonName;
  }

  /**
   * Sets the value of the visitReasonName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitReasonName(String value) {
    this.visitReasonName = value;
  }

  /**
   * Gets the value of the visitRemarks property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitRemarks() {
    return visitRemarks;
  }

  /**
   * Sets the value of the visitRemarks property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitRemarks(String value) {
    this.visitRemarks = value;
  }

  /**
   * Gets the value of the visitSeq property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getVisitSeq() {
    return visitSeq;
  }

  /**
   * Sets the value of the visitSeq property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setVisitSeq(Integer value) {
    this.visitSeq = value;
  }

  /**
   * Gets the value of the visitTypeCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitTypeCode() {
    return visitTypeCode;
  }

  /**
   * Sets the value of the visitTypeCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitTypeCode(String value) {
    this.visitTypeCode = value;
  }

  /**
   * Gets the value of the visitTypeName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVisitTypeName() {
    return visitTypeName;
  }

  /**
   * Sets the value of the visitTypeName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVisitTypeName(String value) {
    this.visitTypeName = value;
  }

  /**
   * Gets the value of the workEndDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getWorkEndDate() {
    return workEndDate;
  }

  /**
   * Sets the value of the workEndDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setWorkEndDate(XMLGregorianCalendar value) {
    this.workEndDate = value;
  }

  /**
   * Gets the value of the workStartDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getWorkStartDate() {
    return workStartDate;
  }

  /**
   * Sets the value of the workStartDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setWorkStartDate(XMLGregorianCalendar value) {
    this.workStartDate = value;
  }

}
