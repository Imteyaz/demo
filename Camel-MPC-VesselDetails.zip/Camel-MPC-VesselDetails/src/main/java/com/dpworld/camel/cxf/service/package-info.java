@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.cxf.camel.dpworld.com/")
package com.dpworld.camel.cxf.service;

