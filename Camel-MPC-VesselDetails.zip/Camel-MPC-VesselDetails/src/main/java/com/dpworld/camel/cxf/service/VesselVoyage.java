package com.dpworld.camel.cxf.service;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>
 * Java class for vesselVoyage complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="vesselVoyage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="agentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="agentId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="agentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="airDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="anchorDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="arrivalDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="arriveFromPortCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="arriveFromPortName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beam" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="berthDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="bookingTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bookingTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callReasonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="chargeTonage" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="connectingVessel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactNo" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="contactPerson" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="containerSegregateFlag" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="customerReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="firstCallDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="inBoundVoyageNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isActive" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="lineCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lineId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lineName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outVoyageNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="portArrivalDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="portEtaDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="portEtbDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="portEtdDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="rotationNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sailDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="sailDraft" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="sailToPortCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sailToPortName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shipingServiceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shipingServiceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="shipingServiceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="terminalVisits" type="{http://service.cxf.camel.dpworld.com/}voyageTerminalVisit" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="vesselClosingDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="vesselCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="vesselId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="vesselLoa" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="vesselName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vesselPositionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vesselPositionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="voyagePortCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyagePortId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="voyagePortName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voyageTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "vesselVoyage", propOrder = {"agentCode", "agentId", "agentName", "airDraft",
    "anchorDate", "arrivalDraft", "arriveFromPortCode", "arriveFromPortName", "beam", "berthDate",
    "bookingTypeCode", "bookingTypeName", "callReasonCode", "callReasonName", "callSign",
    "chargeTonage", "connectingVessel", "contactEmail", "contactNo", "contactPerson",
    "containerSegregateFlag", "customerReference", "firstCallDate", "id", "inBoundVoyageNo",
    "isActive", "lineCode", "lineId", "lineName", "outVoyageNo", "portArrivalDate", "portEtaDate",
    "portEtbDate", "portEtdDate", "rotationNumber", "sailDate", "sailDraft", "sailToPortCode",
    "sailToPortName", "shipingServiceCode", "shipingServiceId", "shipingServiceName",
    "terminalVisits", "vesselClosingDate", "vesselCode", "vesselId", "vesselLoa", "vesselName",
    "vesselPositionCode", "vesselPositionName", "voyageDate", "voyagePortCode", "voyagePortId",
    "voyagePortName", "voyageReferenceNumber", "voyageRemarks", "voyageStatus", "voyageType",
    "voyageTypeDesc"})
public class VesselVoyage {

  protected String agentCode;
  protected Long agentId;
  protected String agentName;
  protected Double airDraft;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar anchorDate;
  protected Double arrivalDraft;
  protected String arriveFromPortCode;
  protected String arriveFromPortName;
  protected Double beam;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar berthDate;
  protected String bookingTypeCode;
  protected String bookingTypeName;
  protected String callReasonCode;
  protected String callReasonName;
  protected String callSign;
  protected Double chargeTonage;
  protected String connectingVessel;
  protected String contactEmail;
  protected Long contactNo;
  protected String contactPerson;
  protected Integer containerSegregateFlag;
  protected String customerReference;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar firstCallDate;
  protected Long id;
  protected String inBoundVoyageNo;
  protected Integer isActive;
  protected String lineCode;
  protected Long lineId;
  protected String lineName;
  protected String outVoyageNo;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar portArrivalDate;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar portEtaDate;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar portEtbDate;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar portEtdDate;
  protected Long rotationNumber;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar sailDate;
  protected Double sailDraft;
  protected String sailToPortCode;
  protected String sailToPortName;
  protected String shipingServiceCode;
  protected Long shipingServiceId;
  protected String shipingServiceName;
  @XmlElement(nillable = true)
  protected List<VoyageTerminalVisit> terminalVisits;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar vesselClosingDate;
  protected Long vesselCode;
  protected Long vesselId;
  protected Double vesselLoa;
  protected String vesselName;
  protected String vesselPositionCode;
  protected String vesselPositionName;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar voyageDate;
  protected String voyagePortCode;
  protected Long voyagePortId;
  protected String voyagePortName;
  protected String voyageReferenceNumber;
  protected String voyageRemarks;
  protected String voyageStatus;
  protected String voyageType;
  protected String voyageTypeDesc;

  @Override
public String toString() {
	return "VesselVoyage [agentCode=" + agentCode + ", agentId=" + agentId
			+ ", agentName=" + agentName + ", airDraft=" + airDraft
			+ ", anchorDate=" + anchorDate + ", arrivalDraft=" + arrivalDraft
			+ ", arriveFromPortCode=" + arriveFromPortCode
			+ ", arriveFromPortName=" + arriveFromPortName + ", beam=" + beam
			+ ", berthDate=" + berthDate + ", bookingTypeCode="
			+ bookingTypeCode + ", bookingTypeName=" + bookingTypeName
			+ ", callReasonCode=" + callReasonCode + ", callReasonName="
			+ callReasonName + ", callSign=" + callSign + ", chargeTonage="
			+ chargeTonage + ", connectingVessel=" + connectingVessel
			+ ", contactEmail=" + contactEmail + ", contactNo=" + contactNo
			+ ", contactPerson=" + contactPerson + ", containerSegregateFlag="
			+ containerSegregateFlag + ", customerReference="
			+ customerReference + ", firstCallDate=" + firstCallDate + ", id="
			+ id + ", inBoundVoyageNo=" + inBoundVoyageNo + ", isActive="
			+ isActive + ", lineCode=" + lineCode + ", lineId=" + lineId
			+ ", lineName=" + lineName + ", outVoyageNo=" + outVoyageNo
			+ ", portArrivalDate=" + portArrivalDate + ", portEtaDate="
			+ portEtaDate + ", portEtbDate=" + portEtbDate + ", portEtdDate="
			+ portEtdDate + ", rotationNumber=" + rotationNumber
			+ ", sailDate=" + sailDate + ", sailDraft=" + sailDraft
			+ ", sailToPortCode=" + sailToPortCode + ", sailToPortName="
			+ sailToPortName + ", shipingServiceCode=" + shipingServiceCode
			+ ", shipingServiceId=" + shipingServiceId
			+ ", shipingServiceName=" + shipingServiceName
			+ ", terminalVisits=" + terminalVisits + ", vesselClosingDate="
			+ vesselClosingDate + ", vesselCode=" + vesselCode + ", vesselId="
			+ vesselId + ", vesselLoa=" + vesselLoa + ", vesselName="
			+ vesselName + ", vesselPositionCode=" + vesselPositionCode
			+ ", vesselPositionName=" + vesselPositionName + ", voyageDate="
			+ voyageDate + ", voyagePortCode=" + voyagePortCode
			+ ", voyagePortId=" + voyagePortId + ", voyagePortName="
			+ voyagePortName + ", voyageReferenceNumber="
			+ voyageReferenceNumber + ", voyageRemarks=" + voyageRemarks
			+ ", voyageStatus=" + voyageStatus + ", voyageType=" + voyageType
			+ ", voyageTypeDesc=" + voyageTypeDesc + "]";
}

/**
   * Gets the value of the agentCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getAgentCode() {
    return agentCode;
  }

  /**
   * Sets the value of the agentCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setAgentCode(String value) {
    this.agentCode = value;
  }

  /**
   * Gets the value of the agentId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getAgentId() {
    return agentId;
  }

  /**
   * Sets the value of the agentId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setAgentId(Long value) {
    this.agentId = value;
  }

  /**
   * Gets the value of the agentName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getAgentName() {
    return agentName;
  }

  /**
   * Sets the value of the agentName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setAgentName(String value) {
    this.agentName = value;
  }

  /**
   * Gets the value of the airDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getAirDraft() {
    return airDraft;
  }

  /**
   * Sets the value of the airDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setAirDraft(Double value) {
    this.airDraft = value;
  }

  /**
   * Gets the value of the anchorDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getAnchorDate() {
    return anchorDate;
  }

  /**
   * Sets the value of the anchorDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setAnchorDate(XMLGregorianCalendar value) {
    this.anchorDate = value;
  }

  /**
   * Gets the value of the arrivalDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getArrivalDraft() {
    return arrivalDraft;
  }

  /**
   * Sets the value of the arrivalDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setArrivalDraft(Double value) {
    this.arrivalDraft = value;
  }

  /**
   * Gets the value of the arriveFromPortCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getArriveFromPortCode() {
    return arriveFromPortCode;
  }

  /**
   * Sets the value of the arriveFromPortCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setArriveFromPortCode(String value) {
    this.arriveFromPortCode = value;
  }

  /**
   * Gets the value of the arriveFromPortName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getArriveFromPortName() {
    return arriveFromPortName;
  }

  /**
   * Sets the value of the arriveFromPortName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setArriveFromPortName(String value) {
    this.arriveFromPortName = value;
  }

  /**
   * Gets the value of the beam property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getBeam() {
    return beam;
  }

  /**
   * Sets the value of the beam property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setBeam(Double value) {
    this.beam = value;
  }

  /**
   * Gets the value of the berthDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getBerthDate() {
    return berthDate;
  }

  /**
   * Sets the value of the berthDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setBerthDate(XMLGregorianCalendar value) {
    this.berthDate = value;
  }

  /**
   * Gets the value of the bookingTypeCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getBookingTypeCode() {
    return bookingTypeCode;
  }

  /**
   * Sets the value of the bookingTypeCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setBookingTypeCode(String value) {
    this.bookingTypeCode = value;
  }

  /**
   * Gets the value of the bookingTypeName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getBookingTypeName() {
    return bookingTypeName;
  }

  /**
   * Sets the value of the bookingTypeName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setBookingTypeName(String value) {
    this.bookingTypeName = value;
  }

  /**
   * Gets the value of the callReasonCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getCallReasonCode() {
    return callReasonCode;
  }

  /**
   * Sets the value of the callReasonCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setCallReasonCode(String value) {
    this.callReasonCode = value;
  }

  /**
   * Gets the value of the callReasonName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getCallReasonName() {
    return callReasonName;
  }

  /**
   * Sets the value of the callReasonName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setCallReasonName(String value) {
    this.callReasonName = value;
  }

  /**
   * Gets the value of the callSign property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getCallSign() {
    return callSign;
  }

  /**
   * Sets the value of the callSign property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setCallSign(String value) {
    this.callSign = value;
  }

  /**
   * Gets the value of the chargeTonage property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getChargeTonage() {
    return chargeTonage;
  }

  /**
   * Sets the value of the chargeTonage property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setChargeTonage(Double value) {
    this.chargeTonage = value;
  }

  /**
   * Gets the value of the connectingVessel property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getConnectingVessel() {
    return connectingVessel;
  }

  /**
   * Sets the value of the connectingVessel property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setConnectingVessel(String value) {
    this.connectingVessel = value;
  }

  /**
   * Gets the value of the contactEmail property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getContactEmail() {
    return contactEmail;
  }

  /**
   * Sets the value of the contactEmail property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setContactEmail(String value) {
    this.contactEmail = value;
  }

  /**
   * Gets the value of the contactNo property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getContactNo() {
    return contactNo;
  }

  /**
   * Sets the value of the contactNo property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setContactNo(Long value) {
    this.contactNo = value;
  }

  /**
   * Gets the value of the contactPerson property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getContactPerson() {
    return contactPerson;
  }

  /**
   * Sets the value of the contactPerson property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setContactPerson(String value) {
    this.contactPerson = value;
  }

  /**
   * Gets the value of the containerSegregateFlag property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getContainerSegregateFlag() {
    return containerSegregateFlag;
  }

  /**
   * Sets the value of the containerSegregateFlag property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setContainerSegregateFlag(Integer value) {
    this.containerSegregateFlag = value;
  }

  /**
   * Gets the value of the customerReference property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getCustomerReference() {
    return customerReference;
  }

  /**
   * Sets the value of the customerReference property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setCustomerReference(String value) {
    this.customerReference = value;
  }

  /**
   * Gets the value of the firstCallDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getFirstCallDate() {
    return firstCallDate;
  }

  /**
   * Sets the value of the firstCallDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setFirstCallDate(XMLGregorianCalendar value) {
    this.firstCallDate = value;
  }

  /**
   * Gets the value of the id property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getId() {
    return id;
  }

  /**
   * Sets the value of the id property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setId(Long value) {
    this.id = value;
  }

  /**
   * Gets the value of the inBoundVoyageNo property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getInBoundVoyageNo() {
    return inBoundVoyageNo;
  }

  /**
   * Sets the value of the inBoundVoyageNo property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setInBoundVoyageNo(String value) {
    this.inBoundVoyageNo = value;
  }

  /**
   * Gets the value of the isActive property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getIsActive() {
    return isActive;
  }

  /**
   * Sets the value of the isActive property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setIsActive(Integer value) {
    this.isActive = value;
  }

  /**
   * Gets the value of the lineCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getLineCode() {
    return lineCode;
  }

  /**
   * Sets the value of the lineCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setLineCode(String value) {
    this.lineCode = value;
  }

  /**
   * Gets the value of the lineId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getLineId() {
    return lineId;
  }

  /**
   * Sets the value of the lineId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setLineId(Long value) {
    this.lineId = value;
  }

  /**
   * Gets the value of the lineName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getLineName() {
    return lineName;
  }

  /**
   * Sets the value of the lineName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setLineName(String value) {
    this.lineName = value;
  }

  /**
   * Gets the value of the outVoyageNo property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getOutVoyageNo() {
    return outVoyageNo;
  }

  /**
   * Sets the value of the outVoyageNo property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setOutVoyageNo(String value) {
    this.outVoyageNo = value;
  }

  /**
   * Gets the value of the portArrivalDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getPortArrivalDate() {
    return portArrivalDate;
  }

  /**
   * Sets the value of the portArrivalDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setPortArrivalDate(XMLGregorianCalendar value) {
    this.portArrivalDate = value;
  }

  /**
   * Gets the value of the portEtaDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getPortEtaDate() {
    return portEtaDate;
  }

  /**
   * Sets the value of the portEtaDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setPortEtaDate(XMLGregorianCalendar value) {
    this.portEtaDate = value;
  }

  /**
   * Gets the value of the portEtbDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getPortEtbDate() {
    return portEtbDate;
  }

  /**
   * Sets the value of the portEtbDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setPortEtbDate(XMLGregorianCalendar value) {
    this.portEtbDate = value;
  }

  /**
   * Gets the value of the portEtdDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getPortEtdDate() {
    return portEtdDate;
  }

  /**
   * Sets the value of the portEtdDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setPortEtdDate(XMLGregorianCalendar value) {
    this.portEtdDate = value;
  }

  /**
   * Gets the value of the rotationNumber property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getRotationNumber() {
    return rotationNumber;
  }

  /**
   * Sets the value of the rotationNumber property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setRotationNumber(Long value) {
    this.rotationNumber = value;
  }

  /**
   * Gets the value of the sailDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getSailDate() {
    return sailDate;
  }

  /**
   * Sets the value of the sailDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setSailDate(XMLGregorianCalendar value) {
    this.sailDate = value;
  }

  /**
   * Gets the value of the sailDraft property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getSailDraft() {
    return sailDraft;
  }

  /**
   * Sets the value of the sailDraft property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setSailDraft(Double value) {
    this.sailDraft = value;
  }

  /**
   * Gets the value of the sailToPortCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSailToPortCode() {
    return sailToPortCode;
  }

  /**
   * Sets the value of the sailToPortCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSailToPortCode(String value) {
    this.sailToPortCode = value;
  }

  /**
   * Gets the value of the sailToPortName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSailToPortName() {
    return sailToPortName;
  }

  /**
   * Sets the value of the sailToPortName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSailToPortName(String value) {
    this.sailToPortName = value;
  }

  /**
   * Gets the value of the shipingServiceCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getShipingServiceCode() {
    return shipingServiceCode;
  }

  /**
   * Sets the value of the shipingServiceCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setShipingServiceCode(String value) {
    this.shipingServiceCode = value;
  }

  /**
   * Gets the value of the shipingServiceId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getShipingServiceId() {
    return shipingServiceId;
  }

  /**
   * Sets the value of the shipingServiceId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setShipingServiceId(Long value) {
    this.shipingServiceId = value;
  }

  /**
   * Gets the value of the shipingServiceName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getShipingServiceName() {
    return shipingServiceName;
  }

  /**
   * Sets the value of the shipingServiceName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setShipingServiceName(String value) {
    this.shipingServiceName = value;
  }

  /**
   * Gets the value of the terminalVisits property.
   * 
   * <p>
   * This accessor method returns a reference to the live list, not a snapshot.
   * Therefore any modification you make to the returned list will be present
   * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
   * for the terminalVisits property.
   * 
   * <p>
   * For example, to add a new item, do as follows:
   * 
   * <pre>
   * getTerminalVisits().add(newItem);
   * </pre>
   * 
   * 
   * <p>
   * Objects of the following type(s) are allowed in the list
   * {@link VoyageTerminalVisit }
   * 
   * 
   */
  public List<VoyageTerminalVisit> getTerminalVisits() {
    if (terminalVisits == null) {
      terminalVisits = new ArrayList<VoyageTerminalVisit>();
    }
    return this.terminalVisits;
  }

  /**
   * Gets the value of the vesselClosingDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getVesselClosingDate() {
    return vesselClosingDate;
  }

  /**
   * Sets the value of the vesselClosingDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setVesselClosingDate(XMLGregorianCalendar value) {
    this.vesselClosingDate = value;
  }

  /**
   * Gets the value of the vesselCode property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVesselCode() {
    return vesselCode;
  }

  /**
   * Sets the value of the vesselCode property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVesselCode(Long value) {
    this.vesselCode = value;
  }

  /**
   * Gets the value of the vesselId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVesselId() {
    return vesselId;
  }

  /**
   * Sets the value of the vesselId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVesselId(Long value) {
    this.vesselId = value;
  }

  /**
   * Gets the value of the vesselLoa property.
   * 
   * @return possible object is {@link Double }
   * 
   */
  public Double getVesselLoa() {
    return vesselLoa;
  }

  /**
   * Sets the value of the vesselLoa property.
   * 
   * @param value allowed object is {@link Double }
   * 
   */
  public void setVesselLoa(Double value) {
    this.vesselLoa = value;
  }

  /**
   * Gets the value of the vesselName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVesselName() {
    return vesselName;
  }

  /**
   * Sets the value of the vesselName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVesselName(String value) {
    this.vesselName = value;
  }

  /**
   * Gets the value of the vesselPositionCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVesselPositionCode() {
    return vesselPositionCode;
  }

  /**
   * Sets the value of the vesselPositionCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVesselPositionCode(String value) {
    this.vesselPositionCode = value;
  }

  /**
   * Gets the value of the vesselPositionName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVesselPositionName() {
    return vesselPositionName;
  }

  /**
   * Sets the value of the vesselPositionName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVesselPositionName(String value) {
    this.vesselPositionName = value;
  }

  /**
   * Gets the value of the voyageDate property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getVoyageDate() {
    return voyageDate;
  }

  /**
   * Sets the value of the voyageDate property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setVoyageDate(XMLGregorianCalendar value) {
    this.voyageDate = value;
  }

  /**
   * Gets the value of the voyagePortCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyagePortCode() {
    return voyagePortCode;
  }

  /**
   * Sets the value of the voyagePortCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyagePortCode(String value) {
    this.voyagePortCode = value;
  }

  /**
   * Gets the value of the voyagePortId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVoyagePortId() {
    return voyagePortId;
  }

  /**
   * Sets the value of the voyagePortId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVoyagePortId(Long value) {
    this.voyagePortId = value;
  }

  /**
   * Gets the value of the voyagePortName property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyagePortName() {
    return voyagePortName;
  }

  /**
   * Sets the value of the voyagePortName property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyagePortName(String value) {
    this.voyagePortName = value;
  }

  /**
   * Gets the value of the voyageReferenceNumber property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageReferenceNumber() {
    return voyageReferenceNumber;
  }

  /**
   * Sets the value of the voyageReferenceNumber property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageReferenceNumber(String value) {
    this.voyageReferenceNumber = value;
  }

  /**
   * Gets the value of the voyageRemarks property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageRemarks() {
    return voyageRemarks;
  }

  /**
   * Sets the value of the voyageRemarks property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageRemarks(String value) {
    this.voyageRemarks = value;
  }

  /**
   * Gets the value of the voyageStatus property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageStatus() {
    return voyageStatus;
  }

  /**
   * Sets the value of the voyageStatus property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageStatus(String value) {
    this.voyageStatus = value;
  }

  /**
   * Gets the value of the voyageType property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageType() {
    return voyageType;
  }

  /**
   * Sets the value of the voyageType property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageType(String value) {
    this.voyageType = value;
  }

  /**
   * Gets the value of the voyageTypeDesc property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getVoyageTypeDesc() {
    return voyageTypeDesc;
  }

  /**
   * Sets the value of the voyageTypeDesc property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setVoyageTypeDesc(String value) {
    this.voyageTypeDesc = value;
  }

}
