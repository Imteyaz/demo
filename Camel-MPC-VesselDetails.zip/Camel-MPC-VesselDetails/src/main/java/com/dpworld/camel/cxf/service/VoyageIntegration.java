package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>
 * Java class for voyageIntegration complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="voyageIntegration">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="attributeCharVal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="attributeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="attributeDateVal" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="attributeNumVal" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="modifiedAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="portCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rotation" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sourceReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sourceSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="terminalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="visitSeqNo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="voyageId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "voyageIntegration", propOrder = {"attributeCharVal", "attributeCode",
    "attributeDateVal", "attributeNumVal", "modifiedAt", "modifiedBy", "portCode", "rotation",
    "sourceReference", "sourceSystem", "terminalCode", "visitId", "visitSeqNo", "voyageId"})
public class VoyageIntegration {

  protected String attributeCharVal;
  protected String attributeCode;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar attributeDateVal;
  protected Long attributeNumVal;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar modifiedAt;
  protected String modifiedBy;
  protected String portCode;
  protected Long rotation;
  protected String sourceReference;
  protected String sourceSystem;
  protected String terminalCode;
  protected Long visitId;
  protected Integer visitSeqNo;
  protected Long voyageId;

  /**
   * Gets the value of the attributeCharVal property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getAttributeCharVal() {
    return attributeCharVal;
  }

  /**
   * Sets the value of the attributeCharVal property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setAttributeCharVal(String value) {
    this.attributeCharVal = value;
  }

  /**
   * Gets the value of the attributeCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getAttributeCode() {
    return attributeCode;
  }

  /**
   * Sets the value of the attributeCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setAttributeCode(String value) {
    this.attributeCode = value;
  }

  /**
   * Gets the value of the attributeDateVal property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getAttributeDateVal() {
    return attributeDateVal;
  }

  /**
   * Sets the value of the attributeDateVal property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setAttributeDateVal(XMLGregorianCalendar value) {
    this.attributeDateVal = value;
  }

  /**
   * Gets the value of the attributeNumVal property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getAttributeNumVal() {
    return attributeNumVal;
  }

  /**
   * Sets the value of the attributeNumVal property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setAttributeNumVal(Long value) {
    this.attributeNumVal = value;
  }

  /**
   * Gets the value of the modifiedAt property.
   * 
   * @return possible object is {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the value of the modifiedAt property.
   * 
   * @param value allowed object is {@link XMLGregorianCalendar }
   * 
   */
  public void setModifiedAt(XMLGregorianCalendar value) {
    this.modifiedAt = value;
  }

  /**
   * Gets the value of the modifiedBy property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Sets the value of the modifiedBy property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setModifiedBy(String value) {
    this.modifiedBy = value;
  }

  /**
   * Gets the value of the portCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getPortCode() {
    return portCode;
  }

  /**
   * Sets the value of the portCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setPortCode(String value) {
    this.portCode = value;
  }

  /**
   * Gets the value of the rotation property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getRotation() {
    return rotation;
  }

  /**
   * Sets the value of the rotation property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setRotation(Long value) {
    this.rotation = value;
  }

  /**
   * Gets the value of the sourceReference property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSourceReference() {
    return sourceReference;
  }

  /**
   * Sets the value of the sourceReference property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSourceReference(String value) {
    this.sourceReference = value;
  }

  /**
   * Gets the value of the sourceSystem property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSourceSystem() {
    return sourceSystem;
  }

  /**
   * Sets the value of the sourceSystem property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSourceSystem(String value) {
    this.sourceSystem = value;
  }

  /**
   * Gets the value of the terminalCode property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getTerminalCode() {
    return terminalCode;
  }

  /**
   * Sets the value of the terminalCode property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setTerminalCode(String value) {
    this.terminalCode = value;
  }

  /**
   * Gets the value of the visitId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVisitId() {
    return visitId;
  }

  /**
   * Sets the value of the visitId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVisitId(Long value) {
    this.visitId = value;
  }

  /**
   * Gets the value of the visitSeqNo property.
   * 
   * @return possible object is {@link Integer }
   * 
   */
  public Integer getVisitSeqNo() {
    return visitSeqNo;
  }

  /**
   * Sets the value of the visitSeqNo property.
   * 
   * @param value allowed object is {@link Integer }
   * 
   */
  public void setVisitSeqNo(Integer value) {
    this.visitSeqNo = value;
  }

  /**
   * Gets the value of the voyageId property.
   * 
   * @return possible object is {@link Long }
   * 
   */
  public Long getVoyageId() {
    return voyageId;
  }

  /**
   * Sets the value of the voyageId property.
   * 
   * @param value allowed object is {@link Long }
   * 
   */
  public void setVoyageId(Long value) {
    this.voyageId = value;
  }

}
