package com.dpworld.camel.cxf.service;

import java.util.List;

public class MainMethod {

  public static void main(String[] args) {

    VoyageService service = new VoyageService();

    RotationCriteria criteria = new RotationCriteria();
    criteria.setRotationNumber("802262");
    criteria.setSourceSystem("BPA");
    criteria.setPrivateKey("12345");
   // criteria.setTerminal("T1");
  //  criteria.setVisitId(null);
  //  criteria.setVisitType(null);
  //  criteria.setVoyageReferenceNumber(null);

    service.getVoyageServicePort().searchVesselVoyages(criteria);

    System.out.println(service.getVoyageServicePort()
        .searchVesselVoyages(criteria)
        .getVesselVoyage()
        .getVesselName());

    VesselVoyage result = service.getVoyageServicePort()
        .searchVesselVoyages(criteria)
        .getVesselVoyage();
    System.out.println(result.toString());
    // result.get


    List<VoyageTerminalVisit> list = service.getVoyageServicePort()
        .searchVesselVoyages(criteria)
        .getVesselVoyage()
        .getTerminalVisits();
   

    for (VoyageTerminalVisit vist : list) {
    	
    	System.out.println("========================="+vist.toString());

      System.out.println(vist.getVisitId());
      System.out.println(vist.getVisitReasonCode());
      System.out.println(vist.getVisitReasonName());
      System.out.println(vist.getVisitSeq());
      System.out.println(vist.getVisitTypeCode());
      System.out.println(vist.getVisitTypeName());
      System.out.println(vist.getTerminal());
      System.out.println(vist.getTerminalName());
      System.out.println(vist.getEstimatedArrivalTime());
      System.out.println(vist.getEstimatedBerthTime());
      System.out.println(vist.getEstimatedDepartTime());
      System.out.println(vist.getEstimatedDischargeMoves());
      System.out.println(vist.getEstimatedLoadMoves());
      System.out.println(vist.getEstimatedOtherMoves());
      System.out.println(vist.getVesselPositionCode());
      System.out.println(vist.getVesselPositionName());
      System.out.println(vist.getOperationTypeCode());
      System.out.println(vist.getOperationTypeName());
      System.out.println(vist.getPreferredBerthCode());
      System.out.println(vist.getPreferredBerthName());
      System.out.println(vist.getWorkEndDate());
      System.out.println(vist.getWorkStartDate());
      System.out.println(vist.getVisitRemarks());
      System.out.println(vist.getLaybyFromBerth());
      System.out.println(vist.getLoadCutoffTime());
      System.out.println(vist.getDeadShipFlag());
      System.out.println(vist.getDeadWeight());
      System.out.println(vist.getGasFlag());
      System.out.println(vist.getInertedFlag());
      System.out.println(vist.getLoadedShipFlag());
      System.out.println(vist.getNoOfCranes());
      System.out.println(vist.getNoOfHatches());
      System.out.println("vist.getPriority()====="+vist.getPriority());
      System.out.println(vist.getRepairCompany());
      System.out.println(vist.getSailAftDraft());
      System.out.println(vist.getSailForwardDraft());
      System.out.println(vist.getSustainedGears());
      System.out.println(vist.getUnBerthingTime());


    }


    // System.out.println(service.getVoyageServicePort().searchVesselVoyages(criteria).getVesselVoyage().getPortArrivalDate());

    /*
     * VesselVoyageResult result = new VesselVoyageResult();
     * result.getVesselVoyage(). //result.getVesselVoyage().get
     * SearchVesselVoyages searchVesselVoyages = new SearchVesselVoyages();
     * searchVesselVoyages.setArg0(criteria);
     */

    // System.out.println(factory.createSearchVesselVoyages(searchVesselVoyages).getValue().toString());


  }

}
