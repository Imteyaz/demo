package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>
 * Java class for vesselVoyageResult complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="vesselVoyageResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="errorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vesselVoyage" type="{http://service.cxf.camel.dpworld.com/}vesselVoyage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "vesselVoyageResult", propOrder = {"errorMessage", "vesselVoyage"})
public class VesselVoyageResult {

  protected String errorMessage;
  protected VesselVoyage vesselVoyage;

  /**
   * Gets the value of the errorMessage property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * Sets the value of the errorMessage property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setErrorMessage(String value) {
    this.errorMessage = value;
  }

  /**
   * Gets the value of the vesselVoyage property.
   * 
   * @return possible object is {@link VesselVoyage }
   * 
   */
  public VesselVoyage getVesselVoyage() {
    return vesselVoyage;
  }

  /**
   * Sets the value of the vesselVoyage property.
   * 
   * @param value allowed object is {@link VesselVoyage }
   * 
   */
  public void setVesselVoyage(VesselVoyage value) {
    this.vesselVoyage = value;
  }

}
