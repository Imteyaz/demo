package com.dpworld.camel.cxf.service;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the com.dpworld.camel.cxf.service package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _IntegrateVoyageParams_QNAME = new QName(
      "http://service.cxf.camel.dpworld.com/", "integrateVoyageParams");
  private final static QName _SearchVesselVoyagesResponse_QNAME = new QName(
      "http://service.cxf.camel.dpworld.com/", "searchVesselVoyagesResponse");
  private final static QName _SearchVesselVoyages_QNAME = new QName(
      "http://service.cxf.camel.dpworld.com/", "searchVesselVoyages");
  private final static QName _IntegrateVoyageParamsResponse_QNAME = new QName(
      "http://service.cxf.camel.dpworld.com/", "integrateVoyageParamsResponse");

  /**
   * Create a new ObjectFactory that can be used to create new instances of
   * schema derived classes for package: com.dpworld.camel.cxf.service
   * 
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link SearchVesselVoyagesResponse }
   * 
   */
  public SearchVesselVoyagesResponse createSearchVesselVoyagesResponse() {
    return new SearchVesselVoyagesResponse();
  }

  /**
   * Create an instance of {@link IntegrateVoyageParams }
   * 
   */
  public IntegrateVoyageParams createIntegrateVoyageParams() {
    return new IntegrateVoyageParams();
  }

  /**
   * Create an instance of {@link SearchVesselVoyages }
   * 
   */
  public SearchVesselVoyages createSearchVesselVoyages() {
    return new SearchVesselVoyages();
  }

  /**
   * Create an instance of {@link IntegrateVoyageParamsResponse }
   * 
   */
  public IntegrateVoyageParamsResponse createIntegrateVoyageParamsResponse() {
    return new IntegrateVoyageParamsResponse();
  }

  /**
   * Create an instance of {@link VesselVoyage }
   * 
   */
  public VesselVoyage createVesselVoyage() {
    return new VesselVoyage();
  }

  /**
   * Create an instance of {@link VoyageIntegration }
   * 
   */
  public VoyageIntegration createVoyageIntegration() {
    return new VoyageIntegration();
  }

  /**
   * Create an instance of {@link AuthInfo }
   * 
   */
  public AuthInfo createAuthInfo() {
    return new AuthInfo();
  }

  /**
   * Create an instance of {@link RotationCriteria }
   * 
   */
  public RotationCriteria createRotationCriteria() {
    return new RotationCriteria();
  }

  /**
   * Create an instance of {@link VoyageTerminalVisit }
   * 
   */
  public VoyageTerminalVisit createVoyageTerminalVisit() {
    return new VoyageTerminalVisit();
  }

  /**
   * Create an instance of {@link OutputMessageResult }
   * 
   */
  public OutputMessageResult createOutputMessageResult() {
    return new OutputMessageResult();
  }

  /**
   * Create an instance of {@link VesselVoyageResult }
   * 
   */
  public VesselVoyageResult createVesselVoyageResult() {
    return new VesselVoyageResult();
  }

  /**
   * Create an instance of {@link VoyageIntegrationParam }
   * 
   */
  public VoyageIntegrationParam createVoyageIntegrationParam() {
    return new VoyageIntegrationParam();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}
   * {@link IntegrateVoyageParams }{@code >}
   * 
   */
  @XmlElementDecl(namespace = "http://service.cxf.camel.dpworld.com/", name = "integrateVoyageParams")
  public JAXBElement<IntegrateVoyageParams> createIntegrateVoyageParams(IntegrateVoyageParams value) {
    return new JAXBElement<IntegrateVoyageParams>(_IntegrateVoyageParams_QNAME,
        IntegrateVoyageParams.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}
   * {@link SearchVesselVoyagesResponse }{@code >}
   * 
   */
  @XmlElementDecl(namespace = "http://service.cxf.camel.dpworld.com/", name = "searchVesselVoyagesResponse")
  public JAXBElement<SearchVesselVoyagesResponse> createSearchVesselVoyagesResponse(SearchVesselVoyagesResponse value) {
    return new JAXBElement<SearchVesselVoyagesResponse>(_SearchVesselVoyagesResponse_QNAME,
        SearchVesselVoyagesResponse.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}
   * {@link SearchVesselVoyages }{@code >}
   * 
   */
  @XmlElementDecl(namespace = "http://service.cxf.camel.dpworld.com/", name = "searchVesselVoyages")
  public JAXBElement<SearchVesselVoyages> createSearchVesselVoyages(SearchVesselVoyages value) {
    return new JAXBElement<SearchVesselVoyages>(_SearchVesselVoyages_QNAME,
        SearchVesselVoyages.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}
   * {@link IntegrateVoyageParamsResponse }{@code >}
   * 
   */
  @XmlElementDecl(namespace = "http://service.cxf.camel.dpworld.com/", name = "integrateVoyageParamsResponse")
  public JAXBElement<IntegrateVoyageParamsResponse> createIntegrateVoyageParamsResponse(IntegrateVoyageParamsResponse value) {
    return new JAXBElement<IntegrateVoyageParamsResponse>(_IntegrateVoyageParamsResponse_QNAME,
        IntegrateVoyageParamsResponse.class, null, value);
  }

}
