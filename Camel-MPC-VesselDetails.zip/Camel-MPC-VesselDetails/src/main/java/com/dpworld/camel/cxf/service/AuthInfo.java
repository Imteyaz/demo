package com.dpworld.camel.cxf.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>
 * Java class for authInfo complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="authInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="privateKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sourceSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "authInfo", propOrder = {"privateKey", "sourceSystem"})
@XmlSeeAlso({RotationCriteria.class, VoyageIntegrationParam.class})
public class AuthInfo {

  protected String privateKey;
  protected String sourceSystem;

  /**
   * Gets the value of the privateKey property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getPrivateKey() {
    return privateKey;
  }

  /**
   * Sets the value of the privateKey property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setPrivateKey(String value) {
    this.privateKey = value;
  }

  /**
   * Gets the value of the sourceSystem property.
   * 
   * @return possible object is {@link String }
   * 
   */
  public String getSourceSystem() {
    return sourceSystem;
  }

  /**
   * Sets the value of the sourceSystem property.
   * 
   * @param value allowed object is {@link String }
   * 
   */
  public void setSourceSystem(String value) {
    this.sourceSystem = value;
  }

}
