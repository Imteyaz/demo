package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.PilotVesselDataDTO;
import com.dpworld.mpcsystem.persistence.dao.PilotDispatchDao;
import com.dpworld.mpcsystem.persistence.model.MpcVesselData;

@Repository("pilotDispatchDao")
public class PilotDispatchDaoImpl extends
PersistenceUnitDaoImpl<MpcVesselData, Long> implements PilotDispatchDao{

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PilotDispatchDaoImpl.class);
	public PilotDispatchDaoImpl(Class<MpcVesselData> persistentClass) {
		super(persistentClass);
		
	}
	
	public PilotDispatchDaoImpl() {
		super(MpcVesselData.class);
	}
	
	
	@Transactional
	public Date getPilotDispatchTime(PilotVesselDataDTO vesselData)
	{
		try{
			EntityManager em = getEntityManager();
			String myQry = "SELECT m FROM MpcVesselData m  where m.mvdRecId = (select max(b.mvdRecId) from MpcVesselData b "
					+ " where  b.vesselName='"+vesselData.getVesselName()+"' "
					+ " and m.rotataionNo='"+vesselData.getRotationNo()+"' and m.isValid = 1 )";
			Query query = em.createQuery(myQry);
			List<MpcVesselData> vesselList = query.getResultList();
			
			if(vesselList.size()>0){
				return vesselList.get(0).getPilotDspTime();
			}
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
		return null;
	}
	
	@Transactional
	public List<PilotVesselDataDTO> getPilotDispatchTimeData(PilotVesselDataDTO vesselData)
	{
		try{
			List<PilotVesselDataDTO> resultList =new ArrayList<PilotVesselDataDTO>();
			EntityManager em = getEntityManager();
			String myQry = "select m from MpcVesselData m "
					+ " where  m.vesselName='"+vesselData.getVesselName()+"' "
					+ " and m.rotataionNo='"+vesselData.getRotationNo()+"' and m.isValid = 1";
			Query query = em.createQuery(myQry);
			List<MpcVesselData> vesselList = query.getResultList();
			
			for(MpcVesselData data :vesselList){
				PilotVesselDataDTO dto= new PilotVesselDataDTO();
				dto.setDispatchTime(data.getPilotDspTime());
				dto.setRotationNo(data.getRotataionNo());
				dto.setStatus(data.getStatus());
				dto.setVesselName(data.getVesselName());
				resultList.add(dto);
			}
			return resultList;
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
		return null;
	}
	

	@Transactional
	public void saveMpcVesselDetails(PilotVesselDataDTO vesselData) {
		
		try{
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			Date date = (Date) queryTime.getSingleResult();

			MpcVesselData vessel = new MpcVesselData();
			
			String myQry = "SELECT m FROM MpcVesselData m "
					+ "where m.vesselName='"+vesselData.getVesselName()+"' "
					+ "and m.rotataionNo='"+vesselData.getRotationNo()+"' "
					+ "and m.status='"+vesselData.getStatus()+"' "
					+ "and m.isValid = 1";
			Query query = em.createQuery(myQry);
			List<MpcVesselData> vesselList = query.getResultList();
			if(vesselList.size()>0){
				// Update Record
				for(MpcVesselData mpcVesselData : vesselList){
					mpcVesselData.setPilotDspTime(MPCUtil.changeStringToNewDateFormat(vesselData.getPilotDispatchTime()));
					mpcVesselData.setSrcSys(MPCConstants.SOURCE_SYS);
				    mpcVesselData.setModifiedBy(vesselData.getModifiedBy());
				    mpcVesselData.setModifiedOn(date);
				    mpcVesselData.setStatus(vesselData.getStatus());
				    em.persist(mpcVesselData);
				}
			}
			else
			{ 
				// New Record
				Query queryResult = em
						.createNativeQuery("SELECT SEQ_MPC_VESSEL_DATA_PK01.nextval FROM DUAL");
				long id = ((BigDecimal) queryResult.getSingleResult())
						.longValue();
				MpcVesselData mpcVesselData = new MpcVesselData();
				mpcVesselData.setMvdRecId(id);
				mpcVesselData.setVesselName(vesselData.getVesselName().trim());
				mpcVesselData.setPilotDspTime(MPCUtil.changeStringToNewDateFormat(vesselData.getPilotDispatchTime()));
				if(vesselData.getRotationNo()!=null){
					mpcVesselData.setRotataionNo(vesselData.getRotationNo().trim());	
				}
				mpcVesselData.setSrcSys(MPCConstants.SOURCE_SYS);
				mpcVesselData.setImoNo(vesselData.getImoNo());
				if(vesselData.getStatus()!=null){
				mpcVesselData.setStatus(vesselData.getStatus().trim());
				}
				mpcVesselData.setIsValid(1);
				mpcVesselData.setCreatedBy(vesselData.getCreatedBy());
				mpcVesselData.setCreatedOn(date);
				
				em.persist(mpcVesselData);
				
			}
			
			
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
	}
	
	@Transactional
	public void saveMpcUserOrder(PilotVesselDataDTO vesselData) {
		LOGGER.debug("===saveMpcUserOrder=   getMvdgroup=="+vesselData.getMvdgroup()+"useroderno"+vesselData.getUserOrderNo());
		try{
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			Date date = (Date) queryTime.getSingleResult();

			MpcVesselData vessel = new MpcVesselData();
			
			String myQry = "SELECT m FROM MpcVesselData m "
					+ "where m.rotataionNo='"+vesselData.getRotationNo()+"' "
					//+ "and m.userorder='"+vesselData.getUserOrderNo()+"' "
					+ "and m.mvdgroup='"+vesselData.getMvdgroup()+"' "
					+ "and m.isValid = 1";
			Query query = em.createQuery(myQry);
			List<MpcVesselData> vesselList = query.getResultList();
			if(vesselList.size()>0){
				// Update Record
				for(MpcVesselData mpcVesselData : vesselList){
					mpcVesselData.setUserorder(vesselData.getUserOrderNo());
					mpcVesselData.setSrcSys(MPCConstants.SOURCE_SYS);
				    mpcVesselData.setModifiedBy(vesselData.getModifiedBy());
				    mpcVesselData.setModifiedOn(date);
				    mpcVesselData.setMvdgroup(vesselData.getMvdgroup());
				    if(vesselData.getUserOrderNo().trim() =="0"  || ("0").equals(vesselData.getUserOrderNo().trim())){
						mpcVesselData.setIsValid(0);
						LOGGER.debug("userorder====="+vesselData.getUserOrderNo());
					
					}
					em.persist(mpcVesselData);
				}
			}
			else
			{ 
				// New Record
				Query queryResult = em
						.createNativeQuery("SELECT SEQ_MPC_VESSEL_DATA_PK01.nextval FROM DUAL");
				long id = ((BigDecimal) queryResult.getSingleResult())
						.longValue();
				MpcVesselData mpcVesselData = new MpcVesselData();
				mpcVesselData.setMvdRecId(id);
				mpcVesselData.setMvdgroup(vesselData.getMvdgroup().trim());
				mpcVesselData.setUserorder(vesselData.getUserOrderNo());
				if(vesselData.getRotationNo()!=null){
					mpcVesselData.setRotataionNo(vesselData.getRotationNo().trim());	
				}
				mpcVesselData.setSrcSys(MPCConstants.SOURCE_SYS);
			//	mpcVesselData.setImoNo(vesselData.getImoNo());
				if(vesselData.getMvdgroup()!=null){
				mpcVesselData.setMvdgroup(vesselData.getMvdgroup().trim());
				}
				mpcVesselData.setIsValid(1);
				mpcVesselData.setCreatedBy(vesselData.getCreatedBy());
				mpcVesselData.setCreatedOn(date);
				
				em.persist(mpcVesselData);
				
			}
			
			
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
	}
	
	

	public List<MpcVesselData> getMpcVesselDataByVessel(String vesselName,
			String rotation) {
		List<MpcVesselData> vesselList = null;
		try{
		EntityManager em = getEntityManager();
		String myQry = "SELECT m FROM MpcVesselData m "
				+ "where m.vesselName='"+vesselName+"' "
				+ "and m.rotataionNo='"+rotation+"' and m.isValid = 1";
		Query query = em.createQuery(myQry);
		vesselList = query.getResultList();
		
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
		
		return vesselList;
	}
	
		
	public List<MpcVesselData> getMpcVesselDataByVessel(String vesselName,
				String rotation,String status) {
			List<MpcVesselData> vesselList = null;
		//	LOGGER.info("ta7 saveMpcVesselDetails ..rotation...: "+rotation);
			String statusex="Incoming";
			try{
			EntityManager em = getEntityManager();
			String myQry = "SELECT m FROM MpcVesselData m "
					+ "where m.vesselName='"+vesselName+"' "
					+ "and m.rotataionNo='"+rotation+"' and m.isValid = 1";
			if(status=="Incoming" || "Incoming".equalsIgnoreCase(status))
		{
			myQry = "select m from MpcVesselData m "
					+ " where  m.vesselName='"+vesselName+"' "
					+ "and m.status='"+status+"' "
					+ " and m.rotataionNo='"+rotation+"' and m.isValid = 1";
		}else{
		/* myQry = "select m from MpcVesselData m "
				+ " where  m.vesselName='"+vesselName+"' "
				+ " and m.rotataionNo='"+rotation+"' and m.isValid = 1";*/
				 myQry = "SELECT m FROM MpcVesselData m  where m.mvdRecId = (select max(b.mvdRecId) from MpcVesselData b "
				+ " where  b.vesselName='"+vesselName+"' "
				+ " and m.status!='"+statusex+"' "
				+ " and m.rotataionNo='"+rotation+"' and m.isValid = 1 )"
				+ " and m.rotataionNo='"+rotation+"'";
		}
		
			Query query = em.createQuery(myQry);
			vesselList = query.getResultList();
			
			}
			catch(Exception er){
				LOGGER.error(er.getMessage());
			}
			
			return vesselList;
		}
		
		
		
	public List<MpcVesselData> getMpcUserOrder(String mvdgroup,
			String rotation) {
		List<MpcVesselData> vesselList = null;
	//	LOGGER.info("ta7 saveMpcVesselDetails ..rotation...: "+rotation);
		//String statusex="Incoming";
		try{
		EntityManager em = getEntityManager();
		String myQry = "SELECT m FROM MpcVesselData m "
				+ "where m.rotataionNo='"+rotation+"' "
				//+ "and m.userorder='"+vesselData.getUserOrderNo()+"' "
				+ "and m.mvdgroup='"+mvdgroup+"' "
				+ "and m.isValid = 1";
		Query query = em.createQuery(myQry);
		vesselList = query.getResultList();
	
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
		
		return vesselList;
	}	
		
		
		
	
	

}
