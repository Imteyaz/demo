package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.ConversationHistoryDTO;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainGeofenceMasterDTO;
import com.dpworld.mpcsystem.persistence.dao.ConversationHistoryDao;
import com.dpworld.mpcsystem.persistence.dao.GeofencingDataViewDao;
import com.dpworld.mpcsystem.persistence.dao.GeofencingMasterDao;
import com.dpworld.mpcsystem.service.ConversationHistoryService;

@Service("conversationHistoryService")
public class ConversationHistoryServiceImpl implements ConversationHistoryService{
	
	@Autowired
	private ConversationHistoryDao conversationHistoryDao;
	
	@Override
	public List<ConversationHistoryDTO> getConversationHistoryList(String userName) {
		
		return conversationHistoryDao.getConversationHistoryList(userName);
		
	}

}
