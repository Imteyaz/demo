package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainGeofenceMasterDTO;
import com.dpworld.mpcsystem.persistence.dao.GeofencingMasterDao;
import com.dpworld.mpcsystem.service.GeofencingMasterService;

@Service("geofencingMasterService")
public class GeofencingMasterServiceImpl implements GeofencingMasterService{
	
	@Autowired
	private GeofencingMasterDao geofencingMasterDao;


	public List<MaintainGeofenceMasterDTO> getMaintainGeofenceMasterList() {

		return geofencingMasterDao.getGeofenceMasterList();
	}

	public void saveOrUpdateGeofenceMasterData(
			MaintainGeofenceMasterDTO maintainGeofenceDTO) {
		geofencingMasterDao.saveOrUpdateMaintainGeofenceMasterData(maintainGeofenceDTO);

	}

}
