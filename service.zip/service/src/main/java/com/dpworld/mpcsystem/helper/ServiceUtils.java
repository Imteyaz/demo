package com.dpworld.mpcsystem.helper;

import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.dpworld.mpcsystem.helper.responsebinder.DataRow;
import com.dpworld.mpcsystem.helper.responsebinder.ResultSet;
import com.dpworld.mpcsystem.helper.responsebinder.ServiceBinder;
import com.dpworld.mpcsystem.helper.responsebinder.ServiceBinderImpl;

public class ServiceUtils {

	private static final Logger LOG = Logger.getLogger(ServiceUtils.class);
	private static final String ROLECHANGED = "roleChanged";
	private static final String PICTURE = "Picture";
	
	private ServiceUtils(){}

	/**
	 * Converting request objects into name value pairs to include into the
	 * request binder
	 * 
	 * @param request
	 *            The HttpServletRequest object
	 * 
	 * @return ServiceBinder
	 */

	@SuppressWarnings("unchecked")
	public static ServiceBinder serializeRequestArguments(
			ServletRequest servletRequest) throws RuntimeException {
		LOG.debug("Inside serializeRequestArguments Method ");
		try {

			HttpServletRequest request = (HttpServletRequest) servletRequest;
			ServiceBinder binder = new ServiceBinderImpl();
			
			populateHeaderNames(binder,request);

			/*
			 * Iterates through cookies in the request and adds the key value
			 * pair to the ServiceBinder object.
			 */
			populateCookies(binder, request);
			populateQueryString(binder, request);
			populateParameterNames(binder, request);

			/*
			 * Sets the binder's method type from the method of the
			 * HttpServletRequest object
			 */
			if ("post".equalsIgnoreCase(request.getMethod())) {
				binder.setMethod(Method.POST);
			} else if ("put".equalsIgnoreCase(request.getMethod())) {
				binder.setMethod(Method.PUT);
			} else if ("head".equalsIgnoreCase(request.getMethod())) {
				binder.setMethod(Method.HEAD);
			} else if ("delete".equalsIgnoreCase(request.getMethod())) {
				binder.setMethod(Method.DELETE);
			} else {
				binder.setMethod(Method.GET);
			}

			/*
			 * Sets the ServiceBinder's request date
			 */
			binder.setRequestDate(Calendar.getInstance().getTime());
			LOG.debug("returned Binder in serializeRequestArguments");
			return binder;
		} catch (Exception e) {
			LOG.error("Exception while returning binder --> "
					+ e.getStackTrace());
			throw new RuntimeException(e);
		}

	}
	
	
	private static void populateCookies(ServiceBinder binder,
			HttpServletRequest request) {
		Cookie[] cookies = null;
		try {
			cookies = request.getCookies();
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					binder.putLocal(cookie.getName(), cookie.getValue());
				}
			}
		} catch (Exception e) {
			LOG.error("Exception in cookies in serializeRequestArguments Method --> "
					+ e.getStackTrace());
		}
	}
		/*
		 * Iterates through the query string in the request and adds the key
		 * value pair to the ServiceBinder object.
		 */
	private static void populateQueryString(ServiceBinder binder, HttpServletRequest request) {
		String queryString = null;
		try {
			queryString = request.getQueryString();
			if (queryString != null && !"".equals(queryString)) {
				String[] pairs = queryString.split("&");
				if (pairs != null && pairs.length > 0) {
					for (String pair : pairs) {
						String[] splitPair = pair.split("=");
						if (splitPair != null && splitPair.length == 2) {
							binder.putLocal(splitPair[0], splitPair[1]);
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception in queryString in serializeRequestArguments Method --> "
					+ e.getStackTrace());
		}
}
	/*
	 * Iterates through headers in the request and adds the key value
	 * pair to the ServiceBinder object.
	 */
	private static void populateHeaderNames(ServiceBinder binder, HttpServletRequest request) {
		
		Enumeration<String> headerNames = null;
		try {
			headerNames = request.getHeaderNames();
			if (headerNames != null) {
				while (headerNames.hasMoreElements()) {
					String headerName = headerNames.nextElement();
					String value = request.getHeader(headerName);
					binder.putLocal(headerName, value);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception in headerNames in serializeRequestArguments Method --> "
					+ e.getStackTrace());
		}
	}
	
	/*
	 * Iterates through the parameters in the request and adds the key
	 * value pair to the ServiceBinder object.
	 */
	
	private static void populateParameterNames(ServiceBinder binder, HttpServletRequest request) {
		Enumeration<String> parameterNames = null;
	try {
		parameterNames = request.getParameterNames();
		if (parameterNames != null) {
			while (parameterNames.hasMoreElements()) {
				String parameterName = parameterNames.nextElement();
				String value = request.getParameter(parameterName);
				binder.putLocal(parameterName, value);
			}
		}
	} catch (Exception e) {
		LOG.error("Exception in parameterNames in serializeRequestArguments Method --> "
				+ e.getStackTrace());
	}
	}
	/**
	 * Converting ServiceBinder data to json. For writing out json to a Writer
	 * object for a response.
	 * 
	 * @param binder
	 *            ServiceBinder object
	 * @param out
	 *            Writer object
	 * 
	 * @return void
	 */

	@SuppressWarnings("unchecked")
	public static String serializeServiceBinder(ServiceBinder binder)
			throws RuntimeException {
		LOG.debug("Inside serializeServiceBinder Method -->binder : " + binder);
		try {
			JSONObject json = new JSONObject();

			/*
			 * Set ServiceBinder's response date
			 */
			binder.setResponseDate(Calendar.getInstance().getTime());

			/*
			 * Populate's JSON object with the ServiceBinder's values then
			 * outputs the JSON to the Writer object
			 */

			json.put("ResponseCode", binder.getResponseCode().toString());
			String responseMessageCode = "";
			if (binder.getResponseMessageCode() != null) {
				responseMessageCode = binder.getResponseMessageCode()
						.toString();
			}
			json.put("ResponseMessageCode", responseMessageCode);
			json.put("StatusMessage", binder.getStatusMessage());
			json.put("RequestDate", binder.getRequestDate().toString());
			json.put("ResponseDate", binder.getResponseDate().toString());
			json.put("role", binder.getLocal("role"));
			json.put(ROLECHANGED, binder.getLocal(ROLECHANGED));

			// Checking the null condition for image binary data.
			if (binder.getStatusMessage() != null
					&& "UPLOADED".equalsIgnoreCase(binder.getStatusMessage())) {
				json.put(PICTURE, "Image exists");
			} else {
				json.put(PICTURE, "No Image");
			}

			Map<String, String> localBinder = binder.getBinder();
			Set<String> binderKeys = localBinder.keySet();
			Iterator<String> keyIterator = binderKeys.iterator();

			while (keyIterator.hasNext()) {
				String key = keyIterator.next();
				String value = localBinder.get(key);
				json.put(key, value);
			}

			if (!binder.getResultSets().isEmpty()) {
				Map<String, ResultSet> resultsets = binder.getResultSets();
				Iterator<String> resultsetNames = resultsets.keySet()
						.iterator();
				while (resultsetNames.hasNext()) {
					String resultsetName = resultsetNames.next();
					ResultSet resultset = binder.getResultSet(resultsetName);
					List<DataRow> rows = resultset.getRows();
					JSONArray jsonRows = new JSONArray();
					for (DataRow row : rows) {
						jsonRows.put(row.getRowData());

					}
					json.put(resultsetName, jsonRows);
				}
			}
			LOG.debug("returning json string in serializeServiceBinder Method "); 
			return json.toString();
		} catch (Exception e) {
			LOG.error("exception while returning json string ------> "
					+ e.getStackTrace());
			throw new RuntimeException(e);
		}

	}

	public static void main(String[] args) {
		try {
			Map<String, String> m1 = new HashMap<String, String>() {
				{
					put("a", "12");
					put("b", "23");
				}
			};

			Map<String, String> m2 = new HashMap<String, String>() {
				{
					put("11", "ww");
					put("22", "xx");
				}
			};
			JSONArray jsonRows = new JSONArray();
			jsonRows.put(m1);
			jsonRows.put(m2);
			JSONObject json = new JSONObject();
			json.put("result", jsonRows); 
		} catch (Exception e) {
			LOG.error("exception while returning json string --> "
					+ e.getStackTrace());
			throw new RuntimeException(e);
		}

	}

	public static String safeString(String str) {
		if (str == null) {
			return new String("");
		}
		return str;
	}

}
