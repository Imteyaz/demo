package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;
import java.util.Map;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.common.utility.pojo.MpcGeofenceDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselGeofenceData;
import com.dpworld.mpcsystem.common.utility.pojo.VesselInfo;
import com.dpworld.mpcsystem.persistence.model.MpcGeoFenceData;
import com.dpworld.mpcsystem.persistence.model.MpcGeofenceMaster;

public interface GeofrencingMarinPortDao {

	Map<String, List<GeoFenceData>> getGeoFenceData();

	void saveVTSData(List<VesselInfo> vessels);

	List<VesselInfo> getVesselFromTable();

	void saveGeofenceData(List<VesselGeofenceData> vesselGeofenceDatas);
	
	/**
	 * This method is used to purge table data.
	 * @author Itpeople.Muthukumar
	 * 
	 */
	//void purgeTables() throws Exception;
	void purgeMpcTables() throws Exception;
	
	/**
	 * This method is used to purge conversation Tables
	 */
	void purgeConversationTables();
	
	List<MaintainScoreDTO> getMaintainScoreList();
	
    void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO);
	
    List<SysParamDetailDTO> getSysParamData();
    
	List<MpcGeofenceDTO> constructGeofenceData();
	
	List<MpcGeofenceDTO> constructGeofenceInfo(String mgmGfCode);

	List<MpcGeofenceDTO> getDistinctGeofenceNames();
	
	MpcGeoFenceData getGeofenceCodeByVessName(String vesselName);
	List<String> getMpcSysParamsList();
	List<MpcGeofenceMaster> getAreaData();

	List<SysParamDetailDTO> constructSysParamGeofence();

	List<MpcGeofenceDTO> geofenceBasinData();

	List<String> getAutoRefreshTime(String paramCatg, String paramGroup, String paramCode);

	void generateSystemAlerts(List<VesselDetailsDTO> vesselsList);
	
    public void saveSysParamData(SysParamDetailDTO sysParamDetailDTO);   
	
}
