package com.dpworld.mpcsystem.service;

import com.dpworld.mpcsystem.common.utility.pojo.ColorPickerDTO;

public interface ColorPickerService {

	void saveColorDtls(
			ColorPickerDTO colorPickerDTO);
	
}
