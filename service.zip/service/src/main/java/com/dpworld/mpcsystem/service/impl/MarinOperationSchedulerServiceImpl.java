package com.dpworld.mpcsystem.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.cache.MPCCacheManager;
import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.VesselDataCalcHelper;
import com.dpworld.mpcsystem.common.utility.VesselLocationCalculator;
import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselGeofenceData;
import com.dpworld.mpcsystem.common.utility.pojo.VesselIconsPointsHolder;
import com.dpworld.mpcsystem.common.utility.pojo.VesselInfo;
import com.dpworld.mpcsystem.persistence.dao.GeofrencingMarinPortDao;
import com.dpworld.mpcsystem.persistence.model.MpcGeoFenceData;
import com.dpworld.mpcsystem.service.MarinOperationSchedulerService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

@Service
public class MarinOperationSchedulerServiceImpl implements
		MarinOperationSchedulerService {

	@Autowired
	private GeofrencingMarinPortDao geofrencingMarinPortDao;
	
    public GeofrencingMarinPortDao getGeofrencingMarinPortDao() {
		return geofrencingMarinPortDao;
	}

	public void setGeofrencingMarinPortDao(
			GeofrencingMarinPortDao geofrencingMarinPortDao) {
		this.geofrencingMarinPortDao = geofrencingMarinPortDao;
	}
	@Autowired
    private static final Logger LOGGER = LoggerFactory.getLogger(MarinOperationSchedulerServiceImpl.class);

	public void executeProcess() {
		
		Boolean purge_flag = true;
		purge_flag = Boolean.parseBoolean(MPCUtil.getFuseUrl("purge_flag"));
		LOGGER.info("purge_flag Flag :" + purge_flag + " executeProcess() method ");
		//MPCCacheManager instance = MPCCacheManager.getInstance();
		//instance.setMpcVesselDto();
		//instance.setMpcMarineJobListDto();
		//LOGGER.info("infinispan executed ......");
		if (purge_flag && geofrencingMarinPortDao != null) {
			Client c = Client.create();
			try {
				c.resource(MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL) + "saveVesselDetails").get(String.class);
			} catch (Exception e) {
				LOGGER.error("executeProcess",e);
			}
			try {
				geofrencingMarinPortDao.purgeMpcTables();
			} catch (Exception e) {
				LOGGER.error("executeProcess",e);
			}

		} else {
			LOGGER.info("purge_flag Flag is false Hence not purging the data...");
		}

	} 
	
	
public void executeProcessforMarineJoblist() {
		
		//Boolean purge_flag = true;
		//purge_flag = Boolean.parseBoolean(MPCUtil.getFuseUrl("purge_flag"));
	try {	
	LOGGER.info("  executeProcessforMarineJoblist() schedular  method ");
		MPCCacheManager instance = MPCCacheManager.getInstance();
		instance.setMpcVesselDto();
		instance.setMpcMarineJobListDto();
		LOGGER.info("infinispan executed ......");
	}catch (Exception e) {
		LOGGER.error("executeProcessforMarineJoblist",e);
	}

	}
	

	public void catchVesselGeofenceData1() {
		Boolean purge_flag = true;
		purge_flag = Boolean.parseBoolean(MPCUtil.getFuseUrl("purge_flag"));
		LOGGER.info("purge_flag Flag :" + purge_flag + " catchVesselGeofenceData() method ");
		if (purge_flag && geofrencingMarinPortDao != null) {
			try {
				VesselLocationCalculator locationCalculator = new VesselLocationCalculator();
				VesselDataCalcHelper helper = new VesselDataCalcHelper();
				String geoLocation = null;
				if (geofrencingMarinPortDao != null) {
					Map<String, List<GeoFenceData>> data = geofrencingMarinPortDao.getGeoFenceData();
					List<VesselInfo> result = geofrencingMarinPortDao.getVesselFromTable();
					List<VesselGeofenceData> vesselGeofenceDatas = new ArrayList<VesselGeofenceData>();
					for (VesselInfo vessl : result) {
						VesselGeofenceData vesselGeofenceData = new VesselGeofenceData();
						geoLocation = helper.getVesselGeoLocation(data, new Double(vessl.getLat()),
								new Double(vessl.getLng()));
						if (StringUtils.isNotEmpty(geoLocation)) {
							vesselGeofenceData.setGeofencingCode(geoLocation);
						}
						String vesselGeoCode = locationCalculator.getTerminalQ(vessl.getLat().doubleValue(),
								vessl.getLng().doubleValue());
						if (StringUtils.isNotEmpty(vesselGeoCode)) {
							vesselGeofenceData.setGeofencingCode(vesselGeoCode);
						}
						String location = VesselIconsPointsHolder.getVesselGeofence(data, vessl.getLat(),
								vessl.getLng());
						if (StringUtils.isNotEmpty(location)) {
							vesselGeofenceData.setGeofencingCode(location);
						}

						vesselGeofenceData.setVesselName(vessl.getVesselName());
						MpcGeoFenceData mpcGeoDataParam = new MpcGeoFenceData();
						mpcGeoDataParam.setMgmGfCode(vesselGeofenceData.getGeofencingCode().trim());
						if (validateGeoCode(vessl.getVesselName(), mpcGeoDataParam)) {
							vesselGeofenceDatas.add(vesselGeofenceData);
						}
					}
					if (vesselGeofenceDatas != null && !vesselGeofenceDatas.isEmpty()) {
						geofrencingMarinPortDao.saveGeofenceData(vesselGeofenceDatas);
					}
				}
			} catch (Exception e) {
				LOGGER.error("catchVesselGeofenceData",e);
			}
		} else {
			LOGGER.info("purge_flag Flag is false Hence not saving the data in MPC_GEOFENCE_DATA");
		}

	}
	
	
	public void catchVesselGeofenceData() {
		Boolean purge_flag = true;
		purge_flag = Boolean.parseBoolean(MPCUtil.getFuseUrl("purge_flag"));
		LOGGER.info("purge_flag Flag :" + purge_flag + " catchVesselGeofenceData() method ");
		if (purge_flag && geofrencingMarinPortDao != null) {
			try {
				Client c = Client.create();
				Gson gson = new Gson();
				WebResource resource = null;
				resource = c.resource(MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL)
						+ "workOrderList");
				String response = resource.get(String.class);
				 List<VesselDetailsDTO> list = gson.fromJson(response,
						new TypeToken<List<VesselDetailsDTO>>() {
						}.getType());
				
				List<VesselGeofenceData> vesselGeofenceDatas = new ArrayList<VesselGeofenceData>();
				if (list != null && !list.isEmpty()) {
					for (VesselDetailsDTO dto : list) {
						if (dto.getVesselLocation() != null && !dto.getVesselLocation().isEmpty()) {
							VesselGeofenceData vesselGeofenceData = new VesselGeofenceData();
							vesselGeofenceData.setGeofencingCode(dto.getVesselLocation());
							vesselGeofenceData.setVesselName(dto.getVesselName());
							MpcGeoFenceData mpcGeoDataParam = new MpcGeoFenceData();
							mpcGeoDataParam.setMgmGfCode(vesselGeofenceData.getGeofencingCode().trim());
							if (validateGeoCode(dto.getVesselName(), mpcGeoDataParam)) {
								vesselGeofenceDatas.add(vesselGeofenceData);
							}
						}
					}
				}
				
				if (vesselGeofenceDatas != null && !vesselGeofenceDatas.isEmpty()) {
					geofrencingMarinPortDao.saveGeofenceData(vesselGeofenceDatas);
				}	
				
			} catch (Exception e) {
				LOGGER.error("catchVesselGeofenceData ",e);
			}
		} else {
			LOGGER.info("purge_flag Flag is false Hence not saving the data in MPC_GEOFENCE_DATA");
		}

	}
	
	
	private  boolean validateGeoCode(String vessName , MpcGeoFenceData mpcGeoDataParam){
		MpcGeoFenceData geodataFromDb = geofrencingMarinPortDao.getGeofenceCodeByVessName(vessName);
		LOGGER.info(vessName +" geoCode from db "+geodataFromDb.getMgmGfCode()+"  geoCode from Param "+mpcGeoDataParam.getMgmGfCode());
		BeanComparator comparator = new BeanComparator("mgmGfCode");
		if(comparator.compare(mpcGeoDataParam, geodataFromDb)!=0){
			return true;
		}
		return false;
		
	}
	/**
	 * Method to generate system alerts and purge conversation tables
	 */
	public void executeProcessForAlerts() {
		
		Boolean conv_purge_flag = true;
		conv_purge_flag = Boolean.parseBoolean(MPCUtil.getFuseUrl("conv_purge_flag"));
		LOGGER.info("conv_purge_flag Flag :" + conv_purge_flag + " executeProcessForAlerts() method ");
		
		if (conv_purge_flag && geofrencingMarinPortDao != null) {
			Client c = Client.create();
			WebResource resource = null;
			Gson gson = new Gson();
			String response = null;
			try {
				String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);
				// Call Fuse for to get Vessel details For Alerts
				resource = c.resource(url + "vesselList");
				response = resource.get(String.class);
				List<VesselDetailsDTO> vesselsList = gson.fromJson(response, new TypeToken<List<VesselDetailsDTO>>() {
				}.getType());
				// Generate Alerts
				if (geofrencingMarinPortDao != null && vesselsList != null && !vesselsList.isEmpty()) {
					geofrencingMarinPortDao.generateSystemAlerts(vesselsList);
				}
			} catch (Exception e) {
				LOGGER.error("executeProcessForAlerts",e);
			}

			// Calling Purge Conversation Tables
			try {
					geofrencingMarinPortDao.purgeConversationTables();
				
			} catch (Exception e) {
				LOGGER.error("executeProcessForAlerts",e);
			}
		}else {
			LOGGER.info("Conversation conv_purge_flag Flag is false Hence not purging the data...");
		}

	}
}
