package com.dpworld.mpcsystem.helper;

/**
 * Enum class for defining the HTTP methods
 * 
 */
public enum Method {
	POST, GET, HEAD, DELETE, PUT
}
