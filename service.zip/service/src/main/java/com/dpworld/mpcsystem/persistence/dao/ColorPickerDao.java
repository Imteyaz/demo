package com.dpworld.mpcsystem.persistence.dao;

import com.dpworld.mpcsystem.common.utility.pojo.ColorPickerDTO;

public interface ColorPickerDao {
	
	void saveColorDtls(
			ColorPickerDTO colorPickerDTO);

}
