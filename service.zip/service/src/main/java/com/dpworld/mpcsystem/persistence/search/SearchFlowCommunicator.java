package com.dpworld.mpcsystem.persistence.search;

/**
 * @Author : Rahul Singh
 * @For : Giving decorated operation methods for service instance at run time.
 */
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.dpworld.mpcsystem.common.GenericException;
import com.dpworld.mpcsystem.common.utility.mapping.NullAwareBeanUtilsBean;
import com.dpworld.mpcsystem.common.utility.mapping.PayloadEntity;
import com.dpworld.mpcsystem.common.utility.mapping.PayloadEntityMappingRepository;

public class SearchFlowCommunicator<T, E, W> extends SearchFlow<T, E, W>
		implements SearchCommunicator<T> {

	private static final Logger LOG = Logger
			.getLogger("com.nbad.echannel.persistence.search.SearchFlowCommunicator");

	public SearchFlowCommunicator(Class<T> serviceFactoryInterface,
			SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
		super(serviceFactoryInterface, searchingCriteriaValuesHolder);
	}

	@Override
	public SearchFlowFactoryContext<T, E, W> getSearchFlowContext() {
		LOG.debug("getSearchFlowContext Method ");
		return new SearchFlowFactoryContext<T, E, W>() {

			@Override
			public E beforeSearch(
					SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
				PayloadEntity<E, W> reversedatabasemapper = new PayloadEntityMappingRepository<E, W>(
						new NullAwareBeanUtilsBean<E, W>(
								searchingCriteriaValuesHolder.getEntityClass(),
								searchingCriteriaValuesHolder.getWsClass(),
								searchingCriteriaValuesHolder.getDiffPropT2S()));
				return reversedatabasemapper.embedRequest(
						searchingCriteriaValuesHolder.getEntity(),
						searchingCriteriaValuesHolder.getWsbean());
			}

			@SuppressWarnings("unchecked")
			@Override
			public List<W> transformResult(
					SearchingCriteriaValuesHolder<E, W> holder)
					throws GenericException {
				List<W> searchedResult = new ArrayList<W>();
				List<?> result = holder.getResult();
				Map<String, String> diffPropS2T = null;
				if (searchingCriteriaValuesHolder.getDiffPropT2S() != null) {
					diffPropS2T = (Map<String, String>) MapUtils
							.invertMap(searchingCriteriaValuesHolder
									.getDiffPropT2S());
				}
				PayloadEntity<W, Object> reversedatabasemapper = new PayloadEntityMappingRepository<W, Object>(
						new NullAwareBeanUtilsBean<W, Object>(
								searchingCriteriaValuesHolder.getWsClass(),
								searchingCriteriaValuesHolder.getAliasClass(),
								diffPropS2T));
				for (Object entity : result) {
					try {
						W w = searchingCriteriaValuesHolder.getWsClass()
								.newInstance();
						w = reversedatabasemapper.embedRequest(w, entity);
						searchedResult.add(w);
					} catch (Exception e) {
						LOG.error(e);
					}
				}
				if (holder.getSearchingResultLimit() != null
						&& searchedResult.size() > holder
								.getSearchingResultLimit().intValue()) {
					return searchedResult.subList(0, holder
							.getSearchingResultLimit().intValue());
				}
				return searchedResult;
			}

			@Override
			public boolean validate(SearchingCriteriaValuesHolder<E, W> holder) {
				boolean searchCriteria = false;
				try {
					searchCriteria = validateConditions(holder, searchCriteria);
				} catch (Exception e) {
					LOG.error(e);
				}
				return searchCriteria;
			}

			@Override
			public T getCommunicatorModule() {
				return service;
			}

			private boolean validateConditions(
					SearchingCriteriaValuesHolder<E, W> holder,
					boolean searchCriteria) throws Exception {
				Set<String> searchingProperty = holder.getSearchingProperty();
				boolean searchCriteriaLocal = searchCriteria;
				W w = holder.getWsbean();
				Object[] parm = null;
				for (String property : searchingProperty) {
					PropertyDescriptor pd = new PropertyDescriptor(property,
							holder.getWsClass());
					Method readMethod = pd.getReadMethod();
					if (readMethod != null) {
						Object returned = pd.getReadMethod().invoke(w, parm);
						boolean condit1 = returned != null
								&& !StringUtils.isEmpty(returned.toString());
						if (condit1 && !(returned instanceof Collection)
								&& !(returned instanceof Map)
								&& !(returned instanceof Class)) {
							searchCriteriaLocal = true;
							break;
						}
					}
				}
				return searchCriteriaLocal;
			}
		};
	}

}
