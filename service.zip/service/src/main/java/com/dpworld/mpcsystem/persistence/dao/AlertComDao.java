package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;
import java.util.Map;

import com.dpworld.mpcsystem.common.utility.pojo.ConversationDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;
import com.dpworld.mpcsystem.common.utility.pojo.FilterConversationsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.Response;
import com.dpworld.mpcsystem.common.utility.pojo.SubscribedUserDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.TrendingViewDTO;

public interface AlertComDao {

	
	List<ConversationDTO> findAllConversationInfoOrderByDate(String userName, String flag, String roleName);
	
	List<TrendingViewDTO> findAllTrendingInfoOrderByDate(String userName);

	String addConversation(ConversationDTO conversationdto);
	
	List<ConversationDTO> findConversationById(String convId);
	
	List<ConversationDTO> findConversationById(String convId,String convType);
	
	String addCommentConversation(ConversationDTO conversationdto);

	Response userStatus( String convId, String statusCode, String recId,String loginUserName);
	
/*	List<ConversationDTO>getAllMessagesByConversationId(int ConversationId);*/
	List<ConversationDTO> getRecentAlertByUserCodeRole(String userCode, String roleName);
	Map getRecentAlertByUserCode(String userCode, String roleName);
	
	List<ConversationSubDTO> findSubscribedUserListByConvId(String convId);
	
	List<ConversationSubDTO> findSubscribedUserListByConvId(String convId,String convType);
	
	List<ConversationDTO> filterConversationsByCriteria(FilterConversationsDTO filterConversationsDTO);

	List<SubscribedUserDTO> findSubscribedData(String userName);

	List<ConversationDTO> getAlertsForVesselListByUserCode(String userCode, String roleName);
	
	String addNewUsers(ConversationSubDTO conversationSubDTO);
	
	List<ConversationDTO> getAlertsForVesselListByTopic(String topicValue, String userCode, String roleCode);
	
	}

