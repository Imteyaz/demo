package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.DateUtilities;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.common.utility.pojo.MpcGeofenceDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselGeofenceData;
import com.dpworld.mpcsystem.common.utility.pojo.VesselInfo;
import com.dpworld.mpcsystem.persistence.dao.GeofrencingMarinPortDao;
import com.dpworld.mpcsystem.persistence.model.Conversation;
import com.dpworld.mpcsystem.persistence.model.MpcAlertCurrVal;
import com.dpworld.mpcsystem.persistence.model.MpcAlertMaster;
import com.dpworld.mpcsystem.persistence.model.MpcGeoFenceData;
import com.dpworld.mpcsystem.persistence.model.MpcGeofenceMaster;
import com.dpworld.mpcsystem.persistence.model.MpcScoreMaster;
import com.dpworld.mpcsystem.persistence.model.MpcSysParams;
import com.dpworld.mpcsystem.persistence.model.MpcVslLocs;

@Repository("geofrencingMarinPortDao")
public class GeofrencingMarinPortDaoImpl extends PersistenceUnitDaoImpl<MpcGeoFenceData, Long> implements GeofrencingMarinPortDao {
	private static final String WHERE = " where ";
	private static final String DELETEFROM = "delete from ";
	private static final String DATE_FORMAT_MMDDYY = "MM/dd/yyyy";

	/*
	 * @Autowired private GeofrencingMarinPortDelegate
	 * geofrencingMarinPortDelegate;
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(GeofrencingMarinPortDaoImpl.class);
	public GeofrencingMarinPortDaoImpl() {
		super(MpcGeoFenceData.class);
	}

	public GeofrencingMarinPortDaoImpl(Class<MpcGeoFenceData> persistentClass) {
		super(persistentClass);
	}

	public Map<String, List<GeoFenceData>> getGeoFenceData() {

		Map<String, List<GeoFenceData>> geoFenceMap = new HashMap<String, List<GeoFenceData>>();
		try {
			EntityManager em = getEntityManager();
			TypedQuery<MpcGeofenceMaster> query = em.createNamedQuery("MpcGeofenceMaster.findAll", MpcGeofenceMaster.class);
			List<MpcGeofenceMaster> results = query.getResultList();
			if (!results.isEmpty()) {
				for (MpcGeofenceMaster geomaster : results) {
					List<GeoFenceData> geoFenceList = geoFenceMap.get(geomaster.getMgmGFCode());
                    
					if (geoFenceList == null) {
						geoFenceList = new ArrayList<GeoFenceData>();
					}
					GeoFenceData geoFenceData = new GeoFenceData();
					geoFenceData.setGeoCode(geomaster.getMgmGFCode());
					geoFenceData.setLat(geomaster.getMgmGFLat());
					geoFenceData.setLng(geomaster.getMgmGFLong());
					geoFenceData.setPointOrder(geomaster.getMgmGFSeqNo());
					geoFenceList.add(geoFenceData);
					geoFenceMap.put(geomaster.getMgmGFCode(), geoFenceList);
				}

				for (Map.Entry<String, List<GeoFenceData>> entry : geoFenceMap.entrySet()) {
					Collections.sort(entry.getValue(), new PointsOrderComparator());
				}

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}
		return geoFenceMap;
	}

	private class PointsOrderComparator implements Comparator<GeoFenceData> {

		public int compare(GeoFenceData d, GeoFenceData d1) {
			if (d.getPointOrder() > d1.getPointOrder()) {
				return 1;
			} else if (d.getPointOrder() < d1.getPointOrder()) {
				return -1;
			} else {
				return 0;
			}
		}
	}

	@Transactional
	public void saveVTSData(List<VesselInfo> vessels) {

		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery(" SELECT SYSDATE FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();

		for (VesselInfo v : vessels) {
			MpcVslLocs mpcVslLocs = new MpcVslLocs();
			mpcVslLocs.setDstName(v.getVesselDestinationName());
			mpcVslLocs.setImoNo(v.getImoNumber() + "");
			mpcVslLocs.setIsValid(1);
			mpcVslLocs.setSrcName(v.getVesselSourceName());
			mpcVslLocs.setSrcSys("VTS");
			mpcVslLocs.setTxnDate(date);
			mpcVslLocs.setLat(v.getLat());
			mpcVslLocs.setLng(v.getLng());
			mpcVslLocs.setSrcName(v.getVesselSourceName());
			mpcVslLocs.setVessName(v.getVesselName());
			if (v.getEta() != null) {
				mpcVslLocs.setVslEta(v.getEta());
			}
			Query queryTxId = em.createNativeQuery("SELECT (to_number(to_char(sysdate, 'RRMMDD'))||seq_mpc_sq1.nextval) FROM  dual");
			String txId = (String) queryTxId.getSingleResult();
			mpcVslLocs.setTxnId(new Long(txId));

			em.persist(mpcVslLocs);

		}

	}

	public List<VesselInfo> getVesselFromTable() {
		List<VesselInfo> vessels = new ArrayList<VesselInfo>();
		EntityManager em = getEntityManager();
		try {
			Map<String, List<GeoFenceData>> dataGeofence = getGeoFenceData();
			if(dataGeofence !=null ){
			String sqlQuery = "select a.*" + " from mpc_vsl_locs a" + " where  a.txn_id = (select max(b.txn_id) " + " from   mpc_vsl_locs b"
					+ " where  a.vess_name = b.vess_name " + "and b.src_sys in ('VTS', 'AIS'))";
			Query query = em.createNativeQuery(sqlQuery, MpcVslLocs.class);
			List<MpcVslLocs> data = query.getResultList();
			VesselInfo vesl = null;
			String vesselGeoCode = null;
			for (MpcVslLocs vsl : data) {
				vesl = new VesselInfo();
				if(vsl.getLat()!=null && vsl.getLng()!=null){
				vesselGeoCode = getVesselGeofence(dataGeofence, vsl.getLat(), vsl.getLng());
				vesl.setGeofenceArea(assignValue(vesselGeoCode));
				if (vesselGeoCode!=null && StringUtils.contains("T1Q1,T1Q2,T1Q3,T1Q4,T1Q5,T1Q6,T1Q7,T2Q1,T3Q1", vesselGeoCode)) {
				} else if (vesselGeoCode!=null && StringUtils.contains("CHANNEL", vesselGeoCode) || StringUtils.contains("ANCHOR", vesselGeoCode)) {
					vesl.setBerthedTerminalGeocode(vesselGeoCode);
				} else {
					vesl.setBerthedTerminalGeocode("UNKOWN");
				}
				vesl.setEta(assignValue(vsl.getVslEta()));
				vesl.setImoNumber(assignValue(vsl.getImoNo()));
				vesl.setLat(vsl.getLat());
				vesl.setLng(vsl.getLng());
				vesl.setVesselDestinationName(assignValue(vsl.getDstName()));
				vesl.setVesselName(assignValue(vsl.getVessName()));
				vesl.setVesselSourceName(assignValue(vsl.getSrcName()));
				vesl.setDegrees(assignValue(vsl.getDegree()));
				vesl.setSpeed(assignValue(vsl.getSpeed()));
				vesl.setHeading(assignValue(vsl.getHeading()));
				String lastRcvd = vsl.getTxnDate() != null ? vsl.getTxnDate().toString() : MPCConstants.EMPTY_STRING;
				if (!lastRcvd.equalsIgnoreCase(MPCConstants.EMPTY_STRING)) {
					LOGGER.debug("lastRcvd value : "+lastRcvd);
					Date d = DateUtilities.parseDate(lastRcvd, MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
					lastRcvd = DateUtilities.formatDate(d, MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
				}
				vesl.setLastRecord(assignValue(lastRcvd));
				vesl.setSource(assignValue(vsl.getSrcSys()));
				vessels.add(vesl);
			}else{
				if(vsl.getLat()==null || vsl.getLng()==null)
				LOGGER.info("Lat and long values are null ");
			}
				
				
			}
		}else{
			LOGGER.info("Geofence data is null");
		}
		} catch (Exception e) {
			LOGGER.error("getVesselFromTable", e);
		}finally{
			if(em.isOpen())
			em.close();
		}
		return vessels;
	}
	
	public String assignValue(String obj)
	{
		return obj !=null ? obj :MPCConstants.EMPTY_STRING;
	}

	private boolean isPointInsidePolygon(float lat, float lng, List<GeoFenceData> polyPoints) {
		float x = lat;
		float y = lng;
		boolean inside = false;
		for (int i = 0, j = polyPoints.size() - 1; i < polyPoints.size(); j = i++) {
			float xi = polyPoints.get(i).getLat();
			float yi = polyPoints.get(i).getLng();
			float xj = polyPoints.get(j).getLat();
			float yj = polyPoints.get(j).getLng();
			boolean intersect = ((yi > y) != (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
			if (intersect) {
				inside = !inside;
			}
		}
		return inside;
	}

	private String getVesselGeofence(Map<String, List<GeoFenceData>> data, float lat, float lng) {

		for (Map.Entry<String, List<GeoFenceData>> entry : data.entrySet()) {
			String loctation = entry.getKey();
			List<GeoFenceData> shape = entry.getValue();
			if (isPointInsidePolygon(lat, lng, shape)) {
				return loctation;
			}
		}
		return MPCConstants.EMPTY_STRING;
	}

	@Transactional
	public void saveGeofenceData(List<VesselGeofenceData> vesselGeofenceDatas) {

		try {

			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL ");
			Date date = (Date) queryTime.getSingleResult();

			for (VesselGeofenceData vGeofenceData : vesselGeofenceDatas) {

				MpcGeoFenceData mpcGeoFenceData = new MpcGeoFenceData();
				mpcGeoFenceData.setMgmGfCode(vGeofenceData.getGeofencingCode());
				mpcGeoFenceData.setMgdObjName(vGeofenceData.getVesselName());
				mpcGeoFenceData.setMgdObjType("vessel");
				mpcGeoFenceData.setIsValid(1);
				mpcGeoFenceData.setMgdRecDate(date);
				mpcGeoFenceData.setSrcSys("MPC");
				mpcGeoFenceData.setCareatedDate(date);
				mpcGeoFenceData.setMgdObjEntry(date);
				mpcGeoFenceData.setMgdObjExit(date);
				mpcGeoFenceData.setMgdRecDate(date);

				Query queryResult = em.createNativeQuery("SELECT SEQ_MPC_GEOFENCEDATA.nextval FROM DUAL");
				long id = ((BigDecimal) queryResult.getSingleResult()).longValue();

				mpcGeoFenceData.setMgdRecId(id);
				mpcGeoFenceData.setCreatedBy("MPC");
				em.persist(mpcGeoFenceData);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

	}

	
	
	
	@Transactional
	public void purgeMpcTables() throws Exception{

		long recordCount = 0;
		long systemParamCount = 0;
		int noOfEntitiesDeleted = 0;
		String[] tables = new String[] { MPCConstants.MPC_VSL_LOCS, MPCConstants.MPC_GEOFENCE_DATA};

		for (int i = 0; i < tables.length; i++) {
			EntityManager em = getEntityManager();

			String tableName = tables[i];

			String columnName = null;
			if (tableName != null && tableName.trim().equalsIgnoreCase(MPCConstants.MPC_VSL_LOCS)) {
				columnName = "txn_date";
			}else if (tableName != null && tableName.trim().equalsIgnoreCase(MPCConstants.MPC_GEOFENCE_DATA)) {
				columnName = "mgd_rec_date";
			}

			StringBuilder builder = new StringBuilder("Select Count(*) from ");
			if(MPCConstants.MPC_VSL_LOCS.equalsIgnoreCase(tableName)){
				builder.append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 0.1) ");	
			}else{	
				builder.append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 1) ");
			}
			
			try{
			Query countQuery = em.createNativeQuery(builder.toString());
			try {
				List resultCount = countQuery.getResultList();
				
				if (!resultCount.isEmpty()) {
					recordCount = ((BigDecimal) resultCount.get(0)).longValue();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			builder.setLength(0);

			builder.append("SELECT MSP_VAL1 FROM MPC_SYS_PARAMS WHERE MSP_PARAM_CODE = '");
			builder.append(tableName).append("'");
			Query systemParamQuery = em.createNativeQuery(builder.toString());
			try {
				List systemCountList = systemParamQuery.getResultList();
				
				if (!systemCountList.isEmpty()) {
					systemParamCount =  Long.parseLong((String)systemCountList.get(0));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (recordCount > 0 && recordCount > systemParamCount) {

				while (recordCount > systemParamCount) {

					builder.setLength(0);
					if(MPCConstants.MPC_VSL_LOCS.equalsIgnoreCase(tableName)){
					builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 0.1) and rownum < ")
							.append(systemParamCount);
					}else{
						builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 1) and rownum < ")
						.append(systemParamCount);
					}
					Query deleteQuery = em.createNativeQuery(builder.toString());
					em.joinTransaction();
					noOfEntitiesDeleted = deleteQuery.executeUpdate();

					recordCount = recordCount - systemParamCount;

					if (recordCount <= systemParamCount) {

						builder.setLength(0);
						if(MPCConstants.MPC_VSL_LOCS.equalsIgnoreCase(tableName)){
						builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 0.1)");
						}else{
							builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 1)");
						}
						Query query = em.createNativeQuery(builder.toString());
						em.joinTransaction();
						noOfEntitiesDeleted = query.executeUpdate();
						recordCount = recordCount - systemParamCount;
						break;
					}
				}

			} else if(recordCount>0){
				builder.setLength(0);
				if(MPCConstants.MPC_VSL_LOCS.equalsIgnoreCase(tableName)){
				builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 0.1)");
				}else{
					builder.append(DELETEFROM).append(tableName).append(WHERE).append(columnName).append(" < (sysdate - 1)");
				}
				Query query = em.createNativeQuery(builder.toString());
				em.joinTransaction();
				noOfEntitiesDeleted = query.executeUpdate();
			}
			} catch (Exception e) {
				LOGGER.error("Exception while executing purgeTables API .."
						+ e.getMessage());
				e.printStackTrace();
				em.getTransaction().rollback();
			}finally{
				LOGGER.info("No. of records deleted from :"+tableName +" are : "+noOfEntitiesDeleted);
				if(em.isOpen())
				em.close();
			}
			
		}
	}

	/**
	 * Method to purge alert communications tables
	 * 
	 * @param em
	 */
	@Transactional
	public void purgeConversationTables() {
		EntityManager em = getEntityManager();
		long alertRecordCount = 0;
		long subcrRecordCount = 0;
		try {
			StringBuilder builder = new StringBuilder("Select Count(*) from ");
			builder.append(MPCConstants.MPC_CONVERSATIONS);
			builder.append(" where rec_id in (select mc.rec_id from ");
			builder.append(MPCConstants.MPC_CONVERSATIONS + " mc ");
			builder.append("inner join ");
			builder.append(MPCConstants.MPC_ALERT_MASTER + " alt_mst on mc.alt_id=alt_mst.alt_id ");
			builder.append("and mc.conv_type='");
			builder.append(MPCConstants.CONV_TYPE_ALERT);
			builder.append("' where (mc.created_on+alt_mst.alt_validity)<=SYSDATE )");
			Query countQuery = em.createNativeQuery(builder.toString());
			alertRecordCount = ((BigDecimal) countQuery.getSingleResult()).longValue();
			if (alertRecordCount > 0) {
				// PURGE ALERTS
				// insert records in table MPC_CONVERSATIONS_HIST
				StringBuilder insertQuery = new StringBuilder("Insert into ");
				insertQuery.append(MPCConstants.MPC_CONVERSATIONS_HIST);
				insertQuery.append(" (REC_ID, REC_DATE, CONV_TYPE, ALT_ID, CONV_ID, CONV_TOPIC_TYPE, CONV_TOPIC_VAL, "
						+ "CONV_SUBTOPIC_TYPE, CONV_SUBTOPIC_VAL, CONV_TEXT, CONV_USER, IS_VALID, SRC_SYS, "
						+ "CREATED_ON, CREATED_BY, MODIFIED_ON, MODIFIED_BY) ");
				insertQuery.append("select mc.REC_ID, mc.REC_DATE, mc.CONV_TYPE, mc.ALT_ID, mc.CONV_ID, mc.CONV_TOPIC_TYPE, "
						+ "mc.CONV_TOPIC_VAL, mc.CONV_SUBTOPIC_TYPE, mc.CONV_SUBTOPIC_VAL, mc.CONV_TEXT, mc.CONV_USER, "
						+ "mc.IS_VALID, mc.SRC_SYS, mc.CREATED_ON, mc.CREATED_BY, mc.MODIFIED_ON, mc.MODIFIED_BY ");
				insertQuery.append("from ");
				insertQuery.append(MPCConstants.MPC_CONVERSATIONS + " mc ");
				insertQuery.append("inner join ");
				insertQuery.append(MPCConstants.MPC_ALERT_MASTER + " alt_mst on mc.alt_id=alt_mst.alt_id ");
				insertQuery.append("and mc.conv_type='");
				insertQuery.append(MPCConstants.CONV_TYPE_ALERT);
				insertQuery.append("' where (mc.created_on+alt_mst.alt_validity)<=SYSDATE ");
				em.createNativeQuery(insertQuery.toString()).executeUpdate();

				// delete records from table MPC_CONVERSATIONS table
				StringBuilder deleteQuery = new StringBuilder("Delete from ");
				deleteQuery.append(MPCConstants.MPC_CONVERSATIONS);
				deleteQuery.append(" where rec_id in (select mc.rec_id from ");
				deleteQuery.append(MPCConstants.MPC_CONVERSATIONS + " mc ");
				deleteQuery.append("inner join ");
				deleteQuery.append(MPCConstants.MPC_ALERT_MASTER + " alt_mst on mc.alt_id=alt_mst.alt_id ");
				deleteQuery.append("and mc.conv_type='");
				deleteQuery.append(MPCConstants.CONV_TYPE_ALERT);
				deleteQuery.append("' where (mc.created_on+alt_mst.alt_validity)<=SYSDATE )");
				em.createNativeQuery(deleteQuery.toString()).executeUpdate();
			}
			// PURGE CONVERSATIONS
			builder.setLength(0);
			builder.append(" select count(*) from ");
			builder.append(MPCConstants.MPC_CONV_SUSBCR + " where conv_id in (select ");
			createQueryByParameter("mc.conv_id", builder);
			countQuery = em.createNativeQuery(builder.toString());
			subcrRecordCount = ((BigDecimal) countQuery.getSingleResult()).longValue();
			if (subcrRecordCount > 0) {
				// Insert records in table MPC_CONV_SUBSCR_HIST
				builder.setLength(0);
				builder.append("insert into " + MPCConstants.MPC_CONV_SUBSCR_HIST);
				builder.append(" select * from ");
				builder.append(MPCConstants.MPC_CONV_SUSBCR + " where conv_id in (select ");
				createQueryByParameter("mc.conv_id", builder);
				em.createNativeQuery(builder.toString()).executeUpdate();

				// Purge records from MPC_CONV_SUSBCR table
				builder.setLength(0);
				builder.append("delete from ");
				builder.append(MPCConstants.MPC_CONV_SUSBCR + " where conv_id in (select ");
				createQueryByParameter("mc.conv_id", builder);
				em.createNativeQuery(builder.toString()).executeUpdate();

				// Insert records in table MPC_CONVERSATIONS_HIST
				builder.setLength(0);
				builder.append("insert into " + MPCConstants.MPC_CONVERSATIONS_HIST);
				builder.append(" select ");
				createQueryByParameter("*", builder);
				builder.deleteCharAt(builder.lastIndexOf(")"));
				em.createNativeQuery(builder.toString()).executeUpdate();

				// Purge records from MPC_CONVERSATIONS table
				builder.setLength(0);
				builder.append("delete");
				createQueryByParameter(" ", builder);
				builder.deleteCharAt(builder.lastIndexOf(")"));
				em.createNativeQuery(builder.toString()).executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		} finally {
			LOGGER.info("Alert Records Purged Count = " + alertRecordCount);
			LOGGER.info("Convsr Subcr Purged Count  = " + subcrRecordCount);
		}

	}

	/*
	 * Get Maintain Score List
	 */
	public List<MaintainScoreDTO> getMaintainScoreList() {

		List<MaintainScoreDTO> maintainScoreList = new ArrayList<MaintainScoreDTO>();

		try {

			EntityManager em = getEntityManager();
			TypedQuery<MpcScoreMaster> query = em.createNamedQuery("MpcScoreMaster.findAll", MpcScoreMaster.class);
			List<MpcScoreMaster> results = query.getResultList();
			if (results != null && !results.isEmpty()) {
				for (MpcScoreMaster mpcScoreMaster : results) {

					MaintainScoreDTO maintainScoreDTO = new MaintainScoreDTO();
					maintainScoreDTO.setRecId(String.valueOf(mpcScoreMaster.getRecId()));
					maintainScoreDTO.setRecDate(mpcScoreMaster.getRecDate().toString());
					maintainScoreDTO.setMsmCritType(mpcScoreMaster.getMsmCritType());
					maintainScoreDTO.setMsmCritVal(mpcScoreMaster.getMsmCritVal());
					maintainScoreDTO.setMsmScore(mpcScoreMaster.getMsmScore().toString());
					maintainScoreDTO.setMsmScoreType(mpcScoreMaster.getMsmScoreType());
					if (mpcScoreMaster.getIsValid() == 1) {
						maintainScoreDTO.setIsValid(MPCConstants.YES);
					} else if (mpcScoreMaster.getIsValid() == 0) {
						maintainScoreDTO.setIsValid(MPCConstants.NO);
					}
					maintainScoreDTO.setUserCode(mpcScoreMaster.getUserCode());
					maintainScoreDTO.setCreatedBy(mpcScoreMaster.getCreatedBy());
					if (mpcScoreMaster.getCreatedOn() != null) {
						maintainScoreDTO.setCreatedOn(mpcScoreMaster.getCreatedOn().toString());
					}
					if (mpcScoreMaster.getModifiedBy() != null) {
						maintainScoreDTO.setModifiedBy(mpcScoreMaster.getModifiedBy());
					}
					if (mpcScoreMaster.getModifiedOn() != null) {
						maintainScoreDTO.setModifiedOn(mpcScoreMaster.getModifiedOn().toString());
					}

					maintainScoreList.add(maintainScoreDTO);
				}
			}

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return maintainScoreList;
	}

	/**
	 * Save and Update Maintain Score Details
	 */
	@Transactional
	public void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO) {

		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery("SELECT  SYSDATE FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();

		MpcScoreMaster mpcScoreMaster = new MpcScoreMaster();

		// If SAVE
		if (MPCConstants.EMPTY_STRING.equals(maintainScoreDTO.getRecId())) {

			Query queryResult = em.createNativeQuery(" SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");
			long id = ((BigDecimal) queryResult.getSingleResult()).longValue();

			try {
				long recId = Long.parseLong(this.getCurrentYear(date) + String.valueOf(id));
				mpcScoreMaster.setRecId(recId);
			} catch (Exception er) {
				LOGGER.error(er.getMessage());
			}
			mpcScoreMaster.setRecDate(date);
			mpcScoreMaster.setMsmScoreType(maintainScoreDTO.getMsmScoreType());
			mpcScoreMaster.setMsmCritType(maintainScoreDTO.getMsmCritType());
			mpcScoreMaster.setMsmCritVal(maintainScoreDTO.getMsmCritVal());

			if (!MPCConstants.EMPTY_STRING.equals(maintainScoreDTO.getMsmScore()) || maintainScoreDTO.getMsmScore() != null) {
				mpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO.getMsmScore()));
			}

			mpcScoreMaster.setUserCode(maintainScoreDTO.getUserCode());
			if (maintainScoreDTO.getIsValid().equals(MPCConstants.YES)) {
				mpcScoreMaster.setIsValid(1);
			} else if (maintainScoreDTO.getIsValid().equals(MPCConstants.NO)) {
				mpcScoreMaster.setIsValid(0);
			}

			mpcScoreMaster.setCreatedOn(date);
			mpcScoreMaster.setCreatedBy(maintainScoreDTO.getCreatedBy());

			em.persist(mpcScoreMaster);

		} // IF UPDATE
		else {
			String recID = maintainScoreDTO.getRecId();
			long myRecId = Long.parseLong(recID.trim());
			// Get Data By ID
			MpcScoreMaster upMpcScoreMaster = new MpcScoreMaster();
			upMpcScoreMaster = em.find(MpcScoreMaster.class, myRecId);

			// Set Values in DTO
			upMpcScoreMaster.setMsmScoreType(maintainScoreDTO.getMsmScoreType());
			upMpcScoreMaster.setMsmCritType(maintainScoreDTO.getMsmCritType());
			upMpcScoreMaster.setMsmCritVal(maintainScoreDTO.getMsmCritVal());

			upMpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO.getMsmScore()));

			if (!maintainScoreDTO.getMsmScore().equals("") || maintainScoreDTO.getMsmScore() != null) {
				upMpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO.getMsmScore()));
			}

			if (maintainScoreDTO.getIsValid().equals(MPCConstants.YES)) {
				upMpcScoreMaster.setIsValid(1);
			} else if (maintainScoreDTO.getIsValid().equals(MPCConstants.NO)) {
				upMpcScoreMaster.setIsValid(0);
			}

			upMpcScoreMaster.setUserCode(maintainScoreDTO.getUserCode());
			upMpcScoreMaster.setModifiedBy(maintainScoreDTO.getModifiedBy());
			upMpcScoreMaster.setModifiedOn(date);

			em.persist(upMpcScoreMaster);

		}

	}

	/*
	 * Get List From SysParamDetailDto
	 */
	public List<SysParamDetailDTO> getSysParamData() {

		// Map m = new HashMap();
		List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
		EntityManager em = getEntityManager();
		TypedQuery<MpcSysParams> query = em.createNamedQuery("MpcSysParams.findAll", MpcSysParams.class);

		List<MpcSysParams> results = query.getResultList();
	

		if (!results.isEmpty()) {
			for (MpcSysParams sysparams : results) {

				SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();

				sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
				sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
				sysParamDatas.setMspParamGroup(sysparams.getMspParamGroup());
				sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
				sysParamDatas.setMspVal1(sysparams.getMspVal1());
				if (sysparams.getIsValid() != null) {
					if ((sysparams.getIsValid()).equals(1)) {
						sysParamDatas.setIsValid(MPCConstants.YES);
					} else {
						sysParamDatas.setIsValid(MPCConstants.NO);
					}
				}

				sysParamDatas.setCreatedBy(sysparams.getCreatedBy());

				// New Added
				if (sysparams.getCreatedOn() != null) {
					sysParamDatas.setCreatedOn(sysparams.getCreatedOn().toString());
				}
				sysParamDatas.setMspChar1(sysparams.getMspChar1());
				sysParamDatas.setMspChar2(sysparams.getMspChar2());
				if (sysparams.getMspNum1() != null) {
					sysParamDatas.setMspNum1(sysparams.getMspNum1().toString());
				}

				if (sysparams.getMspNum2() != null) {
					sysParamDatas.setMspNum2(sysparams.getMspNum2().toString());
				}

				if (sysparams.getMspDate1() != null) {

					sysParamDatas.setMspDate1(this.changeDateFormat(sysparams.getMspDate1().toString()));
				}

				if (sysparams.getMspDate2() != null) {
					sysParamDatas.setMspDate2(this.changeDateFormat(sysparams.getMspDate2().toString()));
				}

				sysParamDatas.setMspVal2(sysparams.getMspVal2());
				sysParamDatas.setMspVal3(sysparams.getMspVal3());
				sysParamDatas.setSrcSys(sysparams.getSrcSys());

				sysParamDatas.setModifiedBy(sysparams.getModifiedBy());
				if (sysparams.getModifiedOn() != null) {
					sysParamDatas.setModifiedOn(sysparams.getModifiedOn().toString());
				}

				sysParamData.add(sysParamDatas);
			}
		}
		return sysParamData;

	}

	@Transactional
	public void saveSysParamData(SysParamDetailDTO sysParamDetailDTO) {

		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery("SELECT SYSDATE  FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();

		MpcSysParams mpcsysparams = new MpcSysParams();
		String s = String.valueOf(sysParamDetailDTO.getRecId());
		if (MPCConstants.EMPTY_STRING.equals(s)) {
			Query queryResult = em.createNativeQuery("SELECT  SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");

			long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
			// New Added
			try {
				long recId = Long.parseLong(this.getCurrentYear(date) + String.valueOf(id));
				mpcsysparams.setRecId(recId);
			} catch (Exception er) {
				LOGGER.error(er.getMessage());
			}

			mpcsysparams.setMspParamCatg(sysParamDetailDTO.getMspParamCatg());
			mpcsysparams.setMspParamGroup(sysParamDetailDTO.getMspParamGroup());
			mpcsysparams.setMspParamCode(sysParamDetailDTO.getMspParamCode());
			mpcsysparams.setMspVal1(sysParamDetailDTO.getMspVal1());
			if (sysParamDetailDTO.getIsValid() != null) {
				if (sysParamDetailDTO.getIsValid().equals(MPCConstants.YES)) {
					mpcsysparams.setIsValid(1);
				} else {
					mpcsysparams.setIsValid(0);
				}
			}

			mpcsysparams.setCreatedBy(sysParamDetailDTO.getCreatedBy());
			mpcsysparams.setCreatedOn(date);

			mpcsysparams.setMspChar1(sysParamDetailDTO.getMspChar1());
			mpcsysparams.setMspChar2(sysParamDetailDTO.getMspChar2());

			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspDate1())) {
				mpcsysparams.setMspDate1(convertStringToDate(sysParamDetailDTO.getMspDate1()));
			}
			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspDate2())) {
				mpcsysparams.setMspDate2(this.convertStringToDate(sysParamDetailDTO.getMspDate2()));
			}

			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspNum1())) {
				mpcsysparams.setMspNum1(Integer.parseInt(sysParamDetailDTO.getMspNum1()));
			}
			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspNum2())) {
				mpcsysparams.setMspNum2(Integer.parseInt(sysParamDetailDTO.getMspNum2()));
			}

			mpcsysparams.setMspVal2(sysParamDetailDTO.getMspVal2());
			mpcsysparams.setMspVal3(sysParamDetailDTO.getMspVal3());

			em.persist(mpcsysparams);

		} else {

			String recID = sysParamDetailDTO.getRecId();

			MpcSysParams mpcsysparamsedit = new MpcSysParams();
			mpcsysparamsedit = em.find(MpcSysParams.class, Long.parseLong(recID));
			mpcsysparamsedit.setMspParamCatg(sysParamDetailDTO.getMspParamCatg());
			mpcsysparamsedit.setMspParamGroup(sysParamDetailDTO.getMspParamGroup());
			mpcsysparamsedit.setMspParamCode(sysParamDetailDTO.getMspParamCode());
			mpcsysparamsedit.setMspVal1(sysParamDetailDTO.getMspVal1());
			if (sysParamDetailDTO.getIsValid() != null) {
				if ("Yes".equals(sysParamDetailDTO.getIsValid())) {
					mpcsysparamsedit.setIsValid(1);
				} else {
					mpcsysparamsedit.setIsValid(0);
				}
			}

			mpcsysparamsedit.setModifiedBy(sysParamDetailDTO.getModifiedBy());
			mpcsysparamsedit.setModifiedOn(date);
			// New Added

			mpcsysparamsedit.setMspChar1(sysParamDetailDTO.getMspChar1());
			mpcsysparamsedit.setMspChar2(sysParamDetailDTO.getMspChar2());

			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspDate1())) {

				mpcsysparamsedit.setMspDate1(this.convertStringToDate(sysParamDetailDTO.getMspDate1()));
			}
			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspDate2())) {

				mpcsysparamsedit.setMspDate2(this.convertStringToDate(sysParamDetailDTO.getMspDate2()));
			}

			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspNum1())) {
				mpcsysparamsedit.setMspNum1(Integer.parseInt(sysParamDetailDTO.getMspNum1()));
			}
			if (!MPCConstants.EMPTY_STRING.equals(sysParamDetailDTO.getMspNum2())) {
				mpcsysparamsedit.setMspNum2(Integer.parseInt(sysParamDetailDTO.getMspNum2()));
			}

			mpcsysparamsedit.setMspVal2(sysParamDetailDTO.getMspVal2());
			mpcsysparamsedit.setMspVal3(sysParamDetailDTO.getMspVal3());

			em.persist(mpcsysparamsedit);
		}
	}

	/*
	 * Get Year in YY Format
	 */
	public static String getCurrentYear(Date currentDate) {

		String year = null;
		try {
			DateFormat format = new SimpleDateFormat("yy");
			year = format.format(currentDate);
		} catch (Exception er) {
			er.printStackTrace();
		}
		return year;
	}

	/*
	 * Change Date Format From YY-MM-DD to MM/DD/YYYY
	 */
	public String changeDateFormat(String myDate) {
		String changedDate = null;
		try {
			DateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
			Date date2 = (Date) parser.parse(myDate);

			DateFormat formatter = new SimpleDateFormat(DATE_FORMAT_MMDDYY);
			changedDate = formatter.format(date2);
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
		return changedDate;
	}

	/*
	 * Convert String to Date
	 */
	public Date convertStringToDate(String strDate) {
		Date initDate = null;

		try {
			initDate = new SimpleDateFormat(DATE_FORMAT_MMDDYY).parse(strDate);
		} catch (ParseException e) {
			LOGGER.error(e.getMessage());
		}
		return initDate;
	}

	public List<MpcGeofenceDTO> constructGeofenceData() {
		List<MpcGeofenceDTO> vesselGeofenceList = new ArrayList<MpcGeofenceDTO>();
		List<MpcGeofenceDTO> rs = new ArrayList<MpcGeofenceDTO>();
		try {
			EntityManager em = getEntityManager();
			Query nativeQuery = em
					.createNativeQuery("select GF, VSL FROM (select a.mgm_gf_code GF, a.mgd_obj_name VSL from mpc_geofence_data a where "
							+ " a.mgd_rec_id = (select max(b.mgd_rec_id) from mpc_geofence_data b where  b.mgd_obj_name = a.mgd_obj_name) and "
							+ "exists (select 1 from mpc_int_vsl c where  a.mgd_obj_name = c.vess_name) ) group by GF ,VSL order by GF,VSL");
			List<Object[]> resultSet = nativeQuery.getResultList();
			if (resultSet != null && !resultSet.isEmpty()) {
				for (Object[] obj : resultSet) {
					MpcGeofenceDTO mpcGeofenceDTO = new MpcGeofenceDTO();
					mpcGeofenceDTO.setMgmGfCode((String) obj[0]);
					mpcGeofenceDTO.setMgdObjName((String) obj[1]);
					rs.add(mpcGeofenceDTO);
				}
				return rs;
			} else {
				return null;
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
			return null;
		}
	}

	public List<MpcGeofenceDTO> constructGeofenceInfo(String mgmGfCode) {
		List<MpcGeofenceDTO> vesselGeofenceList = new ArrayList<MpcGeofenceDTO>();
		try {
			EntityManager em = getEntityManager();
			String geofenceNameQuery = "SELECT DISTINCT(m.mgdObjName), m.mgmGfCode FROM MpcGeoFenceData m where m.mgmGfCode ='" + mgmGfCode + "' ";
			Query query = em.createQuery(geofenceNameQuery);
			@SuppressWarnings("unchecked")
			List<Object[]> rs = query.getResultList();
			if (rs != null && !rs.isEmpty()) {
				for (Object[] item : rs) {
					MpcGeofenceDTO mfdto = new MpcGeofenceDTO();
					mfdto.setMgdObjName(item[0].toString());
					mfdto.setMgmGfCode(item[1].toString());
					vesselGeofenceList.add(mfdto);

				}
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
		return vesselGeofenceList;
	}

	public List<MpcGeofenceDTO> getDistinctGeofenceNames() {
		List<MpcGeofenceDTO> vesselGeofenceNamesList = new ArrayList<MpcGeofenceDTO>();
		try {
			EntityManager em = getEntityManager();
			String geofenceNameQuery = "SELECT  DISTINCT m.mgdObjName FROM MpcGeoFenceData m ";
			Query query = em.createQuery(geofenceNameQuery);
			@SuppressWarnings("unchecked")
			List<String> rs = query.getResultList();
			if (rs != null && !rs.isEmpty()) {
				for (String item : rs) {
					MpcGeofenceDTO mfdto = new MpcGeofenceDTO();
					mfdto.setMgdObjName(item);
					vesselGeofenceNamesList.add(mfdto);
				}
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
		return vesselGeofenceNamesList;
	}

	public MpcGeoFenceData getGeofenceCodeByVessName(String vesselName) {
		MpcGeoFenceData vesselGeofence = new MpcGeoFenceData();
		;
		try {
			EntityManager em = getEntityManager();
			String constructGeofence = "SELECT a.mgm_gf_code from mpc_geofence_data a where  a.mgd_rec_id = (select max(b.mgd_rec_id) "
					+ "from mpc_geofence_data b where  b.mgd_obj_name = a.mgd_obj_name) and a.mgd_obj_name = '" + vesselName + "'"
					+ "and a.is_valid = 1";

			Query query = em.createNativeQuery(constructGeofence);
			List<String> geofenceList = (List<String>) query.getResultList();
			if (geofenceList.size() > 0) {
				vesselGeofence.setMgmGfCode(geofenceList.get(0).trim());
			} else {
				vesselGeofence.setMgmGfCode("");
			}

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return vesselGeofence;
	}

	/**
	 * NativeQuery: Plain Sql type Query.
	 * 
	 * Query: HQL Query used.
	 */
	@SuppressWarnings("unchecked")
	public List<String> getMpcSysParamsList() {

		EntityManager em = getEntityManager();

		/*
		 * Query query = em.createNativeQuery("select msp_val1 from " +
		 * "mpc_sys_params where  msp_param_catg = 'GEOFENCE' and " +
		 * "msp_param_group = 'LABELS' and is_valid = 1 order by msp_num1");
		 */

		Query query = em.createQuery("select mspVal1 from " + "MpcSysParams where  mspParamCatg = 'GEOFENCE' and mspParamGroup = 'LABELS' "
				+ "and isValid = 1 order by mspNum1 desc");

		return (List<String>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MpcGeofenceMaster> getAreaData() {

		EntityManager em = getEntityManager();

		Query query = em.createQuery("from MpcGeofenceMaster where isValid = '1' order by mgmGFCode ");

		return (List<MpcGeofenceMaster>) query.getResultList();
	}

	public List<SysParamDetailDTO> constructSysParamGeofence() {
		List<SysParamDetailDTO> sysParamGeofenceList = new ArrayList<SysParamDetailDTO>();
		// List<String> rs= new ArrayList<String>();
		try {
			EntityManager em = getEntityManager();

			String geofenceData = "SELECT m.mspParamCode FROM "
					+ "MpcSysParams m where m.mspParamCatg = 'GEOFENCE' and m.mspParamGroup = 'PIECHART' "
					+ "and m.isValid = 1 order by m.mspNum1 desc";
			/*
			 * String constructGeofence = "SELECT m FROM MpcGeoFenceData m " +
			 * "where m.mgdObjName='" + vesselName + "' " + "and m.isValid = 1";
			 */
			Query query = em.createQuery(geofenceData);
			List<String> rs = query.getResultList();
			if (rs != null && !rs.isEmpty()) {
				for (String item : rs) {
					SysParamDetailDTO mfdto = new SysParamDetailDTO();
					mfdto.setMspParamCode(item);
					sysParamGeofenceList.add(mfdto);
				}
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return sysParamGeofenceList;
	}

	public List<MpcGeofenceDTO> geofenceBasinData() {
		List<MpcGeofenceDTO> basinList = new ArrayList<MpcGeofenceDTO>();
		// List<String> rs= new ArrayList<String>();
		try {
			EntityManager em = getEntityManager();
			String geofenceData = "SELECT Distinct(m.mgdObjName) FROM MpcGeoFenceData m WHERE m.mgmGfCode='BASIN'";
			/*
			 * String constructGeofence = "SELECT m FROM MpcGeoFenceData m " +
			 * "where m.mgdObjName='" + vesselName + "' " + "and m.isValid = 1";
			 */
			Query query = em.createQuery(geofenceData);
			List<String> rs = query.getResultList();
			if (rs != null && !rs.isEmpty()) {
				for (String item : rs) {
					MpcGeofenceDTO mfdto = new MpcGeofenceDTO();
					mfdto.setMgdObjName(item);
					basinList.add(mfdto);
				}
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return basinList;
	}

	@SuppressWarnings("unchecked")
	public List<String> getAutoRefreshTime() {

		EntityManager em = getEntityManager();

		String refreshTime = "SELECT m.mspVal1 FROM "
				+ "MpcSysParams m where m.mspParamCatg = 'AUTOREFRESH' and m.mspParamGroup = 'DASHBOARD' and m.mspParamCode = 'MINUTES'  "
				+ "and m.isValid = 1";
		Query query = em.createQuery(refreshTime);
		return (List<String>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<String> getAutoRefreshTime(String paramCatg, String paramGroup, String paramCode) {

		EntityManager em = getEntityManager();

		String refreshTime = "SELECT m.mspVal1 FROM " + "MpcSysParams m where m.mspParamCatg = '" + paramCatg + "' and m.mspParamGroup = '"
				+ paramGroup + "' and m.mspParamCode = '" + paramCode + "'  " + "and m.isValid = 1";
		Query query = em.createQuery(refreshTime);
		return (List<String>) query.getResultList();

	}
	public BigDecimal getSysParamAlertDetails(String paramCatag , String paramGroup , String paramCode) {
	    Map<String, String> codeValueMap = new HashMap<String, String>();
	    EntityManager em = getEntityManager();
	    List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
	    String myQry = "SELECT m.msp_num1 FROM mpc_sys_params m where m.is_valid = 1 "
	    		+ "and m.msp_param_catg='"+paramCatag+"' and m.msp_param_group='"+paramGroup+"' "
	    		+ "and m.msp_param_code='"+paramCode+"'";
	    
	    Query thresholdQuery = em.createNativeQuery(myQry);
		BigDecimal thresholdValue = null;
		List list = thresholdQuery.getResultList();
		if (list != null && !list.isEmpty()) {
			thresholdValue = (BigDecimal)list.get(0);
			
		}
		LOGGER.info(" Sys Param Value: "+thresholdValue);
	    return thresholdValue;
	  }
	
	public Map<String, String> getSysParamDetailsByAlertCode() {
	    Map<String, String> codeValueMap = new HashMap<String, String>();
	    EntityManager em = getEntityManager();
	    List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
	    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1";
	    Query query = em.createQuery(myQry);
	    List<MpcSysParams> results = query.getResultList();
	    //logger.info("SYS PARAMS DATA FROM DB : "+results); 
	    if (results.size() > 0) {
				for (MpcSysParams sysparams : results) {
					if (sysparams != null
							&& sysparams.getMspParamCatg() != null
							&& (sysparams.getMspParamCatg().equalsIgnoreCase("ALERT")
							&& sysparams.getMspParamGroup().equalsIgnoreCase("ETCALERT")
							))
						codeValueMap.put(sysparams.getMspParamCode(),
								sysparams.getMspVal1());
				}
	    }
		LOGGER.debug(" SYSPARAM MAP : "+codeValueMap);
	    return codeValueMap;
	  }
	
	@Transactional
	public void generateSystemAlerts(List<VesselDetailsDTO> vesselsList) {
		try {
			LOGGER.info("inside generate alert systems ");
			HashMap<String, VesselDetailsDTO> uniqueVslListMap = null;
			EntityManager em = getEntityManager();
			TypedQuery<MpcAlertCurrVal> query = em.createNamedQuery("MpcAlertCurrVal.findAll", MpcAlertCurrVal.class);
			List<MpcAlertCurrVal> results = query.getResultList();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM  DUAL");
			Date date = (Date) queryTime.getSingleResult();

			String hHMGtQueryString = "SELECT m.mspVal1 FROM "
					+ "MpcSysParams m where m.mspParamCatg = 'HHMGT_ALERT' and m.mspParamGroup = 'ALERT_VALUE' and m.isValid = 1 ";
			Query hHMGtQuery = em.createQuery(hHMGtQueryString);
			String hHMGTValue = null;
			try {
				List<MpcSysParams> result = hHMGtQuery.getResultList();
				if (result != null && !result.isEmpty()) {
					hHMGTValue = hHMGtQuery.getResultList().get(0).toString();
				}
			} catch (Exception er) {
				er.printStackTrace();
				LOGGER.error("getting error hHMGTValue",er);
			}
			if (hHMGTValue == null) {
				hHMGTValue = "100"; // Default Value;
			}
			TypedQuery<MpcAlertMaster> alertMasterQuery = em.createNamedQuery("MpcAlertMaster.findAll", MpcAlertMaster.class);
			List<MpcAlertMaster> alerMasterResults = alertMasterQuery.getResultList();

			HashMap<String, MpcAlertCurrVal> currVlaMap = new HashMap<String, MpcAlertCurrVal>();
			HashMap<String, MpcAlertMaster> alertMasterMap = new HashMap<String, MpcAlertMaster>();
			if (results != null && !results.isEmpty()) {
				for (MpcAlertCurrVal currVal : results) {
					currVlaMap.put(currVal.getMacRefCol1() + currVal.getMacChgCol(), currVal);
				}
			}
			if (alerMasterResults != null && !alerMasterResults.isEmpty()) {
				for (MpcAlertMaster alertMaster : alerMasterResults) {
					alertMasterMap.put(alertMaster.getAltCode(), alertMaster);
				}
			}
			uniqueVslListMap = new HashMap<String, VesselDetailsDTO>();
			for (VesselDetailsDTO vslDto : vesselsList) {
				if (vslDto.getRotation() != null && !vslDto.getRotation().isEmpty()) {
					uniqueVslListMap.put(vslDto.getRotation(), vslDto);
				}
			}
			BigDecimal time = getSysParamAlertDetails(MPCConstants.ALERT, MPCConstants.SHOWALERT, MPCConstants.DURATIONHRS);
			if (results == null || results.isEmpty()) {
				populateDataInTable(uniqueVslListMap, alertMasterMap, em, date ,time);
			} else {
				generateAlertsAndUpdateData(uniqueVslListMap, alertMasterMap, currVlaMap, em, date, hHMGTValue,time);
			}
		} catch (Exception er) {
			LOGGER.error("Error generate alert Systems" , er);
		}

	}

	private void generateAlertsAndUpdateData(HashMap<String, VesselDetailsDTO> vesselsListMap, HashMap<String, MpcAlertMaster> alertMasterMap,
			HashMap<String, MpcAlertCurrVal> currVlaMap, EntityManager em, Date date, String hHMGTValue,BigDecimal time) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm");
		for (Map.Entry<String, VesselDetailsDTO> vslEntry : vesselsListMap.entrySet()) {
			VesselDetailsDTO promisVal = vslEntry.getValue();
			if (promisVal != null && promisVal.getRotation() != null) {
				for (Map.Entry<String, MpcAlertMaster> entry : alertMasterMap.entrySet()) {
					String alertCode = entry.getKey();
					switch (alertCode) {
					case "VSLBB1": // AGENTETA 1
						if (promisVal.getEtaDate() != null && !promisVal.getEtaDate().isEmpty()) { // VSLBB1
							boolean flag = checkDuration(promisVal.getEtaDate(), time,date);
							if(flag) {
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "AGENTETA");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1()) && currVal.getMacCurrVal() != null) {
									if (sdf.parse(promisVal.getEtaDate()).compareTo(sdf.parse(currVal.getMacCurrVal())) != 0) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VSLBB1");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<nAgETA>", promisVal.getEtaDate()).replace("<prev value>", currVal.getMacCurrVal());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getEtaDate());
										currVal.setModifiedOn(date);
										em.persist(currVal);
										
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getEtaDate() != null && !promisVal.getEtaDate().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("AGENTETA");
										mpcVslCurrVal.setMacCurrVal(promisVal.getEtaDate());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
							}
						}
						break;
					case "VSLBB2": // AGENTETD 2
						if (promisVal.getEtdDate() != null && !promisVal.getEtdDate().isEmpty()) { // VSLBB2
							boolean flag = checkDuration(promisVal.getEtdDate(), time,date);
							if(flag) {
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "AGENTETD");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1()) && currVal.getMacCurrVal() != null) {
									if (sdf.parse(promisVal.getEtdDate()).compareTo(sdf.parse(currVal.getMacCurrVal())) != 0) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VSLBB2");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<nAgETD>", promisVal.getEtdDate()).replace("<prev value>", currVal.getMacCurrVal());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getEtdDate());
										currVal.setModifiedOn(date);
										em.persist(currVal);
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getEtdDate() != null && !promisVal.getEtdDate().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("AGENTETD");
										mpcVslCurrVal.setMacCurrVal(promisVal.getEtdDate());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
							}
						}
						break;
					case "BPCHG3": // BERTHINGPOSITION 3
						if (promisVal.getBerthPosition() != null && !promisVal.getBerthPosition().isEmpty()) { // BPCHG3
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "BERTHINGPOSITION");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									if (!promisVal.getBerthPosition().equalsIgnoreCase(currVal.getMacCurrVal())) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG3");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<new BP>", promisVal.getBerthPosition()).replace("<prev value>", currVal.getMacCurrVal());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getBerthPosition());
										currVal.setModifiedOn(date);
										em.persist(currVal);
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getEtaDate() != null && !promisVal.getEtaDate().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("BERTHINGPOSITION");
										mpcVslCurrVal.setMacCurrVal(promisVal.getBerthPosition());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					case "VBRTH": // VBRTH 4
						if (promisVal.getStatus() != null && !promisVal.getStatus().isEmpty()) { // VBRTH
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "VESSELSTATUS");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									if (promisVal.getStatus().equalsIgnoreCase("ALONGSIDE")
											&& !currVal.getMacCurrVal().equalsIgnoreCase("	ALONGSIDE")) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VBRTH");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName());
										if (promisVal.getTerminal() != null) {
											alertText = alertText.replace("<Terminal", promisVal.getTerminal());
										}
										if (promisVal.getFromBollard() != null) {
											alertText = alertText.replace("- FB", promisVal.getFromBollard());
										}
										if (promisVal.getToBollard() != null) {
											alertText = alertText.replace("- TB>", promisVal.getToBollard());
										}
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getStatus());
										currVal.setModifiedOn(date);
										em.persist(currVal);
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getStatus() != null && !promisVal.getStatus().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("VESSELSTATUS");
										mpcVslCurrVal.setMacCurrVal(promisVal.getStatus());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					case "VOCOMP": // VOCOMP 5
						if (promisVal.getStatus() != null && !promisVal.getStatus().isEmpty()) { // VOCOMP
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "VESSELSTATUS");
							LOGGER.debug("currVal:" + promisVal.getRotation() + "====VOCOMP===" + " executeProcessForAlerts() method ");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									if (promisVal.getStatus().equalsIgnoreCase("COMPLETED") && !currVal.getMacCurrVal().equalsIgnoreCase("COMPLETED")) {
										// generate alert and insert in   to check
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VOCOMP");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getStatus());
										currVal.setModifiedOn(date);
										em.persist(currVal);
										
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getStatus() != null && !promisVal.getStatus().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("VESSELSTATUS");
										mpcVslCurrVal.setMacCurrVal(promisVal.getStatus());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					case "VDELAY": // VDELAY 6
						if (promisVal.getEtc() != null && !promisVal.getEtc().isEmpty()) { // VDELAY
							boolean flag = checkDuration(promisVal.getEtc(), time,date);
							if(flag) {
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "ETC");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									 BigDecimal thresholdValue= getSysParamAlertDetails(MPCConstants.ALERT,MPCConstants.VDELAY,MPCConstants.THRESHOLD) ;
									long timeDiff = TimeUnit.MILLISECONDS.toMinutes(Math.abs(sdf.parse(promisVal.getEtc()).getTime() - sdf.parse(currVal.getMacCurrVal()).getTime()));	
									if (timeDiff >= thresholdValue.longValue()) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VDELAY");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<new ETC>", promisVal.getEtc()).replace("<prev value>", currVal.getMacCurrVal());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getEtc());
										currVal.setModifiedOn(date);
										em.persist(currVal);
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getEtc() != null && !promisVal.getEtc().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("ETC");
										mpcVslCurrVal.setMacCurrVal(promisVal.getEtc());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						}
						break;
					  case "VACOM1": // VDELAY 6 by tariq
						if (promisVal.getEtc() != null && !promisVal.getEtc().isEmpty()) { // VDELAY
							boolean flag1 = checkDuration(promisVal.getEtc(), time,date);
							if(flag1) {
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "ETC1");
							SimpleDateFormat sdft = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
								if (currVal != null && promisVal.getRotation() != null  ) { // record exists in current value table 
								Integer timelefttocomplete=1200;//Integer.getInteger(currVal.getMacCurrVal().trim()) ;
								if(currVal.getMacCurrVal()!=null)
								{
								timelefttocomplete=Integer.valueOf(currVal.getMacCurrVal().toString().trim()) ;
								}
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
																		
									boolean flag=false;	 
									 Integer flagtime=0;
									 Integer vacomp1=30;
									 Integer vacomp2=60;
									 Integer vacomp3=120;
									 Calendar cal = Calendar.getInstance();
									 Date currentDate= sdft.parse(sdft.format(cal.getTime()));
										
										long diff =  sdft.parse(promisVal.getEtc()).getTime()-(currentDate.getTime());
										long diffMinutes = diff / (60 * 1000) ;
										if (sdft.parse(promisVal.getEtc()).compareTo(currentDate) > 0) 
										{
											 Map<String, String> codeValueMap = new HashMap<String, String>();
											 codeValueMap= getSysParamDetailsByAlertCode() ;
											 if(codeValueMap.get("VACOMP1")!=null && codeValueMap.get("VACOMP2")!=null && codeValueMap.get("VACOMP3")!=null )
											 { vacomp1=Integer.valueOf(codeValueMap.get("VACOMP1"));
											 vacomp2=Integer.valueOf(codeValueMap.get("VACOMP2"));
											 vacomp3=Integer.valueOf(codeValueMap.get("VACOMP3"));
												LOGGER.info("vacomp1==:" + vacomp1+"===vacomp2 ="+vacomp2+"vacomp3"+vacomp3 );
											 }
											
											if (diffMinutes < vacomp1 && timelefttocomplete !=vacomp1 ) 
											{
											
												flag=true;
												flagtime=vacomp1;
											
											}else if(diffMinutes < vacomp2 && timelefttocomplete !=vacomp2 && timelefttocomplete !=vacomp1)
											{
												flag=true;
												flagtime=vacomp2;
											}else if(diffMinutes < vacomp3 && timelefttocomplete !=vacomp3 && timelefttocomplete !=vacomp2 && timelefttocomplete !=vacomp1){
												flag=true;
												flagtime=vacomp3;
											}
												
										LOGGER.debug("flag==:" + flag+"===flagtime ="+flagtime+"diffMinutes"+diffMinutes );
										if(flag==true)	
										{
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("VACOM1");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<TimeDif>", diffMinutes+"");
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										//currVal.setMacCurrVal(promisVal.getEtc());
										currVal.setMacCurrVal(flagtime.toString());
										currVal.setModifiedOn(date);
										em.persist(currVal);
										}
										
										}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									LOGGER.debug("in else====== record=getEtc===:"  );
									if (promisVal.getEtc() != null && !promisVal.getEtc().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("ETC1");
										mpcVslCurrVal.setMacCurrVal(null);
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						}
						break;
					case "BPCHG1": // BPCHG1
						if ((promisVal.getFromBollard() != null && !promisVal.getFromBollard().isEmpty())
								|| (promisVal.getToBollard() != null && !promisVal.getToBollard().isEmpty())) { // BPCHG1
							MpcAlertCurrVal currValFb = currVlaMap.get(promisVal.getRotation() + "FROMBOLLARD");
							MpcAlertCurrVal currValTb = currVlaMap.get(promisVal.getRotation() + "TOBOLLARD");
							if (currValFb != null || currValTb != null) { // record exists in current value table
								if (currValFb != null && currValTb != null) {
									if (promisVal.getRotation() != null && promisVal.getRotation().equalsIgnoreCase(currValFb.getMacRefCol1())
											&& promisVal.getRotation().equalsIgnoreCase(currValTb.getMacRefCol1())) {
										if ((promisVal.getFromBollard() != null && !promisVal.getFromBollard().equalsIgnoreCase(
												currValFb.getMacCurrVal()))
												&& (promisVal.getToBollard() != null && !promisVal.getToBollard().equalsIgnoreCase(
														currValTb.getMacCurrVal()))) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG1");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
													.replace("<FB", promisVal.getFromBollard()).replace("TB>", promisVal.getToBollard())
													.replace("<prev value>", currValFb.getMacCurrVal() + " - " + currValTb.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update FB Current Val
											currValFb.setMacCurrVal(promisVal.getFromBollard());
											currValFb.setModifiedOn(date);
											em.persist(currValFb);
											// Update TB Current Val
											currValTb.setMacCurrVal(promisVal.getToBollard());
											currValTb.setModifiedOn(date);
											em.persist(currValTb);

										} else if ((promisVal.getFromBollard() != null && promisVal.getFromBollard().equalsIgnoreCase(
												currValFb.getMacCurrVal()))
												&& (promisVal.getToBollard() != null && !promisVal.getToBollard().equalsIgnoreCase(
														currValTb.getMacCurrVal()))) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG1");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName());
											if (promisVal.getFromBollard() != null) {
												alertText = alertText.replace("<FB", promisVal.getFromBollard());
											}
											alertText = alertText.replace("TB>", promisVal.getToBollard()).replace("<prev value>",
													currValTb.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update MPC Current Val
											currValTb.setMacCurrVal(promisVal.getToBollard());
											currValTb.setModifiedOn(date);
											em.persist(currValTb);
										} else if ((promisVal.getFromBollard() != null && !promisVal.getFromBollard().equalsIgnoreCase(
												currValFb.getMacCurrVal()))
												&& (promisVal.getToBollard() != null && promisVal.getToBollard().equalsIgnoreCase(
														currValTb.getMacCurrVal()))) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG1");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
													.replace("<FB", promisVal.getFromBollard());
											if (promisVal.getToBollard() != null) {
												alertText = alertText.replace("TB>", promisVal.getToBollard());
											}
											alertText = alertText.replace("<prev value>", currValFb.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update MPC Current Val
											currValFb.setMacCurrVal(promisVal.getFromBollard());
											currValFb.setModifiedOn(date);
											em.persist(currValFb);

										}
									}
								} else if (currValFb != null) {
									if (promisVal.getRotation() != null && promisVal.getRotation().equalsIgnoreCase(currValFb.getMacRefCol1())) {
										if (promisVal.getFromBollard() != null
												&& !promisVal.getFromBollard().equalsIgnoreCase(currValFb.getMacCurrVal())) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG1");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
													.replace("<FB", promisVal.getFromBollard());
											
											alertText = alertText.replace("<prev value>", currValFb.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update MPC Current Val
											currValFb.setMacCurrVal(promisVal.getFromBollard());
											currValFb.setModifiedOn(date);
											em.persist(currValFb);
										}
									}
									
									
								} else if (currValTb != null) {
									if (promisVal.getRotation() != null && promisVal.getRotation().equalsIgnoreCase(currValTb.getMacRefCol1())) {
										if (promisVal.getToBollard() != null && !promisVal.getToBollard().equalsIgnoreCase(currValTb.getMacCurrVal())) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG1");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName());
											
											alertText = alertText.replace("TB>", promisVal.getToBollard()).replace("<prev value>",
													currValTb.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update MPC Current Val
											currValTb.setMacCurrVal(promisVal.getToBollard());
											currValTb.setModifiedOn(date);
											em.persist(currValTb);
										}
									}
								}
							} else { // insert new record in current value table
								// MpcAlertCurrVal mpcVslCurrVal = new
								// MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getFromBollard() != null && !promisVal.getFromBollard().isEmpty()) {
										MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("FROMBOLLARD");
										mpcVslCurrVal.setMacCurrVal(promisVal.getFromBollard());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
									if (promisVal.getToBollard() != null && !promisVal.getToBollard().isEmpty()) {
										MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("TOBOLLARD");
										mpcVslCurrVal.setMacCurrVal(promisVal.getToBollard());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					case "BPCHG2": // BPCHG2 - 10
						if (promisVal.getHhCrane() != null && !promisVal.getHhCrane().isEmpty()) { // BPCHG2
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "HHCRANE");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									if (!promisVal.getHhCrane().equalsIgnoreCase(currVal.getMacCurrVal())) {
										// generate alert and insert in
										// conversation table
										MpcAlertMaster alertDetail = alertMasterMap.get("BPCHG2");
										Conversation conversation = new Conversation();
										conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
										conversation.setAltId((int) alertDetail.getAltId());
										String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
												.replace("<HH Crane", promisVal.getHhCrane());
										if (promisVal.getHhMTG() != null) {
											alertText = alertText.replace("HH MTG>", promisVal.getHhMTG().toString());
										}
										alertText = alertText.replace("<prev value>", currVal.getMacCurrVal());
										conversation.setConvText(alertText);
										saveUpdateConversationRecord(conversation, em, date);
										// Update MPC Current Val
										currVal.setMacCurrVal(promisVal.getHhCrane());
										currVal.setModifiedOn(date);
										em.persist(currVal);
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getHhCrane() != null && !promisVal.getHhCrane().isEmpty()) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("HHCRANE");
										mpcVslCurrVal.setMacCurrVal(promisVal.getHhCrane());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					case "VSLATE": // VSLATE
						if (promisVal.getAisEta() != null && !promisVal.getAisEta().isEmpty() || promisVal.getNewETA() != null
								&& !promisVal.getNewETA().isEmpty()) { // VSLATE
							MpcAlertCurrVal currValAisEta = currVlaMap.get(promisVal.getRotation() + "AISETA");
							MpcAlertCurrVal currValVtsEta = currVlaMap.get(promisVal.getRotation() + "VTSETA");
							MpcAlertCurrVal currValAgentEta = currVlaMap.get(promisVal.getRotation() + "AGENTETA");
							if (currValAgentEta != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currValAgentEta.getMacRefCol1())) {
									if (promisVal.getAisEta() != null && currValAisEta != null && currValAisEta.getMacCurrVal() != null) {
										boolean flag = checkDuration(promisVal.getAisEta(), time,date);
										if(flag) {
										if (sdf.parse(promisVal.getAisEta()).compareTo(sdf.parse(currValAisEta.getMacCurrVal())) != 0) {
											if (sdf.parse(promisVal.getAisEta()).compareTo(sdf.parse(currValAgentEta.getMacCurrVal())) > 0) {
												// generate alert and insert in
												// conversation table
												MpcAlertMaster alertDetail = alertMasterMap.get("VSLATE");
												Conversation conversation = new Conversation();
												conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
												conversation.setAltId((int) alertDetail.getAltId());
												String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
														.replace("<new ETA>", promisVal.getAisEta())
														.replace("<prev value>", currValAisEta.getMacCurrVal());
												conversation.setConvText(alertText);
												saveUpdateConversationRecord(conversation, em, date);
												// Update MPC Current Val
												currValAisEta.setMacCurrVal(promisVal.getAisEta());
												currValAisEta.setModifiedOn(date);
												em.persist(currValAisEta);
											}
										}
										}
									} else if (promisVal.getNewETA() != null && currValVtsEta != null && currValVtsEta.getMacCurrVal() != null) {
										boolean flag = checkDuration(promisVal.getNewETA(), time,date);
										if(flag) {
										if (sdf.parse(promisVal.getNewETA()).compareTo(sdf.parse(currValVtsEta.getMacCurrVal())) != 0) {
											if (sdf.parse(promisVal.getNewETA()).compareTo(sdf.parse(currValAgentEta.getMacCurrVal())) > 0) {
												// generate alert and insert in
												// conversation table
												MpcAlertMaster alertDetail = alertMasterMap.get("VSLATE");
												Conversation conversation = new Conversation();
												conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
												conversation.setAltId((int) alertDetail.getAltId());
												String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
														.replace("<new ETA>", promisVal.getNewETA())
														.replace("<prev value>", currValVtsEta.getMacCurrVal());
												conversation.setConvText(alertText);
												saveUpdateConversationRecord(conversation, em, date);
												// Update MPC Current Val
												currValVtsEta.setMacCurrVal(promisVal.getNewETA());
												currValVtsEta.setModifiedOn(date);
												em.persist(currValVtsEta);
											}
										}
										}
									}
								}
							}
						}
						break;
					case "VSERLY": // VSERLY
						if (promisVal.getAisEta() != null && !promisVal.getAisEta().isEmpty() || promisVal.getNewETA() != null
								&& !promisVal.getNewETA().isEmpty()) { // VSERLY
							MpcAlertCurrVal currValAisEta = currVlaMap.get(promisVal.getRotation() + "AISETA");
							MpcAlertCurrVal currValVtsEta = currVlaMap.get(promisVal.getRotation() + "VTSETA");
							MpcAlertCurrVal currValAgentEta = currVlaMap.get(promisVal.getRotation() + "AGENTETA");
							if (currValAgentEta != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currValAgentEta.getMacRefCol1())) {
									if (promisVal.getAisEta() != null && currValAisEta != null && currValAisEta.getMacCurrVal() != null) {
										boolean flag = checkDuration(promisVal.getAisEta(), time,date);
										if(flag) {
										if (sdf.parse(promisVal.getAisEta()).compareTo(sdf.parse(currValAisEta.getMacCurrVal())) != 0) {
											if (sdf.parse(promisVal.getAisEta()).compareTo(sdf.parse(currValAgentEta.getMacCurrVal())) > 0) {
												// generate alert and insert in
												// conversation table
												MpcAlertMaster alertDetail = alertMasterMap.get("VSERLY");
												Conversation conversation = new Conversation();
												conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
												conversation.setAltId((int) alertDetail.getAltId());
												String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
														.replace("<new ETA>", promisVal.getAisEta())
														.replace("<prev value>", currValAisEta.getMacCurrVal());
												conversation.setConvText(alertText);
												saveUpdateConversationRecord(conversation, em, date);
												// Update MPC Current Val
												currValAisEta.setMacCurrVal(promisVal.getAisEta());
												currValAisEta.setModifiedOn(date);
												em.persist(currValAisEta);
											}
										}
										}
									} else if (promisVal.getNewETA() != null && currValVtsEta != null && currValVtsEta.getMacCurrVal() != null) {
										boolean flag = checkDuration(promisVal.getNewETA(), time,date);
										if(flag) {
										if (sdf.parse(promisVal.getNewETA()).compareTo(sdf.parse(currValVtsEta.getMacCurrVal())) != 0) {
											if (sdf.parse(promisVal.getNewETA()).compareTo(sdf.parse(currValAgentEta.getMacCurrVal())) > 0) {
												// generate alert and insert in
												// conversation table
												MpcAlertMaster alertDetail = alertMasterMap.get("VSLATE");
												Conversation conversation = new Conversation();
												conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
												conversation.setAltId((int) alertDetail.getAltId());
												String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
														.replace("<new ETA>", promisVal.getNewETA())
														.replace("<prev value>", currValVtsEta.getMacCurrVal());
												conversation.setConvText(alertText);
												saveUpdateConversationRecord(conversation, em, date);
												// Update MPC Current Val
												currValVtsEta.setMacCurrVal(promisVal.getNewETA());
												currValVtsEta.setModifiedOn(date);
												em.persist(currValVtsEta);
											}
										}
										}
									}
								}
							}
						}
						break;
					case "VACOMP": // HHMGT
						if (promisVal.getHhMTG() != null) { // VACOMP
							MpcAlertCurrVal currVal = currVlaMap.get(promisVal.getRotation() + "HHMGT");
							if (currVal != null && promisVal.getRotation() != null) { // record exists in current value table
								if (promisVal.getRotation().equalsIgnoreCase(currVal.getMacRefCol1())) {
									if (promisVal.getHhMTG() < Integer.valueOf(hHMGTValue)) {
										if (!promisVal.getHhMTG().toString().equalsIgnoreCase(currVal.getMacCurrVal())) {
											// generate alert and insert in
											// conversation table
											MpcAlertMaster alertDetail = alertMasterMap.get("VACOMP");
											Conversation conversation = new Conversation();
											conversation.setConvTopicVal(promisVal.getRotation() + "-" + promisVal.getVesselName());
											conversation.setAltId((int) alertDetail.getAltId());
											String alertText = alertDetail.getAltText().replace("<vessel>", promisVal.getVesselName())
													.replace("<HH MTG>", promisVal.getHhMTG().toString())
													.replace("<prev value>", currVal.getMacCurrVal());
											conversation.setConvText(alertText);
											saveUpdateConversationRecord(conversation, em, date);
											// Update MPC Current Val
											currVal.setMacCurrVal(promisVal.getHhMTG().toString());
											currVal.setModifiedOn(date);
											em.persist(currVal);
										}
									}
								}
							} else { // insert new record in current value table
								MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
								if (promisVal != null && promisVal.getRotation() != null) {
									if (promisVal.getHhMTG() != null) {
										mpcVslCurrVal.setMacRefCol1(promisVal.getRotation());
										mpcVslCurrVal.setMacChgCol("HHMGT");
										mpcVslCurrVal.setMacCurrVal(promisVal.getHhMTG().toString());
										saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
									}
								}

							}
						}
						break;
					default:
						// No Operation
					}

				}

			}

		}
	}

	private void populateDataInTable(HashMap<String, VesselDetailsDTO> vesselsListMap, HashMap<String, MpcAlertMaster> alertMasterMap,
			EntityManager em, Date date,BigDecimal time) throws ParseException {
		for (Map.Entry<String, VesselDetailsDTO> vslEntry : vesselsListMap.entrySet()) {
			VesselDetailsDTO vsl = vslEntry.getValue();
			if (vsl != null && vsl.getRotation() != null) {
				for (Map.Entry<String, MpcAlertMaster> entry : alertMasterMap.entrySet()) {
					String alertCode = entry.getKey();
					switch (alertCode) {
					case "VSLBB1": // AGENTETA
						if (vsl.getEtaDate() != null && !vsl.getEtaDate().isEmpty()) {
							boolean flag = checkDuration(vsl.getEtaDate(), time,date);
							if(flag) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("AGENTETA");
							mpcVslCurrVal.setMacCurrVal(vsl.getEtaDate());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
							}
						}
						break;
					case "VSLBB2": // AGENTETD
						if (vsl.getEtdDate() != null && !vsl.getEtdDate().isEmpty()) {
							boolean flag = checkDuration(vsl.getEtdDate(), time,date);
							if(flag) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("AGENTETD");
							mpcVslCurrVal.setMacCurrVal(vsl.getEtdDate());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
							}
						}
						break;
					case "BPCHG3": // BERTHINGPOSITION
						if (vsl.getBerthPosition() != null && !vsl.getBerthPosition().isEmpty()) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("BERTHINGPOSITION");
							mpcVslCurrVal.setMacCurrVal(vsl.getBerthPosition());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						break;
					case "VSLATE": // VSLATE OR VSERLY - AISETA/VTSETA
						if (vsl.getAisEta() != null && !vsl.getAisEta().isEmpty()) { // AIS
							boolean flag = checkDuration(vsl.getAisEta(), time,date);
							if(flag) {														// ETA
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("AISETA");
							mpcVslCurrVal.setMacCurrVal(vsl.getAisEta());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						}
						if (vsl.getNewETA() != null && !vsl.getNewETA().isEmpty()) { // VTS
							boolean flag = checkDuration(vsl.getNewETA(), time,date);
							if(flag) {															// ETA
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("VTSETA");
							mpcVslCurrVal.setMacCurrVal(vsl.getNewETA());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						}
						break;
					case "VDELAY": // ETC
						if (vsl.getEtc() != null && !vsl.getEtc().isEmpty()) {
							boolean flag = checkDuration(vsl.getEtc(), time,date);
							if(flag) {	
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("ETC");
							mpcVslCurrVal.setMacCurrVal(vsl.getEtc());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
							}
						}
						break;
					case "VACOM1": // ETC 
						if (vsl.getEtc() != null && !vsl.getEtc().isEmpty()) {
							boolean flag = checkDuration(vsl.getEtc(), time,date);
							if(flag) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("ETC1");
							mpcVslCurrVal.setMacCurrVal(null);
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
							}
						}
						break;
					case "VACOMP": // HH MGT
						if (vsl.getHhMTG() != null) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("HHMGT");
							mpcVslCurrVal.setMacCurrVal(vsl.getHhMTG().toString());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						break;
					case "VOCOMP": // VESSELSTATUS
						if (vsl.getStatus() != null && !vsl.getStatus().isEmpty()) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("VESSELSTATUS");
							mpcVslCurrVal.setMacCurrVal(vsl.getStatus());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						break;
					case "BPCHG1": // From BOLLARD / To BOLLARD
						if (vsl.getFromBollard() != null && !vsl.getFromBollard().isEmpty()) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("FROMBOLLARD");
							mpcVslCurrVal.setMacCurrVal(vsl.getFromBollard());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						if (vsl.getToBollard() != null && !vsl.getToBollard().isEmpty()) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("TOBOLLARD");
							mpcVslCurrVal.setMacCurrVal(vsl.getToBollard());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						break;
					case "BPCHG2": // HHCRANE
						if (vsl.getHhCrane() != null && !vsl.getHhCrane().isEmpty()) {
							MpcAlertCurrVal mpcVslCurrVal = new MpcAlertCurrVal();
							mpcVslCurrVal.setMacRefCol1(vsl.getRotation());
							mpcVslCurrVal.setMacChgCol("HHCRANE");
							mpcVslCurrVal.setMacCurrVal(vsl.getHhCrane());
							saveUpdateCurrValRecord(mpcVslCurrVal, em, date);
						}
						break;
					default:
						// No Operation
					}

				}

			}
		}
	}
	private boolean checkDuration(String timeDateDto ,BigDecimal timeDurationHrs, Date currentDate) throws ParseException {
		LOGGER.debug("timeDateDto====> "+timeDateDto+"timeDurationHrs====> "+timeDurationHrs+"currentDate === > "+ currentDate );
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm");
		long timeDiff = TimeUnit.MILLISECONDS.toMinutes(sdf.parse(timeDateDto).getTime()  - currentDate.getTime());
		long timeMinutes= timeDurationHrs.longValue()*60;
		LOGGER.debug("timeDiff ====> "+timeDiff+" timeMinutes === > "+timeMinutes );
		if(timeDiff>0 && timeDiff<=timeMinutes) {
			return true ;
		}
		return false;
	}
	
	private void  saveUpdateCurrValRecord(MpcAlertCurrVal mpcVslCurrVal, EntityManager em, Date date) {
		Query queryResult = em.createNativeQuery("SELECT seq_mpc_altcurrval_pk01.nextval FROM DUAL");
		long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
		Long recId = Long.parseLong(MPCUtil.getCurrentYear(date) + String.valueOf(id));
		mpcVslCurrVal.setRecId(recId);
		mpcVslCurrVal.setRecdate(date);
		mpcVslCurrVal.setSrcSys(MPCConstants.SOURCE_SYS);
		mpcVslCurrVal.setIsValid(1);
		mpcVslCurrVal.setCreatedOn(date);
		mpcVslCurrVal.setCreatedBy("SYSTEM");
		em.persist(mpcVslCurrVal);
		em.flush();
		LOGGER.info("Persisted record to mpc_alert_currval table with id : "+recId);
		
	}

	private void saveUpdateConversationRecord(Conversation conversation, EntityManager em, Date date) {
		Query queryResult1 = em.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
		long recid = ((BigDecimal) queryResult1.getSingleResult()).longValue();
		long rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date) + String.valueOf(recid));
		conversation.setRecId(rec_Id);
		conversation.setRecdate(date);
		conversation.setConvType("A");
		conversation.setConvTopicType("VESSEL");
		conversation.setConvUser("SYSTEM");
		conversation.setIsValid(1);
		conversation.setSrcSys("MPC");
		conversation.setCreatedOn(date);
		conversation.setCreatedBy("MPC");
		em.persist(conversation);
		em.flush();
		LOGGER.info("Persisted record to mpc_conversations table with id : "+rec_Id);
	}

	private void createQueryByParameter(String parameter, StringBuilder builder) {
		builder.append(parameter + " from ");
		builder.append(MPCConstants.MPC_CONVERSATIONS + " mc ");
		builder.append("where mc.rec_date < (mc.rec_date-(select CASE upper(msp_param_code) ");
		builder.append("WHEN 'MINUTES' THEN msp_val1/1440 WHEN 'HOURS' THEN msp_val1/24 WHEN 'DAYS' THEN ");
		builder.append("msp_val1/1 END from MPC_SYS_PARAMS where msp_param_catg='TIMEINTERVAL' and msp_param_group='PURGE_CONVER')) and mc.conv_type='C' )");
	}
}
