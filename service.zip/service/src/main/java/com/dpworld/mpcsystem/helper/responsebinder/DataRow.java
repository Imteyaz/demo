package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.Map;

/**
 * Interface class for defining the DataRow methods
 */
public interface DataRow {

	void put(String fieldName, String value);

	String get(String fieldName);

	String get(int index);

	String[] getFieldNames();

	Map<String, String> getRowData();

	void setRowData(Map<String, String> data);

}