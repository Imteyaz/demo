package com.dpworld.mpcsystem.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.nbad.echannel.common.constant.Constant;

/**
 * AuditLogAspect to log AuditLog object into DB with the help of AuditService.
 * 
 * @author T2943 - Kathiravan Manickam
 * 
 */
@Aspect
public class AuditLogAspect {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AuditLogAspect.class);

	/**
	 * LogAfterReturning method which executes when createAudit() call completes
	 * and interact with service to log the audit information in DB.
	 * 
	 * @param joinPoint
	 *            the join point to execute a method
	 * @param auditLog
	 *            the object to save
	 */
	@AfterReturning(pointcut = "execution (* com.nbad.echannel.helper.AuditUtils.createAudit(..))", returning = "auditLog")
	public void logAfterReturning(JoinPoint joinPoint
	// , AuditLog auditLog
	) {
		/*
		 * LOGGER.info("logAfterReturning executing...");
		 * LOGGER.info("AuditLog Details : " + auditLog); AuditService
		 * auditService = (AuditService)
		 * ApplicationContextProvider.getApplicationContext()
		 * .getBean("auditService"); boolean isAudit = true; try { for (Object
		 * args : joinPoint.getArgs()) { if (args instanceof Boolean) { isAudit
		 * = (Boolean) args; } } Constant.AUDIT_KEY = Constant.AUDIT_KEY + 1;
		 * auditService.put(auditLog, Constant.AUDIT_KEY, isAudit);
		 */
		// } catch (Exception e) {
		// throw new HibernateException("Audit Log Exception", e);
		// }
		LOGGER.info("Audit logged...");
	}

}
