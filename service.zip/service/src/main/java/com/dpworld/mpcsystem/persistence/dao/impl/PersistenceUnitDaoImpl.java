package com.dpworld.mpcsystem.persistence.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.ObjectRetrievalFailureException;

import com.dpworld.mpcsystem.persistence.dao.GenericDao;

/**
 * This class serves as the Base class for all other DAOs - namely to hold
 * common CRUD methods that they might all use. You should only need to extend
 * this class when your require custom CRUD logic.
 * <p/>
 * 
 * 
 */
@SuppressWarnings("unchecked")
public class PersistenceUnitDaoImpl<T, PK extends Serializable> implements
		GenericDao<T, PK> {

	/**
	 * Log variable for all child classes. Uses LogFactory.getLog(getClass())
	 * from Commons Logging
	 */
	protected final Logger LOGGER = LoggerFactory.getLogger(getClass());

	private Class<T> persistentClass;

	@PersistenceContext(unitName = "persistenceUnitMPC")
	//@PersistenceContext(unitName = "default")
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	public PersistenceUnitDaoImpl(final Class<T> persistentClass) {
		this.persistentClass = persistentClass;
	}

	public PersistenceUnitDaoImpl(final Class<T> persistentClass,
			EntityManager entityManager) {
		this.persistentClass = persistentClass;
		this.entityManager = entityManager;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<T> getAll(String queryName) {
		return entityManager.createNamedQuery(queryName, persistentClass)
				.getResultList();
	}

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings({ "rawtypes" })
	public List<T> getAllDistinct(String queryName) {
		Collection result = new LinkedHashSet(getAll(queryName));
		return new ArrayList(result);
	}

	/**
	 * {@inheritDoc}
	 */
	public T get(PK id, String queryName, String queryParam) {
		Query namedQuery = entityManager.createNamedQuery(queryName,
				this.persistentClass);
		namedQuery.setParameter(queryParam, id);
		T entity = (T) namedQuery.getSingleResult();

		if (entity == null) {
			LOGGER.warn("Oh, '" + this.persistentClass + "' object with id '"
					+ id + "' not found...");
			throw new ObjectRetrievalFailureException(this.persistentClass, id);
		}

		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists(String queryName, Map<String, Object> queryParams) {
		Query namedQuery = createQuery(queryName, queryParams);
		T entity = (T) namedQuery.getSingleResult();
		return entity != null;
	}

	/**
	 * {@inheritDoc}
	 */
	public void save(T object) {
		entityManager.persist(object);
		entityManager.flush();
	}

	/**
	 * {@inheritDoc}
	 */
	public T update(T object) {
		object = entityManager.merge(object);
		entityManager.flush();
		return object;
	}

	/**
	 * {@inheritDoc}
	 */
	public void remove(PK id, String queryName, String queryParam) {
		entityManager.remove(this.get(id, queryName, queryParam));
	}

	/**
	 * {@inheritDoc}
	 */
	public List<T> findByNamedQuery(String queryName,
			Map<String, Object> queryParams) {
		return createQuery(queryName, queryParams).getResultList();
	}

	/**
	 * {@inheritDoc}
	 */
	public T get(String queryName, Map<String, Object> queryParams) {
		return (T) createQuery(queryName, queryParams).getSingleResult();
	}

	/**
	 * {@inheritDoc}
	 */
	public void remove(T object) {
		entityManager.remove(object);
		entityManager.flush();
	}

	/**
	 * Generic method to create query.
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @param queryParam
	 *            query params of the named query
	 * @return the query object.
	 */
	private Query createQuery(String queryName, Map<String, Object> queryParams) {
		Query namedQuery = entityManager.createNamedQuery(queryName);

		for (Map.Entry<String, Object> s : queryParams.entrySet()) {
			namedQuery.setParameter(s.getKey(), s.getValue());
		}
		return namedQuery;
	}

	/**
	 * Generic method to execute native query for delete/insert/update
	 * operations
	 * 
	 * @param queryName
	 *            query name of the native query
	 * @param queryParam
	 *            query param of the native query
	 */
	public void executeNativeQuery(String queryName,
			Map<String, Object> queryParams) {
		Query nativeQuery = entityManager.createNativeQuery(queryName);

		for (Map.Entry<String, Object> s : queryParams.entrySet()) {
			nativeQuery.setParameter(s.getKey(), s.getValue());
		}
		nativeQuery.executeUpdate();
	}
}
