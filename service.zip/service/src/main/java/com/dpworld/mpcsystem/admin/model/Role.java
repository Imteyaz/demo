/**
 * 
 */
package com.dpworld.mpcsystem.admin.model;

import java.io.Serializable;

/**
 * @author sapcle.mohammed
 *
 */
public class Role implements Serializable {

  private static final long serialVersionUID = -6862553588220140496L;

  private String roleName;

  public String getRoleName() {
    return roleName;
  }

  public void setRoleName(String roleName) {
    this.roleName = roleName;
  }
}
