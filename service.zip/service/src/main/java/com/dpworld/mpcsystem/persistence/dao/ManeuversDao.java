package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;

public interface ManeuversDao {
	
	 List<GeoFenceViewDTO> getGeoFenceVesselList(String mgdObjName);

}
