/**
 * 
 */
package com.dpworld.mpcsystem.persistence.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Entity
@Table(name="voyages")
@SecondaryTables({
    @SecondaryTable(name="vessels", pkJoinColumns={
        @PrimaryKeyJoinColumn(name="VESS_NAME", referencedColumnName="VESS_NAME") })
})
public class Voyages implements Serializable {
	
	private static final long serialVersionUID = -8645697427159916496L;
	@Id
	@Column(name = "VESS_NAME")
	String vesselName;
	@Column(name = "ROTN")
	String rotation;
	@Column(name = "eta_date")
	String agentEta;
	@Column(name = "bth_date")
	String berthDate;
	@Column(name = "sail_date")
	String sailDate;
	@Column(name = "dual_berth")
	String dualBerth;
	@Column(name = "port_code")
	String port;
	@Column(name = "terminal_id")
	String terminal;
	
	@Column(table="vessels")
    private String vessels;
	
	public String getRotation() {
		return rotation;
	}
	public void setRotation(String rotation) {
		this.rotation = rotation;
	}
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	
	public String getAgentEta() {
		return agentEta;
	}
	public void setAgentEta(String agentEta) {
		this.agentEta = agentEta;
	}

	public String getBerthDate() {
		return berthDate;
	}
	public void setBerthDate(String berthDate) {
		this.berthDate = berthDate;
	}
	public String getSailDate() {
		return sailDate;
	}
	public void setSailDate(String sailDate) {
		this.sailDate = sailDate;
	}
	public String getDualBerth() {
		return dualBerth;
	}
	public void setDualBerth(String dualBerth) {
		this.dualBerth = dualBerth;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getVessels() {
		return vessels;
	}
	public void setVessels(String vessels) {
		this.vessels = vessels;
	}

}
