package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.ConversationHistoryDTO;

public interface ConversationHistoryService {
	List<ConversationHistoryDTO> getConversationHistoryList(String userName);

}
