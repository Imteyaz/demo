package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailReportDTO;
import com.dpworld.mpcsystem.persistence.dao.DelayedReportDao;
import com.dpworld.mpcsystem.service.DelayedReportService;

@Service("delayedReportService")
public class DelayedReportServiceImpl implements DelayedReportService{
	
	@Autowired
	private DelayedReportDao delayedReportDao;
	
	public List<VesselDetailReportDTO> getRotationList(){
		return delayedReportDao.getRotationList();
	}
	
	public List<VesselDetailReportDTO> getCompRotationList(){
		return delayedReportDao.getCompRotationList();
	}

}
