package com.dpworld.mpcsystem.annotation;

public class PerformanceAspect {

	private static boolean flag = isLogEnable();

	private PerformanceAspect() {
	}

	/**
	 * This method get check performance log is enable.
	 * 
	 * @return
	 */
	private static boolean isLogEnable() {
		flag = true;
		return flag;
	}
}
