package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.DateUtilities;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;
import com.dpworld.mpcsystem.common.utility.pojo.FilterConversationsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.Response;
import com.dpworld.mpcsystem.common.utility.pojo.SubscribedUserDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.TrendingViewDTO;
import com.dpworld.mpcsystem.persistence.dao.AlertComDao;
import com.dpworld.mpcsystem.persistence.model.Conversation;
import com.dpworld.mpcsystem.persistence.model.ConversationSub;
import com.dpworld.mpcsystem.persistence.model.MpcSysParams;


@Repository("alertComDao")
public class AlertComDaoImpl extends PersistenceUnitDaoImpl<Conversation, Long> implements AlertComDao {
    private static final Logger logger = LoggerFactory.getLogger(AlertComDaoImpl.class);
    private static AlertComDaoImpl alertComDaoImpl;
    public AlertComDaoImpl(Class<Conversation> persistentClass) {
		super(persistentClass);
	}
	
	
	public AlertComDaoImpl() {
		super(Conversation.class);
	}
	


	public static AlertComDaoImpl  getAlertComDaoImplInstance(){
		if(null==alertComDaoImpl){
			return new AlertComDaoImpl();
		}else{
			return alertComDaoImpl;
		}
	}

	@SuppressWarnings("unchecked")
	public List<ConversationDTO> findAllConversationInfoOrderByDate(String userName, String sortingOrder, String roleName) {
		
		List<ConversationDTO> conversationDTOs = new ArrayList<ConversationDTO>();
	//	List<ConversationDTO> conversationDTO2 = new ArrayList<ConversationDTO>();
		String queryToFetchAlertsAndConv=null;
		Query query =  null;
		
		userName=userName.toLowerCase();
		try {
			EntityManager em = getEntityManager();
			
			queryToFetchAlertsAndConv="select * from "
					+ " (SELECT B.REC_ID, B.REC_DATE,"
					+ " b.conv_topic_type, MIN(B.CONV_ID) CONV_ID, B.CONV_USER, B.CONV_TEXT,"
					+ " b.created_by, b.conv_topic_val, b.alt_id FROM mpc_conv_subscr a, mpc_conversations b"
				//	+ " WHERE a.conv_id = b.conv_id AND a.user_code = '"+userName+"' AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1"
					+ " WHERE a.conv_id = b.conv_id AND lower(a.user_code) = '"+userName+"' AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1"
					+ " AND 1440 * (sysdate-b.rec_date) <="
					+ " ( select m.msp_val1 from mpc_sys_params m "
					+ " where m.msp_param_catg = 'TIMEINTERVAL' "
					+ " and m.msp_param_group = 'CONVERSATION' "
					+ " and m.msp_param_code = 'MINUTES' "
					+ " and m.is_valid = 1 "
					+ " ) and a.is_valid = 1 and b.is_valid = 1 and b.conv_type='C'"
					+ " GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, "
					+ " b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by,"
					+ " b.conv_topic_val, b.alt_id"
					+ " union all               "
					+ " SELECT B.REC_ID, B.REC_DATE,"
					+ " b.conv_topic_type, MIN(b.conv_id) CONV_ID, B.CONV_USER, B.CONV_TEXT, "
					+ " b.created_by, b.conv_topic_val, b.alt_id FROM mpc_conv_subscr a, mpc_conversations b "
					+ " WHERE a.alt_id = b.alt_id AND a.role_code = '"+roleName+"' AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1 "
					+ " AND 1440 * (sysdate-b.rec_date) <= "
					+ " ( select m.msp_val1 from mpc_sys_params m"
					+ " where m.msp_param_catg = 'TIMEINTERVAL' "
					+ " and m.msp_param_group = 'CONVERSATION' "
					+ " and m.msp_param_code = 'MINUTES' "
					+ " and m.is_valid = 1) "
					+ " and b.conv_type='A'"
					+ " GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, "
					+ " b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by,"
					+ " b.conv_topic_val, b.alt_id ) all_rec  ";


					if (sortingOrder.equals(MPCConstants.SORT_CONVLIST_ASC)){
						queryToFetchAlertsAndConv+=" order by 2 asc ";
					}else{
						queryToFetchAlertsAndConv+=" order by 2 desc ";
					}
			
					query = em.createNativeQuery(queryToFetchAlertsAndConv);
			
			
			List<Object[]> rows = query.getResultList();
			for (Object[] row : rows) {
				
				   logger.debug(" COMPLETE ROW IS  : "+Arrays.toString(row));
				   
					ConversationDTO conversationDTO = new ConversationDTO();
					if(row[0] != null){
						conversationDTO.setRecId(row[0].toString());
						}
					if(row[1] != null){
						conversationDTO.setRecDate(row[1].toString());
						}
					if(row[2] != null){
						conversationDTO.setConvTopicType(row[2].toString());
						}
					if(row[3] != null){
						conversationDTO.setConvId(row[3].toString());
						}
					if(row[4] != null){
						conversationDTO.setConverUser(row[4].toString().toLowerCase());
						}
					if(row[5] != null){
						conversationDTO.setConvText(row[5].toString());
						}
					if(row[6] != null){
						conversationDTO.setCreatedBy(row[6].toString());
						}
					if(row[7] != null){
						conversationDTO.setConvTopicVal(row[7].toString());
						}
					if(row[8] != null){
						conversationDTO.setAltId(row[8].toString());
						}
			/*		if(row[9] != null){
						conversationDTO.setCreatedOn(row[9].toString());
						}*/
					conversationDTOs.add(conversationDTO);
				}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		 		
		return conversationDTOs;
	}

	
	
	
	
	
	public List<TrendingViewDTO> findAllTrendingInfoOrderByDate(String userName) 
	{
		
		List<TrendingViewDTO> trendingViewDTO = new ArrayList<TrendingViewDTO>();

			try {
				
				EntityManager em = getEntityManager();
				userName=userName.toLowerCase();
				Query query = em .createNativeQuery("select mc.conv_id, mc.conv_topic_type, mc.conv_topic_val, mc.conv_subtopic_type, mc.conv_subtopic_val,max(NVL(mc.alt_id,0)),"
						+ " min(mc.created_on) created_on, count(mc.rec_id), NVL(mcs.user_code,0) IS_SUBSCRIBED,"
						+ " min(mcs.created_on) followed_on, min(mcs.rec_id) rec_id, mcs.subscr_status"
						+ " from mpc_conversations mc "
						+ " left join mpc_conv_subscr  mcs on mc.conv_id = mcs.conv_id and lower(mcs.user_code)='"+userName+"' and mcs.is_valid=1 "
						+ " where 1440 * (sysdate-mc.rec_date) <= "
						+ " ( select m.msp_val1 from mpc_sys_params m"
						+ " where m.msp_param_catg = 'TIMEINTERVAL'"
						+ " and m.msp_param_group = 'TRENDING'"
						+ " and m.msp_param_code = 'MINUTES'"
						+ " and m.is_valid = 1 "
						+ " )  "
						+ " and mc.is_valid=1 and mc.conv_type='A'"
						+ " group by  mc.conv_id, mc.conv_topic_type,"
						+ " mc.conv_topic_val, mc.conv_subtopic_type, mc.conv_subtopic_val, mcs.user_code, mcs.subscr_status order by  created_on desc");


				@SuppressWarnings("unchecked")
				List<Object[]> rows = query.getResultList();
				
				if (rows.size() > 0) {

					for (Object[] row : rows) {
						TrendingViewDTO trendingViewDTO2 = new TrendingViewDTO();
						if(row[0] != null){
							trendingViewDTO2.setConvId(row[0].toString());
						}
						if(row[1] != null){
							trendingViewDTO2.setConvTopicType(row[1].toString());
						}
						if(row[2] != null){
							trendingViewDTO2.setConvTopicVal(row[2].toString());
						}
						if(row[3] != null){
							trendingViewDTO2.setConvSubTopicType(row[3].toString());
						}
						if(row[4] != null){
							trendingViewDTO2.setConvSubTopicVal(row[4].toString());
						}
						if(row[5] != null){
							trendingViewDTO2.setAltId(row[5].toString());
						}
						if(row[6] != null){
							trendingViewDTO2.setCreatedOn(row[6].toString());
						}
						if(row[7] != null){
							trendingViewDTO2.setCount(row[7].toString());
						}
						if(row[8] != null){
							trendingViewDTO2.setIsSubscribed(row[8].toString());
						}
						if(row[9] != null){
							trendingViewDTO2.setFollowedOn(row[9].toString());
						}
						if(row[10] != null){
							trendingViewDTO2.setRecId(row[10].toString());
						}
						if(row[11] != null){
							trendingViewDTO2.setSubsStatus(row[11].toString());
						}
						
						
						trendingViewDTO.add(trendingViewDTO2);
					}
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			return trendingViewDTO;
		}
	
	


	@Override
	public String addCommentConversation(ConversationDTO conversationdto) {
		return null;
	}

	
	@Transactional
	public Response userStatus(String convId, String statusCode, String recId, String loginUserName) {

		ConversationSub conversationSub = null;
		Date date = null;
		Response response = new Response();
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
     		if(recId != null && recId != ""){
     			long rec_id = Long.parseLong(recId);
     			conversationSub = em.find(ConversationSub.class, rec_id);
     		}
			
			if(conversationSub!=null){
				conversationSub.setSubscrStatus(statusCode);
				conversationSub.setModifiedOn(date);
				conversationSub.setModifiedBy(loginUserName);
				em.persist(conversationSub);
			}else{
				long CONV_ID = Long.parseLong(convId);
				logger.info("CONV_ID : " + CONV_ID);
				
				Conversation conversation = (Conversation) em.createQuery("SELECT c FROM Conversation c WHERE c.convId LIKE :convId")
				.setParameter("convId", CONV_ID).getResultList().get(0);
				
				
				Query queryResult1 = em
						.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
				long recid = ((BigDecimal) queryResult1.getSingleResult()).longValue();
				long rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
							+ String.valueOf(recid));
				if(conversation != null)
				{   
					ConversationSub conversationSub2 = new ConversationSub();
					conversationSub2.setConvId(conversation.getConvId());
					conversationSub2.setRecdate(date);
					conversationSub2.setUserCode(loginUserName);
					conversationSub2.setSubscrStatus("1");
					conversationSub2.setIsValid(1);
					conversationSub2.setSrcSys("MPC");
					conversationSub2.setCreatedOn(date);
					conversationSub2.setCreatedBy(loginUserName);
					/*conversationSub2.setModifiedOn(new Date());
					conversationSub2.setModifiedBy(loginUserName);*/
					conversationSub2.setRecId(rec_Id);
					//conversationSub2.setAltId(altId);
					em.persist(conversationSub2);
					
				}
				
				
				
			}
			
		
		}catch (Exception e) {
			e.printStackTrace();
			
		}
		response.setDateTime(date.toString());
		if(statusCode.equals("0"))
			response.setStatus("1");
		else
			response.setStatus("0");
		
		return response;
	}

	@Transactional
	public String addConversation(ConversationDTO conversationdto) {
		
		String flag = "true";
		
		HashMap<String, String> userRoleMap = new HashMap<String, String>();
		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();
			
		try {
			
			
			
				
							Conversation conversation = new Conversation();
							Query queryResult1 = em
									.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
							long recid = ((BigDecimal) queryResult1.getSingleResult()).longValue();
							long rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
										+ String.valueOf(recid));
							
							if(conversationdto.getConvId() !=null && !conversationdto.getConvId().equals(""))
							{
								conversation.setConvId(Long.parseLong(conversationdto.getConvId()));
								
							}
							else
							{	
								Query queryResult2 = em
										.createNativeQuery("SELECT seq_mcnv_convid.nextval FROM DUAL");
								long convid = ((BigDecimal) queryResult2.getSingleResult()).longValue();
								
									long conv_id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
											+ String.valueOf(convid));
									conversation.setConvId(conv_id);
								
							}	
							
							if (conversationdto.getAltId() !=null && !conversationdto.getAltId().equals(""))  
							{	
								conversation.setAltId(Integer.parseInt(conversationdto.getAltId()));
								
								
							}	
							
							conversation.setRecId(rec_Id);
						    conversation.setRecdate(date);
						    conversation.setConvTopicType(conversationdto.getConvTopicType());
						    conversation.setConvTopicVal(conversationdto.getConvTopicVal());
						    conversation.setConvUser(conversationdto.getConverUser());
						    conversation.setConvText(conversationdto.getConvText());
						    conversation.setConvType(MPCConstants.CONV_TYPE_CONV);
						    conversation.setIsValid(MPCConstants.DATA_VALID_FLAG);
						    conversation.setSrcSys(conversationdto.getSrcSys());
						    conversation.setCreatedOn(date);
						    conversation.setCreatedBy(conversationdto.getCreatedBy());
							
						    em.persist(conversation);
						    
						    userRoleMap = conversationdto.getUserRoleMap();
							
						if(conversationdto.getUserlist().size()>0){
							for(String userName : conversationdto.getUserlist()){
					
								
								
								Query queryResult3 = em
										.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
								long subrecid = ((BigDecimal) queryResult3.getSingleResult()).longValue();
								long sub_rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
											+ String.valueOf(subrecid));
								
								
								ConversationSub conversationSub = new ConversationSub();
								conversationSub.setRecId(sub_rec_Id);
								conversationSub.setRecdate(date);
								conversationSub.setConvId(conversation.getConvId());
								conversationSub.setUserCode(userName);
								conversationSub.setRoleCode(userRoleMap.get(userName));
								conversationSub.setSubscrStatus("1");
								conversationSub.setIsValid(MPCConstants.DATA_VALID_FLAG);
								conversationSub.setSrcSys(conversationdto.getSrcSys());
								conversationSub.setCreatedBy(conversation.getCreatedBy());
								conversationSub.setCreatedOn(date);
								
								em.persist(conversationSub);
								
								
							}
						}
					
				
			
			
				
		} catch (Exception er) {
			er.printStackTrace();
			flag = "false";
		}
		
		return flag;
	}


	
	public List<ConversationDTO> findConversationById(String convId) {
	// Add time
		
		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		// select * from mpc_conversations con where con.conv_id = '111' order by rec_date desc
		
		try
		{		
			EntityManager em = getEntityManager();
					
			String myQry = "SELECT m FROM Conversation m "
					+ "where m.convId='"+convId+"' "
					+ "and m.isValid = 1 order by recdate desc";
			Query query = em.createQuery(myQry);
			List<Conversation> convList = query.getResultList();
			if(convList!=null && convList.size()>0){
				for(Conversation conv : convList){
					
					ConversationDTO conversationDTO = new ConversationDTO();
					conversationDTO.setRecId(String.valueOf(conv.getRecId()));
					conversationDTO.setRecDate(conv.getRecdate().toString());
					conversationDTO.setConvType(conv.getConvType());
					if(conv.getAltId()!=null){
						conversationDTO.setAltId(conv.getAltId().toString());	
					}
					conversationDTO.setConvId(String.valueOf(conv.getConvId()));
					conversationDTO.setConvTopicType(conv.getConvTopicType());
					conversationDTO.setConvTopicVal(conv.getConvTopicVal());
					conversationDTO.setConvSubTopicType(conv.getConvSubTopicType());
					conversationDTO.setConvSubTopicVal(conv.getConvSubTopicVal());
					conversationDTO.setConvText(conv.getConvText());
					conversationDTO.setConverUser(conv.getConvUser().toLowerCase());
					conversationDTO.setIsValid(conv.getIsValid().toString());
					conversationDTO.setSrcSys(conv.getSrcSys());
					conversationDTO.setCreatedBy(conv.getCreatedBy());
					if(conv.getCreatedOn()!=null){
					conversationDTO.setCreatedOn(conv.getCreatedOn().toString());
					}
					conversationList.add(conversationDTO);
				}
			}

			
		}
		catch(Exception er){
			er.printStackTrace();
		}
		
		
		return conversationList;
	}
	
	
	public List<ConversationDTO> findConversationById(String convId,String convType) {
		// Add time
			
			List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
			// select * from mpc_conversations con where con.conv_id = '111' order by rec_date desc
			String myQry =null;
			try
			{		
				EntityManager em = getEntityManager();
						
				if (convType !=null && convType.equalsIgnoreCase(MPCConstants.CONV_TYPE_ALERT)){  // if contype is alert then fetch alerts else fetch conversation
				 myQry = "SELECT m FROM Conversation m "
						+ "where m.convType='"+MPCConstants.CONV_TYPE_ALERT+"' and m.altId='"+convId+"' "
						+ "and m.isValid = 1 order by recdate desc";
				}else {
					 myQry = "SELECT m FROM Conversation m "
							 + "where m.convType='"+MPCConstants.CONV_TYPE_CONV+"' and m.convId='"+convId+"' "
							+ "and m.isValid = 1 order by recdate desc";
				}
				Query query = em.createQuery(myQry);
				List<Conversation> convList = query.getResultList();
				if(convList!=null && convList.size()>0){
					for(Conversation conv : convList){
						
						ConversationDTO conversationDTO = new ConversationDTO();
						conversationDTO.setRecId(String.valueOf(conv.getRecId()));
						conversationDTO.setRecDate(conv.getRecdate().toString());
						conversationDTO.setConvType(conv.getConvType());
						if(conv.getAltId()!=null){
							conversationDTO.setAltId(conv.getAltId().toString());	
						}
						if(conv.getConvId()!=null){
							conversationDTO.setConvId(String.valueOf(conv.getConvId()));	
						}
						//conversationDTO.setConvId(String.valueOf(conv.getConvId()));
						conversationDTO.setConvTopicType(conv.getConvTopicType());
						conversationDTO.setConvTopicVal(conv.getConvTopicVal());
						conversationDTO.setConvSubTopicType(conv.getConvSubTopicType());
						conversationDTO.setConvSubTopicVal(conv.getConvSubTopicVal());
						conversationDTO.setConvText(conv.getConvText());
						conversationDTO.setConverUser(conv.getConvUser().toLowerCase());
						conversationDTO.setIsValid(conv.getIsValid().toString());
						conversationDTO.setSrcSys(conv.getSrcSys());
						conversationDTO.setCreatedBy(conv.getCreatedBy());
						if(conv.getCreatedOn()!=null){
						conversationDTO.setCreatedOn(conv.getCreatedOn().toString());
						}
						conversationList.add(conversationDTO);
					}
				}

				
			}
			catch(Exception er){
				er.printStackTrace();
			}
			
			
			return conversationList;
		}
		

	
	public List<ConversationDTO> getRecentAlertByUserCodeRole(String userCode, String roleName) {

		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		try {

			EntityManager em = getEntityManager();
			userCode=userCode.toLowerCase();
			String myQry = "SELECT B.REC_ID, B.REC_DATE,"
					+ " b.conv_topic_type, MIN(B.CONV_ID) CONV_ID, B.CONV_USER, B.CONV_TEXT, "
					+ "b.created_by, b.conv_topic_val, b.alt_id FROM mpc_conv_subscr a, mpc_conversations b "
					+ "WHERE ( a.conv_id = b.conv_id or a.alt_id=b.alt_id) "
					+ "AND "
					+ "((lower(a.user_code) = '"+userCode.trim()+"' and b.conv_type='C') "
							+ "or "
							+ "(a.role_code = '"+roleName+"' and b.conv_type='A')) "
									+ "AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1 "
					+ "AND lower(b.conv_user) != '"+userCode.trim()+"' "
					+ "and 1440 * (sysdate-b.rec_date) <= "
		    	    	   	+ "( select m.msp_val1 from mpc_sys_params m " 
							+ "where m.msp_param_catg = 'TIMEINTERVAL' "
							+ "and m.msp_param_group = 'RECENT_CONVER' "
							+ "and m.msp_param_code = 'MINUTES' "
							+ "and m.is_valid = 1 "
							+ ") " 
					+ "GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, "
					+ "b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by, b.conv_topic_val, b.alt_id order by b.rec_date desc";
			
			
			Query query = em.createNativeQuery(myQry);

			@SuppressWarnings("unchecked")
			List<Object[]> rows = query.getResultList();

			if (rows.size() > 0) {

				for (Object[] row : rows) {

					ConversationDTO conversationDTO = new ConversationDTO();
					if(row[0] != null){
						conversationDTO.setRecId(row[0].toString());
						}
					if(row[1] != null){
						conversationDTO.setRecDate(row[1].toString());
						}
					if(row[2] != null){
						conversationDTO.setConvTopicType(row[2].toString());
						}
					if(row[3] != null){
						conversationDTO.setConvId(row[3].toString());
						}
					if(row[4] != null){
						conversationDTO.setConverUser(row[4].toString().toLowerCase());
						}
					if(row[5] != null){
						conversationDTO.setConvText(row[5].toString());
						}
					if(row[6] != null){
						conversationDTO.setCreatedBy(row[6].toString());
						}
					if(row[7] != null){
						conversationDTO.setConvTopicVal(row[7].toString());
						}
					if(row[8] != null){
						conversationDTO.setAltId(row[8].toString());
						}
					conversationList.add(conversationDTO);
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}

		return conversationList;
	}

	public Map getRecentAlertByUserCode(String userCode, String roleName) {
		BigDecimal aAndCCount = BigDecimal.ZERO;
		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		Map resutMap = new HashMap();
		try {
			EntityManager em = getEntityManager();
			userCode=userCode.toLowerCase().trim();
			String d = getLRDfromSysParmas(userCode);
			if(null==d){
			d = getTimeIntervalfromSysParmas();	
			}
			SimpleDateFormat original = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
			SimpleDateFormat target = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
			Date date = original.parse(d);
			d = target.format(date);
			String countQry  = "SELECT B.REC_ID, B.REC_DATE,"
					+ " b.conv_topic_type, MIN(B.CONV_ID) CONV_ID, B.CONV_USER, B.CONV_TEXT, "
					+ "b.created_by, b.conv_topic_val, b.alt_id FROM mpc_conv_subscr a, mpc_conversations b "
					+ "WHERE "
					+ "  ( a.conv_id = b.conv_id or a.alt_id = b.alt_id) AND ((lower(a.user_code) = '"+userCode+"' "
					+ " and b.conv_type='C') or (a.role_code = '"+roleName+"' and b.conv_type='A')) "
					+ " AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1 AND lower(b.conv_user) != "
					+ " lower('"+userCode+"')  and b.rec_date >= TO_DATE('"+d+"','DD-MON-YYYY HH24:MI')"
							 + "GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, "
							+ "b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by, b.conv_topic_val, b.alt_id order by b.rec_date desc";
			Query countquery = em.createNativeQuery(countQry);
			List<Object[]> rows = countquery.getResultList();

			if (rows.size() > 0) {

				for (Object[] row : rows) {

					ConversationDTO conversationDTO = new ConversationDTO();
					if(row[0] != null){
						conversationDTO.setRecId(row[0].toString());
						}
					if(row[1] != null){
						conversationDTO.setRecDate(row[1].toString());
						}
					if(row[2] != null){
						conversationDTO.setConvTopicType(row[2].toString());
						}
					if(row[3] != null){
						conversationDTO.setConvId(row[3].toString());
						}
					if(row[4] != null){
						conversationDTO.setConverUser(row[4].toString().toLowerCase());
						}
					if(row[5] != null){
						conversationDTO.setConvText(row[5].toString());
						}
					if(row[6] != null){
						conversationDTO.setCreatedBy(row[6].toString());
						}
					if(row[7] != null){
						conversationDTO.setConvTopicVal(row[7].toString());
						}
					if(row[8] != null){
						conversationDTO.setAltId(row[8].toString());
						}
					conversationList.add(conversationDTO);
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}
		resutMap.put("CONVERSATIONLIST_KEY", conversationList);
		if (conversationList != null && !conversationList.isEmpty()) {
			aAndCCount = new BigDecimal(conversationList.size());
			
		}else{
			aAndCCount = BigDecimal.ZERO;
		}
		resutMap.put("AC_COUNT_KEY", aAndCCount);
		return resutMap;
	}
	
	
	public String getLRDfromSysParmas(String userName) {
		
		 EntityManager em = getEntityManager();
		String myQry = "select m.msp_date1 from mpc_sys_params m "
				+ " where  m.msp_param_catg = 'ALERT' and m.msp_param_group = 'LAST_READ_DATE' "
				+ " and lower(m.msp_param_code) = lower('"+userName+"') and m.is_valid = 1";
		Query query = em.createNativeQuery(myQry);
		
		List list= query.getResultList();
		if(list!=null && !list.isEmpty()){
		return list.get(0).toString();
		}
		return null;
	}
	
	public String getTimeIntervalfromSysParmas() {
		EntityManager em = getEntityManager();

		String myQry = "select sysdate - (to_number(msp_val1)/1440) from   "
				+ " mpc_sys_params where  msp_param_catg = 'TIMEINTERVAL' and msp_param_group ="
				+ "  'RECENT_CONVER' and msp_param_code = 'MINUTES' and is_valid = 1 ";
		Query query = em.createNativeQuery(myQry);
		
		List list= query.getResultList();
		if(list!=null && !list.isEmpty()){
		return list.get(0).toString();
		}
		return null;
	}

	public List<ConversationSubDTO> findSubscribedUserListByConvId(String convId) {
		
		List<ConversationSubDTO> conversationSubList = new ArrayList<ConversationSubDTO>();
		
		try
		{
			/*select * from mpc_conv_subscr con where con.conv_id = '201737028'*/
			
			
			EntityManager em = getEntityManager();
			
			String myQry = "SELECT m FROM ConversationSub m "
					+ "where m.convId='"+convId+"' "
					+ "and m.isValid = 1";
			Query query = em.createQuery(myQry);
			List<ConversationSub> convSubsrList = query.getResultList();
			if(convSubsrList!=null && convSubsrList.size()>0){
				for(ConversationSub conversationSub : convSubsrList){
					ConversationSubDTO conversationSubDTO = new ConversationSubDTO();
					conversationSubDTO.setRecId(String.valueOf(conversationSub.getRecId()));
					if(conversationSub.getRecdate()!=null){
					conversationSubDTO.setRecDate(conversationSub.getRecdate().toString());
					}
					if(conversationSub.getAltId()!=null){
					conversationSubDTO.setAltId(conversationSub.getAltId().toString());
					}
					conversationSubDTO.setConvId(String.valueOf(conversationSub.getConvId()));
					conversationSubDTO.setUserCode(conversationSub.getUserCode().toLowerCase());
					conversationSubDTO.setRoleCode(conversationSub.getRoleCode());
					conversationSubDTO.setSubscrStatus(conversationSub.getSubscrStatus());
					conversationSubDTO.setIsValid(conversationSub.getIsValid().toString());
					conversationSubDTO.setSrcSys(conversationSub.getSrcSys());
					conversationSubDTO.setCreatedBy(conversationSub.getCreatedBy());
					if(conversationSub.getCreatedOn()!=null){
					conversationSubDTO.setCreatedOn(conversationSub.getCreatedOn().toString());
					}
					
					conversationSubList.add(conversationSubDTO);
				}
			}
			
		}
		catch(Exception er){
			er.printStackTrace();
		}
		
		return conversationSubList;
	}


public List<ConversationSubDTO> findSubscribedUserListByConvId(String convId,String convType) {
		
		List<ConversationSubDTO> conversationSubList = new ArrayList<ConversationSubDTO>();
		
		try
		{
			/*select * from mpc_conv_subscr con where con.conv_id = '201737028'*/
			
			
			EntityManager em = getEntityManager();
			
			String myQry =null;
			
			if(convType.equals(MPCConstants.CONV_TYPE_ALERT)){
				 myQry = "SELECT m FROM ConversationSub m "
							+ "where m.altId='"+convId+"' "
							+ "and m.subscrStatus=1 and  m.isValid = 1";
			}else{
				 myQry = "SELECT m FROM ConversationSub m "
						+ "where m.convId='"+convId+"' "
						+ "and m.subscrStatus=1 and m.isValid = 1";
			}
			
			Query query = em.createQuery(myQry);
			List<ConversationSub> convSubsrList = query.getResultList();
			if(convSubsrList!=null && convSubsrList.size()>0){
				for (ConversationSub conversationSub : convSubsrList) {
					ConversationSubDTO conversationSubDTO = new ConversationSubDTO();
					if(String.valueOf(conversationSub
							.getRecId()) !=null)
					conversationSubDTO.setRecId(String.valueOf(conversationSub
							.getRecId()));
					if (conversationSub.getRecdate() != null) {
						conversationSubDTO.setRecDate(conversationSub
								.getRecdate().toString());
					}
					if (conversationSub.getAltId() != null) {
						conversationSubDTO.setAltId(conversationSub.getAltId()
								.toString());
					}
					if (conversationSub.getConvId() != null) {
						conversationSubDTO.setConvId(String
								.valueOf(conversationSub.getConvId()));
					}
					if (conversationSub.getUserCode() != null) {
						conversationSubDTO.setUserCode(conversationSub
								.getUserCode().toLowerCase());
					}
					if (conversationSub.getRoleCode() != null) {
						conversationSubDTO.setRoleCode(conversationSub
								.getRoleCode());
					}
					if (conversationSub.getSubscrStatus() != null) {
						conversationSubDTO.setSubscrStatus(conversationSub
								.getSubscrStatus());
					}
					if (conversationSub.getIsValid() != null) {
						conversationSubDTO.setIsValid(conversationSub
								.getIsValid().toString());
					}
					if (conversationSub.getSrcSys() != null) {
						conversationSubDTO.setSrcSys(conversationSub
								.getSrcSys());
					}
					if (conversationSub.getCreatedBy() != null) {
						conversationSubDTO.setCreatedBy(conversationSub
								.getCreatedBy());
					}
					if (conversationSub.getCreatedOn() != null) {
						conversationSubDTO.setCreatedOn(conversationSub
								.getCreatedOn().toString());
					}

					conversationSubList.add(conversationSubDTO);
				}
			}
			
		}
		catch(Exception er){
			er.printStackTrace();
		}
		
		return conversationSubList;
	}


	
	
	public List<ConversationDTO> filterConversationsByCriteria(
			FilterConversationsDTO filterConversationsDTO) {
		
		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		//	List<ConversationDTO> conversationDTO2 = new ArrayList<ConversationDTO>();

			try {
				EntityManager em = getEntityManager();
				
				StringBuffer queryBuffer = new StringBuffer();
				queryBuffer.append("SELECT B.REC_ID, B.REC_DATE,"
						+ " b.conv_topic_type, MIN(B.CONV_ID) CONV_ID, B.CONV_USER, B.CONV_TEXT, "
						+ "b.created_by, b.conv_topic_val, b.alt_id FROM mpc_conv_subscr a, mpc_conversations b ");
				queryBuffer.append("WHERE (a.conv_id = b.conv_id or a.alt_id=b.alt_id) "
						+ "AND ((lower(a.user_code) = '"+filterConversationsDTO.getSessionName().toLowerCase()+"' and b.conv_type='C') "
						+ "or (a.role_code = '"+filterConversationsDTO.getRoleName()+"' and b.conv_type='A')) "
						+ "AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1 ");
				
				if(!filterConversationsDTO.getFilterTopic().equals("")){
					queryBuffer.append("AND b.Conv_Topic_Val = '"+filterConversationsDTO.getFilterTopic()+"' ");		
				}
				if(!filterConversationsDTO.getFilterUsers().equals("")){
				queryBuffer.append("AND b.CONV_USER = '"+filterConversationsDTO.getFilterUsers().toLowerCase()+"' ");
				}
				if(!filterConversationsDTO.getFilterSrcSystem().equals("")){
				queryBuffer.append("AND b.src_sys = '"+filterConversationsDTO.getFilterSrcSystem()+"' ");
				}
				if(!filterConversationsDTO.getFilterFromTime().equals("")){
				queryBuffer.append("AND b.rec_date >= to_date('"+filterConversationsDTO.getFilterFromTime()+"', 'dd/MM/yyyy hh24:mi:ss') ");
				}
                if(!filterConversationsDTO.getFilterToTime().equals("")){
                queryBuffer.append("AND b.rec_date <= to_date('"+filterConversationsDTO.getFilterToTime()+"', 'dd/MM/yyyy hh24:mi:ss') ");
				}
                if(filterConversationsDTO.getFilterConvTypeList().size()>0){
                    queryBuffer.append("AND b.conv_type in (:convType)  ");
    			}
                
                
                
				queryBuffer.append("AND 1440 * (sysdate-b.rec_date) <= "
						+ " ( select m.msp_val1 from mpc_sys_params m " 
								+ "where m.msp_param_catg = 'TIMEINTERVAL' "
								+ "and m.msp_param_group = 'CONVERSATION' "
								+ "and m.msp_param_code = 'MINUTES' "
								+ "and m.is_valid = 1 ) ");
				queryBuffer.append("GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, ");
				queryBuffer.append("b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by, b.conv_topic_val, b.alt_id order by b.rec_date desc");
				
				Query query = em.createNativeQuery(queryBuffer.toString());
				 if(filterConversationsDTO.getFilterConvTypeList().size()>0){
					 query.setParameter("convType", filterConversationsDTO.getFilterConvTypeList());
	    		}
				
				 
				List<Object[]> rows = query.getResultList();
				for (Object[] row : rows) {
						ConversationDTO conversationDTO = new ConversationDTO();
						if(row[0] != null){
							conversationDTO.setRecId(row[0].toString());
							}
						if(row[1] != null){
							conversationDTO.setRecDate(row[1].toString());
							}
						if(row[2] != null){
							conversationDTO.setConvTopicType(row[2].toString());
							}
						if(row[3] != null){
							conversationDTO.setConvId(row[3].toString());
							}
						if(row[4] != null){
							conversationDTO.setConverUser(row[4].toString().toLowerCase());
							}
						if(row[5] != null){
							conversationDTO.setConvText(row[5].toString());
							}
						if(row[6] != null){
							conversationDTO.setCreatedBy(row[6].toString());
							}
						if(row[7] != null){
							conversationDTO.setConvTopicVal(row[7].toString());
							}
						if(row[8] != null){
							conversationDTO.setAltId(row[8].toString());
							}
						conversationList.add(conversationDTO);
					}
					
				
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			 
		return conversationList;
	}


	public List<ConversationDTO> getAlertsForVesselListByUserCode(
			String userCode, String roleName) {
		
		
		/*select a.*, c.conv_text, c.rec_id
		from mpc_conversations c,
		( SELECT 
		       MIN(B.REC_DATE) rec_date,
		       b.conv_topic_type,
		       B.CONV_ID,
		       b.conv_topic_val
		  FROM mpc_conv_subscr a, mpc_conversations b
		 WHERE a.conv_id = b.conv_id
		   AND a.user_code = 'Vinculum.Ashok'
		   AND SUBSCR_STATUS = 1
		   AND a.is_valid = 1
		   AND b.is_valid = 1
		 GROUP BY 
		          b.conv_topic_type,
		          b.conv_id,
		          b.conv_topic_val) a
		where c.rec_date = a.rec_date 
		  and c.conv_id = a.conv_id
		  and c.conv_topic_val = a.conv_topic_val
		  and 1440 * (sysdate-c.rec_date) <= 
		  ( select m.msp_val1 from mpc_sys_params m 
		   where m.msp_param_catg = 'TIMEINTERVAL' 
		  and m.msp_param_group = 'CONVERSATION' 
		  and m.msp_param_code = 'MINUTES' 
		  and m.is_valid = 1 
		  ) 
		 order by c.rec_date desc;*/
		
		
		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		try {

			EntityManager em = getEntityManager();
		
			userCode=userCode.toLowerCase();
			String myQry = "select a.*, c.conv_text, c.conv_user, c.rec_id "+
							"from mpc_conversations c, "+
							"( SELECT "+
							       "MIN(B.REC_DATE) rec_date, MAX(B.REC_DATE) max_date ,"+
							       "b.conv_topic_type, "+
							       "B.CONV_ID, b.conv_topic_val, b.alt_id "+
							  "FROM mpc_conv_subscr a, mpc_conversations b "+
							 "WHERE (a.conv_id = b.conv_id or a.alt_id=b.alt_id) "+
							   "AND ((lower(a.user_code) = '"+userCode+"' and b.conv_type='C') "
							   		+ "or "
							   		+ "(a.role_code = '"+roleName+"' and b.conv_type='A')) "+
							   "AND SUBSCR_STATUS = 1 "+
							   "AND a.is_valid = 1 "+
							   "AND b.is_valid = 1 "+
							 "GROUP BY "+
							          "b.conv_topic_type, "+
							          "b.conv_id, "+
							          "b.conv_topic_val, b.alt_id) a "+
							"where c.rec_date = a.rec_date "+ 
							  "and (c.conv_id = a.conv_id or c.alt_id = a.alt_id) "+
							  "and c.conv_topic_val = a.conv_topic_val "+
							  "and 1440 * (sysdate-a.max_date) <= "+ 
							  "( select m.msp_val1 from mpc_sys_params m "+ 
							   "where m.msp_param_catg = 'TIMEINTERVAL' "+ 
							  "and m.msp_param_group = 'RECENT_CONVER' "+ 
							  "and m.msp_param_code = 'MINUTES' "+ 
							  "and m.is_valid = 1 "+ 
							  ") "+ 
							 "order by c.rec_date desc";
			
			
			Query query = em.createNativeQuery(myQry);

			@SuppressWarnings("unchecked")
			List<Object[]> rows = query.getResultList();

			if (rows.size() > 0) {

				for (Object[] row : rows) {

					ConversationDTO conversationDTO = new ConversationDTO();
					
					if(row[0] != null){
						conversationDTO.setRecDate(row[0].toString());
						}
					if(row[1] != null){
						conversationDTO.setConvTopicType(row[1].toString());
						}
					if(row[2] != null){
						conversationDTO.setConvTopicType(row[2].toString());
						}
					if(row[3] != null){
						conversationDTO.setConvId(row[3].toString());
						}
					if(row[4] != null){
						conversationDTO.setConvTopicVal(row[4].toString());
						}
					if(row[5] != null){
						conversationDTO.setConvText(row[5].toString());
						}
					if(row[6] != null){
						conversationDTO.setConverUser(row[6].toString().toLowerCase());
						}
					
					if(row[7] != null){
						conversationDTO.setRecId(row[7].toString());
						}

					if(row[8] != null){
						conversationDTO.setAltId(row[8].toString());
						}
					
					conversationList.add(conversationDTO);
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}
		
		return conversationList;
	}


	public List<ConversationDTO> getAlertsForVesselListByTopic(
			String topicValue, String userCode, String roleCode) {
		List<ConversationDTO> conversationList = new ArrayList<ConversationDTO>();
		try {

			EntityManager em = getEntityManager();
		
			
			/*String myQry = "select a.*, c.conv_text, c.conv_user, c.rec_id "+
							"from mpc_conversations c, "+
							"( SELECT "+
							       "MIN(B.REC_DATE) rec_date, MAX(B.REC_DATE) max_date ,"+
							       "b.conv_topic_type, "+
							       "B.CONV_ID, b.conv_topic_val,min(B.alt_ID) alt_ID  "+
							  "FROM mpc_conv_subscr a, mpc_conversations b "+
							 "WHERE ( a.conv_id = b.conv_id or a.alt_id=b.alt_id) "+
							   "AND ((a.user_code = '"+userCode+"' and b.conv_type='C') "
							   		+ "or "
							   		+ "(a.role_code = '"+roleCode+"' and b.conv_type='A')) "+
							   "AND b.conv_topic_val = '"+topicValue+"' "+
							   "AND SUBSCR_STATUS = 1 "+
							   "AND a.is_valid = 1 "+
							   "AND b.is_valid = 1 "+
							 "GROUP BY "+
							          "b.conv_topic_type, "+
							          "b.conv_id, "+
							          "b.conv_topic_val, b.alt_id) a "+
							"where c.rec_date = a.rec_date "+ 
							  "and (c.conv_id = a.conv_id or c.alt_id=a.alt_id) "+
							  "and c.conv_topic_val = a.conv_topic_val "+
							  "and 1440 * (sysdate-a.max_date) <= "+ 
							  "( select m.msp_val1 from mpc_sys_params m "+ 
							   "where m.msp_param_catg = 'TIMEINTERVAL' "+ 
							  "and m.msp_param_group = 'RECENT_CONVER' "+ 
							  "and m.msp_param_code = 'MINUTES' "+ 
							  "and m.is_valid = 1 "+ 
							  ") "+ 
							 "order by c.rec_date desc";
*/	
			userCode=userCode.toLowerCase();
			String myQry = "SELECT * FROM ( "+
"SELECT B.REC_DATE, "+
            "MAX(B.REC_DATE), "+
            "b.conv_topic_type, "+ 
            "MIN(b.conv_id) CONV_ID, "+ 
            "b.conv_topic_val, "+
            "b.alt_id, "+
            "B.CONV_TEXT, "+ 
            "B.CONV_USER, "+
            "B.REC_ID FROM mpc_conv_subscr a, mpc_conversations b "+
            "WHERE a.alt_id = b.alt_id AND a.role_code = '"+roleCode+"' "+
            "AND SUBSCR_STATUS = 1 AND a.is_valid = 1 AND b.is_valid = 1 "+
            "AND b.conv_topic_val = '"+topicValue+"' "+
            "AND 1440 * (sysdate-b.rec_date) <= "+ 
            "( select m.msp_val1 from mpc_sys_params m  "+ 
                 "where m.msp_param_catg = 'TIMEINTERVAL' "+  
                "and m.msp_param_group = 'RECENT_CONVER' "+ 
                "and m.msp_param_code = 'MINUTES' "+  
                "and m.is_valid = 1) "+ 
            "and b.conv_type='A' "+
            "GROUP BY B.REC_ID, B.REC_DATE, b.conv_topic_type, "+
            "b.conv_id, B.CONV_USER, B.CONV_TEXT, b.created_by, "+
            "b.conv_topic_val, b.alt_id "+
            "union "+
            "select a.*, c.alt_id, c.conv_text, c.conv_user, c.rec_id "+
              "from mpc_conversations c, "+  
              "( SELECT "+ 
                     "MIN(B.REC_DATE) rec_date, MAX(B.REC_DATE) max_date , "+
							       "b.conv_topic_type, "+
							       "B.CONV_ID, b.conv_topic_val "+
							  "FROM mpc_conv_subscr a, mpc_conversations b "+ 
							 "WHERE (a.conv_id = b.conv_id) "+
							   "AND (lower(a.user_code) = '"+userCode+"' and b.conv_type='C') "+  
							   "AND b.conv_topic_val = '"+topicValue+"' "+ 
							   "AND SUBSCR_STATUS = 1 "+ 
							   "AND a.is_valid = 1 "+ 
							   "AND b.is_valid = 1 "+
							 "GROUP BY "+
							          "b.conv_topic_type, "+
							          "b.conv_id, "+
							          "b.conv_topic_val) a "+
							"where c.rec_date = a.rec_date "+  
							  "and (c.conv_id = a.conv_id) "+ 
							  "and c.conv_topic_val = a.conv_topic_val "+ 
							  "and 1440 * (sysdate-a.max_date) <= "+  
							  "( select m.msp_val1 from mpc_sys_params m "+ 
							   "where m.msp_param_catg = 'TIMEINTERVAL' "+  
							  "and m.msp_param_group = 'RECENT_CONVER' "+  
							  "and m.msp_param_code = 'MINUTES' "+  
							  "and m.is_valid = 1 "+  
							  ") "+  
							 ") all_rec "+ 
                     "order by 2 desc";
			
			Query query = em.createNativeQuery(myQry);

			@SuppressWarnings("unchecked")
			List<Object[]> rows = query.getResultList();

			if (rows.size() > 0) {

				for (Object[] row : rows) {

					ConversationDTO conversationDTO = new ConversationDTO();
					
					if(row[0] != null){
						conversationDTO.setRecDate(row[1].toString());
						}
					if(row[2] != null){
						conversationDTO.setConvTopicType(row[2].toString());
						}
					if(row[3] != null){
						conversationDTO.setConvId(row[3].toString());
						}
					if(row[4] != null){
						conversationDTO.setConvTopicVal(row[4].toString());
						}
					if(row[5] != null){
						conversationDTO.setAltId(row[5].toString());
						}
					if(row[6] != null){
						conversationDTO.setConvText(row[6].toString());
						}
					if(row[7] != null){
						conversationDTO.setConverUser(row[7].toString().toLowerCase());
						}
					
					if(row[8] != null){
						conversationDTO.setRecId(row[8].toString());
						}

					conversationList.add(conversationDTO);
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}
		
		return conversationList;
	}
	
	@Transactional
	public String addNewUsers(ConversationSubDTO conversationSubDTO) {
		
		
		Date date = null;
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
	
			if(conversationSubDTO.getUserlist().size()>0){
				for(String userName : conversationSubDTO.getUserlist()){
					
					Query queryResult3 = em
							.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
					long subrecid = ((BigDecimal) queryResult3.getSingleResult()).longValue();
					long sub_rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
								+ String.valueOf(subrecid));
					
					Query queryResult2 = em
							.createNativeQuery("SELECT seq_mcnv_convid.nextval FROM DUAL");
					long convid = ((BigDecimal) queryResult2.getSingleResult()).longValue();
					
					long conv_id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
								+ String.valueOf(convid));
						
				
					ConversationSub conversationSub = new ConversationSub();
					conversationSub.setRecId(sub_rec_Id);
					conversationSub.setRecdate(date);
					conversationSub.setConvId(conv_id);
					//conversationSub.setConvId(Long.parseLong(conversationSubDTO.getConvId()));
					conversationSub.setUserCode(userName.toLowerCase());
					conversationSub.setRoleCode("");
					conversationSub.setSubscrStatus("1");
					conversationSub.setIsValid(1);
					conversationSub.setSrcSys(conversationSubDTO.getSrcSys());
					conversationSub.setCreatedBy(conversationSubDTO.getCreatedBy());
					conversationSub.setCreatedOn(date);
					//conversationSub.setModifiedOn(date);
					//conversationSub.setModifiedBy(userName);
					
					em.persist(conversationSub);
				}
			}
			

			} catch (Exception er) {
			er.printStackTrace();
			}
		
		return "success";
	}


	@Override
	public List<SubscribedUserDTO> findSubscribedData(String userName) {
		List<SubscribedUserDTO> subscribedUserDTO  = new ArrayList<SubscribedUserDTO>();

			try {
				
				EntityManager em = getEntityManager();

				Query query = em .createNativeQuery(" select mc.conv_id, mc.conv_topic_type, mc.conv_topic_val, mc.conv_subtopic_type, mc.conv_subtopic_val,"
						+ " mc.alt_id,ma.alt_code, min(mc.created_on) created_on ,count(mcs.user_code) user_subscribed"
						+ " from mpc_conversations mc inner join mpc_alert_master ma on mc.alt_id=ma.alt_id"
						+ " left join mpc_conv_subscr  mcs on mc.conv_id = mcs.conv_id and mcs.subscr_status =1 and mcs.is_valid=1 "
						+ " where 1440 * (sysdate-mc.rec_date) <= "
						+ " ( select m.msp_val1 from mpc_sys_params m"
						+ " where m.msp_param_catg = 'TIMEINTERVAL'"
						+ " and m.msp_param_group = 'TRENDING'"
						+ " and m.msp_param_code = 'MINUTES'"
						+ " and m.is_valid = 1 "
						+ " ) "
						+ " and mc.is_valid=1 and mc.alt_id is not null"
						+ " group by  mc.conv_id, mc.conv_topic_type,"
						+ " mc.conv_topic_val, mc.conv_subtopic_type,mc.conv_subtopic_val,mc.alt_id,ma.alt_code order by  created_on desc");


				@SuppressWarnings("unchecked")
				List<Object[]> rows = query.getResultList();
				
				if (rows.size() > 0) {

					for (Object[] row : rows) {
						SubscribedUserDTO subscribedUserDTO2 = new SubscribedUserDTO();
						if(row[0] != null){
							subscribedUserDTO2.setConvId(row[0].toString());
						}
						if(row[1] != null){
							subscribedUserDTO2.setConvSubTopicType(row[1].toString());
						}
						if(row[2] != null){
							subscribedUserDTO2.setConvTopicVal(row[2].toString());
						}
						if(row[3] != null){
							subscribedUserDTO2.setConvSubTopicType(row[3].toString());
						}
						if(row[4] != null){
							subscribedUserDTO2.setConvSubTopicVal(row[4].toString());
						}
						if(row[5] != null){
							subscribedUserDTO2.setAltId(row[5].toString());
						}
						if(row[6] != null){
							subscribedUserDTO2.setAltCode(row[6].toString());
						}
						if(row[7] != null){
							subscribedUserDTO2.setCreatedOn(row[7].toString());
						}
						if(row[8] != null){
							subscribedUserDTO2.setUserSubscribed(row[8].toString().toLowerCase());
						}
						
						subscribedUserDTO.add(subscribedUserDTO2);
					}
				}
				
			}catch (Exception e) {
				e.printStackTrace();
				
			}
		return subscribedUserDTO;
	}
			
}
