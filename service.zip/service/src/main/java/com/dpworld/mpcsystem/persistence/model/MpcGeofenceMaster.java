package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_geofence_master")
@NamedQuery(name = "MpcGeofenceMaster.findAll", query = "SELECT m FROM MpcGeofenceMaster m ORDER BY m.mgmRecId DESC")
public class MpcGeofenceMaster {

	@Id
	@Column(name = "MGM_REC_ID")
	private long mgmRecId;

	@Temporal(TemporalType.DATE)
	@Column(name = "MGM_REC_DATE")
	private Date mgmRecDate;

	@Column(name = "TERMINAL_ID")
	private Integer terminalId;

	@Column(name = "MGM_GF_CODE")
	private String mgmGFCode;

	@Column(name = "MGM_GF_LAT")
	private Float mgmGFLat;

	@Column(name = "MGM_GF_LONG")
	private Float mgmGFLong;

	@Column(name = "MGM_GF_SEQNO")
	private Integer mgmGFSeqNo;

	@Column(name = "IS_VALID")
	private Integer isValid;

	@Column(name = "SRC_SYS")
	private String srcSys;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_DATE")
	private Date careatedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	public long getMgmRecId() {
		return mgmRecId;
	}

	public void setMgmRecId(long mgmRecId) {
		this.mgmRecId = mgmRecId;
	}

	public Date getMgmRecDate() {
		return mgmRecDate;
	}

	public void setMgmRecDate(Date mgmRecDate) {
		this.mgmRecDate = mgmRecDate;
	}

	public Integer getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(Integer terminalId) {
		this.terminalId = terminalId;
	}

	public String getMgmGFCode() {
		return mgmGFCode;
	}

	public void setMgmGFCode(String mgmGFCode) {
		this.mgmGFCode = mgmGFCode;
	}

	public Float getMgmGFLat() {
		return mgmGFLat;
	}

	public void setMgmGFLat(Float mgmGFLat) {
		this.mgmGFLat = mgmGFLat;
	}

	public Float getMgmGFLong() {
		return mgmGFLong;
	}

	public void setMgmGFLong(Float mgmGFLong) {
		this.mgmGFLong = mgmGFLong;
	}

	public Integer getMgmGFSeqNo() {
		return mgmGFSeqNo;
	}

	public void setMgmGFSeqNo(Integer mgmGFSeqNo) {
		this.mgmGFSeqNo = mgmGFSeqNo;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCareatedDate() {
		return careatedDate;
	}

	public void setCareatedDate(Date careatedDate) {
		this.careatedDate = careatedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
