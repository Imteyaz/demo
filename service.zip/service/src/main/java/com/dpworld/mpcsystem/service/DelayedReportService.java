package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailReportDTO;

public interface DelayedReportService {

	List<VesselDetailReportDTO> getRotationList();
	List<VesselDetailReportDTO> getCompRotationList();
	
}
