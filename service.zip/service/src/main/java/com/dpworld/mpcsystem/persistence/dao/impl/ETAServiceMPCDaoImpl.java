/**
 * 
 */
package com.dpworld.mpcsystem.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.persistence.dao.ETAServiceMPCDao;
import com.dpworld.mpcsystem.persistence.model.MpcVslLocs;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Repository("etaServiceMPCDao")
public class ETAServiceMPCDaoImpl extends PersistenceUnitDaoImpl<MpcVslLocs, Long> implements ETAServiceMPCDao {
	
	public ETAServiceMPCDaoImpl() {
		super(MpcVslLocs.class);
	}
	
	public ETAServiceMPCDaoImpl(Class<MpcVslLocs> persistentClass) {
		super(persistentClass);
	}


	public List<VesselDetailsDTO> getVesseldetails() {

		EntityManager em = getEntityManager();
		List<VesselDetailsDTO> etaReportList = new ArrayList<VesselDetailsDTO>();
		try {
			String stringQuery = "select a.vess_name,(select max(b.vsl_eta) from mpc_vsl_locs "
					+ " b where a.vess_name = b.vess_name and b.src_sys = 'VTS') VTS_ETA, (select max(c.vsl_eta) "
					+ " from mpc_vsl_locs c where a.vess_name = c.vess_name and c.src_sys = 'AIS') AIS_ETA from   "
					+ " mpc_vsl_locs a where  a.txn_id = (select max(d.txn_id) from mpc_vsl_locs d where a.vess_name = "
					+ " d.vess_name ) ";
			Query query = em.createNativeQuery(stringQuery);
			List<Object[]> rows = query.getResultList();
			for (Object[] row : rows) {

				VesselDetailsDTO etaReport = new VesselDetailsDTO();
				if(row[0] != null){
					etaReport.setVesselName(row[0].toString());
					}
				if(row[1] != null){
					etaReport.setVtsEta(row[1].toString());
					}
				if(row[2] != null){
					etaReport.setAisEta(row[2].toString());
					}
				etaReportList.add(etaReport);
			}
		}catch(Exception ex) {
			
		}
		return etaReportList;
	
	}

}
