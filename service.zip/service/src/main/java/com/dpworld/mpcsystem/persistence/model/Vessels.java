/**
 * 
 */
package com.dpworld.mpcsystem.persistence.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Entity
@Table(name="vessels")
public class Vessels implements Serializable {
	private static final long serialVersionUID = -9128479114906742445L;
	@Id
	@Column(name = "VESS_NAME")
	String vesselName;
	@Column(name = "vess_type")
	
	String vesselTypes;
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	public String getVesselTypes() {
		return vesselTypes;
	}
	public void setVesselTypes(String vesselTypes) {
		this.vesselTypes = vesselTypes;
	}

}
