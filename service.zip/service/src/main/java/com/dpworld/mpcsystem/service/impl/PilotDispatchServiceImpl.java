package com.dpworld.mpcsystem.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.PilotVesselDataDTO;
import com.dpworld.mpcsystem.persistence.dao.PilotDispatchDao;
import com.dpworld.mpcsystem.persistence.model.MpcVesselData;
import com.dpworld.mpcsystem.service.PilotDispatchService;

@Service("pilotDispatchService")
public class PilotDispatchServiceImpl implements PilotDispatchService {

	@Autowired
	private PilotDispatchDao pilotDispatchDao;

	public void saveMpcVesselDetails(PilotVesselDataDTO vesselData) {

		pilotDispatchDao.saveMpcVesselDetails(vesselData);
	}
	
	public void saveMpcUserOrder(PilotVesselDataDTO vesselData) {

		pilotDispatchDao.saveMpcUserOrder(vesselData);
	}
	

	public List<MpcVesselData> getMpcVesselDataByVessel(String vesselName,
			String rotation) {

		return pilotDispatchDao.getMpcVesselDataByVessel(vesselName, rotation);
	}

	public List<MpcVesselData> getMpcVesselDataByVessel(String vesselName,
			String rotation,String status) {

		return pilotDispatchDao.getMpcVesselDataByVessel(vesselName, rotation,status);
	}
	
	public List<MpcVesselData> getMpcUserOrder(String mvdgroup,
			String rotation) {

		return pilotDispatchDao.getMpcUserOrder(mvdgroup, rotation);
	}

	public Date getPilotDispatchTime(PilotVesselDataDTO vesselData) {
		return pilotDispatchDao.getPilotDispatchTime(vesselData);
	}
	
	public List<PilotVesselDataDTO> getPilotDispatchTimeData(PilotVesselDataDTO vesselData)
	{
		return pilotDispatchDao.getPilotDispatchTimeData(vesselData);
	}

}
