/**
 * 
 */
//package com.dpworld.tos.admin.model;
package com.dpworld.mpcsystem.admin.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author sapcle.Mohammed
 *
 */
public class Menu implements Serializable {

  private static final long serialVersionUID = -6872549240817084220L;

  private Integer menuSeq;
  private String menupath;
  private String menuName;
  private String parentMenuname;
  private String roleName;
  private String menuLevel;

  public String getMenuLevel() {
	return menuLevel;
}

public void setMenuLevel(String menuLevel) {
	this.menuLevel = menuLevel;
}

private List<Menu> menus = new ArrayList<>();

  public List<Menu> getMenus() {
    return menus;
  }

  public void setMenus(List<Menu> menus) {
    this.menus = menus;
  }

  public Integer getMenuSeq() {
    return menuSeq;
  }

  public void setMenuSeq(Integer menuSeq) {
    this.menuSeq = menuSeq;
  }

  public String getMenupath() {
    return menupath;
  }

  public void setMenupath(String menupath) {
    this.menupath = menupath;
  }

  public String getMenuName() {
    return menuName;
  }

  public void setMenuName(String menuName) {
    this.menuName = menuName;
  }

  public String getParentMenuname() {
    return parentMenuname;
  }

  public void setParentMenuname(String parentMenuname) {
    this.parentMenuname = parentMenuname;
  }

  public String getRoleName() {
    return roleName;
  }

  public void setRoleName(String roleName) {
    this.roleName = roleName;
  }
}
