package com.dpworld.mpcsystem.persistence.search;

public interface SearchCommunicator<T> {
	T getCommunicatorModule();
}
