package com.dpworld.mpcsystem.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dpworld.mpcsystem.annotation.Loggable;

/**
 * ChannelsAspect contains all aspects related.
 * 
 * 
 */
@Aspect
public class ChannelsAspect {

	private final static Logger LOGGER = LoggerFactory.getLogger(ChannelsAspect.class);

	/**
	 * CalculateExecutionTime which calculates execution time for a method
	 * 
	 * @param proceedingJoinPoint
	 *            the ProceedingJoinPoint to execute a method
	 * @throws Throwable
	 */
	@Around("@annotation(.annotation.Profileable)")
	public Object calculateExecutionTime(ProceedingJoinPoint proceedingJoinPoint)
			throws Throwable {
		LOGGER.info("Executing method ...");
		long startTime = System.currentTimeMillis();
		Object value = proceedingJoinPoint.proceed();
		long elapsedTime = System.currentTimeMillis() - startTime;
		LOGGER.info("Method Execution time : " + elapsedTime);
		return value;
	}

	/**
	 * Loggable which logs entry & exit message
	 * 
	 * @param proceedingJoinPoint
	 *            the ProceedingJoinPoint to execute a method
	 * @throws Throwable
	 */
	@Around("@annotation(loggable)")
	public Object loggable(ProceedingJoinPoint proceedingJoinPoint,
			Loggable loggable) throws Throwable {
		LOGGER.info("Enters into " + loggable.method() + " !!!");
		Object value = proceedingJoinPoint.proceed();
		LOGGER.info("Exit from " + loggable.method() + " !!!");
		return value;
	}

}
