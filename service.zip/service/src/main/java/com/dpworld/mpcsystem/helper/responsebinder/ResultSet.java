package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.List;

/**
 * Interface class for defining the ResultSet methods
 */
public interface ResultSet {

	String getName();

	void setName(String name);

	List<DataRow> getRows();

	DataRow createNewRow();

	DataRow copyRow(DataRow row, int index);

	DataRow createNewRow(String[] names);

}