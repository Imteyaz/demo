package com.dpworld.mpcsystem.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.persistence.dao.ManeuversDao;
import com.dpworld.mpcsystem.persistence.model.MpcGeoFenceData;

@Repository("maneuversDao")
public class ManeuversDaoImpl extends
PersistenceUnitDaoImpl<MpcGeoFenceData, Long> implements ManeuversDao{
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ManeuversDaoImpl.class);
	public ManeuversDaoImpl() {
		super(MpcGeoFenceData.class);
	}
	
	public ManeuversDaoImpl(Class<MpcGeoFenceData> persistentClass) {
		super(persistentClass);
		
	}
	
	public List<GeoFenceViewDTO> getGeoFenceVesselList(String mgdObjName) {

		List<GeoFenceViewDTO> geoFenceViewDTOs = new ArrayList<GeoFenceViewDTO>();

		try {
			EntityManager em = getEntityManager();

			String geofenceNameQuery = "select mgm_gf_code, max(mgd_obj_entry) ent, max(mgd_obj_exit) from mpc_geofence_data "
					+ "where  mgd_obj_name = '"
					+ mgdObjName.trim()
					+ "' and is_valid = 1 group by mgm_gf_code order by ent asc";
			
			Query query = em.createNativeQuery(geofenceNameQuery);

			@SuppressWarnings("unchecked")
			List<Object[]> rows = query.getResultList();

			if (rows.size() > 0) {

				for (Object[] row : rows) {
					GeoFenceViewDTO geoFenceViewDTO = new GeoFenceViewDTO();
					if (row[0] != null) {
						geoFenceViewDTO.setMgmGfCode(row[0].toString());
					}
					if (row[1] != null) {
						geoFenceViewDTO.setMgdObjEntry(row[1].toString());
					}
					if (row[2] != null) {
						geoFenceViewDTO.setMgdObjExit(row[2].toString());
					}
					geoFenceViewDTOs.add(geoFenceViewDTO);
				}

			}

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
		return geoFenceViewDTOs;
	}

}
