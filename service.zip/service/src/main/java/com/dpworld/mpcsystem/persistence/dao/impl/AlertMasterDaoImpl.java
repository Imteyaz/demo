package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.AlertMasterDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;
import com.dpworld.mpcsystem.common.utility.pojo.UserRoleInfoDTO;
import com.dpworld.mpcsystem.persistence.dao.AlertMasterDao;
import com.dpworld.mpcsystem.persistence.model.ConversationSub;
import com.dpworld.mpcsystem.persistence.model.MpcAlertMaster;

@Repository("alertMasterDao")
public class AlertMasterDaoImpl  extends
PersistenceUnitDaoImpl<MpcAlertMaster, Long> implements AlertMasterDao{
	
	public AlertMasterDaoImpl() {
		super(MpcAlertMaster.class);
	}

	public AlertMasterDaoImpl(Class<MpcAlertMaster> persistentClass) {
		super(persistentClass);
	}
	
	
	public List<AlertMasterDTO> getAlertMasterList() {
		
		List<AlertMasterDTO> alertMasterList = new ArrayList<AlertMasterDTO>();
		
		try {
		EntityManager em = getEntityManager();
		TypedQuery<MpcAlertMaster> query = em.createNamedQuery("MpcAlertMaster.findAll", MpcAlertMaster.class);
		
		List<MpcAlertMaster> results = query.getResultList();
		if (results != null && !results.isEmpty()) {
			for (MpcAlertMaster mpcAlertMaster : results) {
				
				AlertMasterDTO alertMasterDTO = new AlertMasterDTO();
				alertMasterDTO.setAltId(Long.toString(mpcAlertMaster.getAltId()));
				alertMasterDTO.setAltCode(mpcAlertMaster.getAltCode());
				alertMasterDTO.setAltText(mpcAlertMaster.getAltText());
				alertMasterDTO.setAltSeverity(mpcAlertMaster.getAltSeverity());
				alertMasterDTO.setAltValidity(String.valueOf(mpcAlertMaster.getAltValidity()));
				alertMasterDTO.setAltType(mpcAlertMaster.getAltType());
				alertMasterDTO.setAltGroup(mpcAlertMaster.getAltGroup());
				
				alertMasterDTO.setAltCatg(mpcAlertMaster.getAltCatg());
				
				if (mpcAlertMaster.getIsValid() == 1) {
					alertMasterDTO.setIsValid(MPCConstants.YES);
				} else if (mpcAlertMaster.getIsValid() == 0) {
					alertMasterDTO.setIsValid(MPCConstants.NO);
				}
				alertMasterDTO.setSrcSys(MPCConstants.SOURCE_SYS);
				alertMasterDTO
				.setCreatedBy(mpcAlertMaster.getCreatedBy());
				if (mpcAlertMaster.getCreatedOn() != null) {
					alertMasterDTO.setCreatedOn(mpcAlertMaster
							.getCreatedOn().toString());
				}
				if (mpcAlertMaster.getModifiedBy() != null) {
					alertMasterDTO.setModifiedBy(mpcAlertMaster
							.getModifiedBy());
				}
				if (mpcAlertMaster.getModifiedOn() != null) {
					alertMasterDTO.setModifiedOn(mpcAlertMaster
							.getModifiedOn().toString());
				}
			
				alertMasterList.add(alertMasterDTO);

			}
		}
		}catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
		return alertMasterList;
	}
	
	@Transactional
	public void saveOrUpdateAlertMaster(AlertMasterDTO alertMasterDTO) {

		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();

		MpcAlertMaster mpcAlertMaster = new MpcAlertMaster();

		// If SAVE
		if (MPCConstants.EMPTY_STRING.equals(alertMasterDTO.getAltId())) {

			Query queryResult = em
					.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");
			long id = ((BigDecimal) queryResult.getSingleResult()).longValue();

			try {
				long altId = Long.parseLong(MPCUtil.getCurrentYear(date)
						+ String.valueOf(id));
				mpcAlertMaster.setAltId(altId);
			} catch (Exception er) {
				LOGGER.error(er.getMessage());
			}
			mpcAlertMaster.setAltCode(alertMasterDTO.getAltCode());
			mpcAlertMaster.setAltText(alertMasterDTO.getAltText());
			mpcAlertMaster.setAltSeverity(alertMasterDTO.getAltSeverity());
			if (!MPCConstants.EMPTY_STRING.equals(alertMasterDTO.getAltValidity())) {
			mpcAlertMaster.setAltValidity(Integer.parseInt(alertMasterDTO.getAltValidity()));
			}
			mpcAlertMaster.setAltType(alertMasterDTO.getAltType());
			mpcAlertMaster.setAltGroup(alertMasterDTO.getAltGroup());
			mpcAlertMaster.setAltCatg(alertMasterDTO.getAltCatg());
			if (alertMasterDTO.getIsValid().equals(MPCConstants.YES)) {
				mpcAlertMaster.setIsValid(1);
			} else if (alertMasterDTO.getIsValid().equals(MPCConstants.NO)) {
				mpcAlertMaster.setIsValid(0);
			}
			mpcAlertMaster.setSrcSys(MPCConstants.SOURCE_SYS);
			
			mpcAlertMaster.setCreatedOn(date);
			mpcAlertMaster.setCreatedBy(alertMasterDTO.getCreatedBy());

			em.persist(mpcAlertMaster);

		} // IF UPDATE
		else {
			String altId = alertMasterDTO.getAltId();
			long newAltId = Long.parseLong(altId.trim());
			// Get Data By ID
			MpcAlertMaster upMpcAlertMaster = new MpcAlertMaster();
			upMpcAlertMaster = em.find(MpcAlertMaster.class, newAltId);

			// Set Values in DTO
			upMpcAlertMaster.setAltCode(alertMasterDTO.getAltCode());
			upMpcAlertMaster.setAltText(alertMasterDTO.getAltText());
			upMpcAlertMaster.setAltSeverity(alertMasterDTO.getAltSeverity());
			if(!MPCConstants.EMPTY_STRING.equals(alertMasterDTO.getAltValidity())) {
			upMpcAlertMaster.setAltValidity(Integer.parseInt(alertMasterDTO.getAltValidity()));
			}
			upMpcAlertMaster.setAltType(alertMasterDTO.getAltType());	
			upMpcAlertMaster.setAltGroup(alertMasterDTO.getAltGroup());
			upMpcAlertMaster.setAltCatg(alertMasterDTO.getAltCatg());
			
			if (alertMasterDTO.getIsValid().equals(MPCConstants.YES)) {
				upMpcAlertMaster.setIsValid(1);
			} else if (alertMasterDTO.getIsValid().equals(MPCConstants.NO)) {
				upMpcAlertMaster.setIsValid(0);
			}
			upMpcAlertMaster.setSrcSys(MPCConstants.SOURCE_SYS);
			upMpcAlertMaster.setModifiedBy(alertMasterDTO.getModifiedBy());
			upMpcAlertMaster.setModifiedOn(date);

			em.persist(upMpcAlertMaster);

		}

	}

	public AlertMasterDTO getAlertMasterDTOById(String altId) {
		
		MpcAlertMaster mpcAlertMaster = new MpcAlertMaster();
		AlertMasterDTO alertMasterDTO = new AlertMasterDTO();
		
		try
		{
			EntityManager em = getEntityManager();	
     		
     			long altIdVal = Long.parseLong(altId);
     			mpcAlertMaster = em.find(MpcAlertMaster.class, altIdVal);
     		    
     			if(mpcAlertMaster!=null){
     				
     				alertMasterDTO.setAltId(String.valueOf(mpcAlertMaster.getAltId()));
     				alertMasterDTO.setAltCode(mpcAlertMaster.getAltCode());
     				alertMasterDTO.setAltText(mpcAlertMaster.getAltText());
     				alertMasterDTO.setAltSeverity(mpcAlertMaster.getAltSeverity());
     				alertMasterDTO.setAltValidity(mpcAlertMaster.getAltValidity().toString());
     				alertMasterDTO.setIsValid(mpcAlertMaster.getIsValid().toString());
     				alertMasterDTO.setSrcSys(mpcAlertMaster.getSrcSys());
     				alertMasterDTO.setCreatedOn(mpcAlertMaster.getCreatedOn().toString());
     				alertMasterDTO.setCreatedBy(mpcAlertMaster.getCreatedBy());
     			}
			
			
			
		}
		catch(Exception er){
			LOGGER.error(er.getMessage());
		}
		
		return alertMasterDTO;
	}

/*	@Transactional
	public String addNewUser(ConversationSubDTO conversationSubDTO) {
		
		Date date = null;
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
	
					
					Query queryResult3 = em
							.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
					long subrecid = ((BigDecimal) queryResult3.getSingleResult()).longValue();
					long sub_rec_Id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
								+ String.valueOf(subrecid));
					
					// System.out.println("New Comment functionality");
					Query queryResult2 = em
							.createNativeQuery("SELECT seq_mcnv_convid.nextval FROM DUAL");
					long convid = ((BigDecimal) queryResult2.getSingleResult()).longValue();
					
					long conv_id = Long.parseLong(MPCUtil.getCurrentYearYYYYMMDDFormat(date)
								+ String.valueOf(convid));
						
				
					ConversationSub conversationSub = new ConversationSub();
					conversationSub.setRecId(sub_rec_Id);
					conversationSub.setRecdate(date);
					//conversationSub.setConvId(conv_id);
					//conversationSub.setConvId(Long.parseLong(conversationSubDTO.getConvId()));
					conversationSub.setUserCode("");
					conversationSub.setRoleCode(conversationSubDTO.getRoleCode());
					conversationSub.setSubscrStatus("1");
					conversationSub.setIsValid(1);
					conversationSub.setSrcSys(conversationSubDTO.getSrcSys());
					conversationSub.setCreatedBy(conversationSubDTO.getCreatedBy());
					conversationSub.setCreatedOn(date);
					//conversationSub.setModifiedOn(date);
					//conversationSub.setModifiedBy(userName);
					
					em.persist(conversationSub);
			

			} catch (Exception er) {
			er.printStackTrace();
			}
		
		return null;
	}*/
	
	@Transactional
	public String subscribeUsers(
			HashMap<String, List<UserRoleInfoDTO>> selectedRoleMap,
			String sessionName, String altId) {
		
		Date date = null;
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
			
			for (Map.Entry<String,  List<UserRoleInfoDTO>> mapEntry : selectedRoleMap.entrySet()) {
				List<UserRoleInfoDTO> userList = mapEntry.getValue();
				for (UserRoleInfoDTO urDto : userList) {
					Query queryResult3 = em
							.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
					long subrecid = ((BigDecimal) queryResult3
							.getSingleResult()).longValue();
					long sub_rec_Id = Long.parseLong(MPCUtil
							.getCurrentYearYYYYMMDDFormat(date)
							+ String.valueOf(subrecid));
					ConversationSub conversationSub = new ConversationSub();
					conversationSub.setRecId(sub_rec_Id);
					conversationSub.setRecdate(date);
					conversationSub.setUserCode(urDto.getDomainId());
					conversationSub.setRoleCode(mapEntry.getKey());
					conversationSub.setSubscrStatus("1");
					conversationSub.setIsValid(1);
					conversationSub.setAltId(Integer.parseInt(altId));
					conversationSub.setSrcSys("MPC");
					conversationSub.setCreatedBy(sessionName);
					conversationSub.setCreatedOn(date);
					em.persist(conversationSub);
				}
					}
			

			} catch (Exception er) {
			LOGGER.error(er.getMessage());
			}
		
		return null;
	}

	
	
	
	@Transactional
	public String subscribeUsers(
			List<String> selectedRoleList,
			String sessionName, String altId) {
		
		Date date = null;
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
			
			for(String roleCode:selectedRoleList){
				
				Query queryResult3 = em
						.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
				long subrecid = ((BigDecimal) queryResult3
						.getSingleResult()).longValue();
				long sub_rec_Id = Long.parseLong(MPCUtil
						.getCurrentYearYYYYMMDDFormat(date)
						+ String.valueOf(subrecid));
				
				ConversationSub conversationSub = new ConversationSub();
				conversationSub.setRecId(sub_rec_Id);
				conversationSub.setRecdate(date);
				conversationSub.setRoleCode(roleCode);
				conversationSub.setSubscrStatus(MPCConstants.SUBSCRP_STATUS_ACTIVE);
				conversationSub.setIsValid(MPCConstants.DATA_VALID_FLAG);
				conversationSub.setAltId(Integer.parseInt(altId));
				conversationSub.setSrcSys(MPCConstants.SRC_SYSYTEM_MPC);
				conversationSub.setCreatedBy(sessionName);
				conversationSub.setCreatedOn(date);
			

				em.persist(conversationSub);
				
			}
			
			
			
			
						

			} catch (Exception er) {
			LOGGER.error(er.getMessage());
			}
		
		return null;
	}

	@SuppressWarnings("deprecation")
	@Transactional
	public String subscribeUsers(
			List<String> selectedRoleList,List<ConversationSubDTO> rolesToUpdate,
			String sessionName, String altId) {
		ConversationSub conversationSub=null;
		Date date = null;
		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			date = (Date) queryTime.getSingleResult();
			
			//insert newly mapped records
			
			for(String roleCode:selectedRoleList){
				
				Query queryResult3 = em
						.createNativeQuery("SELECT seq_mcnv_recid_pk.nextval FROM DUAL");
				long subrecid = ((BigDecimal) queryResult3
						.getSingleResult()).longValue();
				long sub_rec_Id = Long.parseLong(MPCUtil
						.getCurrentYearYYYYMMDDFormat(date)
						+ String.valueOf(subrecid));
				
			    conversationSub = new ConversationSub();
				conversationSub.setRecId(sub_rec_Id);
				conversationSub.setRecdate(date);
				conversationSub.setRoleCode(roleCode);
				conversationSub.setSubscrStatus(MPCConstants.SUBSCRP_STATUS_ACTIVE);
				conversationSub.setIsValid(MPCConstants.DATA_VALID_FLAG);
				conversationSub.setAltId(Integer.parseInt(altId));
				conversationSub.setSrcSys(MPCConstants.SRC_SYSYTEM_MPC);
				conversationSub.setCreatedBy(sessionName);
				conversationSub.setCreatedOn(date);
			

				em.persist(conversationSub);
				
			}
			
			//loop to update
			for(ConversationSubDTO roleToUpdate:rolesToUpdate){
				
				if(roleToUpdate.getIsValid()==null){
					
			    conversationSub = new ConversationSub();
			    
				conversationSub.setRecId(Long.parseLong(roleToUpdate.getRecId()));
				conversationSub.setRecdate(date);
				conversationSub.setRoleCode(roleToUpdate.getRoleCode());
				conversationSub.setSubscrStatus(roleToUpdate.getSubscrStatus());
				conversationSub.setIsValid(MPCConstants.DATA_VALID_FLAG);
				conversationSub.setAltId(Integer.parseInt(roleToUpdate.getAltId()));
				conversationSub.setSrcSys(MPCConstants.SRC_SYSYTEM_MPC);
				conversationSub.setCreatedBy(roleToUpdate.getCreatedBy());
				conversationSub.setCreatedOn(date);
				conversationSub.setModifiedBy(sessionName);
				conversationSub.setModifiedOn(date);
				
				em.merge(conversationSub);
				}
			
				
			}
			

			} catch (Exception er) {
				LOGGER.error(er.getMessage());
			}
		
		return null;
	}

	
	
	@Override
	public List<ConversationSubDTO> getExistingRoles(String altId, Boolean activeRoles) {
		
		List<ConversationSubDTO> convSubList = new ArrayList<ConversationSubDTO>();
		
		try {
			
			EntityManager em = getEntityManager();
			String queryToFetchRoles=" select subs.alt_id,subs.role_code,nvl(subs.modified_on , subs.created_on) subscribedOn,"
					+ " nvl(subs.modified_by, subs.created_by) subscribedBy, subs.subscr_status,subs.rec_id,subs.rec_date,subs.created_on,subs.created_by  "
					+ " from mpc_conv_subscr subs where alt_id='"+altId+"' ";
					
			if(activeRoles){
							queryToFetchRoles+="and subs.subscr_status=1 ";
					}
					
			queryToFetchRoles+=" and is_valid=1 ";
				
					

			Query query = em .createNativeQuery(queryToFetchRoles);


			@SuppressWarnings("unchecked")
			List<Object[]> rows = query.getResultList();
			
			if (!rows.isEmpty()) {

				for (Object[] row : rows) {
					ConversationSubDTO convsubDTO = new ConversationSubDTO();
					if(row[0] != null){
						convsubDTO.setAltId(row[0].toString());
					}
					if(row[1] != null){
						convsubDTO.setRoleCode(row[1].toString());
					}
					if(row[2] != null){
						convsubDTO.setCreatedOn(row[2].toString());
					}
					if(row[3] != null){
						convsubDTO.setCreatedBy(row[3].toString());
					}
					if(row[4] != null){
						convsubDTO.setSubscrStatus(row[4].toString());
					}
					if(row[5] != null){
						convsubDTO.setRecId(row[5].toString());
					}
					if(row[6] != null){
						convsubDTO.setRecDate(row[6].toString());
					}
					if(row[7] != null){
						convsubDTO.setCreatedOn(row[7].toString());
					}
					if(row[8] != null){
						convsubDTO.setCreatedBy(row[8].toString());
					}
					convSubList.add(convsubDTO);
				}
			}
			
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return convSubList;
	}
	
}
