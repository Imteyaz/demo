package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainGeofenceMasterDTO;

public interface GeofencingMasterDao {

	List<MaintainGeofenceMasterDTO> getGeofenceMasterList();

	void saveOrUpdateMaintainGeofenceMasterData(
			MaintainGeofenceMasterDTO maintainGeofenceDTO);
	
}
