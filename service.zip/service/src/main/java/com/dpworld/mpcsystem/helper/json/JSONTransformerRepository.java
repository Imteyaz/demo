package com.dpworld.mpcsystem.helper.json;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.dpworld.mpcsystem.helper.ServiceUtils;
import com.dpworld.mpcsystem.helper.responsebinder.DataRow;

public class JSONTransformerRepository<T> implements JSONTransformer<T> {

	private static final Logger LOG = Logger
			.getLogger("com.hti.svcs.common.JSONTransformerRepository");

	public String[] getBinderColumns(Class<T> classz) {
//		LOG.info("getBinderColumns Method --> classz " + classz.getName());
		Field[] fields = classz.getDeclaredFields();
		List<Field> listArrays = Arrays.asList(fields);
		List<Field> list = new ArrayList<Field>(listArrays);
		Field serialField = null;
		int serialIndex = -1;
		try {
			serialField = classz.getDeclaredField("serialVersionUID");
		} catch (Exception e) {
			LOG.error("Exception in getBinderColumns : " + e.getMessage(), e);
			e.printStackTrace();
		}
		if (serialField != null && serialIndex != -1) {
			serialIndex = list.indexOf(serialField);
			list.remove(serialIndex);
		}
		String[] columns = new String[list.size()];
		for (int i = 0; i < columns.length; i++) {
			columns[i] = list.get(i).getName();
		}
		return columns;
	}

	public void populateRow(DataRow row, T dto, Class<T> classz) {
	
		new JSONTransformerProcessor<T>().execute(row, dto,
				new JSONTransformerTemplate<T>() {
					public void transformer(DataRow row, T dto, Class<T> classz) {
						Object[] paramKey = null;
						@SuppressWarnings("unchecked")
						Class<T> obj = (Class<T>) dto.getClass();
						String[] columns = getBinderColumns(classz);
						java.lang.reflect.Method[] methods = obj
								.getDeclaredMethods();
						for (String column : columns) {
							for (java.lang.reflect.Method method : methods) {
								if (((method.getName()).equalsIgnoreCase("get"
										+ column) || (method.getName())
										.equalsIgnoreCase("is" + column))
										&& method.getParameterTypes().length == 0) {
									try {
										Object returned = method.invoke(dto,
												paramKey);
										if (returned != null) {
											row.put(column, ServiceUtils
													.safeString(returned
															.toString()));
										}
									} catch (Exception e) {
										LOG.error(
												"Exception in populateRow Method : "
														+ e.getMessage(), e);
									}
									break;
								}
							}
						}
					}
				}, classz);
	
	}

}
