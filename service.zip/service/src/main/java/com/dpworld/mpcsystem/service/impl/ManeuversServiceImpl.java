package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.persistence.dao.ManeuversDao;
import com.dpworld.mpcsystem.service.ManeuversService;

@Service("maneuversService")
public class ManeuversServiceImpl implements ManeuversService{

	@Autowired
	private ManeuversDao maneuversDao;
	
	public List<GeoFenceViewDTO> getGeoFenceVesselList(String mgdObjName) {
		
		return maneuversDao.getGeoFenceVesselList(mgdObjName);
	}

}
