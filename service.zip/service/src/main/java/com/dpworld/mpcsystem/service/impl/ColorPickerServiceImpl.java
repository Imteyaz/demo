package com.dpworld.mpcsystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.ColorPickerDTO;
import com.dpworld.mpcsystem.persistence.dao.ColorPickerDao;
import com.dpworld.mpcsystem.service.ColorPickerService;
import com.dpworld.mpcsystem.service.SysParamService;


@Service("colorPickerService")
public class ColorPickerServiceImpl implements ColorPickerService{

	@Autowired
	private ColorPickerDao colorPickerDao;
	
	public void saveColorDtls(
			ColorPickerDTO colorPickerDTO) {
		colorPickerDao.saveColorDtls(colorPickerDTO);

	}
	
}
