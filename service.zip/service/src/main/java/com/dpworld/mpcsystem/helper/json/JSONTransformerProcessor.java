package com.dpworld.mpcsystem.helper.json;

import com.dpworld.mpcsystem.helper.responsebinder.DataRow;

public class JSONTransformerProcessor<T> {

	protected void execute(DataRow row, T dto,
			JSONTransformerTemplate<T> template, Class<T> classz) {
		template.invoke(row, dto, classz);
	}

}
