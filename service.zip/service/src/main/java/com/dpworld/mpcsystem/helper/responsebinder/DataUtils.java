package com.dpworld.mpcsystem.helper.responsebinder;

import org.apache.log4j.Logger;

public class DataUtils {

	private static final Logger LOG = Logger.getLogger(DataUtils.class);

	/**
	 * Creates a new ResultSet object
	 * 
	 * @param resultSetName
	 *            The name of the ResultSet
	 * @param fieldNames
	 *            An array of all the field names.
	 * @throws RuntimeException
	 * @return ResultSet
	 */
	private DataUtils(){}
	
	public static ResultSet createNewResultSet(String resultSetName,
			String[] fieldNames) throws RuntimeException {
		LOG.debug("Inside createNewResultSet method :resultSetName,fieldNames --> "
				+ resultSetName + " " + fieldNames);
		try {
			return new ResultSetImpl(resultSetName, fieldNames);
		} catch (Exception e) {
			LOG.error(
					"Exception in createNewResultSet method --> "
							+ e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}
	/**
	 * Creates new ServiceBinder object
	 * 
	 * @throws RuntimeException
	 * @return ServiceBinder
	 */
	public static ServiceBinder createNewServiceBinder()
			throws RuntimeException {
		LOG.debug("Inside createNewServiceBinder method ");
		try {
			return new ServiceBinderImpl();
		} catch (Exception e) {
			LOG.error(
					"Exception In createNewServiceBinder --> "
							+ e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

}
