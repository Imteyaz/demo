package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;

public interface ScoreMasterDao {
	
	List<MaintainScoreDTO> getMaintainScoreList();

	void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO);
}
