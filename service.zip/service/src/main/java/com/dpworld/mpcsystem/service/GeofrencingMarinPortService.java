package com.dpworld.mpcsystem.service;

import java.util.List;
import java.util.Map;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.common.utility.pojo.MpcGeofenceDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselInfo;
import com.dpworld.mpcsystem.helper.responsebinder.ServiceBinder;

public interface GeofrencingMarinPortService {

	Map<String, List<GeoFenceData>> getGeoFenceData();

	ServiceBinder getVTSVesselData(ServiceBinder binder,Map<String,String> codeMap,List<SysParamDetailDTO> sysParamList) throws Exception;

	List<MaintainScoreDTO> getMaintainScoreList();
	
	void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO);
	
    public List<SysParamDetailDTO> getSysParamData();
	
	public void addSysParam(SysParamDetailDTO sysParamDetailDTO);
	
    List<VesselInfo> getVesselFromTable();
    
    List<MpcGeofenceDTO> constructGeofenceData();
    
    List<MpcGeofenceDTO> constructGeofenceInfo(String mgmGfCode);

	List<MpcGeofenceDTO> getDistinctGeofenceNames();

	List<String> getMpcSysParamsList();

	List<String> getAreaData();
	
	List<SysParamDetailDTO> constructSysParamGeofence();

	List<MpcGeofenceDTO> geofenceBasinData();

	List<String> getAutoRefreshTime(String paramCatg, String paramGroup, String paramCode);
}
