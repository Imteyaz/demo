package com.dpworld.mpcsystem.delegate.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.delegate.GeofrencingMarinPortDelegate;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

@Repository
public class GeofrencingMarinPortDelegateImpl implements
		GeofrencingMarinPortDelegate {

	public List<VesselDetailsDTO> vesselDetailBPAPromis() {
		Client c = Client.create();
		Gson gson = new Gson();
		WebResource resource = null;
		resource = c
				.resource(MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL)+"vesselList");
		String response = resource.get(String.class);
		return gson.fromJson(response,
				new TypeToken<List<VesselDetailsDTO>>() {
				}.getType());
	}


}
