package com.dpworld.mpcsystem.helper.json;

import com.dpworld.mpcsystem.helper.responsebinder.DataRow;

public interface JSONTransformer<T> {

	public String[] getBinderColumns(Class<T> classz);

	public void populateRow(DataRow row, T dto, Class<T> classz);

}
