package com.dpworld.mpcsystem.helper.json;

import com.dpworld.mpcsystem.helper.responsebinder.DataRow;

public abstract class JSONTransformerTemplate<T> {

	public final void invoke(DataRow row, T dto, Class<T> classz) {
		transformer(row, dto, classz);
	}

	public abstract void transformer(DataRow row, T dto, Class<T> classz);
}
