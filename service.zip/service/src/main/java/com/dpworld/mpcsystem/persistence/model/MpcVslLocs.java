package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_vsl_locs")
@NamedQuery(name = "MpcVslLocs.findAll", query = "SELECT m FROM MpcVslLocs m")
public class MpcVslLocs {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "txn_id")
	private long txnId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "txn_date")
	private Date txnDate;

	@Column(name = "vess_name")
	private String vessName;

	@Column(name = "imo_no")
	private String imoNo;

	@Column(name = "src_name")
	private String srcName;

	@Column(name = "dst_name")
	private String dstName;

	@Column(name = "LAT")
	private Float lat;

	@Column(name = "LNG")
	private Float lng;

	@Column(name = "vsl_eta")
	private String vslEta;

	@Column(name = "src_sys")
	private String srcSys;

	@Column(name = "is_valid")
	private int isValid;

	@Column(name = "vts_cog")
	private String degree;
	
	@Column(name = "vts_sog")
	private String speed;
	
	@Column(name = "vts_heading")
	private String heading;
	
	
	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}


	public long getTxnId() {
		return txnId;
	}

	public void setTxnId(long txnId) {
		this.txnId = txnId;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getVessName() {
		return vessName;
	}

	public void setVessName(String vessName) {
		this.vessName = vessName;
	}

	public String getImoNo() {
		return imoNo;
	}

	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}

	public String getSrcName() {
		return srcName;
	}

	public void setSrcName(String srcName) {
		this.srcName = srcName;
	}

	public String getDstName() {
		return dstName;
	}

	public void setDstName(String dstName) {
		this.dstName = dstName;
	}

	public Float getLat() {
		return lat;
	}

	public void setLat(Float lat) {
		this.lat = lat;
	}

	public Float getLng() {
		return lng;
	}

	public void setLng(Float lng) {
		this.lng = lng;
	}

	public String getVslEta() {
		return vslEta;
	}

	public void setVslEta(String vslEta) {
		this.vslEta = vslEta;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public int getIsValid() {
		return isValid;
	}

	public void setIsValid(int isValid) {
		this.isValid = isValid;
	}

	@Override
	public String toString() {
		return "MpcVslLocs [txnId=" + txnId + ", txnDate=" + txnDate
				+ ", vessName=" + vessName + ", imoNo=" + imoNo + ", srcName="
				+ srcName + ", dstName=" + dstName + ", lat=" + lat + ", lng="
				+ lng + ", vslEta=" + vslEta + ", srcSys=" + srcSys
				+ ", isValid=" + isValid + "]";
	}

}
