package com.dpworld.mpcsystem.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.persistence.dao.SysParamDao;
import com.dpworld.mpcsystem.service.SysParamService;

@Service("sysParamService")
public class SysParamServiceImpl implements SysParamService{

	@Autowired
	private SysParamDao sysParamDao;
	
	 /*public List<SysParamDetailDTO> getSysParamData(String mspParamCatg,String mspParamGroup,String mspParamCode) {
			return sysParamDao.getSysParamData( mspParamCatg, mspParamGroup, mspParamCode);
		}*/
	 
	 public List<SysParamDetailDTO> getSysParamData() {
			return sysParamDao.getSysParamData();
		}
		
	   public void addSysParam(SysParamDetailDTO sysParamDetailDTO) { 
		   sysParamDao.saveSysParamData(sysParamDetailDTO);
		}
		

	   public List<SysParamDetailDTO> getSysParamDetailsByCategory(
				String paramCategory) {
			
			return sysParamDao.getSysParamDetailsByCategory(paramCategory);
		}
	   
	   public Map<String,String> getSysParamDetailsByCode(
				) {
			
			return sysParamDao.getSysParamDetailsByCode();
		}
	   public Map<String,String> getSysParamAutoRefresh(String mspParamCatg,String mspParamGroup,String mspParamCode)
	   {
			
			return sysParamDao.getSysParamAutoRefresh(mspParamCatg, mspParamGroup, mspParamCode) ;
		}
	   public List<SysParamDetailDTO> getVesselDegreeByCategory(String category,
				String group) {
			
			return sysParamDao.getVesselDegreeByCategory(category, group);
		}
	   public SysParamDetailDTO saveOrUpdateSysparamForColorChange(
				SysParamDetailDTO sysParamDetailDTO, String category) {
			return sysParamDao.saveOrUpdateSysparamForColorChange(sysParamDetailDTO, category);
			
		}
	   public List<SysParamDetailDTO> getDefaultVesselColor(String category) {
			
			return sysParamDao.getDefaultVesselColor(category);
		}
	   public List<SysParamDetailDTO> getSysParamDataByUserCode(String userCode, String category, String status) {
			
			return sysParamDao.getSysParamDataByUserCode(userCode, category, status);
		}

	   @Override
		public List<SysParamDetailDTO> getColorCodeAsUser(String paramCategory,
				String paramGroup, String paramCode) {
			return sysParamDao.getColorCodeAsUser(paramCategory, paramGroup, paramCode);
		}

	public void saveOrUpdateLRAD(String userCode) {
		sysParamDao.saveOrUpdateLRAD(userCode);
		
	}

}

