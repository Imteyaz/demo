package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="mpc_conversations")
public class Conversation{


	@Id
	@Column(name="REC_ID")
	private long recId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="REC_DATE")
	private Date recdate;
	
	@Column(name="conv_type")
	private String convType;
	
	@Column(name="ALT_ID")
	private Integer altId;
	
	@Column(name="CONV_ID")
	private Long convId;
	
	@Column(name="CONV_TOPIC_TYPE")
	private String convTopicType;
	
	@Column(name="CONV_TOPIC_VAL")
	private String convTopicVal;
	
	@Column(name="CONV_SUBTOPIC_TYPE")
	private String convSubTopicType;
	
	@Column(name="CONV_SUBTOPIC_VAL")
	private String convSubTopicVal;
	
	@Column(name="CONV_TEXT")
	private String convText;
	
	@Column(name="CONV_USER")
	private String convUser;
	
	
	
	@Column(name="IS_VALID")
	private Integer isValid;
	
	@Column(name="SRC_SYS")
	private String srcSys;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_ON")
	private Date createdOn;
	

	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_ON")
	private Date modifiedOn;
	

	@Column(name="MODIFIED_BY")
	private String modifiedBy;


	public long getRecId() {
		return recId;
	}


	public void setRecId(long recId) {
		this.recId = recId;
	}


	public Date getRecdate() {
		return recdate;
	}


	public void setRecdate(Date recdate) {
		this.recdate = recdate;
	}


	public String getConvType() {
		return convType;
	}


	public void setConvType(String convType) {
		this.convType = convType;
	}


	public Integer getAltId() {
		return altId;
	}


	public void setAltId(Integer altId) {
		this.altId = altId;
	}


	public Long getConvId() {
		return convId;
	}

	public void setConvId(Long convId) {
		this.convId = convId;
	}


	public String getConvTopicType() {
		return convTopicType;
	}


	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}


	public String getConvTopicVal() {
		return convTopicVal;
	}


	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}


	public String getConvSubTopicType() {
		return convSubTopicType;
	}


	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}


	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}


	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}


	public String getConvText() {
		return convText;
	}


	public void setConvText(String convText) {
		this.convText = convText;
	}


	public String getConvUser() {
		return convUser;
	}


	public void setConvUser(String string) {
		this.convUser = string;
	}


	public Integer getIsValid() {
		return isValid;
	}


	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}


	public String getSrcSys() {
		return srcSys;
	}


	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	@Override
	public String toString() {
		return "Conversation [recId=" + recId + ", recdate=" + recdate
				+ ", convType=" + convType + ", altId=" + altId + ", convId="
				+ convId + ", convTopicType=" + convTopicType
				+ ", convTopicVal=" + convTopicVal + ", convSubTopicType="
				+ convSubTopicType + ", convSubTopicVal=" + convSubTopicVal
				+ ", convText=" + convText + ", convUser=" + convUser
				+ ", isValid=" + isValid + ", srcSys=" + srcSys
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy
				+ "]";
	}

	
	

	
	
}
