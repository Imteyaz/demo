package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.ConversationHistoryDTO;

public interface ConversationHistoryDao {
	List<ConversationHistoryDTO> getConversationHistoryList(String userName);

}
