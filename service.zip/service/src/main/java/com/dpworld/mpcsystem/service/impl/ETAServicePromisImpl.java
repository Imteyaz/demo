/**
 * 
 */
package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.persistence.dao.ETAServicePromisDao;
import com.dpworld.mpcsystem.service.ETAServicePromis;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Service("etaServicePromis")
public class ETAServicePromisImpl implements ETAServicePromis{
	@Autowired
	private ETAServicePromisDao etaServicePromisDao;
	@Override
	public List<VesselDetailsDTO> getVesseldetails(String fromEtaDate, String toEtaDate,String vesseltypes) {
		
		return etaServicePromisDao.getVesseldetails(fromEtaDate, toEtaDate ,vesseltypes);
	}

}
