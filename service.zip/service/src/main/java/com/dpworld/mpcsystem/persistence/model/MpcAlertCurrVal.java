package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_alert_currval")
@NamedQuery(name = "MpcAlertCurrVal.findAll", query = "SELECT m FROM MpcAlertCurrVal m")
public class MpcAlertCurrVal {


	@Id
	@Column(name="REC_ID")
	private Long recId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="REC_DATE")
	private Date recdate;
	
	@Column(name="ALT_ID")
	private Integer altId;
	
	@Column(name="MAC_REF_COL1")
	private String macRefCol1;
	
	@Column(name="MAC_REF_COL2")
	private String macRefCol2;
	
	@Column(name="MAC_REF_COL3")
	private String macRefCol3;
	
	@Column(name="MAC_CHG_COL")
	private String macChgCol;
	
	@Column(name="MAC_CURRVAL")
	private String macCurrVal;
	
	@Column(name="SRC_SYS")
	private String srcSys;
	
	@Column(name="IS_VALID")
	private Integer isValid;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_ON")
	private Date createdOn;
	

	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_ON")
	private Date modifiedOn;
	

	@Column(name="MODIFIED_BY")
	private String modifiedBy;


	public long getRecId() {
		return recId;
	}


	public void setRecId(long recId) {
		this.recId = recId;
	}


	public Date getRecdate() {
		return recdate;
	}


	public void setRecdate(Date recdate) {
		this.recdate = recdate;
	}


	public Integer getAltId() {
		return altId;
	}


	public void setAltId(Integer altId) {
		this.altId = altId;
	}


	public String getMacRefCol1() {
		return macRefCol1;
	}


	public void setMacRefCol1(String macRefCol1) {
		this.macRefCol1 = macRefCol1;
	}


	public String getMacRefCol2() {
		return macRefCol2;
	}


	public void setMacRefCol2(String macRefCol2) {
		this.macRefCol2 = macRefCol2;
	}


	public String getMacRefCol3() {
		return macRefCol3;
	}


	public void setMacRefCol3(String macRefCol3) {
		this.macRefCol3 = macRefCol3;
	}


	public String getMacChgCol() {
		return macChgCol;
	}


	public void setMacChgCol(String macChgCol) {
		this.macChgCol = macChgCol;
	}


	public String getMacCurrVal() {
		return macCurrVal;
	}


	public void setMacCurrVal(String macCurrVal) {
		this.macCurrVal = macCurrVal;
	}


	public String getSrcSys() {
		return srcSys;
	}


	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}


	public Integer getIsValid() {
		return isValid;
	}


	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	@Override
	public String toString() {
		return "MpcAlertCurrVal [recId=" + recId + ", recdate=" + recdate
				+ ", altId=" + altId + ", macRefCol1=" + macRefCol1
				+ ", macRefCol2=" + macRefCol2 + ", macRefCol3=" + macRefCol3
				+ ", macChgCol=" + macChgCol + ", macCurrVal=" + macCurrVal
				+ ", srcSys=" + srcSys + ", isValid=" + isValid
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy
				+ "]";
	}


	
}
