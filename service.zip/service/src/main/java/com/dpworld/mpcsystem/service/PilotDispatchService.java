package com.dpworld.mpcsystem.service;

import java.util.Date;
import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.PilotVesselDataDTO;
import com.dpworld.mpcsystem.persistence.model.MpcVesselData;

public interface PilotDispatchService {

    void saveMpcVesselDetails(PilotVesselDataDTO vesselData);
    void saveMpcUserOrder(PilotVesselDataDTO vesselData);
	
	List<MpcVesselData> getMpcVesselDataByVessel(String vesselName, String rotation);
	List<MpcVesselData> getMpcVesselDataByVessel(String vesselName, String rotation,String status);
   List<MpcVesselData> getMpcUserOrder(String mvdgroup, String rotation);

   
	public Date getPilotDispatchTime(PilotVesselDataDTO vesselData);
	
	public List<PilotVesselDataDTO> getPilotDispatchTimeData(PilotVesselDataDTO vesselData);
	
}
