package com.dpworld.mpcsystem.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface SearchRequired {

	// If it is an object then dig deep the search by this object.
	boolean isObject() default false;

	// This is fields list required for search by if it is object.
	String[] fields() default {};
}
