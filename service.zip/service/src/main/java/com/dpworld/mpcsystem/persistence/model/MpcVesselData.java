package com.dpworld.mpcsystem.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MPC_VESSEL_DATA")
@NamedQuery(name = "MpcVesselData.findAll", query = "SELECT m FROM MpcVesselData m")
public class MpcVesselData implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "mvd_rec_id")
	private long mvdRecId;
	
	@Column(name = "rotn")
	private String rotataionNo;
	
	@Column(name = "vess_name")
	private String vesselName;
	
	@Column(name = "imo_no")
	private String imoNo;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "mvd_pilot_dsp_time")
	private Date pilotDspTime;
	
	@Column(name = "src_sys")
	private String srcSys;
	
	@Column(name = "is_valid")
	private Integer isValid;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "vess_status")
	private String status;
	@Column(name = "mvd_user_order")
	private String userorder;
	public String getUserorder() {
		return userorder;
	}

	public void setUserorder(String userorder) {
		this.userorder = userorder;
	}

	public String getMvdgroup() {
		return mvdgroup;
	}

	public void setMvdgroup(String mvdgroup) {
		this.mvdgroup = mvdgroup;
	}

	@Column(name = "mvd_group")
	private String mvdgroup;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getMvdRecId() {
		return mvdRecId;
	}

	public void setMvdRecId(long mvdRecId) {
		this.mvdRecId = mvdRecId;
	}

	public String getRotataionNo() {
		return rotataionNo;
	}

	public void setRotataionNo(String rotataionNo) {
		this.rotataionNo = rotataionNo;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getImoNo() {
		return imoNo;
	}

	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}

	public Date getPilotDspTime() {
		return pilotDspTime;
	}

	public void setPilotDspTime(Date pilotDspTime) {
		this.pilotDspTime = pilotDspTime;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
}
