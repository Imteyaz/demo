package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name = "mpc_alert_master")
@NamedQuery(name = "MpcAlertMaster.findAll", query = "SELECT m FROM MpcAlertMaster m ORDER BY m.altId DESC")
public class MpcAlertMaster {
	
	@Id
	@Column(name = "alt_id")
	private long altId;
	
	@Column(name = "alt_code")
	private String altCode;
	
	@Column(name = "alt_text")
	private String altText;
	
	@Column(name = "alt_severity")
	private String altSeverity;
	
	@Column(name = "alt_validity")
	private Integer altValidity;
	
	@Column(name = "alt_type")
	private String altType;
	
	@Column(name = "alt_group")
	private String altGroup;
	
	@Column(name = "alt_catg")
	private String altCatg;
	
	@Column(name = "is_valid")
	private Integer isValid;
	
	@Column(name = "src_sys")
	private String srcSys;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@Column(name = "modified_by")
	private String modifiedBy;

	public long getAltId() {
		return altId;
	}

	public void setAltId(long altId) {
		this.altId = altId;
	}

	public String getAltCode() {
		return altCode;
	}

	public void setAltCode(String altCode) {
		this.altCode = altCode;
	}

	public String getAltText() {
		return altText;
	}

	public void setAltText(String altText) {
		this.altText = altText;
	}

	public String getAltSeverity() {
		return altSeverity;
	}

	public void setAltSeverity(String altSeverity) {
		this.altSeverity = altSeverity;
	}

	public Integer getAltValidity() {
		return altValidity;
	}

	public void setAltValidity(Integer altValidity) {
		this.altValidity = altValidity;
	}

	public String getAltType() {
		return altType;
	}

	public void setAltType(String altType) {
		this.altType = altType;
	}

	public String getAltGroup() {
		return altGroup;
	}

	public void setAltGroup(String altGroup) {
		this.altGroup = altGroup;
	}

	public String getAltCatg() {
		return altCatg;
	}

	public void setAltCatg(String altCatg) {
		this.altCatg = altCatg;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	

}
