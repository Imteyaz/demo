package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainGeofenceMasterDTO;

public interface GeofencingMasterService {

	List<MaintainGeofenceMasterDTO> getMaintainGeofenceMasterList();

	void saveOrUpdateGeofenceMasterData(
			MaintainGeofenceMasterDTO maintainGeofenceDTO);
	
}
