package com.dpworld.mpcsystem.persistence.dao;

import java.util.HashMap;
import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.AlertMasterDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;

import com.dpworld.mpcsystem.common.utility.pojo.UserRoleInfoDTO;

public interface AlertMasterDao {
	
	List<AlertMasterDTO> getAlertMasterList();
	
	void saveOrUpdateAlertMaster(AlertMasterDTO alertMasterDTO);
	
	AlertMasterDTO getAlertMasterDTOById(String altId);
	
	//String addNewUser( ConversationSubDTO conversationSubDTO);

	String subscribeUsers(HashMap<String, List<UserRoleInfoDTO>> selectedRoleMap,
			String sessionName, String altId);
	
	String subscribeUsers(List<String> rolesToAdd,
			String sessionName, String altId);
	
	String subscribeUsers(List<String> rolesToAdd,List<ConversationSubDTO> rolesToUpdate,String sessionName, String altId);
	
	
	List<ConversationSubDTO> getExistingRoles(String altId,Boolean activeRoles);
}
