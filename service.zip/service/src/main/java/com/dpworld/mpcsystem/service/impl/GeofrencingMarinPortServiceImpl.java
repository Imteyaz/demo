package com.dpworld.mpcsystem.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.model.ConfigCode;
import com.dpworld.mpcsystem.common.utility.CodeServiceUtil;
import com.dpworld.mpcsystem.common.utility.DateUtilities;
import com.dpworld.mpcsystem.common.utility.VesselDataCalcHelper;
import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.common.utility.pojo.MpcGeofenceDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselIcon;
import com.dpworld.mpcsystem.common.utility.pojo.VesselInfo;
import com.dpworld.mpcsystem.delegate.GeofrencingMarinPortDelegate;
import com.dpworld.mpcsystem.helper.ResponseCode;
import com.dpworld.mpcsystem.helper.json.JSONTransformer;
import com.dpworld.mpcsystem.helper.json.JSONTransformerRepository;
import com.dpworld.mpcsystem.helper.responsebinder.DataRow;
import com.dpworld.mpcsystem.helper.responsebinder.DataUtils;
import com.dpworld.mpcsystem.helper.responsebinder.ResultSet;
import com.dpworld.mpcsystem.helper.responsebinder.ServiceBinder;
import com.dpworld.mpcsystem.persistence.dao.GeofrencingMarinPortDao;
import com.dpworld.mpcsystem.persistence.dao.SysParamDao;
import com.dpworld.mpcsystem.persistence.model.MpcGeofenceMaster;
import com.dpworld.mpcsystem.service.GeofrencingMarinPortService;

@Service("geofrencingMarinPortService")
public class GeofrencingMarinPortServiceImpl implements
		GeofrencingMarinPortService {

	@Autowired
	private static final Logger logger = LoggerFactory
			.getLogger(GeofrencingMarinPortServiceImpl.class);
	public static Map<String, String> codeMap;
	private static Map<String, String> listOfDegree = null;
	private static Map<String, String> listOfDefaultPositions = null;

	VesselDataCalcHelper helper = new VesselDataCalcHelper();
	@Autowired
	private GeofrencingMarinPortDao geofrencingMarinPortDao;

	@Autowired
	private GeofrencingMarinPortDelegate geofrencingMarinPortDelegate;
	@Autowired
	private SysParamDao sysParmServiceDao;
	@Autowired
	private CodeServiceUtil codeServiceUtil;

	List<ConfigCode> vesselTypeList = new ArrayList<ConfigCode>();
	Map<String, String> codeDescriptionMap = null;

	public Map<String, List<GeoFenceData>> getGeoFenceData() {
		return geofrencingMarinPortDao.getGeoFenceData();
	}

	private Map<String, String> populateCodeDescription(
			List<ConfigCode> vesselTypeList) {                                                   
		Map<String, String> codeDescriptionMap = new HashMap<>();
		if (vesselTypeList != null) {
			for (ConfigCode configCode : vesselTypeList) {
				codeDescriptionMap.put(configCode.getCodeCode(),
						configCode.getCodeDescription1());
			}
		}
		return codeDescriptionMap;
	}

	@PostConstruct
	public void initIt() throws Exception {
		codeMap = sysParmServiceDao.getSysParamDetailsByCode();
		listOfDefaultPositions = sysParmServiceDao
				.loadSysParamMapWithCodeAndValue("BTHPOS", "DEFVAL");
		vesselTypeList = codeServiceUtil.getListCodes(MPCConstants.VESSEL_TYPE);
		codeDescriptionMap = populateCodeDescription(vesselTypeList);
		listOfDegree = sysParmServiceDao.loadSysParamMapWithCodeAndValue(
				"GEOFENCE", "DEGREE");
	}

	private void populateDescription(Map<String, String> codeDescriptionMap,
			VesselDetailsDTO dto) {
		if (dto != null && codeDescriptionMap != null
				&& dto.getVesselType() != null
				&& !dto.getVesselType().trim().isEmpty()
				&& codeDescriptionMap.get(dto.getVesselType().trim()) != null) {
			dto.setVesselDescription(codeDescriptionMap.get(dto.getVesselType()
					.trim()));
		}
	}
	
	
	public Map<String, String> populateCodeDescriptionMap(
			List<ConfigCode> serviceTypeList) {
		Map<String, String> codeDescriptionMap = new HashMap<>();
		if (serviceTypeList != null) {
			for (ConfigCode configCode : serviceTypeList) {
				codeDescriptionMap.put(configCode.getCodeCode(),
						configCode.getCodeDescription1());
			}
		}
		return codeDescriptionMap;
	}
	
	String getVesselStatus(VesselDetailsDTO dto, Map<String, String> codeMap) {
		logger.debug("Calling computeVesselStatus API to calculate Vessel status for vessel :"
				+ dto.getVesselName());
		String codeKey = helper.computeVesselStatus(dto);
		if (codeMap != null && codeMap.get(codeKey) != null) {
			dto.setStatus(codeMap.get(codeKey));
		}
		logger.debug(" Vessel status after performing computation : "
				+codeMap.get(codeKey));
		
		return dto.getStatus();
	}

	public ServiceBinder getVTSVesselData(ServiceBinder binder,Map<String,String> codeMap,List<SysParamDetailDTO> sysParamList)
			throws Exception {
		long startTime=System.currentTimeMillis();
        long vesselFromTableStartTime = System.currentTimeMillis();
		List<VesselInfo> vesselGeofenceInfos = geofrencingMarinPortDao
				.getVesselFromTable();
		long vesselFromTableEndTime = System.currentTimeMillis();
		logger.debug("VTS-TIME getVesselFromTable API Time Taken: "+(vesselFromTableEndTime-vesselFromTableStartTime));
		long promisListStartTime=System.currentTimeMillis();
		List<VesselDetailsDTO> bpaPromisVesselList = geofrencingMarinPortDelegate
				.vesselDetailBPAPromis();
		long promisListEndTime=System.currentTimeMillis();
		logger.debug("VTS-TIME promis API Time Taken: "+(promisListEndTime-promisListStartTime));
		VesselDataCalcHelper helper = new VesselDataCalcHelper();
		JSONTransformer<VesselInfo> transformer = new JSONTransformerRepository<VesselInfo>();
		ResultSet resultset = DataUtils.createNewResultSet("vesselInfo",
				transformer.getBinderColumns(VesselInfo.class));
		List<VesselIcon> iconsList = new ArrayList<VesselIcon>();
		VesselIcon vdefault = new VesselIcon(-1, -1);
		iconsList.add(vdefault);
		VesselDetailsDTO vesselDetailsDTO = null;
		String status = null;
		String position = null;
		String geofenceArea = null;
		String degree = null;// FIXME .. when vessel is not in vessel list don't
								// consider degrees
		String nextLocation =null;
		for (VesselInfo vesselGeoFenceInfo : vesselGeofenceInfos) {
			final String vesselName = vesselGeoFenceInfo.getVesselName();
			vesselDetailsDTO = (VesselDetailsDTO) CollectionUtils.find(
					bpaPromisVesselList, new Predicate() {

						@Override
						public boolean evaluate(Object object) {
							return ((VesselDetailsDTO) object).getVesselName()
									.equalsIgnoreCase(vesselName);
						}
					});
			
			if(vesselDetailsDTO !=null && vesselDetailsDTO.getVesselName()!=null)
			logger.debug("VTS-VESSEL DATA SETTING GEOFENCE FOR : "+vesselDetailsDTO.getVesselName());
			if(vesselDetailsDTO !=null && vesselDetailsDTO.getVesselLocation() !=null){
				logger.debug("VTS-VESSEL DATA :"+vesselDetailsDTO.getVesselName()+" --> "+vesselDetailsDTO.getVesselLocation());;
			geofenceArea= vesselDetailsDTO.getVesselLocation();
			}
		if (vesselDetailsDTO != null) {
			status = helper.computeVesselStatus(vesselDetailsDTO);
				populateDescription(codeDescriptionMap, vesselDetailsDTO);
				logger.debug("Vessel Status Before Setting is : "+vesselDetailsDTO.getVesselName()+" is : "+vesselDetailsDTO.getStatus());
				if(status !=null){
					long statusStartTime = System.currentTimeMillis();
					vesselDetailsDTO.setStatus(status);
					long statusEndTime = System.currentTimeMillis();
					logger.debug("VTS-TIME Time taken to set Status is : "+(statusEndTime-statusStartTime));
				logger.debug("Vessle Status Set Successfully  For Vessel : "+vesselDetailsDTO.getVesselName()+" is : "+vesselDetailsDTO.getStatus());
				}

				if (StringUtils.isEmpty(geofenceArea) && StringUtils.isNotEmpty(vesselDetailsDTO.getVesselLocation())) {
					geofenceArea = vesselDetailsDTO.getVesselLocation();
					vesselGeoFenceInfo.setCurrentLocation(geofenceArea);
					vesselGeoFenceInfo.setGeofenceArea(geofenceArea);
				}
				// update direction based on status
				position = vesselDetailsDTO.getBerthPosition();
				degree = null;
				if (status !=null && MPCConstants.VSL_STATUS_IN_PROGRESS.contains(status)) {
					if (position != null) {
						position = position.equals("STBD") ? "S" : "PORT"
								.equals(position) ? "P" : "";
					} else {
						position = listOfDefaultPositions.get(geofenceArea) != null ? "P"
								: "";
					}
					geofenceArea += position;
				}
				
				// update degrees
				if (vesselDetailsDTO.getStatus() != null && StringUtils.isNotEmpty(vesselDetailsDTO.getStatus())
						&& !vesselDetailsDTO.getStatus().equalsIgnoreCase(
								MPCConstants.INCOMING)
								&& StringUtils.isNotEmpty(vesselDetailsDTO.getVesselLocation())
						&& StringUtils.isNotEmpty(geofenceArea)) {
					logger.debug("Before Setting Degree For Vessel : "
							+ vesselDetailsDTO.getVesselName()
							+ " with status : " + vesselDetailsDTO.getStatus()
							+ " with degree : "
							+ vesselGeoFenceInfo.getDegrees());

					 if ( StringUtils.isNotEmpty(geofenceArea)) 
					degree = listOfDegree.get(geofenceArea);

					vesselGeoFenceInfo.setDegrees(StringUtils
							.isNotEmpty(degree) ? degree : listOfDegree
							.get("DEFAULT"));
					logger.debug("After setting the degree for vessel : "
							+ vesselDetailsDTO.getVesselName()
							+ " with status : " + vesselDetailsDTO.getStatus()
							+ " with degree : "
							+ vesselGeoFenceInfo.getDegrees()
							+" with GF Location : "+vesselGeoFenceInfo.getGeofenceArea());
				} else if (vesselDetailsDTO.getStatus() == null
						|| StringUtils.isEmpty(vesselDetailsDTO.getStatus())
						|| StringUtils.isEmpty(vesselGeoFenceInfo
								.getGeofenceArea())) {
					vesselGeoFenceInfo.setDegrees( listOfDegree
							.get("DEFAULT"));
					logger.debug(" Setting default degree as it status is EMPTY for  : "
							+ vesselDetailsDTO.getVesselName()
							+ " Status : "
							+ vesselDetailsDTO.getStatus());
				}
				else
				{
					logger.debug("Not Setting As the vessel status is INCOMING for vessel : "
							+ vesselDetailsDTO.getVesselName()
							+ " Status : "
							+ vesselDetailsDTO.getStatus());
				}
				if (vesselDetailsDTO.getVesselDescription() != null)
					vesselGeoFenceInfo.setVesselType(vesselDetailsDTO
							.getVesselDescription());
				// update rotation number
				vesselGeoFenceInfo.setRotationNumber(vesselDetailsDTO
						.getRotation());
				vesselGeoFenceInfo.setStatus(status);
				if (vesselGeoFenceInfo.getGeofenceArea() == null
						|| StringUtils.isEmpty(vesselGeoFenceInfo
								.getGeofenceArea())) {
					vesselGeoFenceInfo.setGeofenceArea(vesselDetailsDTO
							.getVesselLocation());
				}

				if (codeMap != null) {
					if (codeMap.get(MPCConstants.ETB_BUFFER_TIME) != null) {
						vesselGeoFenceInfo.setEtb(helper.computeVesselETB(
								vesselDetailsDTO, bpaPromisVesselList,
								sysParamList));

					}
					if (codeMap.get(MPCConstants.MANEUVER_BUFFTER_TIME) != null) {
						Integer bufferTime = Integer.parseInt(codeMap
								.get(MPCConstants.MANEUVER_BUFFTER_TIME));
						if (!StringUtils.isEmpty(vesselDetailsDTO.getEtaDate())) {
							String formatTobeUsed=null;
							if(DateUtilities.isValidDate(vesselDetailsDTO.getEtaDate(), MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM))
							{
								formatTobeUsed = MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM;
							}
							else
							{
								formatTobeUsed = MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM;
							}
							Date eta = DateUtilities
									.parseDate(
											vesselDetailsDTO.getEtaDate(),
											formatTobeUsed);
							String etaDate = DateUtilities
									.formatDate(
											eta,
											MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
							vesselDetailsDTO.setEtaDate(etaDate);
						}
						else if (!StringUtils.isEmpty(vesselDetailsDTO.getEtbDate())) {
							String formatTobeUsed=null;
							if(DateUtilities.isValidDate(vesselDetailsDTO.getEtaDate(), MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM))
							{
								formatTobeUsed = MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM;
							}
							else
							{
								formatTobeUsed = MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM;
							}
							Date etb = DateUtilities
									.parseDate(
											vesselDetailsDTO.getEtbDate(),
											formatTobeUsed);
							String etbDate = DateUtilities
									.formatDate(
											etb,
											MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
							vesselDetailsDTO.setEtbDate(etbDate);
						}
						helper.computeMarineManeuver(bpaPromisVesselList,
								vesselDetailsDTO, codeMap,sysParamList);
						String etm = helper.computeETM(vesselDetailsDTO,
								bufferTime);
						etm = etm != null ? etm : MPCConstants.EMPTY_STRING;
						vesselGeoFenceInfo.setEtm(etm);
					}
				}
				vesselGeoFenceInfo.setEtc(vesselDetailsDTO.getEtc());
				if (!StringUtils.isEmpty(vesselDetailsDTO.getFromBollard())) {

					vesselGeoFenceInfo.setFromBollard("("
							+ vesselDetailsDTO.getFromBollard());
				}
				if (!StringUtils.isEmpty(vesselDetailsDTO.getToBollard())) {
					vesselGeoFenceInfo.setToBollard(" - "
							+ vesselDetailsDTO.getToBollard() + ")");
				} else {
					vesselGeoFenceInfo
							.setFromBollard((!StringUtils
									.isEmpty(vesselGeoFenceInfo
											.getFromBollard()) ? vesselGeoFenceInfo
									.getFromBollard() + ")"
									: MPCConstants.EMPTY_STRING));
				}
				helper.currentNextLocation(vesselDetailsDTO, bpaPromisVesselList, sysParamList);
				nextLocation = vesselDetailsDTO.getNextLocation();
				nextLocation = nextLocation != null ? nextLocation : MPCConstants.EMPTY_STRING;
				vesselGeoFenceInfo.setNextLocation(nextLocation);
			}
			nextLocation = vesselGeoFenceInfo.getNextLocation()!= null ?vesselGeoFenceInfo.getNextLocation() : MPCConstants.EMPTY_STRING;
			vesselGeoFenceInfo.setNextLocation(nextLocation);
			DataRow row = resultset.createNewRow();
			transformer.populateRow(row, vesselGeoFenceInfo, VesselInfo.class);
		}
		binder.addResultSet("vesselInfo", resultset);
		binder.setStatusMessage("Link Info successfully retrieved");
		binder.setResponseCode(ResponseCode.SUCCESS);
		long endTime=System.currentTimeMillis();
		logger.debug("VTS-TIME  vts api completion time : "+(endTime-startTime));
		return binder;
	}

	public class BerthedVesselPredicate implements Predicate {

		private String status;

		public BerthedVesselPredicate(String status) {
			this.status = status;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		@Override
		public boolean evaluate(Object object) {
			VesselDetailsDTO ob = (VesselDetailsDTO) object;
			if (ob.getStatus() != null && status.equals(ob.getStatus())) {
				return true;
			}
			if (ob.getStatus() != null
					&& MPCConstants.OPERATING.equals(ob.getStatus())) {
				return true;
			}
			if (ob.getStatus() != null
					&& MPCConstants.COMPLETED.equals(ob.getStatus())) {
				return true;
			}
			if (ob.getStatus() != null
					&& MPCConstants.SHIFTING.equals(ob.getStatus())) {
				return true;
			}
			return false;

		}

	}

	public class RemoveBerthedDuplicateVesselPredicate implements Predicate {

		private List<VesselDetailsDTO> berthedVesselList;

		public RemoveBerthedDuplicateVesselPredicate(
				List<VesselDetailsDTO> berthedVesselList) {
			this.berthedVesselList = berthedVesselList;
		}

		public List<VesselDetailsDTO> getBerthedVesselList() {
			return berthedVesselList;
		}

		public void setBerthedVesselList(
				List<VesselDetailsDTO> berthedVesselList) {
			this.berthedVesselList = berthedVesselList;
		}

		@Override
		public boolean evaluate(Object object) {
			VesselDetailsDTO ob = (VesselDetailsDTO) object;
			for (VesselDetailsDTO berthedVessl : berthedVesselList) {
				if (berthedVessl.getVesselName().equals(ob.getVesselName())
						&& !"BERTH".equals(ob.getStatus())) {
					// berthedVesselList.add(ob);
					return false;
				}
			}
			return true;

		}

	}

	public List<MaintainScoreDTO> getMaintainScoreList() {

		return geofrencingMarinPortDao.getMaintainScoreList();
	}

	public void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO) {

		geofrencingMarinPortDao.saveOrUpdateMaintainScoreData(maintainScoreDTO);
	}

	public List<SysParamDetailDTO> getSysParamData() {

		return geofrencingMarinPortDao.getSysParamData();
	}

	public void addSysParam(SysParamDetailDTO sysParamDetailDTO) {

		geofrencingMarinPortDao.saveSysParamData(sysParamDetailDTO);
	}

	public List<VesselInfo> getVesselFromTable() {
		return geofrencingMarinPortDao.getVesselFromTable();
	}

	public List<MpcGeofenceDTO> constructGeofenceData() {

		return geofrencingMarinPortDao.constructGeofenceData();
	}

	public List<MpcGeofenceDTO> constructGeofenceInfo(String mgmGfCode) {

		return geofrencingMarinPortDao.constructGeofenceInfo(mgmGfCode);
	}

	public List<MpcGeofenceDTO> getDistinctGeofenceNames() {

		return geofrencingMarinPortDao.getDistinctGeofenceNames();
	}

	public List<String> getMpcSysParamsList() {

		return geofrencingMarinPortDao.getMpcSysParamsList();
	}

	/**
	 * Method to get LAT LONG based on Locations
	 */

	public List<String> getAreaData() {
		List<MpcGeofenceMaster> areaData = geofrencingMarinPortDao
				.getAreaData();
		// Collections.sort(areaData);
		List<String> mapData = geofrencingMarinPortDao.getMpcSysParamsList();
		List<String> listdata = new ArrayList<String>();

		StringBuffer str = new StringBuffer();
		for (String str2 : mapData) {

			if (str2.contains(MPCConstants.TERMINAL1)) {
				str2 = MPCConstants.T1;
			} else if (str2.equals(MPCConstants.TERMINAL2)) {
				str2 = MPCConstants.T2;
			} else if (str2.equals(MPCConstants.TERMINAL3)) {
				str2 = MPCConstants.T3;
			}

			for (MpcGeofenceMaster mgfm : areaData) {
				if (mgfm.getMgmGFCode() != null && str2 != null) {
					if (mgfm.getMgmGFCode().substring(0, 2)
							.equalsIgnoreCase(str2.substring(0, 2))) {

						str.append(mgfm.getMgmGFLat() + ":"
								+ mgfm.getMgmGFLong() + ",");
					}
				}

			}
			if (str != null && str.length() > 0) {
				str.setLength(str.length() - 1);
			}
			listdata.add(str.toString());
			str.setLength(0);
		}
		return listdata;
	}

	/**
	 * @param vesselDetailsDTO
	 */
	public String getVesselStatus(VesselDetailsDTO dto) {
		codeMap = sysParmServiceDao.getSysParamDetailsByCode();
		String codeKey = helper.computeVesselStatus(dto);
		return codeMap.get(codeKey);
	}

	public List<SysParamDetailDTO> constructSysParamGeofence() {

		return geofrencingMarinPortDao.constructSysParamGeofence();
	}

	public List<MpcGeofenceDTO> geofenceBasinData() {

		return geofrencingMarinPortDao.geofenceBasinData();
	}

	public List<String> getAutoRefreshTime(String paramCatg, String paramGroup,
			String paramCode) {

		return geofrencingMarinPortDao.getAutoRefreshTime(paramCatg,
				paramGroup, paramCode);
	}

}
