package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainGeofenceMasterDTO;
import com.dpworld.mpcsystem.persistence.dao.GeofencingMasterDao;
import com.dpworld.mpcsystem.persistence.model.MpcGeofenceMaster;

@Repository("geofencingMasterDao")
public class GeofencingMasterDaoImpl extends
PersistenceUnitDaoImpl<MpcGeofenceMaster, Long> implements GeofencingMasterDao {

	public GeofencingMasterDaoImpl() {
		super(MpcGeofenceMaster.class);
	}
	
	public GeofencingMasterDaoImpl(Class<MpcGeofenceMaster> persistentClass) {
		super(persistentClass);
	}
	
	@Override
	public List<MaintainGeofenceMasterDTO> getGeofenceMasterList() {
		List<MaintainGeofenceMasterDTO> maintainGeofenceMasterList = new ArrayList<MaintainGeofenceMasterDTO>();

		try {

			EntityManager em = getEntityManager();
			TypedQuery<MpcGeofenceMaster> query = em.createNamedQuery(
					"MpcGeofenceMaster.findAll", MpcGeofenceMaster.class);
			List<MpcGeofenceMaster> results = query.getResultList();
			if (results != null && !results.isEmpty()) {
				for (MpcGeofenceMaster mpcGeofenceMaster : results) {

					MaintainGeofenceMasterDTO maintainGeofenceMasterDTO = new MaintainGeofenceMasterDTO();
					maintainGeofenceMasterDTO.setMgmRecId(String
							.valueOf(mpcGeofenceMaster.getMgmRecId()));
					maintainGeofenceMasterDTO.setMgmRecDate(mpcGeofenceMaster
							.getMgmRecDate().toString());
					if (mpcGeofenceMaster.getTerminalId() != null) {
						maintainGeofenceMasterDTO.setTerminalId(String
								.valueOf(mpcGeofenceMaster.getTerminalId()));
					} else {
						maintainGeofenceMasterDTO.setTerminalId("");
					}
					if (mpcGeofenceMaster.getMgmGFCode() != null) {
						maintainGeofenceMasterDTO.setMgmGFCode(String
								.valueOf(mpcGeofenceMaster.getMgmGFCode()));
					} else {
						maintainGeofenceMasterDTO.setMgmGFCode("");
					}
					if (mpcGeofenceMaster.getMgmGFLat() != null) {
						maintainGeofenceMasterDTO.setMgmGFLat(String
								.valueOf(mpcGeofenceMaster.getMgmGFLat()));
					} else {
						maintainGeofenceMasterDTO.setMgmGFLat("");
					}
					if (mpcGeofenceMaster.getMgmGFLong() != null) {
						maintainGeofenceMasterDTO.setMgmGFLong(String
								.valueOf(mpcGeofenceMaster.getMgmGFLong()));
					} else {
						maintainGeofenceMasterDTO.setMgmGFLong("");
					}
					if (mpcGeofenceMaster.getMgmGFSeqNo() != null) {
						maintainGeofenceMasterDTO.setMgmGFSeqNo(String
								.valueOf(mpcGeofenceMaster.getMgmGFSeqNo()));
					} else {
						maintainGeofenceMasterDTO.setMgmGFSeqNo("");
					}

					if (mpcGeofenceMaster.getIsValid() == 1) {
						maintainGeofenceMasterDTO.setIsValid(MPCConstants.YES);
					} else if (mpcGeofenceMaster.getIsValid() == 0) {
						maintainGeofenceMasterDTO.setIsValid(MPCConstants.NO);
					}

					maintainGeofenceMasterDTO.setSrcSys(mpcGeofenceMaster
							.getSrcSys());

					maintainGeofenceMasterDTO.setCreatedBy(mpcGeofenceMaster
							.getCreatedBy());
					if (mpcGeofenceMaster.getCareatedDate() != null) {
						maintainGeofenceMasterDTO
								.setCreatedOn(mpcGeofenceMaster
										.getCareatedDate().toString());
					}
					if (mpcGeofenceMaster.getModifiedBy() != null) {
						maintainGeofenceMasterDTO
								.setModifiedBy(mpcGeofenceMaster
										.getModifiedBy());
					}
					if (mpcGeofenceMaster.getModifiedDate() != null) {
						maintainGeofenceMasterDTO
								.setModifiedOn(mpcGeofenceMaster
										.getModifiedDate().toString());
					}

					maintainGeofenceMasterList.add(maintainGeofenceMasterDTO);
				}
			}

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return maintainGeofenceMasterList;
	}

	@Transactional
	public void saveOrUpdateMaintainGeofenceMasterData(
			MaintainGeofenceMasterDTO maintainGeofenceDTO) {

		try {
			EntityManager em = getEntityManager();
			Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
			Date date = (Date) queryTime.getSingleResult();

			MpcGeofenceMaster mpcGeofenceMaster = new MpcGeofenceMaster();
			if (MPCConstants.EMPTY_STRING.equals(maintainGeofenceDTO.getMgmRecId())) {
				// Create Data ID
				Query queryResult = em
						.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");
				long id = ((BigDecimal) queryResult.getSingleResult())
						.longValue();
					long mgmRecId = Long.parseLong(MPCUtil.getCurrentYear(date)
							+ String.valueOf(id));
					mpcGeofenceMaster.setMgmRecId(mgmRecId);
				mpcGeofenceMaster.setSrcSys("MPC");
				mpcGeofenceMaster.setCareatedDate(date);
				mpcGeofenceMaster.setCreatedBy(maintainGeofenceDTO
						.getCreatedBy());

			} else {
				String mgmRecId = maintainGeofenceDTO.getMgmRecId();
				long myMgmRecId = Long.parseLong(mgmRecId.trim());
				// Get Data By ID
				mpcGeofenceMaster = em
						.find(MpcGeofenceMaster.class, myMgmRecId);
				mpcGeofenceMaster.setModifiedDate(date);
				mpcGeofenceMaster.setModifiedBy(maintainGeofenceDTO
						.getModifiedBy());
			}
			mpcGeofenceMaster.setMgmRecDate(date);

			if (maintainGeofenceDTO.getTerminalId().length() > 0) {
				mpcGeofenceMaster.setTerminalId(Integer
						.parseInt(maintainGeofenceDTO.getTerminalId()));
			} else {
				mpcGeofenceMaster.setTerminalId(null);
			}

			if (maintainGeofenceDTO.getMgmGFCode().length() > 0) {
				mpcGeofenceMaster.setMgmGFCode(maintainGeofenceDTO
						.getMgmGFCode());
			} else {
				mpcGeofenceMaster.setMgmGFCode("");
			}

			if (maintainGeofenceDTO.getMgmGFLat().length() > 0) {
				mpcGeofenceMaster.setMgmGFLat(Float.valueOf(maintainGeofenceDTO
						.getMgmGFLat()));
			} else {
				mpcGeofenceMaster.setMgmGFLat(null);
			}

			if (maintainGeofenceDTO.getMgmGFLong().length() > 0) {
				mpcGeofenceMaster.setMgmGFLong(Float
						.valueOf(maintainGeofenceDTO.getMgmGFLong()));
			} else {
				mpcGeofenceMaster.setMgmGFLong(null);
			}

			if (maintainGeofenceDTO.getMgmGFSeqNo().length() > 0) {
				mpcGeofenceMaster.setMgmGFSeqNo(Integer
						.parseInt(maintainGeofenceDTO.getMgmGFSeqNo()));
			} else {
				mpcGeofenceMaster.setMgmGFSeqNo(null);
			}

			if (maintainGeofenceDTO.getIsValid().equals(MPCConstants.YES)) {
				mpcGeofenceMaster.setIsValid(1);
			} else if (maintainGeofenceDTO.getIsValid().equals(MPCConstants.NO)) {
				mpcGeofenceMaster.setIsValid(0);
			}

			em.persist(mpcGeofenceMaster);
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}
	}
}
