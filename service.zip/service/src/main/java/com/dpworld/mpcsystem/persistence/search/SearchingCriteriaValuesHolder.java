package com.dpworld.mpcsystem.persistence.search;

/**
 * @Author Rahul Singh
 * @For : Searching criteria and parameters holder
 */
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.dpworld.mpcsystem.persistence.search.SearchFlow.SearchFlowFactoryContext;

public class SearchingCriteriaValuesHolder<E, W> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private transient Map<String, String> diffPropT2S = new HashMap<String, String>();
	private Class<E> entityClass;
	private Class<?> aliasClass;
	private transient E entity;
	private transient W wsbean;
	private Class<W> wsClass;
	private transient List<?> result;
	private transient SearchFlow<?, E, W> flow;
	private transient SearchFlowFactoryContext<?, E, W> serviceImpl;

	private transient Set<String> searchingProperty = new HashSet<String>();
	private Integer searchingResultLimit;

	public Class<?> getAliasClass() {
		return aliasClass;
	}

	public void setAliasClass(Class<?> aliasClass) {
		this.aliasClass = aliasClass;
	}

	public W getWsbean() {
		return wsbean;
	}

	public void setWsbean(W wsbean) {
		this.wsbean = wsbean;
	}

	public E getEntity() {
		return entity;
	}

	public void setEntity(E entity) {
		this.entity = entity;
	}

	public Map<String, String> getDiffPropT2S() {
		return diffPropT2S;
	}

	public void setDiffPropT2S(Map<String, String> diffPropT2S) {
		this.diffPropT2S = diffPropT2S;
	}

	public List<?> getResult() {
		return result;
	}

	public void setResult(List<?> result) {
		this.result = result;
	}

	public SearchFlow<?, E, W> getFlow() {
		return flow;
	}

	public void setFlow(SearchFlow<?, E, W> flow) {
		this.flow = flow;
	}

	public SearchFlowFactoryContext<?, E, W> getServiceImpl() {
		return serviceImpl;
	}

	public void setServiceImpl(SearchFlowFactoryContext<?, E, W> serviceImpl) {
		this.serviceImpl = serviceImpl;
	}

	public Class<E> getEntityClass() {
		return entityClass;
	}

	public void setEntityClass(Class<E> entityClass) {
		this.entityClass = entityClass;
	}

	public Class<W> getWsClass() {
		return wsClass;
	}

	public void setWsClass(Class<W> wsClass) {
		this.wsClass = wsClass;
	}

	/*
	 * public CommonExceptionHelper getCommonExceptionHelper() { return
	 * commonExceptionHelper; } public void
	 * setCommonExceptionHelper(CommonExceptionHelper commonExceptionHelper) {
	 * this.commonExceptionHelper = commonExceptionHelper; }
	 */
	public Set<String> getSearchingProperty() {
		return searchingProperty;
	}

	public void addSearchingProperty(String... properties) {
		searchingProperty.addAll(Arrays.asList(properties));
	}

	public Integer getSearchingResultLimit() {
		return searchingResultLimit;
	}

	public void setSearchingResultLimit(Integer searchingResultLimit) {
		this.searchingResultLimit = searchingResultLimit;
	}

}
