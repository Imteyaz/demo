package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.persistence.dao.ScoreMasterDao;
import com.dpworld.mpcsystem.persistence.model.MpcScoreMaster;

@Repository("scoreMasterDao")
public class ScoreMasterDaoImpl extends
PersistenceUnitDaoImpl<MpcScoreMaster, Long> implements ScoreMasterDao{
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ScoreMasterDaoImpl.class);
	public ScoreMasterDaoImpl() {
		super(MpcScoreMaster.class);
	}

	public ScoreMasterDaoImpl(Class<MpcScoreMaster> persistentClass) {
		super(persistentClass);
	}
	

	/*
	 * Get Maintain Score List 
	 * 
	 * 
	 * */
	@Override
	public List<MaintainScoreDTO> getMaintainScoreList() {

		List<MaintainScoreDTO> maintainScoreList = new ArrayList<MaintainScoreDTO>();

		try {

			EntityManager em = getEntityManager();
			TypedQuery<MpcScoreMaster> query = em.createNamedQuery(
					"MpcScoreMaster.findAll", MpcScoreMaster.class);
			List<MpcScoreMaster> results = query.getResultList();
			if (results != null && results.size() > 0) {
				for (MpcScoreMaster mpcScoreMaster : results) {

					MaintainScoreDTO maintainScoreDTO = new MaintainScoreDTO();
					maintainScoreDTO.setRecId(String.valueOf(mpcScoreMaster
							.getRecId()));
					maintainScoreDTO.setRecDate(mpcScoreMaster.getRecDate()
							.toString());
					maintainScoreDTO.setMsmCritType(mpcScoreMaster
							.getMsmCritType());
					maintainScoreDTO.setMsmCritVal(mpcScoreMaster
							.getMsmCritVal());
					maintainScoreDTO.setMsmScore(mpcScoreMaster.getMsmScore()
							.toString());
					maintainScoreDTO.setMsmScoreType(mpcScoreMaster
							.getMsmScoreType());
					if (mpcScoreMaster.getIsValid() == 1) {
						maintainScoreDTO.setIsValid(MPCConstants.YES);
					} else if (mpcScoreMaster.getIsValid() == 0) {
						maintainScoreDTO.setIsValid(MPCConstants.NO);
					}
					maintainScoreDTO.setUserCode(mpcScoreMaster.getUserCode());
					maintainScoreDTO
					.setCreatedBy(mpcScoreMaster.getCreatedBy());
					if (mpcScoreMaster.getCreatedOn() != null) {
						maintainScoreDTO.setCreatedOn(mpcScoreMaster
								.getCreatedOn().toString());
					}
					if (mpcScoreMaster.getModifiedBy() != null) {
						maintainScoreDTO.setModifiedBy(mpcScoreMaster
								.getModifiedBy());
					}
					if (mpcScoreMaster.getModifiedOn() != null) {
						maintainScoreDTO.setModifiedOn(mpcScoreMaster
								.getModifiedOn().toString());
					}

					maintainScoreList.add(maintainScoreDTO);
				}
			}

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return maintainScoreList;
	}


	/**
	 * Save and Update Maintain Score Details
	 */
	@Transactional
	public void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO) {

		EntityManager em = getEntityManager();
		Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
		Date date = (Date) queryTime.getSingleResult();

		MpcScoreMaster mpcScoreMaster = new MpcScoreMaster();

		// If SAVE
		if (maintainScoreDTO.getRecId().equals("")) {

			Query queryResult = em
					.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");
			long id = ((BigDecimal) queryResult.getSingleResult()).longValue();

			try {
				long recId = Long.parseLong(MPCUtil.getCurrentYear(date)
						+ String.valueOf(id));
				mpcScoreMaster.setRecId(recId);
			} catch (Exception er) {
				LOGGER.error(er.getMessage());
			}
			mpcScoreMaster.setRecDate(date);
			mpcScoreMaster.setMsmScoreType(maintainScoreDTO.getMsmScoreType());
			mpcScoreMaster.setMsmCritType(maintainScoreDTO.getMsmCritType());
			mpcScoreMaster.setMsmCritVal(maintainScoreDTO.getMsmCritVal());

			if (!maintainScoreDTO.getMsmScore().equals("")
					|| maintainScoreDTO.getMsmScore() != null) {
				mpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO
						.getMsmScore()));
			}

			mpcScoreMaster.setUserCode(maintainScoreDTO.getUserCode());
			if (maintainScoreDTO.getIsValid().equals(MPCConstants.YES)) {
				mpcScoreMaster.setIsValid(1);
			} else if (maintainScoreDTO.getIsValid().equals(MPCConstants.NO)) {
				mpcScoreMaster.setIsValid(0);
			}

			mpcScoreMaster.setCreatedOn(date);
			mpcScoreMaster.setCreatedBy(maintainScoreDTO.getCreatedBy());

			em.persist(mpcScoreMaster);

		} // IF UPDATE
		else {
			String recID = maintainScoreDTO.getRecId();
			long myRecId = Long.parseLong(recID.trim());
			// Get Data By ID
			MpcScoreMaster upMpcScoreMaster = new MpcScoreMaster();
			upMpcScoreMaster = em.find(MpcScoreMaster.class, myRecId);

			// Set Values in DTO
			upMpcScoreMaster
			.setMsmScoreType(maintainScoreDTO.getMsmScoreType());
			upMpcScoreMaster.setMsmCritType(maintainScoreDTO.getMsmCritType());
			upMpcScoreMaster.setMsmCritVal(maintainScoreDTO.getMsmCritVal());

			upMpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO
					.getMsmScore()));

			if (!maintainScoreDTO.getMsmScore().equals("")
					|| maintainScoreDTO.getMsmScore() != null) {
				upMpcScoreMaster.setMsmScore(Integer.parseInt(maintainScoreDTO
						.getMsmScore()));
			}

			if (maintainScoreDTO.getIsValid().equals(MPCConstants.YES)) {
				upMpcScoreMaster.setIsValid(1);
			} else if (maintainScoreDTO.getIsValid().equals(MPCConstants.NO)) {
				upMpcScoreMaster.setIsValid(0);
			}

			upMpcScoreMaster.setUserCode(maintainScoreDTO.getUserCode());
			upMpcScoreMaster.setModifiedBy(maintainScoreDTO.getModifiedBy());
			upMpcScoreMaster.setModifiedOn(date);

			em.persist(upMpcScoreMaster);

		}

	}
}
