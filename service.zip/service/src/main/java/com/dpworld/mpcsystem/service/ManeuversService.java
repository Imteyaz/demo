package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;

public interface ManeuversService {

	List<GeoFenceViewDTO> getGeoFenceVesselList(String mgdObjName);
}
