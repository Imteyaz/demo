package com.dpworld.mpcsystem.helper;

/**
 * Enum class for defining the response codes
 * 
 */
public enum ResponseCode {
	SUCCESS, PENDING, FAILED
}
