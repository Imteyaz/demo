/**
 * 
 */
package com.dpworld.mpcsystem.service;

import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.admin.model.User;
import com.dpworld.mpcsystem.admin.wsdl.UserInfoResultModel;

@Service
public interface AuthClientService {

  UserInfoResultModel authenticateUser(User user);
}
