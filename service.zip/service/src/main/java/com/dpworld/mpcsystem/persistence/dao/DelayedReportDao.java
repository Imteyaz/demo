package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailReportDTO;

public interface DelayedReportDao {
	
	List<VesselDetailReportDTO> getRotationList();
	List<VesselDetailReportDTO> getCompRotationList();
	
}
