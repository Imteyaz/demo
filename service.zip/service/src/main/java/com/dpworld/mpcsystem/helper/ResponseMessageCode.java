package com.dpworld.mpcsystem.helper;

public enum ResponseMessageCode {
	FAILED_NO_RECORD, FAILED_SAVE, FAILED_DUPLICATE_SAVE, FAILED_SERVICE, FAILED_NO_RECORD_TO_SAVE, FAILED_SESSION_EXPIRED
}
