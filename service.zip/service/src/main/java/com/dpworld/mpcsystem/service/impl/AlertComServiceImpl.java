package com.dpworld.mpcsystem.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.utility.pojo.ConversationDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;
import com.dpworld.mpcsystem.common.utility.pojo.FilterConversationsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.Response;
import com.dpworld.mpcsystem.common.utility.pojo.SubscribedUserDTO;
import com.dpworld.mpcsystem.common.utility.pojo.TrendingViewDTO;
import com.dpworld.mpcsystem.persistence.dao.AlertComDao;
import com.dpworld.mpcsystem.persistence.dao.impl.AlertComDaoImpl;
import com.dpworld.mpcsystem.service.AlertComService;




@Service("alertComService")
public class AlertComServiceImpl implements AlertComService{
	
	
	@Autowired
	AlertComDao alertComDao;
	
	private static AlertComServiceImpl alertComServiceImpl ;
	
	/*@Autowired
	private Conversationcomment conversationcomment;
	*/
private AlertComServiceImpl(){
		
	}

	public static AlertComServiceImpl  getAlertComServiceImplInstance(){
		if(null==alertComServiceImpl){
			return new AlertComServiceImpl();
		}else{
			return alertComServiceImpl;
		}
	}

	public List<ConversationDTO> findAllConversationInfoOrderByDate(String userName, String flag, String roleName) {
		return alertComDao.findAllConversationInfoOrderByDate(userName, flag, roleName);
	}
	
	public List<TrendingViewDTO> findAllTrendingInfoOrderByDate(String userName) {
		return alertComDao.findAllTrendingInfoOrderByDate(userName);
	}

	
	@Transactional
	public String addConversation(ConversationDTO conversationdto) {
	return alertComDao.addConversation(conversationdto);
		}
		
	
	public void addCommentConversation(ConversationDTO conversationdto) {
		
		 alertComDao.addCommentConversation(conversationdto);
	}

	@Override
	public Response userStatus( String convId, String statusCode, String recId, String loginUserName) {
		return alertComDao.userStatus(convId,statusCode, recId, loginUserName);
		
	}

	@Override
	public List<ConversationDTO> findConversationById(String conversationId) {
		return alertComDao.findConversationById(conversationId);
	}

	
	@Override
	public List<ConversationDTO> findConversationById(String conversationId,String conversationType) {
		return alertComDao.findConversationById(conversationId,conversationType);
	}
	
	/*public List<ConversationDTO> getAllMessagesByConversationId(int ConversationId) {
		
		return alertComDao.getAllMessagesByConversationId(ConversationId);
	}*/


	/*@Override
	@Transactional
	public List<Conversation> findAllConversionInfoByVesselName(String vesselName) {
		return conversationDAOInterFace.findAllConversionInfoByVesselName(vesselName);
	}*/
	public List<ConversationDTO> getRecentAlertByUserCodeRole(String userCode, String roleName) {
		
		return alertComDao.getRecentAlertByUserCodeRole(userCode, roleName);
	}
    public Map getRecentAlertByUserCode(String userCode, String roleName) {
    	if(null==alertComDao)
    		alertComDao = AlertComDaoImpl.getAlertComDaoImplInstance();
		return alertComDao.getRecentAlertByUserCode(userCode, roleName);
	}

	
	public List<ConversationSubDTO> findSubscribedUserListByConvId(String convId) {
		return alertComDao.findSubscribedUserListByConvId(convId);
	}

		public List<ConversationSubDTO> findSubscribedUserListByConvId(String convId,String convType) {
		// TODO Auto-generated method stub
		return alertComDao.findSubscribedUserListByConvId(convId,convType);
	}

	
	public List<ConversationDTO> filterConversationsByCriteria(
			FilterConversationsDTO filterConversationsDTO) {
		
		return alertComDao.filterConversationsByCriteria(filterConversationsDTO);
	}


	@Override
	public List<SubscribedUserDTO> findSubscribedData(String userName) {
		 return alertComDao.findSubscribedData(userName);
	}


	
	public List<ConversationDTO> getAlertsForVesselListByUserCode(
			String userCode, String roleName) {
		
		return alertComDao.getAlertsForVesselListByUserCode(userCode, roleName);
	}

	@Override
	public String addNewUsers(ConversationSubDTO conversationSubDTO) {
		return alertComDao.addNewUsers(conversationSubDTO);
	}


	
	public List<ConversationDTO> getAlertsForVesselListByTopic(
			String topicValue, String userCode, String roleCode) {
		
		return alertComDao.getAlertsForVesselListByTopic(topicValue, userCode, roleCode);
	}
}
