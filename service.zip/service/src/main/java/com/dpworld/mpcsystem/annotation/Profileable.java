package com.dpworld.mpcsystem.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.stereotype.Component;

/**
 * For calculate execution time of method
 * 
 * @author T2943 - Kathiravan Manickam
 * 
 */
@Component
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Profileable {

}
