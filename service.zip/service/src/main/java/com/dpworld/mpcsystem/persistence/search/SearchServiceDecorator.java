package com.dpworld.mpcsystem.persistence.search;

/**
 * @Author : Rahul Singh
 * @For : Implementation for searching service instance decoration with additional features.
 * 
 */
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;

import org.apache.log4j.Logger;

import com.dpworld.mpcsystem.common.GenericException;
import com.dpworld.mpcsystem.persistence.search.SearchFlow.SearchFlowFactoryContext;

public class SearchServiceDecorator<T, E, W> implements InvocationHandler {

	private static final Logger LOG = Logger
			.getLogger("com.nbad.echannel.persistence.search.CommunicatorDecorator");
	private final SearchFlow<T, E, W> flow;
	private SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder;

	private SearchServiceDecorator(SearchFlow<T, E, W> flow,
			SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
		this.flow = flow;
		this.searchingCriteriaValuesHolder = searchingCriteriaValuesHolder;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Exception, GenericException {

		final SearchFlowFactoryContext<T, E, W> serviceImpl = flow
				.getSearchFlowContext();
		CommunicatorStateOperator<E, W> communicatorStateOperator = new CommunicatorStateOperator<E, W>();
		searchingCriteriaValuesHolder.setFlow(flow);
		searchingCriteriaValuesHolder.setServiceImpl(serviceImpl);
		boolean searchCriteria = communicatorStateOperator
				.searchCriteriaValidate(searchingCriteriaValuesHolder);
		if (!searchCriteria) {

			GenericException genericException = null;
			throw genericException;
		}
		searchingCriteriaValuesHolder.setEntity((E) (args[0]));
		E param = communicatorStateOperator
				.callOperationBeforeSearch(searchingCriteriaValuesHolder);
		Object result = null;
		try {
			result = method.invoke(serviceImpl.getCommunicatorModule(), param);

		} catch (InvocationTargetException e) {
			LOG.error("InvocationTargetException while returning account Number --> "
					+ e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("Exception while returning account Number --> "
					+ e.getMessage());
			throw e;
		} finally {
			searchingCriteriaValuesHolder.setResult((List<?>) result);
			communicatorStateOperator
					.callOperationAfterSearch(searchingCriteriaValuesHolder);
		}
		return result;
	}

	public static <T, E, W> T decorate(SearchFlow<T, E, W> flow,
			SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
		return decorate(LOG, flow, searchingCriteriaValuesHolder);
	}

	@SuppressWarnings("unchecked")
	public static <T, E, W> T decorate(Logger logger, SearchFlow<T, E, W> flow,
			SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
		LOG.info("decorate Method -->logger,flow " + logger + " " + flow);
		final SearchServiceDecorator<T, E, W> handler = new SearchServiceDecorator<T, E, W>(
				flow, searchingCriteriaValuesHolder);
		final ClassLoader classLoader = flow.serviceFactoryInterface
				.getClassLoader();
		LOG.info("Returned an instance of a proxy class in decorate Method -->logger,flow "
				+ logger + " " + flow + " ");
		return (T) Proxy.newProxyInstance(classLoader,
				new Class<?>[] { flow.serviceFactoryInterface }, handler);
	}
}
