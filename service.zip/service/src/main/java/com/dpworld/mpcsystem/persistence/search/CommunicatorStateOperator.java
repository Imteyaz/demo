package com.dpworld.mpcsystem.persistence.search;

import java.util.List;

import com.dpworld.mpcsystem.common.GenericException;

public class CommunicatorStateOperator<E, W> {

	public E callOperationBeforeSearch(
			SearchingCriteriaValuesHolder<E, W> holder) {
		return holder.getServiceImpl().beforeSearch(holder);
	}

	public List<W> callOperationAfterSearch(
			SearchingCriteriaValuesHolder<E, W> holder) throws GenericException {
		List<W> list = holder.getServiceImpl().transformResult(holder);
		holder.getFlow().setOutputObject(list);
		return list;
	}

	public boolean searchCriteriaValidate(
			SearchingCriteriaValuesHolder<E, W> holder) throws GenericException {
		return holder.getServiceImpl().validate(holder);
	}
}
