package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_geofence_data")
@NamedQuery(name = "MpcGeoFenceData.findAll", query = "SELECT m FROM MpcGeoFenceData m")
public class MpcGeoFenceData {

	@Id
	@Column(name = "MGD_REC_ID")
	private long mgdRecId;

	@Temporal(TemporalType.DATE)
	@Column(name = "MGD_REC_DATE")
	private Date mgdRecDate;

	@Column(name = "MGM_GF_CODE")
	private String mgmGfCode;

	@Column(name = "MGD_OBJ_TYPE")
	private String mgdObjType;

	@Column(name = "MGD_OBJ_NAME")
	private String mgdObjName;

	@Column(name = "MGD_OBJ_CODE")
	private String mgdObjCode;
	@Column(name = "MGD_OBJ_ID")
	private String mgdObjId;

	@Temporal(TemporalType.DATE)
	@Column(name = "MGD_OBJ_ENTRY")
	private Date mgdObjEntry;

	@Temporal(TemporalType.DATE)
	@Column(name = "MGD_OBJ_EXIT")
	private Date mgdObjExit;

	@Column(name = "IS_VALID")
	private Integer isValid;

	@Column(name = "SRC_SYS")
	private String srcSys;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_DATE")
	private Date careatedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	public long getMgdRecId() {
		return mgdRecId;
	}

	public void setMgdRecId(long mgdRecId) {
		this.mgdRecId = mgdRecId;
	}

	public Date getMgdRecDate() {
		return mgdRecDate;
	}

	public void setMgdRecDate(Date mgdRecDate) {
		this.mgdRecDate = mgdRecDate;
	}

	public String getMgmGfCode() {
		return mgmGfCode;
	}

	public void setMgmGfCode(String mgmGfCode) {
		this.mgmGfCode = mgmGfCode;
	}

	public String getMgdObjType() {
		return mgdObjType;
	}

	public void setMgdObjType(String mgdObjType) {
		this.mgdObjType = mgdObjType;
	}

	public String getMgdObjName() {
		return mgdObjName;
	}

	public void setMgdObjName(String mgdObjName) {
		this.mgdObjName = mgdObjName;
	}

	public String getMgdObjCode() {
		return mgdObjCode;
	}

	public void setMgdObjCode(String mgdObjCode) {
		this.mgdObjCode = mgdObjCode;
	}

	public String getMgdObjId() {
		return mgdObjId;
	}

	public void setMgdObjId(String mgdObjId) {
		this.mgdObjId = mgdObjId;
	}

	public Date getMgdObjEntry() {
		return mgdObjEntry;
	}

	public void setMgdObjEntry(Date mgdObjEntry) {
		this.mgdObjEntry = mgdObjEntry;
	}

	public Date getMgdObjExit() {
		return mgdObjExit;
	}

	public void setMgdObjExit(Date mgdObjExit) {
		this.mgdObjExit = mgdObjExit;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCareatedDate() {
		return careatedDate;
	}

	public void setCareatedDate(Date careatedDate) {
		this.careatedDate = careatedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
	public String toString() {
		return "MpcGeoFenceData [mgdRecId=" + mgdRecId + ", mgdRecDate="
				+ mgdRecDate + ", mgmGfCode=" + mgmGfCode + ", mgdObjType="
				+ mgdObjType + ", mgdObjName=" + mgdObjName + ", mgdObjCode="
				+ mgdObjCode + ", mgdObjId=" + mgdObjId + ", mgdObjEntry="
				+ mgdObjEntry + ", mgdObjExit=" + mgdObjExit + ", isValid="
				+ isValid + ", srcSys=" + srcSys + ", createdBy=" + createdBy
				+ ", careatedDate=" + careatedDate + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate + "]";
	}
}
