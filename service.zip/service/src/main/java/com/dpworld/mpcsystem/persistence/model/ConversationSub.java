package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name="MPC_CONV_SUBSCR")
public class ConversationSub {

	
	@Id
	@Column(name="rec_id")
	private long recId;
	
	
	
	@Temporal(TemporalType.DATE)
	@Column(name="rec_date")
	private Date recdate;
	
	@Column(name="alt_id")
	private Integer altId;
	
	@Column(name="conv_id")
	private Long convId;
	
	@Column(name="user_code")
	private String userCode;
	
	
	@Column(name="role_code")
	private String roleCode;
	
	@Column(name="subscr_status")
	private String subscrStatus;
	
	@Column(name="is_valid")
	private Integer isValid;
	
	@Column(name="src_sys")
	private String srcSys;
	
	@Temporal(TemporalType.DATE)
	@Column(name="created_on")
	private Date createdOn;
	

	@Column(name="created_by")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name="modified_on")
	private Date modifiedOn;
	

	@Column(name="modified_by")
	private String modifiedBy;
	
	
	
	


	public ConversationSub() {
		super();
	}


	public ConversationSub(Integer recId, Date recdate, Integer altId, Long convId,
			String userCode, String roleCode, String subscrStatus, Integer isValid,
			String srcSys, Date createdOn, String createdBy, Date modifiedOn,
			String modifiedBy) {
		super();
		this.recId = recId;
		this.recdate = recdate;
		this.altId = altId;
		this.convId = convId;
		this.userCode = userCode;
		this.roleCode = roleCode;
		this.subscrStatus = subscrStatus;
		this.isValid = isValid;
		this.srcSys = srcSys;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}


	public long getRecId() {
		return recId;
	}


	public void setRecId(long recId) {
		this.recId = recId;
	}


	public Date getRecdate() {
		return recdate;
	}


	public void setRecdate(Date recdate) {
		this.recdate = recdate;
	}


	public Integer getAltId() {
		return altId;
	}


	public void setAltId(Integer altId) {
		this.altId = altId;
	}


	public Long getConvId() {
		return convId;
	}


	public void setConvId(Long convId) {
		this.convId = convId;
	}


	public String getUserCode() {
		return userCode;
	}


	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}


	public String getRoleCode() {
		return roleCode;
	}


	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}


	public String getSubscrStatus() {
		return subscrStatus;
	}


	public void setSubscrStatus(String subscrStatus) {
		this.subscrStatus = subscrStatus;
	}


	public Integer getIsValid() {
		return isValid;
	}


	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}


	public String getSrcSys() {
		return srcSys;
	}


	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
}
