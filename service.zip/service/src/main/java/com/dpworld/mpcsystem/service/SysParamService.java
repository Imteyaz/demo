package com.dpworld.mpcsystem.service;

import java.util.List;
import java.util.Map;

import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;

public interface SysParamService {
	
	List<SysParamDetailDTO> getSysParamData();

	public void addSysParam(SysParamDetailDTO sysParamDetailDTO);
	
	List<SysParamDetailDTO> getSysParamDetailsByCategory(String paramCategory);
	
	   public Map<String,String> getSysParamDetailsByCode() ;
	   public Map<String,String> getSysParamAutoRefresh(String mspParamCatg,String mspParamGroup,String mspParamCode) ;
	   
	   List<SysParamDetailDTO> getVesselDegreeByCategory(String category, String group);
	   SysParamDetailDTO saveOrUpdateSysparamForColorChange(SysParamDetailDTO sysParamDetailDTO, String category);
	   List<SysParamDetailDTO> getDefaultVesselColor(String category);
	   List<SysParamDetailDTO> getSysParamDataByUserCode(String userCode, String category, String status);
	   List<SysParamDetailDTO> getColorCodeAsUser(String paramCategory, String paramGroup,
				String paramCode);
	void saveOrUpdateLRAD(String userCode);
}
