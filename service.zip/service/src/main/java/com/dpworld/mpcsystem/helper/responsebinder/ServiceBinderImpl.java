package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.dpworld.mpcsystem.common.exception.MpcSystemException;
import com.dpworld.mpcsystem.helper.Method;
import com.dpworld.mpcsystem.helper.ResponseCode;
import com.dpworld.mpcsystem.helper.ResponseMessageCode;

public class ServiceBinderImpl implements ServiceBinder {
	private ResponseCode responseCodeValue = null;
	private ResponseMessageCode responseMessageCode = null;
	private String statusMessageValue = null;
	private byte[] picutreDataValue = null;
	private Date requestDateValue = null;
	private Date responseDateValue = null;
	private Method methodValue = null;
	private Map<String, String> localBinderValue = new HashMap<String, String>();
	private Map<String, ResultSet> resultSetsValue = new HashMap<String, ResultSet>();

	private final static Logger LOG = Logger.getLogger(ServiceBinderImpl.class);

	/**
	 * Retrieves the ServiceBinder's response code property.
	 * 
	 * @throws RuntimeException
	 * @return ResponseCode
	 * @see ServiceBinder
	 */
	public ResponseCode getResponseCode() throws MpcSystemException {
		LOG.debug("Inside getResponseCode Method ");
		try {
			return responseCodeValue;
		} catch (Exception e) {
			LOG.error(
					"Exception in getResponseCode Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's response code property.
	 * 
	 * @param responseCode
	 *            The response code of the ServiceBinder's HTTP request, e.g.,
	 *            200, 400
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see ResponseCode
	 */
	public void setResponseCode(ResponseCode responseCodeVal)
			throws MpcSystemException {
		LOG.debug("Inside setResponseCode Method :responseCode --> "
				+ responseCodeVal);
		try {
			responseCodeValue = responseCodeVal;
		} catch (Exception e) {
			LOG.error(
					"Exception in setResponseCode Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Retrieves the ServiceBinder's response code property.
	 * 
	 * @throws RuntimeException
	 * @return ResponseCode
	 * @see ServiceBinder
	 */
	public ResponseMessageCode getResponseMessageCode() throws MpcSystemException {
		LOG.debug("Inside getResponseMessageCode Method ");
		try {
			return responseMessageCode;
		} catch (Exception e) {
			LOG.error(
					"Exception in getResponseMessageCode Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's response code property.
	 * 
	 * @param responseCode
	 *            The response code of the ServiceBinder's HTTP request, e.g.,
	 *            200, 400
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see ResponseCode
	 */
	public void setResponseMessageCode(ResponseMessageCode responseMessageCodeVal)
			throws MpcSystemException {
		LOG.debug("Inside setResponseMessageCode Method ");
		try {
			responseMessageCode = responseMessageCodeVal;
		} catch (Exception e) {
			LOG.error(
					"Exception in setResponseMessageCode Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Retrieves the ServiceBinder's status message property.
	 * 
	 * @throws RuntimeException
	 * @return String
	 * @see ServiceBinder
	 */
	public String getStatusMessage() throws MpcSystemException {
		LOG.debug("Inside getStatusMessage Method ");
		try {
			return statusMessageValue;
		} catch (Exception e) {
			LOG.error(
					"Exception in getStatusMesssage Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's status message property.
	 * 
	 * @param statusMessage
	 *            The status message of the Service Binder's
	 * 
	 * @throws RuntimeException
	 * @see ServiceBinder
	 */
	public void setStatusMessage(String statusMessage) throws MpcSystemException {
		LOG.debug("Inside setStatusMessage Method ");
		try {
			statusMessageValue = statusMessage;
		} catch (Exception e) {
			LOG.error(
					"Exception in setStatusMessage Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Retrieves the ServiceBinder's request date property.
	 * 
	 * @throws RuntimeException
	 * @return Date
	 * @see ServiceBinder
	 */
	public Date getRequestDate() throws MpcSystemException {
		LOG.debug("Inside getRequestDate Method ");
		try {
			return requestDateValue;
		} catch (Exception e) {
			LOG.error(
					"Exception in getRequestDate Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's request date property.
	 * 
	 * @param requestDate
	 *            The date of the request.
	 * @throws RuntimeException
	 * @see ServiceBinder
	 */
	public void setRequestDate(Date requestDate) throws MpcSystemException {
		LOG.debug("Inside setRequestDate Method ");
		try {
			requestDateValue = requestDate;
		} catch (Exception e) {
			LOG.error(
					"Exception in setRequestDate Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Retrieves the ServiceBinder's response date property.
	 * 
	 * @throws RuntimeException
	 * @return DATE
	 * @see ServiceBinder
	 */
	public Date getResponseDate() throws MpcSystemException {
		LOG.debug("Inside getResponseDate Method ");
		try {
			return responseDateValue;
		} catch (Exception e) {
			LOG.error(
					"Exception in getResponseDate Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's response date property.
	 * 
	 * @param responseDate
	 *            The date of the response
	 * @throws RuntimeException
	 * @see ServiceBinder
	 */
	public void setResponseDate(Date responseDate) throws MpcSystemException {
		LOG.debug("Inside setResponseDate Method ");
		try {
			responseDateValue = responseDate;
		} catch (Exception e) {
			LOG.error(
					"Exception in setResponseDate Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Retrieves the ServiceBinder's method property.
	 * 
	 * @throws RuntimeException
	 * @return Method
	 * @see ServiceBinder
	 */
	public Method getMethod() throws MpcSystemException {
		LOG.debug("Inside getMethod Method ");
		try {
			return methodValue;
		} catch (Exception e) {
			LOG.error("Exception in getMethod Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Sets the ServiceBinder's method property.
	 * 
	 * @param method
	 *            The method of the ServiceBinder's HTTP request, e.g., POST,
	 *            GET, PUT, and DELETE.
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see Method
	 */
	public void setMethod(Method method) throws MpcSystemException {
		LOG.debug("Inside setMethod Method ");
		try {
			methodValue = method;
		} catch (Exception e) {
			LOG.error("Exception in setMethod Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Adds key value pair to ServiceBinder object
	 * 
	 * @param name
	 *            The key value of the key/value pair.
	 * @param value
	 *            The value of the key/value pair.
	 * @throws RuntimeException
	 * @see ServiceBinder
	 */
	public void putLocal(String name, String value) throws MpcSystemException {
		LOG.debug("Inside putLocal Method :name,value --> " + name + " " + value);
		try {
			if (name != null && !name.equals("")) {
				if (localBinderValue.containsKey(name)) {
					localBinderValue.remove(name);
				}
				if (value != null && !value.equals("")) {
					localBinderValue.put(name, value);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception in putLocal Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Gets value of key value pair when passed a name
	 * 
	 * @param name
	 *            The key of the desired value.
	 * @throws RuntimeException
	 * @return String
	 * @see ServiceBinder
	 */
	public String getLocal(String name) throws MpcSystemException {
		LOG.debug("Inside getLocal Method:name -->" + name);
		try {
			String result = null;
			if (name != null && !name.equals("")) {
				if (localBinderValue.containsKey(name)) {
					result = localBinderValue.get(name);
				}
			}
			return result;
		} catch (Exception e) {
			LOG.error("Exception in getLocal Method -->" + e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Gets the local binder of the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @return Map<String, String>
	 * @see ServiceBinder
	 */
	public Map<String, String> getBinder() throws MpcSystemException {
		LOG.debug("Inside getBinder Method ");
		try {
			LOG.debug("returned getBinder Method :: " + localBinderValue);
			return localBinderValue;
		} catch (Exception e) {
			LOG.error("Exception in getBinder Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Gets resultSets that contains key from the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @return ResultSet
	 * @see ServiceBinder
	 * @see ResultSet
	 */
	public ResultSet getResultSet(String name) throws MpcSystemException {
		LOG.debug("Inside getResultSet Method ");
		try {
			ResultSet result = null;
			if (resultSetsValue.containsKey(name)) {
				result = resultSetsValue.get(name);
			}
			LOG.debug("getResultSet Method result :: " + result);
			return result;
		} catch (Exception e) {
			LOG.error(
					"Exception in getResultSet Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Gets all resultSets from the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @return Map<String, ResultSet>
	 * @see ServiceBinder
	 * @see ResultSet
	 */
	public Map<String, ResultSet> getResultSets() throws MpcSystemException {
		LOG.debug("Inside getResultSets Method ");
		try {
			LOG.debug("returned resultSets in getResultSets Method ::  "
					+ resultSetsValue);
			return resultSetsValue;
		} catch (Exception e) {
			LOG.error(
					"Exception in getResultSets Method --> "
							+ e.getStackTrace(), e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Adds a resultSet to the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see ResultSet
	 */
	public void addResultSet(String name, ResultSet resultset)
			throws MpcSystemException {
		LOG.debug("Inside addResultSet Method ");
		try {
			if (name != null && !name.equals("")) {
				resultSetsValue.put(name, resultset);
			}
		} catch (Exception e) {
			LOG.error(
					"Exception in addResultSet Method --> " + e.getStackTrace(),
					e);
			throw new MpcSystemException(e);
		}
	}

	/**
	 * Adds a image binary data to the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see ResultSet
	 */
	@Override
	public void setPicture(byte[] value) {
		picutreDataValue = value;

	}

	/**
	 * Gets a image binary data from the ServiceBinder
	 * 
	 * @throws RuntimeException
	 * @see ServiceBinder
	 * @see ResultSet
	 */
	@Override
	public byte[] getPicture() {
		return picutreDataValue;
	}

}
