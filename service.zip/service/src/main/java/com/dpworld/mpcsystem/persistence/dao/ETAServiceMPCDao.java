package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;

public interface ETAServiceMPCDao {
	List<VesselDetailsDTO> getVesseldetails();
}
