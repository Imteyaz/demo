package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_sys_params")
@NamedQuery(name = "MpcSysParams.findAll", query = "SELECT m FROM MpcSysParams m ORDER BY m.recId DESC")
public class MpcSysParams {
	
	@Override
	public String toString() {
		return "MpcSysParams [recId=" + recId + ", mspParamCatg="
				+ mspParamCatg + ", mspParamGroup=" + mspParamGroup
				+ ", mspParamCode=" + mspParamCode + ", mspChar1=" + mspChar1
				+ ", mspChar2=" + mspChar2 + ", mspNum1=" + mspNum1
				+ ", mspNum2=" + mspNum2 + ", mspDate1=" + mspDate1
				+ ", mspDate2=" + mspDate2 + ", mspVal1=" + mspVal1
				+ ", mspVal2=" + mspVal2 + ", mspVal3=" + mspVal3 + ", srcSys="
				+ srcSys + ", isValid=" + isValid + ", createdOn=" + createdOn
				+ ", createdBy=" + createdBy + ", modifiedOn=" + modifiedOn
				+ ", modifiedBy=" + modifiedBy + "]";
	}

	@Id
	@Column(name = "rec_id ")
	private long recId;
	
	@Column(name = "msp_param_catg")
	private String mspParamCatg;
	
	@Column(name = "msp_param_group")
	 private String mspParamGroup;
	
	@Column(name = "msp_param_code")
	 private String mspParamCode;
	
	@Column(name = "msp_char1")
	 private String mspChar1;
	
	@Column(name = "msp_char2")
	 private String mspChar2;
	
	 @Column(name = "msp_num1")
	 private Integer mspNum1;
	 
	 @Column(name = "msp_num2")
	 private Integer mspNum2;
	 
	 @Temporal(TemporalType.DATE)
		@Column(name = "msp_date1")
	 private Date mspDate1;
	 
	 @Temporal(TemporalType.DATE)
		@Column(name = "msp_date2")
	 private Date mspDate2;
	 
	 @Column(name = "msp_val1")
	 private String mspVal1;
	 
	 @Column(name = "msp_val2")
	 private String mspVal2;
	 
	 @Column(name = "msp_val3")
	 private String mspVal3;
	 
	 @Column(name = "src_sys")
	 private String srcSys;
	 
	 @Column(name = "is_valid")
	 private Integer isValid;
	 
	 @Temporal(TemporalType.DATE)
		@Column(name = "created_on")
	 private Date createdOn;
	 
	 @Column(name = "created_by")
	 private String createdBy;
	 
	 @Temporal(TemporalType.DATE)
		@Column(name = "modified_on")
	 private Date modifiedOn;
	 
	 @Column(name = "modified_by")
	 private String modifiedBy;

	public long getRecId() {
		return recId;
	}

	public void setRecId(long recId) {
		this.recId = recId;
	}

	public String getMspParamCatg() {
		return mspParamCatg;
	}

	public void setMspParamCatg(String mspParamCatg) {
		this.mspParamCatg = mspParamCatg;
	}

	public String getMspParamGroup() {
		return mspParamGroup;
	}

	public void setMspParamGroup(String mspParamGroup) {
		this.mspParamGroup = mspParamGroup;
	}

	public String getMspParamCode() {
		return mspParamCode;
	}

	public void setMspParamCode(String mspParamCode) {
		this.mspParamCode = mspParamCode;
	}

	public String getMspChar1() {
		return mspChar1;
	}

	public void setMspChar1(String mspChar1) {
		this.mspChar1 = mspChar1;
	}

	public String getMspChar2() {
		return mspChar2;
	}

	public void setMspChar2(String mspChar2) {
		this.mspChar2 = mspChar2;
	}

	public Integer getMspNum1() {
		return mspNum1;
	}

	public void setMspNum1(Integer mspNum1) {
		this.mspNum1 = mspNum1;
	}

	public Integer getMspNum2() {
		return mspNum2;
	}

	public void setMspNum2(Integer mspNum2) {
		this.mspNum2 = mspNum2;
	}

	public Date getMspDate1() {
		return mspDate1;
	}

	public void setMspDate1(Date mspDate1) {
		this.mspDate1 = mspDate1;
	}

	public Date getMspDate2() {
		return mspDate2;
	}

	public void setMspDate2(Date mspDate2) {
		this.mspDate2 = mspDate2;
	}

	public String getMspVal1() {
		return mspVal1;
	}

	public void setMspVal1(String mspVal1) {
		this.mspVal1 = mspVal1;
	}

	public String getMspVal2() {
		return mspVal2;
	}

	public void setMspVal2(String mspVal2) {
		this.mspVal2 = mspVal2;
	}

	public String getMspVal3() {
		return mspVal3;
	}

	public void setMspVal3(String mspVal3) {
		this.mspVal3 = mspVal3;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
}
