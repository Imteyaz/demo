package com.dpworld.mpcsystem.persistence.search;

public interface SearchCommunicatorState {
	void callOperation(SearchingCriteriaValuesHolder holder);

}
