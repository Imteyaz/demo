package com.dpworld.mpcsystem.quartz;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.service.MarinOperationSchedulerService;

@Service
public class MarinOperationJobScheduler extends QuartzJobBean {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(MarinOperationJobScheduler.class);
	@Autowired
	private transient MarinOperationSchedulerService marinOperationSchedulerService;

	public MarinOperationSchedulerService getMarinOperationSchedulerService() {
		return marinOperationSchedulerService;
	}

	public void setMarinOperationSchedulerService(
			MarinOperationSchedulerService marinOperationSchedulerService) {
		this.marinOperationSchedulerService = marinOperationSchedulerService;
	}

	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException { 
		try {
			marinOperationSchedulerService.executeProcess(); 
			marinOperationSchedulerService.catchVesselGeofenceData();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new JobExecutionException(
					"Exception Occured while Calling the Job" + e.getMessage());
		}

	}

}
