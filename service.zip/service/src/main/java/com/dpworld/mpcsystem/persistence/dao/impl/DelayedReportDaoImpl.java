package com.dpworld.mpcsystem.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailReportDTO;
import com.dpworld.mpcsystem.persistence.dao.DelayedReportDao;
import com.dpworld.mpcsystem.persistence.model.MpcIntVsl;

@Repository("delayedReportDao")
public class DelayedReportDaoImpl extends
PersistenceUnitDaoImpl<MpcIntVsl, Long> implements DelayedReportDao{
	public DelayedReportDaoImpl() {
		super(MpcIntVsl.class);
	}
	
	
	public DelayedReportDaoImpl(Class<MpcIntVsl> persistentClass) {
		super(persistentClass);
	}

	@Override
	public List<VesselDetailReportDTO> getRotationList() {
		List<VesselDetailReportDTO> reportDTOList = new ArrayList<VesselDetailReportDTO>();
		
		try{
			
			EntityManager em = getEntityManager();
			String rotnList = "SELECT Distinct m.rotation FROM MpcIntVsl m"
					         + " WHERE  m.isValid = 1 ";
			
			Query query = em.createQuery(rotnList);
			@SuppressWarnings("unchecked")
			List<String> results = query.getResultList();
			if(results != null && !results.isEmpty()){
				for(String  reportDTO : results){
					VesselDetailReportDTO dtsDTO = new VesselDetailReportDTO();
					dtsDTO.setRotation(reportDTO);
					
					reportDTOList.add(dtsDTO);
				}
			}
			
		}
		catch(Exception err){
			LOGGER.error(err.getMessage());
		}
		
		return reportDTOList;
		
	}
	
	public List<VesselDetailReportDTO> getCompRotationList() {
		List<VesselDetailReportDTO> reportDTOList = new ArrayList<VesselDetailReportDTO>();
		
		try{
			
			EntityManager em = getEntityManager();
			String rotnList = "SELECT m.rotation FROM MpcIntVsl m"
					         + " WHERE m.isValid  = 1 ";
			
			Query query = em.createQuery(rotnList);
			@SuppressWarnings("unchecked")
			List<String> results = query.getResultList();
			if(results != null && !results.isEmpty()){
				for(String  reportDTO : results){
					VesselDetailReportDTO dtsDTO = new VesselDetailReportDTO();
					dtsDTO.setRotation(reportDTO);
					
					reportDTOList.add(dtsDTO);
				}
			}
			
		}
		catch(Exception err){
			LOGGER.error(err.getMessage());
		}
		
		return reportDTOList;
		
	}

}
