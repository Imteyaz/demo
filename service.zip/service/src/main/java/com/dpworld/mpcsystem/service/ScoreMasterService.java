package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;

public interface ScoreMasterService {

	List<MaintainScoreDTO> getMaintainScoreList();

	void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO);
}
