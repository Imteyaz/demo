/**
 * 
 */
package com.dpworld.mpcsystem.service.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.dpworld.mpcsystem.admin.model.User;
import com.dpworld.mpcsystem.admin.wsdl.GetExistingUserInfomation;
import com.dpworld.mpcsystem.admin.wsdl.GetExistingUserInfomationResponse;
import com.dpworld.mpcsystem.admin.wsdl.ObjectFactory;
import com.dpworld.mpcsystem.admin.wsdl.UserInfoResultModel;
import com.dpworld.mpcsystem.admin.wsdl.UserParameter;
import com.dpworld.mpcsystem.service.AuthClientService;

@Service
public class AuthClientServiceImpl implements AuthClientService {

  private static final Logger logger = LoggerFactory.getLogger(AuthClientServiceImpl.class);
  @Autowired
  private WebServiceTemplate webServiceTemplate;

  private static final ObjectFactory WS_CLIENT_FACTORY = new ObjectFactory();

  @Override
  public UserInfoResultModel authenticateUser(User user) {
    UserInfoResultModel userDetail = null;
    try {
      // Authenticate by directory
      userDetail = authenticate(user, 0);
      if (userDetail == null || !userDetail.isResult()) {
        // Authenticate by active web
        userDetail = authenticate(user, 1);
      }
    	
    } catch (Exception ex) {
      logger.error(ex.getMessage(), ex);
    }
    return userDetail;
  }

  private UserInfoResultModel authenticate(User user, Integer authenticationType) {
    GetExistingUserInfomation request = WS_CLIENT_FACTORY.createGetExistingUserInfomation();
    UserParameter userDetail = new UserParameter();
    userDetail.setAppCode("MPC");
    if (authenticationType == 0) {
      userDetail.setDomainId(user.getUserId());
      userDetail.setDomainPwd(user.getPassword());
      userDetail.setUserName(StringUtils.EMPTY);
      userDetail.setPassword(StringUtils.EMPTY);
    } else {
      userDetail.setDomainId(user.getUserId());
      userDetail.setDomainPwd(StringUtils.EMPTY);
      userDetail.setUserName(user.getUserId());
      userDetail.setPassword(user.getPassword());
    } 
    userDetail.setAuthenticationType(authenticationType);
    userDetail.setTerminalCode("T3");

    request.setAsObjUserParamInfo(userDetail);

    GetExistingUserInfomationResponse response = (GetExistingUserInfomationResponse) webServiceTemplate.marshalSendAndReceive(
        request, new SoapActionCallback("http://tempuri.org/IUMCheckUserService/getExistingUserInfomation"));
   logger.info("Respose returned from login service :- "+response.getGetExistingUserInfomationResult().getResponseMessage());
   logger.info("Respose returned from login service isResult:- "+response.getGetExistingUserInfomationResult().isResult());
    return response.getGetExistingUserInfomationResult();
  }
}
