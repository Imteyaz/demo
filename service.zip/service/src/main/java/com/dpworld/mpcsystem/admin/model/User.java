/**
 * 
 */
package com.dpworld.mpcsystem.admin.model;

import java.io.Serializable;

import com.dpworld.mpcsystem.admin.wsdl.UserInfoResultModel;

/**
 * @author Vinculum.Abdul
 *
 */
public class User implements Serializable {

  private static final long serialVersionUID = -8518227851681658898L;

  private String userId;
  private String password;
  private String terminalId;
  private String portCode;
  private String sourceSystem;
  private String sourceObject;

  private UserInfoResultModel userDetail;

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getTerminalId() {
    return terminalId;
  }

  public void setTerminalId(String terminalId) {
    this.terminalId = terminalId;
  }

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public String getSourceObject() {
    return sourceObject;
  }

  public void setSourceObject(String sourceObject) {
    this.sourceObject = sourceObject;
  }

  public String getPortCode() {
    return portCode;
  }

  public void setPortCode(String portCode) {
    this.portCode = portCode;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public UserInfoResultModel getUserDetail() {
    return userDetail;
  }

  public void setUserDetail(UserInfoResultModel userDetail) {
    this.userDetail = userDetail;
  }

}
