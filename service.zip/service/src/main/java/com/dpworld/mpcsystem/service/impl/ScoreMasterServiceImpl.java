package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.MaintainScoreDTO;
import com.dpworld.mpcsystem.persistence.dao.GeofrencingMarinPortDao;
import com.dpworld.mpcsystem.persistence.dao.ScoreMasterDao;
import com.dpworld.mpcsystem.service.ScoreMasterService;

@Service("scoreMasterService")
public class ScoreMasterServiceImpl implements ScoreMasterService  {
	@Autowired
	private ScoreMasterDao scoreMasterDao;
	
	public List<MaintainScoreDTO> getMaintainScoreList() {

		return scoreMasterDao.getMaintainScoreList();
	}


	public void saveOrUpdateMaintainScoreData(MaintainScoreDTO maintainScoreDTO) {

		scoreMasterDao.saveOrUpdateMaintainScoreData(maintainScoreDTO);
	}

}
