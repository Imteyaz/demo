package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;
import java.util.Map;

import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;

public interface SysParamDao {
	
	List<SysParamDetailDTO> getSysParamData();

	public void saveSysParamData(SysParamDetailDTO sysParamDetailDTO);
	
	List<SysParamDetailDTO> getSysParamDetailsByCategory(String paramCategory);

	Map<String, String> getSysParamDetailsByCode();
	Map<String, String> getSysParamAutoRefresh(String mspParamCatg,String mspParamGroup,String mspParamCode);
	
	List<SysParamDetailDTO> getVesselDegreeByCategory(String category, String group);
	SysParamDetailDTO saveOrUpdateSysparamForColorChange(SysParamDetailDTO sysParamDetailDTO, String category);
	List<SysParamDetailDTO> getDefaultVesselColor(String category);
	List<SysParamDetailDTO> getSysParamDataByUserCode(String userCode, String category, String status);
	
	Map<String, String> loadSysParamMapWithCodeAndValue(String category, String group);
	List<SysParamDetailDTO> getColorCodeAsUser(String paramCategory, String paramGroup,
			String paramCode);
	public void saveOrUpdateLRAD(String userCode);
}
