package com.dpworld.mpcsystem.service;

public interface MarinOperationSchedulerService {

	void executeProcess();

	void catchVesselGeofenceData();
	
	void executeProcessForAlerts();
	
	void executeProcessforMarineJoblist();
	
}
