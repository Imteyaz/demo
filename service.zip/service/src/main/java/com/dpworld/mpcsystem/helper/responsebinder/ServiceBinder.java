package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.Date;
import java.util.Map;

import com.dpworld.mpcsystem.helper.Method;
import com.dpworld.mpcsystem.helper.ResponseCode;
import com.dpworld.mpcsystem.helper.ResponseMessageCode;

/**
 * Interface class for defining the ServiceBinder methods
 */
public interface ServiceBinder {

	ResponseCode getResponseCode();

	void setResponseCode(ResponseCode responseCode);

	ResponseMessageCode getResponseMessageCode();

	void setResponseMessageCode(ResponseMessageCode responseMessageCode);

	String getStatusMessage();

	void setStatusMessage(String statusMessage);

	Date getRequestDate();

	void setRequestDate(Date requestDate);

	Date getResponseDate();

	void setResponseDate(Date responseDate);

	Method getMethod();

	void setMethod(Method method);

	void putLocal(String name, String value);

	void setPicture(byte[] value);

	byte[] getPicture();

	String getLocal(String name);

	Map<String, String> getBinder();

	ResultSet getResultSet(String name);

	Map<String, ResultSet> getResultSets();

	void addResultSet(String name, ResultSet resultSet);
}