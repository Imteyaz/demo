package com.dpworld.mpcsystem.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.common.utility.pojo.GeofenceformView;
import com.dpworld.mpcsystem.persistence.dao.GeofencingDataViewDao;
import com.dpworld.mpcsystem.persistence.model.MpcGeoFenceData;

@Repository("geofencingDataViewDao")
public class GeofencingDataViewDaoImpl extends
PersistenceUnitDaoImpl<MpcGeoFenceData, Long> implements GeofencingDataViewDao{

	public GeofencingDataViewDaoImpl() {
		super(MpcGeoFenceData.class);
	}
	
	public GeofencingDataViewDaoImpl(Class<MpcGeoFenceData> persistentClass) {
		super(persistentClass);
	}

	public List<GeoFenceViewDTO> getGeoFenceDataList(int min, int max,
			GeofenceformView geofenceformView) {

		List<GeoFenceViewDTO> geoFenceViewDTOList = new ArrayList<GeoFenceViewDTO>();

		try {

			EntityManager em = getEntityManager();

			String myQry = " SELECT m FROM MpcGeoFenceData m ";

			if (geofenceformView.getIsValid() != null) {

				if (geofenceformView.getIsValid().equals(MPCConstants.YES)) {
					myQry = myQry + "Where m.isValid = 1 ";
				} else if (geofenceformView.getIsValid()
						.equals(MPCConstants.NO)) {
					myQry =  myQry + "Where m.isValid = 0";
				}

			}

			if (geofenceformView.getObjName().trim().length() > 0) {
				myQry =  myQry + " and UPPER(m.mgdObjName) like '%"
						+ geofenceformView.getObjName().trim().toUpperCase()
						+ "%'";
			}

			if (geofenceformView.getGfCode().trim().length() > 0) {
				myQry  = myQry + " and UPPER(m.mgmGfCode) like '%"
						+ geofenceformView.getGfCode().trim().toUpperCase()
						+ "%'";
			}

			myQry  = myQry + " ORDER BY m.mgdRecId DESC";

			Query query = em.createQuery(myQry);
			Integer pageNumber = min;
			Integer pageSize = max;
			query.setFirstResult(pageNumber * pageSize);
			query.setMaxResults(pageSize);

			List<MpcGeoFenceData> results = query.getResultList();
			if (!results.isEmpty()) {
				for (MpcGeoFenceData geomaster : results) {

					GeoFenceViewDTO geoFenceViewDTO = new GeoFenceViewDTO();
					geoFenceViewDTO.setMgdRecId(String.valueOf(geomaster
							.getMgdRecId()));
					if (geomaster.getMgdRecDate() != null) {
						geoFenceViewDTO.setMgdRecDate(geomaster.getMgdRecDate()
								.toString());
					}
					geoFenceViewDTO.setMgmGfCode(geomaster.getMgmGfCode());
					geoFenceViewDTO.setMgdObjType(geomaster.getMgdObjType());
					geoFenceViewDTO.setMgdObjName(geomaster.getMgdObjName());
					geoFenceViewDTO.setMgdObjCode(geomaster.getMgdObjCode());
					geoFenceViewDTO.setMgdObjId(geomaster.getMgdObjId());
					if (geomaster.getMgdObjEntry() != null) {
						geoFenceViewDTO.setMgdObjEntry(geomaster
								.getMgdObjEntry().toString());
					}
					if (geomaster.getMgdObjExit() != null) {
						geoFenceViewDTO.setMgdObjExit(geomaster.getMgdObjExit()
								.toString());
					}
					if (geomaster.getIsValid() != null) {
						if (geomaster.getIsValid() == 1) {
							geoFenceViewDTO.setIsValid(MPCConstants.YES);
						} else if (geomaster.getIsValid() == 0) {
							geoFenceViewDTO.setIsValid(MPCConstants.NO);
						}

					}
					geoFenceViewDTO.setSrcSys(geomaster.getSrcSys());
					geoFenceViewDTO.setCreatedBy(geomaster.getCreatedBy());
					if (geomaster.getCareatedDate() != null) {
						geoFenceViewDTO.setCreatedDate(geomaster
								.getCareatedDate().toString());
					}
					geoFenceViewDTO.setModifiedBy(geomaster.getModifiedBy());
					if (geomaster.getModifiedDate() != null) {
						geoFenceViewDTO.setModifiedDate(geomaster
								.getModifiedDate().toString());
					}
					geoFenceViewDTOList.add(geoFenceViewDTO);

				}
			}
		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return geoFenceViewDTOList;
	}

	
	public int countGeofencingData(GeofenceformView geofenceformView) {

		int count = 0;
		try {

			String myQry = "SELECT m FROM  MpcGeoFenceData m ";

			if (geofenceformView.getIsValid() != null) {

				if (geofenceformView.getIsValid().equals(MPCConstants.YES)) {
					myQry =  myQry + "Where m.isValid = 1";
				} else if (geofenceformView.getIsValid()
						.equals(MPCConstants.NO)) {
					myQry = myQry + "Where m.isValid  = 0";
				}

			}

			if (geofenceformView.getObjName().trim().length() > 0) {
				myQry  = myQry + " and UPPER(m.mgdObjName) like '%"
						+ geofenceformView.getObjName().trim().toUpperCase()
						+ "%'";
			}

			if (geofenceformView.getGfCode().trim().length() > 0) {
				myQry =  myQry + " and UPPER(m.mgmGfCode) like '%"
						+ geofenceformView.getGfCode().trim().toUpperCase()
						+ "%'";
			}

			myQry =  myQry + " ORDER BY m.mgdRecId DESC";

			EntityManager em = getEntityManager();
			Query query = em.createQuery(myQry);
			List<MpcGeoFenceData> results = query.getResultList();
			count = results.size();

		} catch (Exception er) {
			LOGGER.error(er.getMessage());
		}

		return count;
	}
	
}
