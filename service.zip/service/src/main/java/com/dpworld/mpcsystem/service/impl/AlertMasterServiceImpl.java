package com.dpworld.mpcsystem.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.AlertMasterDTO;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationSubDTO;
import com.dpworld.mpcsystem.common.utility.pojo.UserRoleInfoDTO;
import com.dpworld.mpcsystem.persistence.dao.AlertMasterDao;
import com.dpworld.mpcsystem.service.AlertMasterService;


@Service("alertMasterService")
public class AlertMasterServiceImpl implements AlertMasterService {
	
	@Autowired
	private AlertMasterDao alertMasterDao;	
	
	public List<AlertMasterDTO> getAlertMasterList() {

		return alertMasterDao.getAlertMasterList();
	}
	
	public void saveOrUpdateAlertMaster(AlertMasterDTO alertMasterDTO) {

		alertMasterDao.saveOrUpdateAlertMaster(alertMasterDTO);
	}

	
	public AlertMasterDTO getAlertMasterDTOById(String altId) {
		
		return alertMasterDao.getAlertMasterDTOById(altId);
	}

	/*@Override
	public String addNewUser(ConversationSubDTO conversationSubDTO) {
		return alertMasterDao.addNewUser(conversationSubDTO);
	}*/
	
	@Override
	public String subscribeUsers(HashMap<String, List<UserRoleInfoDTO>> selectedRoleMap,
			String sessionName, String altId){
		return alertMasterDao.subscribeUsers(selectedRoleMap,sessionName,  altId);
	}
	
	@Override
	public String subscribeUsers(List<String> rolesToAdd, String sessionName,String altId){
		return alertMasterDao.subscribeUsers(rolesToAdd,sessionName,  altId);
	}
	
	@Override
	public String subscribeUsers(List<String> rolesToAdd,List<ConversationSubDTO> rolesToUpdate,String sessionName,String altId){
		return alertMasterDao.subscribeUsers(rolesToAdd,rolesToUpdate,sessionName,  altId);
	}

	@Override
	public List<ConversationSubDTO> getExistingRoles(String altId,Boolean activeRoles ) {
		
		return alertMasterDao.getExistingRoles(altId,activeRoles);
	}

}
