package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.ColorPickerDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.persistence.dao.ColorPickerDao;
import com.dpworld.mpcsystem.persistence.model.MpcSysParams;

@Repository("colorPickerDao")
public class ColorPickerDaoImpl extends
   PersistenceUnitDaoImpl<MpcSysParams, Long> implements ColorPickerDao {
	   
	   public ColorPickerDaoImpl() {
			super(MpcSysParams.class);
		}
		
		public ColorPickerDaoImpl(Class<MpcSysParams> persistentClass) {
			super(persistentClass);
		}

		@Transactional
		public void saveColorDtls(ColorPickerDTO colorPickerDTO) {
			try{
				List<SysParamDetailDTO> sysParamList = new ArrayList<SysParamDetailDTO>();
				EntityManager em = getEntityManager();
				Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
				Date date = (Date) queryTime.getSingleResult();
				
				MpcSysParams mpcSysParams = new MpcSysParams();
				String s = String.valueOf(colorPickerDTO.getTempRecId());
				String status = colorPickerDTO.getStatus();
				String myQry = "SELECT m FROM MpcSysParams m "
						+ "where m.mspParamCatg='" + "COLORCODE" + "' "
						+ "and m.mspParamGroup='" + "VSLSTATUS" + "' "
						+ "and m.mspParamCode='" + status + "' "
						+ "and m.isValid = 1";
				
				Query query = em.createQuery(myQry);
				List<MpcSysParams> results = query.getResultList();
				if(results.size() > 0){
					mpcSysParams = new MpcSysParams();
					mpcSysParams = results.get(0);
					
					
							mpcSysParams.setMspParamCatg("COLORCODE");
							mpcSysParams.setMspParamGroup("VSLSTATUS");
							mpcSysParams.setMspParamCode(colorPickerDTO.getStatus());
							mpcSysParams.setMspVal1(colorPickerDTO.getColor());
							mpcSysParams.setModifiedOn(date);
							mpcSysParams.setModifiedBy(colorPickerDTO.getModifiedBy());
							em.persist(mpcSysParams);
						}
				
				else {
				
					Query queryResult = em
							.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");

					long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
					// New Added
					try {
						long recId = Long.parseLong(MPCUtil.getCurrentYear(date)
								+ String.valueOf(id));
						mpcSysParams.setRecId(recId);
					} catch (Exception er) {
						er.printStackTrace();
					}
				
				mpcSysParams.setMspParamCatg("COLORCODE");
				mpcSysParams.setMspParamGroup("VSLSTATUS");
				mpcSysParams.setMspParamCode(colorPickerDTO.getStatus());
				mpcSysParams.setMspVal1(colorPickerDTO.getColor());
				mpcSysParams.setCreatedOn(date);
				mpcSysParams.setCreatedBy(colorPickerDTO.getCreatedBy());
				mpcSysParams.setIsValid(1);
				em.persist(mpcSysParams);
				
				}
				
			}
			catch(Exception err){
				err.printStackTrace();
			}
			
		}
}
