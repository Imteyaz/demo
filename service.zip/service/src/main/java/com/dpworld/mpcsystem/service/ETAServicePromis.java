/**
 * 
 */
package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;

/**
 * @author Vinculum.Imteyaz
 *
 */

public interface ETAServicePromis {
	List<VesselDetailsDTO> getVesseldetails(String fromEtaDate,String toEtaDate, String vesselTypes);

}
