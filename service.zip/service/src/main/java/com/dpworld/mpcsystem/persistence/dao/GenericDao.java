package com.dpworld.mpcsystem.persistence.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Generic DAO (Data Access Object) with common methods to CRUD POJOs.
 * 
 * <p>
 * Extend this interface if you want typesafe (no casting necessary) DAO's for
 * your domain objects.
 * 
 * @param <T>
 *            - a type variable
 * @param <PK>
 *            - the primary key for that type
 * 
 * @author T2943 - Kathiravan Manickam
 */
public interface GenericDao<T, PK extends Serializable> {

	/**
	 * Generic method used to get all objects of a particular type. This is the
	 * same as lookup up all rows in a table.
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @return List of populated objects
	 */
	List<T> getAll(String queryName);

	/**
	 * Gets all records without duplicates.
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @return List of populated objects
	 */
	List<T> getAllDistinct(String queryName);

	/**
	 * Generic method to get an object based on class and identifier. An
	 * ObjectRetrievalFailureException Runtime Exception is thrown if nothing is
	 * found.
	 * 
	 * @param id
	 *            the identifier (primary key) of the object to get
	 * @param queryName
	 *            query name of the named query
	 * @param queryParam
	 *            query param of the named query
	 * @return a populated object
	 * @see org.springframework.orm.ObjectRetrievalFailureException
	 */
	T get(PK id, String queryName, String queryParam);

	/**
	 * Checks for existence of an object of type T using the id arg.
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @param queryParams
	 *            query params of the named query
	 * @return - true if it exists, false if it doesn't
	 */
	boolean exists(String queryName, Map<String, Object> queryParams);

	/**
	 * Generic method to save an object.
	 * 
	 * @param object
	 *            the object to save
	 * 
	 */
	void save(T object);

	/**
	 * Generic method to save an object - handles both update and insert.
	 * 
	 * @param object
	 *            the object to save
	 * @return the persisted object
	 */
	T update(T object);

	/**
	 * Generic method to delete an object
	 * 
	 * @param object
	 *            the object to remove
	 */
	void remove(T object);

	/**
	 * Generic method to delete an object
	 * 
	 * @param id
	 *            the identifier (primary key) of the object to remove
	 * @param queryName
	 *            query name of the named query
	 * @param queryParam
	 *            query param of the named query
	 */
	void remove(PK id, String queryName, String queryParam);

	/**
	 * Generic method to execute native query for delete/insert/update
	 * operations
	 * 
	 * @param queryName
	 *            query name of the native query
	 * @param queryParam
	 *            query param of the native query
	 */
	void executeNativeQuery(String queryName, Map<String, Object> queryParams);

	/**
	 * Find a list of records by using a named query
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @param queryParams
	 *            a map of the query names and the values
	 * @return a list of the records found
	 */
	List<T> findByNamedQuery(String queryName, Map<String, Object> queryParams);

	/**
	 * Generic method to get an object based on class and identifiers, for
	 * specifically composite keys. An ObjectRetrievalFailureException Runtime
	 * Exception is thrown if nothing is found.
	 * 
	 * @param queryName
	 *            query name of the named query
	 * @param queryParams
	 *            a map of the query names and the values
	 * @return the record found
	 */
	T get(String queryName, Map<String, Object> queryParams);
}