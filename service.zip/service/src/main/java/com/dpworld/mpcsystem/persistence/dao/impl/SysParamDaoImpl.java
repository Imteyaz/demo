package com.dpworld.mpcsystem.persistence.dao.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.DateUtilities;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.persistence.dao.SysParamDao;
import com.dpworld.mpcsystem.persistence.model.MpcSysParams;

@Repository("sysParamDao")
public class SysParamDaoImpl extends PersistenceUnitDaoImpl<MpcSysParams, Long> implements
    SysParamDao {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SysParamDaoImpl.class);
	
	private static SysParamDaoImpl sysParamDaoImpl ;
  public SysParamDaoImpl() {
    super(MpcSysParams.class);
  }

  public SysParamDaoImpl(Class<MpcSysParams> persistentClass) {
    super(persistentClass);
  }
  
 

	public static SysParamDaoImpl  getSysParamDaoImplInstance(){
		if(null==sysParamDaoImpl){
			return new SysParamDaoImpl();
		}else{
			return sysParamDaoImpl;
		}
	}

  /*
   * Get List From SysParamDetailDto
   */
  public List<SysParamDetailDTO> getSysParamData() {


    // Map m = new HashMap();
    List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
    EntityManager em = getEntityManager();
    TypedQuery<MpcSysParams> query = em.createNamedQuery("MpcSysParams.findAll", MpcSysParams.class);

    List<MpcSysParams> results = query.getResultList();

    if (results.size() > 0) {
      for (MpcSysParams sysparams : results) {

        SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();

        sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
        sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
        sysParamDatas.setMspParamGroup(sysparams.getMspParamGroup());
        sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
        sysParamDatas.setMspVal1(sysparams.getMspVal1());
        if (sysparams.getIsValid() != null) {
          if ((sysparams.getIsValid()).equals(1))
            sysParamDatas.setIsValid(MPCConstants.YES);
          else
            sysParamDatas.setIsValid(MPCConstants.NO);
        }

        sysParamDatas.setCreatedBy(sysparams.getCreatedBy());

        // New Added
        if (sysparams.getCreatedOn() != null) {
          sysParamDatas.setCreatedOn(sysparams.getCreatedOn().toString());
        }
        sysParamDatas.setMspChar1(sysparams.getMspChar1());
        sysParamDatas.setMspChar2(sysparams.getMspChar2());
        if (sysparams.getMspNum1() != null) {
          sysParamDatas.setMspNum1(sysparams.getMspNum1().toString());
        }

        if (sysparams.getMspNum2() != null) {
          sysParamDatas.setMspNum2(sysparams.getMspNum2().toString());
        }

        if (sysparams.getMspDate1() != null) {

          sysParamDatas.setMspDate1(MPCUtil.changeDateFormat(sysparams.getMspDate1().toString()));
        }

        if (sysparams.getMspDate2() != null) {
          sysParamDatas.setMspDate2(MPCUtil.changeDateFormat(sysparams.getMspDate2().toString()));
        }

        sysParamDatas.setMspVal2(sysparams.getMspVal2());
        sysParamDatas.setMspVal3(sysparams.getMspVal3());
        sysParamDatas.setSrcSys(sysparams.getSrcSys());

        sysParamDatas.setModifiedBy(sysparams.getModifiedBy());
        if (sysparams.getModifiedOn() != null) {
          sysParamDatas.setModifiedOn(sysparams.getModifiedOn().toString());
        }

        sysParamData.add(sysParamDatas);
      }
    }
    return sysParamData;

  }

  @Transactional
  public void saveSysParamData(SysParamDetailDTO sysParamDetailDTO) {
    EntityManager em = getEntityManager();
    Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
    Date date = (Date) queryTime.getSingleResult();

    MpcSysParams mpcsysparams = new MpcSysParams();
    String s = String.valueOf(sysParamDetailDTO.getRecId());
    if (null==sysParamDetailDTO.getRecId()||s.trim().equals("")) {
      Query queryResult = em.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");

      long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
      // New Added
      try {
        long recId = Long.parseLong(MPCUtil.getCurrentYear(date) + String.valueOf(id));
        mpcsysparams.setRecId(recId);
      } catch (Exception er) {
    	  LOGGER.error(er.getMessage());
      }

      mpcsysparams.setMspParamCatg(sysParamDetailDTO.getMspParamCatg());
      mpcsysparams.setMspParamGroup(sysParamDetailDTO.getMspParamGroup());
      mpcsysparams.setMspParamCode(sysParamDetailDTO.getMspParamCode());
      mpcsysparams.setMspVal1(sysParamDetailDTO.getMspVal1());
      if (sysParamDetailDTO.getIsValid() != null) {
        if (sysParamDetailDTO.getIsValid().equals(MPCConstants.YES)) {
          mpcsysparams.setIsValid(1);
        } else {
          mpcsysparams.setIsValid(0);
        }
      }

      mpcsysparams.setCreatedBy(sysParamDetailDTO.getCreatedBy());
      mpcsysparams.setCreatedOn(date);

      mpcsysparams.setMspChar1(sysParamDetailDTO.getMspChar1());
      mpcsysparams.setMspChar2(sysParamDetailDTO.getMspChar2());

      if (sysParamDetailDTO.getMspDate1()!=null && !sysParamDetailDTO.getMspDate1().equals("")) {
        try {
			mpcsysparams.setMspDate1(DateUtilities.formatDate(sysParamDetailDTO.getMspDate1()));
		} catch (Exception e) {
			e.printStackTrace();
		}
      }
      if (sysParamDetailDTO.getMspDate2()!=null && !sysParamDetailDTO.getMspDate2().equals("")) {
        mpcsysparams.setMspDate2(MPCUtil.convertStringToDate(sysParamDetailDTO.getMspDate2()));
      }

      if (sysParamDetailDTO.getMspNum1()!=null && !sysParamDetailDTO.getMspNum1().equals("")) {
        mpcsysparams.setMspNum1(Integer.parseInt(sysParamDetailDTO.getMspNum1()));
      }
      if (sysParamDetailDTO.getMspNum2()!=null &&!sysParamDetailDTO.getMspNum2().equals("")) {
        mpcsysparams.setMspNum2(Integer.parseInt(sysParamDetailDTO.getMspNum2()));
      }

      mpcsysparams.setMspVal2(sysParamDetailDTO.getMspVal2());
      mpcsysparams.setMspVal3(sysParamDetailDTO.getMspVal3());
      em.persist(mpcsysparams);
    } else {
      String recID = sysParamDetailDTO.getRecId();
      MpcSysParams mpcsysparamsedit;
      mpcsysparamsedit = em.find(MpcSysParams.class, Long.parseLong(recID));
      mpcsysparamsedit.setMspParamCatg(sysParamDetailDTO.getMspParamCatg());
      mpcsysparamsedit.setMspParamGroup(sysParamDetailDTO.getMspParamGroup());
      mpcsysparamsedit.setMspParamCode(sysParamDetailDTO.getMspParamCode());
      mpcsysparamsedit.setMspVal1(sysParamDetailDTO.getMspVal1());
      if (sysParamDetailDTO.getIsValid() != null) {
        if (sysParamDetailDTO.getIsValid().equals("Yes")) {
          mpcsysparamsedit.setIsValid(1);
        } else {
          mpcsysparamsedit.setIsValid(0);
        }
      }

      mpcsysparamsedit.setModifiedBy(sysParamDetailDTO.getModifiedBy());
      mpcsysparamsedit.setModifiedOn(date);
      // New Added

      mpcsysparamsedit.setMspChar1(sysParamDetailDTO.getMspChar1());
      mpcsysparamsedit.setMspChar2(sysParamDetailDTO.getMspChar2());

      if (sysParamDetailDTO.getMspDate1()!=null && !sysParamDetailDTO.getMspDate1().equals("")) {
          try {
        	  mpcsysparamsedit.setMspDate1(DateUtilities.formatDate(sysParamDetailDTO.getMspDate1()));
  		} catch (Exception e) {
  			e.printStackTrace();
  		}
        }
      if (sysParamDetailDTO.getMspDate2()!=null &&!sysParamDetailDTO.getMspDate2().equals("")) {

        mpcsysparamsedit.setMspDate2(MPCUtil.convertStringToDate(sysParamDetailDTO.getMspDate2()));
      }

      if (sysParamDetailDTO.getMspNum1()!=null && !sysParamDetailDTO.getMspNum1().equals("")) {
        mpcsysparamsedit.setMspNum1(Integer.parseInt(sysParamDetailDTO.getMspNum1()));
      }
      if (sysParamDetailDTO.getMspNum2()!=null && !sysParamDetailDTO.getMspNum2().equals("")) {
        mpcsysparamsedit.setMspNum2(Integer.parseInt(sysParamDetailDTO.getMspNum2()));
      }

      mpcsysparamsedit.setMspVal2(sysParamDetailDTO.getMspVal2());
      mpcsysparamsedit.setMspVal3(sysParamDetailDTO.getMspVal3());
      em.persist(mpcsysparamsedit);
    }
  }


  public List<SysParamDetailDTO> getSysParamDetailsByCategory(String paramCategory) {
    EntityManager em = getEntityManager();
    List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
    String myQry = "SELECT m FROM MpcSysParams m " + "where m.mspParamCatg='" + paramCategory
        + "' " + "and m.isValid = 1";
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();

    if (results.size() > 0) {
      for (MpcSysParams sysparams : results) {

        SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();
        sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
        sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
        sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
        sysParamDatas.setMspParamGroup(sysparams.getMspParamGroup());
        sysParamDatas.setMspVal1(sysparams.getMspVal1());
        sysParamData.add(sysParamDatas);
      }
    }

    return sysParamData;
  }

  public Map<String, String> getSysParamDetailsByCode() {
    Map<String, String> codeValueMap = new HashMap<String, String>();
    EntityManager em = getEntityManager();
    List<SysParamDetailDTO> sysParamData = new ArrayList<SysParamDetailDTO>();
    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1";
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();
    //logger.info("SYS PARAMS DATA FROM DB : "+results); 
    if (results.size() > 0) {
			for (MpcSysParams sysparams : results) {
				if (sysparams != null
						&& sysparams.getMspParamCatg() != null
						&& (sysparams.getMspParamCatg().equalsIgnoreCase(
								"VESSEL_UPCOMING_STATUS")
								|| sysparams.getMspParamCatg()
										.equalsIgnoreCase("VESSEL_STATUS") || sysparams
								.getMspParamCatg().equalsIgnoreCase(
										"BUFFER_PARAMS")))
					codeValueMap.put(sysparams.getMspParamCode(),
							sysparams.getMspVal1());
			}
    }
	LOGGER.debug(" SYSPARAM MAP : "+codeValueMap);
    return codeValueMap;
  }
  

	public Map<String, String> getSysParamAutoRefresh(String mspParamCatg,String mspParamGroup,String mspParamCode) {
	    Map<String, String> codeValueMap = new HashMap<String, String>();
	    EntityManager em = getEntityManager();
	    String myQry ="SELECT m FROM MpcSysParams m where m.isValid = 1 and "
	    		+ " m.mspParamCatg = '" + mspParamCatg.trim() + "' and "
	    		+ "m.mspParamGroup = '" + mspParamGroup.trim() + "' and m.mspParamCode = '" + mspParamCode.trim() + "'";
	
	    Query query = em.createQuery(myQry);
	    List<MpcSysParams> results = query.getResultList();
	    if (results.size() > 0) {
	      for (MpcSysParams sysparams : results) {
	    	codeValueMap.put(sysparams.getMspParamCatg(), sysparams.getMspChar1());
	      	codeValueMap.put(sysparams.getMspParamCode(), sysparams.getMspNum1().toString());
	  	  
	      }
	    }

	    return codeValueMap;
	  }
  


  public List<SysParamDetailDTO> getVesselDegreeByCategory(String category, String group) {

    Map<String, String> vesselDegreeMap = new HashMap<String, String>();

    EntityManager em = getEntityManager();
    List<SysParamDetailDTO> sysParamList = new ArrayList<SysParamDetailDTO>();
    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1 " + "and m.mspParamCatg = '"
        + category.trim() + "' and m.mspParamGroup = '" + group.trim() + "'";
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();
    if (results.size() > 0) {
      for (MpcSysParams sysparams : results) {
        SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();

        sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
        sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
        sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
        sysParamDatas.setMspVal1(sysparams.getMspVal1());
        sysParamDatas.setCreatedBy(sysparams.getCreatedBy());

        sysParamList.add(sysParamDatas);

      }
    }
    return sysParamList;
  }

  @Transactional
  public SysParamDetailDTO saveOrUpdateSysparamForColorChange(SysParamDetailDTO sysParamDetailDTO,
      String category) {
    SysParamDetailDTO sysParamDetailDTO2 = new SysParamDetailDTO();
    MpcSysParams mpcsysparams = new MpcSysParams();
    EntityManager em = getEntityManager();
    Query queryTime = em.createNativeQuery("SELECT SYSDATE FROM DUAL");
    Date date = (Date) queryTime.getSingleResult();

    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1 " + "and m.createdBy = '"
        + sysParamDetailDTO.getCreatedBy().trim() + "' " + "and m.mspParamCatg = '"
        + category.trim() + "' " + "and m.mspParamCode = '" + sysParamDetailDTO.getMspParamCode()
        + "'";
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();

    try {

      if (results.size() > 0) {
        // Update Record
        mpcsysparams = results.get(0);
        mpcsysparams.setMspVal1(sysParamDetailDTO.getMspVal1());
        mpcsysparams.setModifiedBy(sysParamDetailDTO.getModifiedBy());
        mpcsysparams.setModifiedOn(date);
        em.persist(mpcsysparams);

        sysParamDetailDTO2 = new SysParamDetailDTO();
        sysParamDetailDTO2.setRecId(String.valueOf(mpcsysparams.getRecId()));
        sysParamDetailDTO2.setMspParamCatg(mpcsysparams.getMspParamCatg());
        sysParamDetailDTO2.setMspParamCode(mpcsysparams.getMspParamCode());
        sysParamDetailDTO2.setMspVal1(mpcsysparams.getMspVal1());
        if (mpcsysparams.getIsValid() != null) {
          sysParamDetailDTO2.setIsValid(mpcsysparams.getIsValid().toString());
        }
        sysParamDetailDTO2.setCreatedBy(mpcsysparams.getCreatedBy());


      } else { // New Save Record
        Query queryResult = em.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");

        long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
        // New Added
        try {
          long recId = Long.parseLong(MPCUtil.getCurrentYear(date) + String.valueOf(id));
          mpcsysparams.setRecId(recId);
        } catch (Exception er) {
          er.printStackTrace();
        }
        mpcsysparams.setMspParamCatg(sysParamDetailDTO.getMspParamCatg());
        mpcsysparams.setMspParamCode(sysParamDetailDTO.getMspParamCode());
        mpcsysparams.setMspVal1(sysParamDetailDTO.getMspVal1());
        mpcsysparams.setIsValid(1);
        mpcsysparams.setCreatedBy(sysParamDetailDTO.getCreatedBy());
        mpcsysparams.setCreatedOn(date);
        em.persist(mpcsysparams);

        sysParamDetailDTO2 = new SysParamDetailDTO();
        sysParamDetailDTO2.setRecId(String.valueOf(mpcsysparams.getRecId()));
        sysParamDetailDTO2.setMspParamCatg(mpcsysparams.getMspParamCatg());
        sysParamDetailDTO2.setMspParamCode(mpcsysparams.getMspParamCode());
        sysParamDetailDTO2.setMspVal1(mpcsysparams.getMspVal1());
        if (mpcsysparams.getIsValid() != null) {
          sysParamDetailDTO2.setIsValid(mpcsysparams.getIsValid().toString());
        }
        sysParamDetailDTO2.setCreatedBy(mpcsysparams.getCreatedBy());
      }

    } catch (Exception er) {
      sysParamDetailDTO2 = new SysParamDetailDTO();
    }


    return sysParamDetailDTO2;
  }

  public List<SysParamDetailDTO> getDefaultVesselColor(String category) {
    EntityManager em = getEntityManager();
    List<SysParamDetailDTO> sysParamList = new ArrayList<SysParamDetailDTO>();
    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1 " + "and m.mspParamCatg = '"
        + category.trim() + "' ";
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();
    if (results.size() > 0) {
      for (MpcSysParams sysparams : results) {
        SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();

        sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
        sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
        sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
        sysParamDatas.setMspVal1(sysparams.getMspVal1());
        if (sysparams.getIsValid() != null) {
          if ((sysparams.getIsValid()).equals(1))
            sysParamDatas.setIsValid(MPCConstants.YES);
          else
            sysParamDatas.setIsValid(MPCConstants.NO);
        }

        sysParamDatas.setCreatedBy(sysparams.getCreatedBy());

        sysParamList.add(sysParamDatas);
      }
    }
    return sysParamList;
  }

  /*
   * Get SysParamList
   */
  public List<SysParamDetailDTO> getSysParamDataByUserCode(String userCode,
      String category,
      String status) {
    EntityManager em = getEntityManager();
    List<SysParamDetailDTO> sysParamList = new ArrayList<SysParamDetailDTO>();
   /* String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1 " + "and m.createdBy = '"
        + userCode.trim() + "' " + "and m.mspParamCatg = '" + category.trim() + "' "
        + "and m.mspParamCode = '" + status.trim() + "'";*/
    String myQry = "SELECT m FROM MpcSysParams m where m.isValid = 1 " ;
    Query query = em.createQuery(myQry);
    List<MpcSysParams> results = query.getResultList();

    if (results.size() > 0) {
      for (MpcSysParams sysparams : results) {
        SysParamDetailDTO sysParamDatas = new SysParamDetailDTO();

        sysParamDatas.setRecId(Long.toString(sysparams.getRecId()));
        sysParamDatas.setMspParamCatg(sysparams.getMspParamCatg());
        sysParamDatas.setMspParamCode(sysparams.getMspParamCode());
        sysParamDatas.setMspVal1(sysparams.getMspVal1());
        if (sysparams.getIsValid() != null) {
          if ((sysparams.getIsValid()).equals(1))
            sysParamDatas.setIsValid(MPCConstants.YES);
          else
            sysParamDatas.setIsValid(MPCConstants.NO);
        }

        sysParamDatas.setCreatedBy(sysparams.getCreatedBy());

        /*
         * // New Added if (sysparams.getCreatedOn() != null) {
         * sysParamDatas.setCreatedOn(sysparams.getCreatedOn() .toString()); }
         * sysParamDatas.setSrcSys(sysparams.getSrcSys());
         * sysParamDatas.setModifiedBy(sysparams.getModifiedBy()); if
         * (sysparams.getModifiedOn() != null) {
         * sysParamDatas.setModifiedOn(sysparams.getModifiedOn() .toString()); }
         */
        sysParamList.add(sysParamDatas);
      }
    }
    return sysParamList;
  }
  
  /**
   * 
   * @return
   */
  @Override
  public Map<String, String> loadSysParamMapWithCodeAndValue(String category, String group) {

    EntityManager em = getEntityManager();
    Map<String, String> codeValueMap = new HashMap<String, String>();
    String sqlQuery = "SELECT m FROM MpcSysParams m where m.isValid = 1 "
        + "and m.mspParamCatg = '"
        + category.trim()
        + "' and m.mspParamGroup = '"
        + group.trim()
        + "'";
    Query query = em.createQuery(sqlQuery);
    List<MpcSysParams> results = query.getResultList();
    for (MpcSysParams sysparam : results) {
      codeValueMap.put(sysparam.getMspParamCode(), sysparam.getMspVal1());
    }
    return codeValueMap;
  }
  
  public List<SysParamDetailDTO> getColorCodeAsUser(
			String mspParamCatg, String mspParamGroup, String paramCode) {
		List<SysParamDetailDTO> sysParamList = new ArrayList<SysParamDetailDTO>();
		try{
		EntityManager em = getEntityManager();
		
		String myQry = "SELECT m FROM MpcSysParams m "
				+ "where m.mspParamCatg='" + mspParamCatg + "' "
				+ "and m.mspParamGroup='" + mspParamGroup + "' "
				+ "and m.mspParamCode='" + paramCode + "' "
				+ "and m.isValid = 1";
		Query query = em.createQuery(myQry);
		
		@SuppressWarnings("unchecked")
		List<MpcSysParams> results = query.getResultList();

		if (results.size() > 0) {
			for (MpcSysParams sysparams : results) {

				SysParamDetailDTO sysParamData = new SysParamDetailDTO();
				
				sysParamData.setMspVal1(sysparams.getMspVal1());
				sysParamData.setCreatedOn(MPCUtil.changeNewDateToStringFormat(sysparams.getCreatedOn()));
				sysParamData.setCreatedBy(sysparams.getCreatedBy());
				if(sysparams.getModifiedOn() != null){
					sysParamData.setModifiedOn(MPCUtil.changeNewDateToStringFormat(sysparams.getModifiedOn()));
				}
				else{
				sysParamData.setModifiedOn("");
				}
				if(sysparams.getModifiedBy() != null){
					sysParamData.setModifiedBy(sysparams.getModifiedBy());
				}
				else{
				sysParamData.setModifiedBy("");
				}
				
				sysParamList.add(sysParamData);
			}
		}
		}
		catch(Exception err){
			 LOGGER.error(err.getMessage());
		}

		return sysParamList;
		
	}
  
  	@Transactional
  	public void saveOrUpdateLRAD(String userCode){
  		SysParamDetailDTO sysParamDetailDTO = new SysParamDetailDTO();
  		EntityManager em = getEntityManager();
  		String recQuery = "select m.rec_id from mpc_sys_params m "
				+ " where  m.msp_param_catg = 'ALERT' and m.msp_param_group = "
				+ " 'LAST_READ_DATE' and lower(m.msp_param_code) = lower('"+userCode+"') "
				+ " and m.is_valid = 1" ;
		Query recIDQuery = em.createNativeQuery(recQuery);
		BigDecimal recID = null;
		List list = recIDQuery.getResultList();
		if (list != null && !list.isEmpty()) {
			recID = (BigDecimal)list.get(0);
			
		}
		Date date = new Date();
		String d = null ;
		try{
		SimpleDateFormat sdf = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		d = sdf.format(date);
		}catch(Exception e){
			e.printStackTrace();
		}
		sysParamDetailDTO.setMspParamCatg("ALERT");
		sysParamDetailDTO.setMspParamGroup("LAST_READ_DATE");
		sysParamDetailDTO.setMspParamCode(userCode);
		sysParamDetailDTO.setIsValid(MPCConstants.YES);
		
		
		
		long recId1 = 0L;
		
		if (null != recID) {
			String updateQuery = "update mpc_sys_params set msp_date1 =TO_DATE('"+d+"','DD-MON-YYYY HH24:MI'),"
					+ " modified_on = TO_DATE('"+d+"','DD-MON-YYYY HH24:MI') where REC_ID ="+recID;
			Query updateQry = em.createNativeQuery(updateQuery);
			int i = updateQry.executeUpdate();
		}else{
			 Query queryResult = em.createNativeQuery("SELECT SEQ_MPC_MASTERS_PK01.nextval FROM DUAL");

		      long id = ((BigDecimal) queryResult.getSingleResult()).longValue();
		      // New Added
		      try {
		         recId1 = Long.parseLong(MPCUtil.getCurrentYear(date) + String.valueOf(id));
		      } catch (Exception er) {
		    	  LOGGER.error(er.getMessage());
		      }
			String insertQuery ="insert into mpc_sys_params (REC_ID, msp_param_catg ,msp_param_group,msp_param_code, MSP_DATE1,CREATED_ON, is_valid)"
					+ " values ("+recId1+",'ALERT','LAST_READ_DATE','"+userCode+"',TO_DATE('"+d+"','DD-MON-YYYY HH24:MI'),TO_DATE('"+d+"','DD-MON-YYYY HH24:MI'),1)";
			Query insertQry = em.createNativeQuery(insertQuery);
			int i = insertQry.executeUpdate();
		}
		
  }
  	
}
