/**
 * 
 */
package com.dpworld.mpcsystem.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.persistence.dao.ETAServicePromisDao;
import com.dpworld.mpcsystem.persistence.model.Voyages;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Repository("etaServicePromisDao")
public class ETAServicePromisDaoImpl extends PersistenceUnitPromisDaoImpl<Voyages, Long> implements ETAServicePromisDao{

	public ETAServicePromisDaoImpl() {
		super(Voyages.class);
	}
	
	public ETAServicePromisDaoImpl(Class<Voyages> persistentClass) {
		super(persistentClass);
		
	}
	@Transactional
	public List<VesselDetailsDTO> getVesseldetails(String fromEtaDate,String toEtaDate ,String vesseltypes){
		EntityManager em = getEntityManager();
		List<VesselDetailsDTO> etaReportList = new ArrayList<VesselDetailsDTO>();
		try {
			String stringQuery = "SELECT a.rotn  , a.vess_name ,a.bth_date  , a.sail_date , a.eta_date  , a.dual_berth , a.port_code ,  a.terminal_id , b.vess_type   "
					+ "			 FROM   voyages a,  vessels b " + 
					"            WHERE  a.vess_name =  b.vess_name " + 
					"            AND a.sail_date IS NULL " + 
					"            AND trunc(a.eta_date) BETWEEN  '"+fromEtaDate+ 
					"'			 AND '" +toEtaDate+ 
					"'            AND a.voyage_type NOT IN ( 1, 9 ) AND b.vess_type in ("+vesseltypes+")";
			Query query = em.createNativeQuery(stringQuery);
			List<Object[]> rows = query.getResultList();
			for (Object[] row : rows) {

				VesselDetailsDTO etaReport = new VesselDetailsDTO();
				if(row[0] != null){
					etaReport.setRotation(row[0].toString());
					}
				if(row[1] != null){
					etaReport.setVesselName(row[1].toString());
					}
				if(row[2] != null){
					etaReport.setBerthDate(row[2].toString());
					}
				if(row[3] != null){
					etaReport.setSailDate(row[3].toString());
					}
				if(row[4] != null){
					etaReport.setAgentEta(row[4].toString());
					}
				if(row[5] != null){
					etaReport.setDualBerth(row[5].toString());
					}
				if(row[6] != null){
					etaReport.setPort(row[6].toString());
					}
				if(row[7] != null){
					etaReport.setTerminal(row[7].toString());
					}
				if(row[8] != null){
					etaReport.setVesselType(row[8].toString());
					}
				etaReportList.add(etaReport);
			}
		}catch(Exception ex) {
			LOGGER.error("Exception while executing getVesseldetails API ..",ex);
		}finally{
			if(em.isOpen())
			em.close();
		}
		return etaReportList;
	}

}
