package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class DataRowImpl implements DataRow {
	private Map<String, String> data = new LinkedHashMap<String, String>();

	private final static Logger LOG = Logger.getLogger(DataRowImpl.class);

	/**
	 * DataRowImpl Constructor
	 * 
	 * @param fieldNames
	 *            An array of field names.
	 * @throws RuntimeException
	 */
	public DataRowImpl(String[] fieldNames) {
		for (String field : fieldNames) {
			data.put(field, null);
		}
	}

	/**
	 * Puts key value pair into a DataRow
	 * 
	 * @param fieldName
	 *            The field name key.
	 * @param value
	 *            The field name value.
	 * @throws RuntimeException
	 */
	public void put(String fieldName, String value) throws RuntimeException {
		LOG.debug("Inside Put Method :fieldName,value--> " + fieldName + " "
				+ value);
		try {
			if (fieldName != null && data.containsKey(fieldName)) {
				data.put(fieldName, value);
			}
		} catch (Exception e) {
			LOG.error("Exception In Put Method : " + e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
		LOG.debug("Put Method end :fieldName,value--> " + fieldName + " "
				+ value);
	}

	/**
	 * Gets the value of a particular field name
	 * 
	 * @param fieldName
	 *            The field name key.
	 * @throws RuntimeException
	 * @return String
	 */
	public String get(String fieldName) throws RuntimeException {
		LOG.debug("Inside get Method :fieldName--> " + fieldName);
		try {
			if (fieldName != null && data.containsKey(fieldName)) {
				LOG.debug("Inside if clause in get Method :fieldName--> "
						+ fieldName);
				return data.get(fieldName);
			}
			return null;
		} catch (Exception e) {
			LOG.error(
					"Exception In get Method :fieldName -->"
							+ e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets the value of a particular key value pair by index
	 * 
	 * @param index
	 *            The index number of a DataRow
	 * @throws RuntimeException
	 * @return String
	 */
	public String get(int index) throws RuntimeException {
		LOG.debug("Inside get Method :index--> " + index);
		try {
			if (data.size() <= index && data.size() >= index) {
				LOG.debug("Inside if clause in get Method :index--> " + index);
				return (String) data.values().toArray()[index];
			}
			return null;
		} catch (Exception e) {
			LOG.error("Exception In get Method :index -->" + e.getStackTrace(),
					e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets all the field names in a DataRow.
	 * 
	 * @throws RuntimeException
	 * @return String[]
	 */
	public String[] getFieldNames() throws RuntimeException {
		LOG.debug("Inside getFieldNames Method ");
		try {
			return (String[]) data.keySet().toArray();
		} catch (Exception e) {
			LOG.error(
					"Exception in getFieldNames Method --> "
							+ e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets a Map of RowData
	 * 
	 * @throws RuntimeException
	 * @return Map<String,String>
	 */
	public Map<String, String> getRowData() throws RuntimeException {
		LOG.debug("Inside getRowData Method ");
		try {
			return data;
		} catch (Exception e) {
			LOG.error(
					"Exception in getRowData Method --> " + e.getStackTrace(),
					e);
			throw new RuntimeException(e);
		}
	}

	public void setRowData(Map<String, String> rowDta) throws RuntimeException {
		LOG.debug("Inside setRowData Method ");
		try {
			data.putAll(rowDta);
		} catch (Exception e) {
			LOG.error(
					"Exception in setRowData Method --> " + e.getStackTrace(),
					e);
			throw new RuntimeException(e);
		}
	}

}
