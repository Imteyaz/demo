/**
 * 
 */
package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;

/**
 * @author Vinculum.Imteyaz
 *
 */
public interface ETAServiceMPC {
	List<VesselDetailsDTO> getVesseldetails();

}
