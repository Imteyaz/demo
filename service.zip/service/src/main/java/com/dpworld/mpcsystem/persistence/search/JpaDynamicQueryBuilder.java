package com.dpworld.mpcsystem.persistence.search;

/**
 * @Author : Rahul Singh
 * @For : Creating dynamic queries in Hibernate and JPA
 * 
 */

import static com.dpworld.mpcsystem.persistence.search.JpaDynamicQueryBuilder.Operator.BETWEEN;
import static com.dpworld.mpcsystem.persistence.search.JpaDynamicQueryBuilder.Operator.IN;
import static com.dpworld.mpcsystem.persistence.search.JpaDynamicQueryBuilder.Operator.LIKE;
import static javax.persistence.TemporalType.DATE;
import static javax.persistence.TemporalType.TIMESTAMP;
import static org.apache.commons.lang.StringUtils.capitalize;
import static org.apache.commons.lang.StringUtils.substringAfterLast;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.dpworld.mpcsystem.annotation.SearchRequired;
import com.dpworld.mpcsystem.persistence.search.JpaDynamicQueryBuilder.Operator.LikePattern;
import com.dpworld.mpcsystem.persistence.search.JpaDynamicQueryBuilder.Operator.OperType;

public class JpaDynamicQueryBuilder {

	private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(JpaDynamicQueryBuilder.class);
	private StringBuilder queryString = new StringBuilder(100);
	private Query query;
	private org.hibernate.Query hibernateQuery;
	private OperType operType = null;

	/**
	 * Enum contains the query operators.
	 * 
	 */
	public enum Operator {
		LIKE("LIKE "), IN("IN "), BETWEEN("BETWEEN "), NE("!= "), GT("> "), LT(
				"< "), GE(">= "), LE("=> "), EQ("= ");

		/**
		 * Enum contains the like operator patterns.
		 * 
		 */
		public enum LikePattern {
			PERCENT_BEFORE, PERCENT_AFTER, PERCENT_AROUND;
		}

		/**
		 * Enum contains the main operators OR & AND.
		 * 
		 */
		public enum OperType {
			AND(" AND "), OR(" OR ");

			private String op;

			private OperType(String op) {
				this.op = op;
			}

			public String getOp() {
				return op;
			}
		}

		private String op;

		private Operator(String op) {
			this.op = op;
		}

		public String getOp() {
			return op;
		}

		/**
		 * @param value
		 *            to be adjusted by given pattern.
		 * @param pattern
		 *            to adjust value based on it.
		 * @return the modified value.
		 */
		public static String adjustLikeValue(String value, LikePattern pattern) {
			switch (pattern) {
			case PERCENT_AFTER:
				return value + "%";
			case PERCENT_BEFORE:
				return "%" + value;
			case PERCENT_AROUND:
				return "%" + value + "%";
			default:
				return "";
			}
		}
	}

	private Map<String, Map<Operator, Object>> advancedParams = new HashMap<String, Map<Operator, Object>>();

	private Map<String, String> orderByParams = new HashMap<String, String>();

	/**
	 * store for final param's and values
	 * **/
	private Map<String, Object> paramsAndValues = new HashMap<String, Object>();

	private JpaDynamicQueryBuilder() {
	}

	/**
	 * @return the final constructed query string.
	 */
	public String getQueryString() {
		return queryString.toString().trim();
	}

	/**
	 * @return the final constructed query string.
	 */
	public void setQueryString(String queryString) {
		this.queryString = new StringBuilder("");
		this.queryString.append(queryString);
	}

	/**
	 * @return the prepared JPA query.
	 */
	public Query getQueryJpa() {
		return query;
	}

	/**
	 * @return the prepared JPA query.
	 */
	public org.hibernate.Query getQueryHibernate() {
		return hibernateQuery;
	}

	/**
	 * @param <t>
	 *            for bean type that is used to construct the query.
	 */
	public static class Builder<T> {
		private JpaDynamicQueryBuilder dqb;
		private String queryObjChar = "";
		private EntityManager em;
		private String queryAppender = new String("");
		private T beanType;
		private Class<?> beanJoinParentType;
		private boolean selectParent;
		private boolean orderByOnParent;
		private Class<T> child;
		private String joinString;
		private String joinConditionString;
		private Object parentBean;

		/**
		 * Enum contains the query operators.
		 * 
		 */
		public enum QueryType {
			HIBERNATE, JPA;
		}

		public Builder() {
			dqb = new JpaDynamicQueryBuilder();
		}

		public Builder<T> setEntityManager(EntityManager em) {
			this.em = em;
			return this;
		}

		public Builder<T> setQueryAppender(String queryAppender) {
			this.queryAppender = queryAppender;
			return this;
		}

		public String getQueryAppender() {
			return queryAppender;
		}

		/**
		 * This method accept the bean type to select by.
		 * 
		 * @param beanType
		 *            to select by.
		 * @return builder instance.
		 */
		public Builder<T> select(T beanType,
				Map<String, List<String>> selectionFieldsMap) {
			if (beanType == null)
				throw new IllegalArgumentException("Bean should be passed.");

			this.beanType = beanType;
			queryObjChar = resolveName(beanType.getClass().getName())
					.substring(0, 1).toLowerCase();
			String querySelectionChar = "";
			if (selectionFieldsMap != null) {
				if (this.selectParent) {
					querySelectionChar = resolveName(
							this.beanJoinParentType.getClass().getName())
							.substring(0, 1).toLowerCase();

				} else {
					querySelectionChar = queryObjChar;
				}
				List<String> filds = selectionFieldsMap.get(querySelectionChar);
				querySelectionChar = StringUtils.remove(
						StringUtils.remove(filds.toString(), "["), "]");
			} else {
				if (this.selectParent) {
					querySelectionChar = resolveName(
							this.beanJoinParentType.getClass().getName())
							.substring(0, 1).toLowerCase();
				} else {
					querySelectionChar = queryObjChar;
				}
			}
			append("SELECT " + querySelectionChar + " FROM "
					+ resolveName(beanType.getClass().getName()) + " "
					+ queryObjChar);

			if (StringUtils.isNotEmpty(this.joinString)) {
				append(this.joinString);
			}
			queryObjChar = queryObjChar + ".";

			return this;
		}

		/**
		 * This method accept the bean type to select by.
		 * 
		 * @param beanType
		 *            to select by.
		 * @return builder instance.
		 */
		public <P> Builder<T> addJoinParentBean(P beanType, String jointColumb) {
			if (beanType == null)
				throw new IllegalArgumentException("Bean should be passed.");

			this.beanJoinParentType = beanType.getClass();
			this.joinString = " join "
					+ resolveName(this.child.getName()).substring(0, 1)
							.toLowerCase()
					+ "."
					+ jointColumb
					+ " "
					+ resolveName(this.beanJoinParentType.getClass().getName())
							.substring(0, 1).toLowerCase();
			return this;
		}

		public Builder<T> setChild(Class<T> child) {
			this.child = child;
			return this;
		}

		public Builder<T> setParentValueEntity(Object parentBean) {
			this.parentBean = parentBean;
			return this;
		}

		public Builder<T> selectParent(boolean selectParent) {
			this.selectParent = selectParent;
			return this;
		}

		public Builder<T> addJoinEqConditionStringP2C(
				String joinParentConditionString,
				String joinChildConditionString) {
			this.joinConditionString = resolveName(
					this.beanJoinParentType.getClass().getName()).substring(0,
					1).toLowerCase()
					+ "."
					+ joinParentConditionString
					+ "="
					+ resolveName(this.child.getName()).substring(0, 1)
							.toLowerCase() + "." + joinChildConditionString;
			return this;
		}

		/**
		 * This method add AND or OR operator to query.
		 * 
		 * @return builder instance.
		 */
		public Builder<T> withOperType(OperType operType) {
			if (dqb.operType == null)
				dqb.operType = operType;

			return this;
		}

		/**
		 * This method add order by column and specify the order type.
		 * 
		 * @param param
		 *            column to order by.
		 * @param desc
		 *            is order type desc or asc.
		 * @return builder instance.
		 */
		public Builder<T> orderBy(String param, boolean desc) {
			dqb.orderByParams.put(param, desc ? "DESC" : "ASC");
			return this;
		}

		/**
		 * This method add order by column and ASC by default.
		 * 
		 * @param param
		 *            column to order by.
		 * @return builder instance.
		 */
		public Builder<T> orderBy(String param) {
			orderBy(param, false);
			return this;
		}

		public Builder<T> setOrderByParent() {
			this.orderByOnParent = true;
			return this;
		}

		/**
		 * This method add order by column and its order type.
		 * 
		 * @param orderByParams
		 *            map contains column and order type.
		 * @return builder instance.
		 */
		public Builder<T> orderBy(Map<String, Boolean> orderByParams) {
			if (orderByParams != null) {
				for (String key : orderByParams.keySet()) {
					orderBy(key, orderByParams.get(key));
				}
			}
			return this;
		}

		/**
		 * @param param
		 * @param operator
		 * @param extras
		 * @return
		 */
		public Builder<T> withAdvancedParam(String param, Operator operator,
				Object extras) {
			try {
				isValidAdvancedParam(operator, extras);
			} catch (IllegalArgumentException iae) {
				throw iae;
			}
			Map<Operator, Object> others = new HashMap<Operator, Object>();
			others.put(operator, extras);
			dqb.advancedParams.put(param, others);
			return this;
		}

		public Builder<T> withAdvancedParam(String param, Operator operator) {
			withAdvancedParam(param, operator, null);
			return this;
		}

		/**
		 * @param advancedParams
		 * @return
		 */
		public Builder<T> withAdvancedParams(
				Map<String, Map<Operator, Object>> advancedParams) {
			if (advancedParams != null)
				dqb.advancedParams.putAll(advancedParams);
			return this;
		}

		public void appenderQueryBuilder() {
			String query = dqb.queryString.toString();
			if (StringUtils.contains(query, "AND")) {
				dqb.queryString.append(" AND " + getQueryAppender());
			} else if (StringUtils.contains(query, "WHERE")) {
				dqb.queryString.append(" AND " + getQueryAppender());
			} else {
				dqb.queryString.append(" WHERE " + getQueryAppender());
			}
		}

		/**
		 * @return the final
		 * @throws IllegalAccessException
		 */
		public JpaDynamicQueryBuilder build(String queryType) {
			try {
				/**
				 * Create and prepare the named query and initialize the
				 * parameters
				 * **/
				boolean childCondition = createQueryAndParams();
				if (parentBean != null) {
					createQueryAndParamsParent(childCondition);
				}
				/**
				 * Resolve Advanced parameter if passed.
				 * **/
				resolveAdvancedParams();
				if (!StringUtils.isEmpty(getQueryAppender())) {
					appenderQueryBuilder();
				}
				/**
				 * Resolve order by parameter if passed.
				 */
				resolveOrderByParams();
				/**
				 * Create, prepare and set the Query parameter
				 */

				LOGGER.debug("Customer Search Query : "
						+ dqb.queryString.toString());
				if (QueryType.HIBERNATE.name().equals(queryType)) {
					prepareQueryParamsHibernate();
				} else {
					prepareQueryParamsJpa();
				}
			} catch (IllegalAccessException iae) {
				LOGGER.error("Error in building the in Search Query : ", iae);
			}
			return dqb;
		}

		private void append(String newVal) {
			dqb.queryString.append(newVal);
		}

		private void put(String key, Object value) {
			dqb.paramsAndValues.put(key, value);
		}

		private void createQueryAndParamsConditionSub1(Field[] subFields,
				Field field, List<String> removeable, String nameSearch)
				throws IllegalAccessException {
			for (Field subField : subFields) {
				if (subField.getName().equals(nameSearch)) {
					subField.setAccessible(true); // so we can access the
													// private fields of the sub
													// type
					if (!isContainingValue(subField.get(field.get(beanType)))) {
						removeable.add(nameSearch);
						break;
					}
				}
			}
		}

		private int createQueryAndParamsConditionSub2(Field subField,
				Map<Field, SearchRequired> fields, Field field,
				List<String> searchFieldsList, int i, int k)
				throws IllegalAccessException {
			int y = k;
			if (isContainingValue(subField.get(field.get(beanType)))) {
				y++;
				String fullName = field.getName()
						+ capitalize(subField.getName());
				append(queryObjChar + field.getName() + "."
						+ subField.getName() + " = :" + fullName);
				put(fullName, subField.get(field.get(beanType)));
				boolean b = false;
				if (i != fields.keySet().size()) {
					b = true;
					append(dqb.operType.getOp());
				}
				if (!b && (y != searchFieldsList.size())) {
					append(dqb.operType.getOp());
				}
			}
			return y;
		}

		private int createQueryAndParamsConditionSub3(Field[] subFields,
				String name, Map<Field, SearchRequired> fields, Field field,
				List<String> searchFieldsList, int i, int k)
				throws IllegalAccessException {
			int y = k;
			for (Field subField : subFields) {
				if (subField.getName().equals(name)) { // if field is the
														// required field then
														// append it to query
					subField.setAccessible(true); // so we can access the
													// private fields of the sub
													// type
					y = createQueryAndParamsConditionSub2(subField, fields,
							field, searchFieldsList, i, y);
					break;
				}
			}
			return y;
		}

		private void createQueryAndParamsConditions(String[] searchFields,
				Map<Field, SearchRequired> fields, Field field,
				Field[] subFields, int i) throws IllegalAccessException {

			if (searchFields.length == 0) { // if no fields then search by the
											// whole object id
				append(queryObjChar + field.getName() + " = :"
						+ field.getName());
				put(field.getName(), field.get(beanType));
				if (i != fields.keySet().size())
					append(dqb.operType.getOp());

			} else {// get the object required search fields
				int j = 0;
				List<String> searchFieldsList = new ArrayList<String>(
						Arrays.asList(searchFields));
				List<String> removeable = new ArrayList<String>();
				for (String nameSearch : searchFieldsList) {
					createQueryAndParamsConditionSub1(subFields, field,
							removeable, nameSearch);
				}
				searchFieldsList.removeAll(removeable);
				for (String name : searchFieldsList) {
					j = createQueryAndParamsConditionSub3(subFields, name,
							fields, field, searchFieldsList, i, j);
				}
			}
		}

		private boolean createQueryAndParams() throws IllegalAccessException {
			/**
			 * get required search fields
			 */
			boolean childCondition = false;
			Map<Field, SearchRequired> fields = getSearchFields();
			int i = 0;
			/**
			 * for testing the last param, to not append the operator
			 **/
			if (!fields.isEmpty()) { // If no fields then construct select all
										// query.
				append(" WHERE ");
				childCondition = true;
			}
			if (StringUtils.isNotEmpty(this.joinConditionString)) {
				append(" " + this.joinConditionString + " ");
				if (!fields.isEmpty()) {
					append(dqb.operType.getOp());
				}
			}
			for (Field field : fields.keySet()) {
				i++;
				SearchRequired srAnnotation = fields.get(field);
				if (srAnnotation.isObject()) {
					// if field described as object get its fields
					Field[] subFields = field.getType().getDeclaredFields();
					// get the required search fields from the annotation fields
					// attribute
					String[] searchFields = srAnnotation.fields();
					createQueryAndParamsConditions(searchFields, fields, field,
							subFields, i);
				} else { // build normal bean type primitive attribute
					append(queryObjChar + field.getName() + " = :"
							+ field.getName());
					put(field.getName(), field.get(beanType));
					if (i != fields.keySet().size())
						append(dqb.operType.getOp());
				}
			}

			return childCondition;
		}

		private void createQueryAndParamsParentSub1(
				Map<Field, SearchRequired> fields, int i) {
			if (i != fields.keySet().size())
				append(dqb.operType.getOp());
		}

		private int createQueryAndParamsParentSub3(Field subField, Field field,
				String queryObjParentChar, Map<Field, SearchRequired> fields,
				String[] searchFields, int k, int i)
				throws IllegalAccessException {
			int y = k;

			if (isContainingValue(subField.get(field
					.get(this.beanJoinParentType.cast(parentBean))))) {
				y++;
				String fullName = field.getName()
						+ capitalize(subField.getName());
				append(queryObjParentChar + "." + field.getName() + "."
						+ subField.getName() + " = :" + fullName);
				put(fullName, subField.get(field.get(this.beanJoinParentType
						.cast(parentBean))));
				boolean b = false;
				if (i != fields.keySet().size()) {
					b = true;
					append(dqb.operType.getOp());
				}
				if (!b && (y != searchFields.length)) {
					append(dqb.operType.getOp());
				}
			}

			return y;
		}

		private void createQueryAndParamsParentSub2(String[] searchFields,
				Field[] subFields, Field field, String queryObjParentChar,
				Map<Field, SearchRequired> fields, int i)
				throws IllegalAccessException {

			int j = 0;
			for (String name : searchFields) {

				for (Field subField : subFields) {

					if (subField.getName().equals(name)) { // if field is the
															// required field
															// then append it to
															// query
						subField.setAccessible(true); // so we can access the
														// private fields of the
														// sub type
						j = createQueryAndParamsParentSub3(subField, field,
								queryObjParentChar, fields, searchFields, j, i);
						break;
					}
				}
			}
		}

		private void createQueryAndParamsParent(boolean childCondition)
				throws IllegalAccessException {
			Map<Field, SearchRequired> fields = getSearchFieldsParent();

			if (!fields.isEmpty() && childCondition) { // If no fields then
														// construct select all
														// query.

				for (Map.Entry<Field, SearchRequired> entry : fields.entrySet()) {
					if (isContainingValue(entry.getKey().get(
							this.beanJoinParentType.cast(parentBean)))) {
						append(dqb.operType.getOp());
						break;
					}

				}
			}

			int i = 0;
			/**
			 * for testing the last param, to not append the operator
			 **/
			String queryObjParentChar = resolveName(
					this.beanJoinParentType.getClass().getName()).substring(0,
					1).toLowerCase();

			for (Field field : fields.keySet()) {
				i++;
				SearchRequired srAnnotation = fields.get(field);
				if (srAnnotation.isObject()) {
					// if field described as object get its fields
					Field[] subFields = field.getType().getDeclaredFields();

					// get the required search fields from the annotation fields
					// attribute
					String[] searchFields = srAnnotation.fields();

					if (searchFields.length == 0) { // if no fields then search
													// by the whole object id
						append(queryObjParentChar + "." + field.getName()
								+ " = :" + field.getName());
						put(field.getName(), field.get(this.beanJoinParentType
								.cast(parentBean)));
						createQueryAndParamsParentSub1(fields, i);

					} else {// get the object required search fields
						createQueryAndParamsParentSub2(searchFields, subFields,
								field, queryObjParentChar, fields, i);
					}
				} else { // build normal bean type primitive attribute
					append(queryObjParentChar + "." + field.getName() + " = :"
							+ field.getName());
					put(field.getName(),
							field.get(this.beanJoinParentType.cast(parentBean)));
					if (i != fields.keySet().size())
						append(dqb.operType.getOp());
				}
			}
		}

		/**
		 * Method to check the values passed againest null.
		 * 
		 * @param value
		 *            to be checked.
		 * @return true if not null, elase false.
		 */

		private boolean isContainingValue(Object value) {
			boolean containsValue = false;
			if (value != null)
				if (value instanceof String)
					containsValue = !String.class.cast(value).trim().isEmpty();
				else
					containsValue = true;

			return containsValue;
		}

		/**
		 * Method to resolve a class name.
		 * 
		 * @param name
		 *            to be resolved.
		 * @return resolved name without packages
		 */

		private String resolveName(String name) {
			return substringAfterLast(name, ".");
		}

		private boolean isIdFieldContainsValueSub(Annotation annotation,
				Field field, Object type) throws IllegalAccessException {
			boolean containsValue = true;
			if (annotation instanceof Id) {
				field.setAccessible(true);
				/**
				 * so we can access the private fields for bean type
				 **/
				if (!isContainingValue(field.get(type)))
					containsValue = false;
			}
			return containsValue;
		}

		private boolean isIdFieldContainsValue(Field[] subFields, Object type)
				throws IllegalAccessException {
			boolean containsValue = true;
			if (subFields != null)
				for (Field field : subFields) {
					for (Annotation annotation : field.getDeclaredAnnotations()) {

						containsValue = isIdFieldContainsValueSub(annotation,
								field, type);

					}
				}
			return containsValue;
		}

		private void searchFieldsConditions(Map<Field, SearchRequired> fields,
				Field field, SearchRequired srAnno)
				throws IllegalAccessException {

			if (isContainingValue(field.get(beanType))) {
				if (srAnno.isObject()) {

					if (srAnno.fields().length > 0
							&& isIdFieldContainsValue(field.getType()
									.getDeclaredFields(), field.get(beanType))) {
						fields.put(field, srAnno);
					}

				} else {
					fields.put(field, srAnno);
				}
			}
		}

		/**
		 * This method get all fields annotated with <code>SearchRequired</code>
		 * , and check if its contents is not null.
		 * 
		 * @return Map<Field, SearchRequired> of declared fields.
		 * @throws IllegalAccessException
		 * @see com.dpworld.mpcsystem.annotation.SearchRequired
		 */
		private Map<Field, SearchRequired> getSearchFields()
				throws IllegalAccessException {
			Map<Field, SearchRequired> fields = new HashMap<Field, SearchRequired>();
			for (Field field : this.beanType.getClass().getDeclaredFields()) {
				for (Annotation annotation : field.getDeclaredAnnotations()) {
					if (annotation instanceof SearchRequired) {
						SearchRequired srAnno = SearchRequired.class
								.cast(annotation);
						field.setAccessible(true);
						/**
						 * so we can access the private fields for bean type
						 */
						searchFieldsConditions(fields, field, srAnno);
					}
				}
			}

			return fields;
		}

		private void searchFieldsParentConditions(
				Map<Field, SearchRequired> fields, Field field,
				SearchRequired srAnno) throws IllegalAccessException {

			if (isContainingValue(field.get(this.beanJoinParentType
					.cast(parentBean)))) {
				if (srAnno.isObject()) {

					if (srAnno.fields().length > 0
							&& isIdFieldContainsValue(field.getType()
									.getDeclaredFields(),
									field.get(this.beanJoinParentType
											.cast(parentBean)))) {
						fields.put(field, srAnno);
					}

				} else {
					fields.put(field, srAnno);
				}
			}
		}

		private Map<Field, SearchRequired> getSearchFieldsParent()
				throws IllegalAccessException {
			Map<Field, SearchRequired> fields = new HashMap<Field, SearchRequired>();
			for (Field field : (this.beanJoinParentType.cast(parentBean))
					.getClass().getDeclaredFields()) {
				for (Annotation annotation : field.getDeclaredAnnotations()) {
					if (annotation instanceof SearchRequired) {
						SearchRequired srAnno = SearchRequired.class
								.cast(annotation);
						field.setAccessible(true);
						/**
						 * so we can access the private fields for bean type
						 */
						searchFieldsParentConditions(fields, field, srAnno);
					}
				}
			}

			return fields;
		}

		private void resolveAdvancedParams() {
			if (dqb.advancedParams == null || dqb.advancedParams.isEmpty())
				return;

			for (String key : dqb.advancedParams.keySet()) {
				/**
				 * if the passed param's doesn't exist in filtered search
				 * param's continue.
				 */
				if (!dqb.paramsAndValues.containsKey(key))
					continue;

				Operator oper = dqb.advancedParams.get(key).keySet().iterator()
						.next();
				Object extra = dqb.advancedParams.get(key).get(oper);
				handleAdvancedParamsOpers(key.trim(), oper, extra);
			}
		}

		private void resolveOrderByParams() {
			if (dqb.orderByParams == null || dqb.orderByParams.isEmpty())
				return;

			append(" ORDER BY ");
			String querySelectionChar = queryObjChar;
			if (this.orderByOnParent) {
				querySelectionChar = resolveName(
						this.beanJoinParentType.getClass().getName())
						.substring(0, 1).toLowerCase() + ".";
			}
			int i = dqb.orderByParams.keySet().size();
			for (String key : dqb.orderByParams.keySet()) {
				i--;
				append(querySelectionChar + key + " "
						+ dqb.orderByParams.get(key));
				if (i > 0) {
					append(", ");
				}
			}
		}

		private void handleAdvancedParamsOpers(String key, Operator operator,
				Object extras) {

			int start = dqb.queryString.toString().indexOf(":" + key);

			dqb.queryString.replace(start - 2, start, operator.getOp());

			if (operator.equals(IN))
				dqb.paramsAndValues.put(key, extras);
			else if (operator.equals(LIKE))
				dqb.paramsAndValues.put(key, Operator.adjustLikeValue(
						(String) dqb.paramsAndValues.get(key),
						LikePattern.class.cast(extras)));
			else if (operator.equals(BETWEEN)) {
				int queryKeyPosition = dqb.queryString.toString().indexOf(key);

				while (dqb.queryString.toString().charAt(queryKeyPosition) != queryObjChar
						.charAt(0))
					queryKeyPosition--;

				dqb.queryString.replace(queryKeyPosition - 1, queryKeyPosition,
						" (");

				queryKeyPosition = dqb.queryString.toString()
						.indexOf(":" + key);

				dqb.queryString.replace(queryKeyPosition, queryKeyPosition
						+ key.length() + 1, ":" + key + "From AND :" + key
						+ "To)");

				dqb.paramsAndValues.remove(key);
				Collection<?> betweenValues = Collection.class.cast(extras);
				dqb.paramsAndValues.put(key + "From", betweenValues.iterator()
						.next());
				dqb.paramsAndValues.put(key + "To", betweenValues.iterator()
						.next());
			}
		}

		/**
		 * This method handles the parameters to be set in Query object and
		 * handle temporal types
		 * 
		 * @param parameters
		 */

		private void prepareQueryParamsJpa() {
			if (em == null)
				return;
			Query querySearch = em.createQuery(dqb.getQueryString());
			if (dqb.paramsAndValues != null || !dqb.paramsAndValues.isEmpty())
				for (String key : dqb.paramsAndValues.keySet()) {
					Object value = dqb.paramsAndValues.get(key);
					if (value instanceof Timestamp) {
						querySearch.setParameter(key,
								Timestamp.class.cast(value), TIMESTAMP);
					} else if (value instanceof Date) {
						querySearch.setParameter(key, Date.class.cast(value),
								DATE);
					} else {
						querySearch.setParameter(key, value);
					}
				}

			dqb.query = querySearch;
		}

		/**
		 * This method handles the parameters to be set in Query object and
		 * handle temporal types
		 * 
		 * @param parameters
		 */

		private void prepareQueryParamsHibernate() {
			if (em == null)
				return;
			Session session = em.unwrap(Session.class);

			org.hibernate.Query hibernateQuerySearch = session.createQuery(dqb
					.getQueryString());
			if (dqb.paramsAndValues != null || !dqb.paramsAndValues.isEmpty())
				for (String key : dqb.paramsAndValues.keySet()) {
					Object value = dqb.paramsAndValues.get(key);
					if (value instanceof Timestamp) {
						hibernateQuerySearch.setParameter(key,
								Timestamp.class.cast(value));
					} else if (value instanceof Date) {
						hibernateQuerySearch.setParameter(key,
								Date.class.cast(value));
					} else {
						hibernateQuerySearch.setParameter(key, value);
					}
				}

			dqb.hibernateQuery = hibernateQuerySearch;
		}

		private void isValidAdvancedParamLike(Object value)
				throws IllegalArgumentException {
			if (!(value instanceof Operator.LikePattern))
				throw new IllegalArgumentException(
						"You should use one value of 'Operator.LikePattern' enum with 'LIKE' operator.");
		}

		private void isValidAdvancedParamIn(Object value)
				throws IllegalArgumentException {
			if (!(value instanceof Collection))
				throw new IllegalArgumentException(
						"You should use 'Collection' object with 'IN' operator.");
		}

		private void isValidAdvancedParamBetween(Object value)
				throws IllegalArgumentException {
			if (value instanceof Collection) {
				Collection<?> values = Collection.class.cast(value);
				if (values.size() != 2)
					throw new IllegalArgumentException(
							"The max values in 'Collection' object with 'BETWEEN' operator should be 2.");
			}
		}

		private void isValidAdvancedParam(Operator operator, Object value)
				throws IllegalArgumentException {
			switch (operator) {
			case LIKE:
				isValidAdvancedParamLike(value);
				break;
			case IN:
				isValidAdvancedParamIn(value);
				break;
			case BETWEEN:
				isValidAdvancedParamBetween(value);
				break;
			default:
				throw new IllegalArgumentException(
						"You should use 'Collection' object with 'BETWEEN' operator.");
			}

		}
	}

}
