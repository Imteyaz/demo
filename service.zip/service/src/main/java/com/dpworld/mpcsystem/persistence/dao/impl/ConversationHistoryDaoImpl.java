package com.dpworld.mpcsystem.persistence.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.pojo.ConversationHistoryDTO;
import com.dpworld.mpcsystem.persistence.dao.ConversationHistoryDao;
import com.dpworld.mpcsystem.persistence.model.MpcConversationHistory;


@Repository("conversationHistoryDao")
public class ConversationHistoryDaoImpl extends
PersistenceUnitDaoImpl<MpcConversationHistory, Long> implements ConversationHistoryDao{
	public ConversationHistoryDaoImpl() {
		super(MpcConversationHistory.class);
	}
	
	
	public ConversationHistoryDaoImpl(Class<MpcConversationHistory> persistentClass) {
		super(persistentClass);
	}

	@Override
	public List<ConversationHistoryDTO> getConversationHistoryList(String userName) {
		List<ConversationHistoryDTO> convHistoryDataList = new ArrayList<ConversationHistoryDTO>();
		
		try {

			EntityManager em = getEntityManager();
			String convData = "select a.*,b.user_code,b.subscr_status"
                    + " from mpc_conversations_hist a,mpc_conv_subscr_hist b "
                    +  " where a.conv_id=b.conv_id  and a.conv_user = '"+userName +"'";
			Query query = em.createNativeQuery(convData);
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			List<Object[]> results = query.getResultList();
			
			if (results != null && results.size() > 0) {
				for (Object[] mpcConvHistory : results) {

					ConversationHistoryDTO conversationHistoryDTO = new ConversationHistoryDTO();
					
					conversationHistoryDTO.setRecId(String
							.valueOf(mpcConvHistory[0]));
					
					conversationHistoryDTO.setRecDate(formatter.format(mpcConvHistory[1]).toString());
					if(mpcConvHistory[2] != null){
					conversationHistoryDTO.setConvType(String.valueOf(mpcConvHistory[2]));
					}
					else {
						conversationHistoryDTO.setConvType("");	
					}
					if(mpcConvHistory[3] != null){
					conversationHistoryDTO.setAltId(String.valueOf(mpcConvHistory[3]));
					}
					else {
						conversationHistoryDTO.setAltId("");	
					}
					if(mpcConvHistory[4] != null){
					conversationHistoryDTO.setConvId(String.valueOf(mpcConvHistory[4]));
					}
					else {
						conversationHistoryDTO.setConvId("");
					}
					if(mpcConvHistory[5] != null){
					conversationHistoryDTO.setConvTopicType(String.valueOf(mpcConvHistory[5]));
					}
					else {
						conversationHistoryDTO.setConvTopicType("");	
					}
					if(mpcConvHistory[6] != null){
					conversationHistoryDTO.setConvTopicVal(String.valueOf(mpcConvHistory[6]));
					}
					else{
						conversationHistoryDTO.setConvTopicVal("");	
					}
					if(mpcConvHistory[7] != null){
					conversationHistoryDTO.setConvSubTopicType(String.valueOf(mpcConvHistory[7]));
					}
					else {
						conversationHistoryDTO.setConvSubTopicType("");
					}
					if(mpcConvHistory[8] != null){
					conversationHistoryDTO.setConvSubTopicVal(String.valueOf(mpcConvHistory[8]));
					}
					else {
						conversationHistoryDTO.setConvSubTopicVal("");	
					}
					if(mpcConvHistory[9] != null){
					conversationHistoryDTO.setConvText(String.valueOf(mpcConvHistory[9]));
					}
					else {
						conversationHistoryDTO.setConvText("");	
					}
					if(mpcConvHistory[10] != null){
					conversationHistoryDTO.setConvUser(String.valueOf(mpcConvHistory[10]));
					}
					else {
						conversationHistoryDTO.setConvUser("");
					}
					if(mpcConvHistory[11].toString().equals("1")){
					conversationHistoryDTO.setIsValid(MPCConstants.YES);
					} else if (mpcConvHistory[11].toString().equals("0")) {
						conversationHistoryDTO.setIsValid(MPCConstants.NO);
					}
					if(mpcConvHistory[12] != null){
					conversationHistoryDTO.setSrcSys(String.valueOf(mpcConvHistory[12]));
					}
					else {
						conversationHistoryDTO.setSrcSys("");	
					}
					if(mpcConvHistory[13] != null){
					conversationHistoryDTO.setCreatedOn(formatter.format(mpcConvHistory[13]).toString());
					}
					else {
						conversationHistoryDTO.setCreatedOn("");	
					}
					if(mpcConvHistory[14] != null){
					conversationHistoryDTO.setCreatedBy(String.valueOf(mpcConvHistory[14]));
					}
					else {
						conversationHistoryDTO.setCreatedBy("");	
					}
					if(mpcConvHistory[15] != null){
					conversationHistoryDTO.setModifiedOn(formatter.format(mpcConvHistory[15]).toString());
					}
					else {
						conversationHistoryDTO.setModifiedOn("");
					}
					if(mpcConvHistory[16] != null){
					conversationHistoryDTO.setModifiedBy(String.valueOf(mpcConvHistory[16]));
					}
					else {
						conversationHistoryDTO.setModifiedBy("");
					}
					if(mpcConvHistory[17] != null){
					conversationHistoryDTO.setUserCode(String.valueOf(mpcConvHistory[17]));
					} else {
						conversationHistoryDTO.setUserCode("");
					}
					if(mpcConvHistory[18] != null){
					conversationHistoryDTO.setSubscrStatus(String.valueOf(mpcConvHistory[18]));
					}
					else {
						conversationHistoryDTO.setSubscrStatus("");	
					}
					convHistoryDataList.add(conversationHistoryDTO);
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}

		return convHistoryDataList;
	}
	

}
