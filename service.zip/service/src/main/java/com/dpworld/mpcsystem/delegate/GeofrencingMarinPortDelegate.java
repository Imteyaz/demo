package com.dpworld.mpcsystem.delegate;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;

public interface GeofrencingMarinPortDelegate {
	List<VesselDetailsDTO> vesselDetailBPAPromis();
}
