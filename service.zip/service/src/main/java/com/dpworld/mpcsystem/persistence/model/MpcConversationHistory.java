package com.dpworld.mpcsystem.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_conversations_hist")
@NamedQuery(name = "MpcConversationHistory.findAll", query = "SELECT m FROM MpcConversationHistory m")
public class MpcConversationHistory implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "REC_ID")
	private long recId;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "REC_DATE")
	private Date recDate;

	@Column(name = "CONV_TYPE")
	private String convType;

	@Column(name = "ALT_ID")
	private Integer altId;

	@Column(name = "CONV_ID")
	private Integer convId;

	@Column(name = "CONV_TOPIC_TYPE")
	private String convTopicType;
	
	@Column(name = "CONV_TOPIC_VAL")
	private String convTopicVal;

	@Column(name = "CONV_SUBTOPIC_TYPE")
	private String convSubTopicType;
	
	@Column(name = "CONV_SUBTOPIC_Val")
	private String convSubTopicVal;
	
	@Column(name = "CONV_TEXT")
	private String convText;
	
	@Column(name = "CONV_USER")
	private String convUser;
	
	@Column(name = "IS_VALID")
	private Integer isValid;

	@Column(name = "SRC_SYS")
	private String srcSys;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_ON")
	private Date careatedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIFIED_ON")
	private Date modifiedDate;
	
	public long getRecId() {
		return recId;
	}

	public void setRecId(long recId) {
		this.recId = recId;
	}

	public Date getRecDate() {
		return recDate;
	}

	public void setRecDate(Date recDate) {
		this.recDate = recDate;
	}

	public String getConvType() {
		return convType;
	}

	public void setConvType(String convType) {
		this.convType = convType;
	}

	public Integer getAltId() {
		return altId;
	}

	public void setAltId(Integer altId) {
		this.altId = altId;
	}

	public Integer getConvId() {
		return convId;
	}

	public void setConvId(Integer convId) {
		this.convId = convId;
	}

	public String getConvTopicType() {
		return convTopicType;
	}

	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}

	public String getConvTopicVal() {
		return convTopicVal;
	}

	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}

	public String getConvSubTopicType() {
		return convSubTopicType;
	}

	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}

	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}

	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}

	public String getConvText() {
		return convText;
	}

	public void setConvText(String convText) {
		this.convText = convText;
	}

	public String getConvUser() {
		return convUser;
	}

	public void setConvUser(String convUser) {
		this.convUser = convUser;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCareatedDate() {
		return careatedDate;
	}

	public void setCareatedDate(Date careatedDate) {
		this.careatedDate = careatedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
}
