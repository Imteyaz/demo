package com.dpworld.mpcsystem.persistence.search;

import java.util.List;

import com.dpworld.mpcsystem.common.GenericException;

public abstract class SearchFlow<T, E, W> implements SearchCommunicator<T> {

	Class<T> serviceFactoryInterface;
	SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder;
	List<W> outputObject;
	T service;

	public SearchFlow(Class<T> serviceFactoryInterface,
			SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder) {
		this.serviceFactoryInterface = serviceFactoryInterface;
		this.searchingCriteriaValuesHolder = searchingCriteriaValuesHolder;
	}

	@Override
	public final T getCommunicatorModule() {
		return SearchServiceDecorator.decorate(this,
				searchingCriteriaValuesHolder);
	}

	public interface SearchFlowFactoryContext<T, E, W> extends
			SearchCommunicator<T> {
		E beforeSearch(
				SearchingCriteriaValuesHolder<E, W> searchingCriteriaValuesHolder);

		List<W> transformResult(SearchingCriteriaValuesHolder<E, W> holder)
				throws GenericException;

		boolean validate(SearchingCriteriaValuesHolder<E, W> holder);

	}

	public List<W> getOutputObject() {
		return outputObject;
	}

	public void setOutputObject(List<W> outputObject) {
		this.outputObject = outputObject;
	}

	public T getService() {
		return service;
	}

	public void setService(T service) {
		this.service = service;
	}

	public abstract SearchFlowFactoryContext<T, E, W> getSearchFlowContext();

}
