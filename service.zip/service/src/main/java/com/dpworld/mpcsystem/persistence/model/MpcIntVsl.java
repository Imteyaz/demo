package com.dpworld.mpcsystem.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "mpc_int_vsl")
@NamedQuery(name = "MpcIntVsl.findAll", query = "SELECT m FROM MpcIntVsl m")
public class MpcIntVsl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "rec_id")
	private long recId;

	@Temporal(TemporalType.DATE)
	@Column(name = "rec_date")
	private Date recDate;
	
	@Column(name = "rotn")
	private String rotation;

	@Column(name = "vess_name")
	private String vessName;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "bth_date")
	private Date bthDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "sail_date")
	private Date sailDate;
	
	@Column(name = "status")
	private String status;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "eta_date")
	private Date etaDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "etb_date")
	private Date etbDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "etd_date")
	private Date etdDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "anch_date")
	private Date anchDate;
	
	@Column(name = "voyage_no")
	private String voyageNo;
	
	@Column(name = "out_voyage_no")
	private String outVoyageNo;
	
	@Column(name = "voyage_route")
	private String voyageRoute;
	
	@Column(name = "voyage_type")
	private String voyageType;
	
	@Column(name = "arr_fm")
	private String arrFm;
	
	@Column(name = "call_reason")
	private String callReason;
	
	@Column(name = "call_type")
	private String callType;
	
	@Column(name = "call_descr")
	private String callDescr;
	
	@Column(name = "plan_moves")
	private int planMoves;
	
	@Column(name = "line_code")
	private String lineCode;
	
	@Column(name = "in_vess_service")
	private String inVessService;
	
	@Column(name = "arr_draft")
	private int arrDraft;
	
	@Column(name = "sail_draft")
	private int sailDraft;
	
	@Column(name = "dual_berth")
	private String dualBerth;
	
	@Column(name = "port_code")
	private String portCode;
	
	@Column(name = "terminal_id")
	private String terminalId;
	
	@Column(name = "load_terminal_id")
	private String loadTerminalId;
	
	@Column(name = "call_sign")
	private String callSign;
	
	@Column(name = "len")
	private int len;
	
	@Column(name = "imo_code")
	private String imoCode;
	
	@Column(name = "vess_type")
	private String vessType;
	
	@Column(name = "src_sys")
	private String srcSys;
	
	@Column(name = "is_valid")
	private int isValid;

	public long getRecId() {
		return recId;
	}

	public void setRecId(long recId) {
		this.recId = recId;
	}

	public Date getRecDate() {
		return recDate;
	}

	public void setRecDate(Date recDate) {
		this.recDate = recDate;
	}

	public String getRotation() {
		return rotation;
	}

	public void setRotation(String rotation) {
		this.rotation = rotation;
	}

	public String getVessName() {
		return vessName;
	}

	public void setVessName(String vessName) {
		this.vessName = vessName;
	}
   
	public Date getBthDate() {
		return bthDate;
	}

	public void setBthDate(Date bthDate) {
		this.bthDate = bthDate;
	}

	public Date getSailDate() {
		return sailDate;
	}

	public void setSailDate(Date sailDate) {
		this.sailDate = sailDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getEtaDate() {
		return etaDate;
	}

	public void setEtaDate(Date etaDate) {
		this.etaDate = etaDate;
	}

	public Date getEtbDate() {
		return etbDate;
	}

	public void setEtbDate(Date etbDate) {
		this.etbDate = etbDate;
	}

	public Date getEtdDate() {
		return etdDate;
	}

	public void setEtdDate(Date etdDate) {
		this.etdDate = etdDate;
	}

	public Date getAnchDate() {
		return anchDate;
	}

	public void setAnchDate(Date anchDate) {
		this.anchDate = anchDate;
	}

	public String getVoyageNo() {
		return voyageNo;
	}

	public void setVoyageNo(String voyageNo) {
		this.voyageNo = voyageNo;
	}

	public String getOutVoyageNo() {
		return outVoyageNo;
	}

	public void setOutVoyageNo(String outVoyageNo) {
		this.outVoyageNo = outVoyageNo;
	}

	public String getVoyageRoute() {
		return voyageRoute;
	}

	public void setVoyageRoute(String voyageRoute) {
		this.voyageRoute = voyageRoute;
	}

	public String getVoyageType() {
		return voyageType;
	}

	public void setVoyageType(String voyageType) {
		this.voyageType = voyageType;
	}

	public String getArrFm() {
		return arrFm;
	}

	public void setArrFm(String arrFm) {
		this.arrFm = arrFm;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getCallDescr() {
		return callDescr;
	}

	public void setCallDescr(String callDescr) {
		this.callDescr = callDescr;
	}

	public int getPlanMoves() {
		return planMoves;
	}

	public void setPlanMoves(int planMoves) {
		this.planMoves = planMoves;
	}

	public String getLineCode() {
		return lineCode;
	}

	public void setLineCode(String lineCode) {
		this.lineCode = lineCode;
	}

	public String getInVessService() {
		return inVessService;
	}

	public void setInVessService(String inVessService) {
		this.inVessService = inVessService;
	}

	public int getArrDraft() {
		return arrDraft;
	}

	public void setArrDraft(int arrDraft) {
		this.arrDraft = arrDraft;
	}

	public int getSailDraft() {
		return sailDraft;
	}

	public void setSailDraft(int sailDraft) {
		this.sailDraft = sailDraft;
	}

	public String getDualBerth() {
		return dualBerth;
	}

	public void setDualBerth(String dualBerth) {
		this.dualBerth = dualBerth;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getLoadTerminalId() {
		return loadTerminalId;
	}

	public void setLoadTerminalId(String loadTerminalId) {
		this.loadTerminalId = loadTerminalId;
	}

	public String getCallSign() {
		return callSign;
	}

	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}

	public int getLen() {
		return len;
	}

	public void setLen(int len) {
		this.len = len;
	}

	public String getImoCode() {
		return imoCode;
	}

	public void setImoCode(String imoCode) {
		this.imoCode = imoCode;
	}

	public String getVessType() {
		return vessType;
	}

	public void setVessType(String vessType) {
		this.vessType = vessType;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public int getIsValid() {
		return isValid;
	}

	public void setIsValid(int isValid) {
		this.isValid = isValid;
	}
	
	
	
	
	
}
