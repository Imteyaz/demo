package com.dpworld.mpcsystem.helper.responsebinder;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class ResultSetImpl implements ResultSet {
	private List<DataRow> rows = new LinkedList<DataRow>();
	private String _name = null;
	private String[] names = null;

	private static final  Logger LOG = Logger.getLogger(ResultSetImpl.class);

	/**
	 * ResultSetImpl Constructor
	 * 
	 * @param name
	 *            The name of the ResultSet.
	 * @param fieldNames
	 *            An array of field names.
	 * @throws RuntimeException
	 */
	public ResultSetImpl(String stringName, String[] fieldNames) {
		names = fieldNames;
		_name = stringName;
	}

	/**
	 * Gets the name of the ResultSetImpl
	 * 
	 * @throws RuntimeException
	 * @return String
	 */
	@Override
	public String getName() throws RuntimeException {
		LOG.debug("Inside getName Method");
		try {
			return _name;
		} catch (Exception e) {
			LOG.error("Exception in getName --> " + e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Sets the name of the ResultSetImpl
	 * 
	 * @param name
	 *            The name of the ResultSet.
	 * @throws RuntimeException
	 */
	@Override
	public void setName(String stringName) throws RuntimeException {
		LOG.debug("Inside setName Method");
		try {
			_name = stringName;
		} catch (Exception e) {
			LOG.error("Exception in setName Method --> " + e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets DataRows of the ResultSetImpl
	 * 
	 * @throws RuntimeException
	 * @return List<DataRow>
	 */
	@Override
	public List<DataRow> getRows() throws RuntimeException {
		LOG.debug("Inside getRows Method ");
		try {
			return rows;
		} catch (Exception e) {
			LOG.error("Exception In getRows Method --> " + e.getStackTrace(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Create new DataRow in the ResultSetImpl
	 * 
	 * @throws RuntimeException
	 * @return DataRow
	 */
	@Override
	public DataRow createNewRow() throws RuntimeException {
		LOG.debug("Inside createNewRow Method no param");
		try {
			DataRow row = new DataRowImpl(names);
			rows.add(row);
			return row;
		} catch (Exception e) {
			LOG.error(
					"Exception in createNewRow  Method no param--> " + e.getStackTrace(),
					e);
			throw new RuntimeException(e);
		}
	}

	@Override
	public DataRow copyRow(DataRow row, int index) throws RuntimeException {
		LOG.debug("Inside copyRow Method ");
		if (index > 0) {
			DataRow rowNew = new DataRowImpl(names);
			try {

				Map<String, String> _data = row.getRowData();
				rowNew.setRowData(_data);
				rows.add(rowNew);
			} catch (Exception e) {
				LOG.error(
						"Exception in copyRow Method --> " + e.getStackTrace(),
						e);
				throw new RuntimeException(e);
			}
			return rowNew;
		} else {
			return row;
		}

	}

	/**
	 * Create new DataRow in the ResultSetImpl
	 * 
	 * @throws RuntimeException
	 * @return DataRow
	 */
	public DataRow createNewRow(String[] stringNames) throws RuntimeException {
		LOG.debug("Inside createNewRow Method ");
		try {
			DataRow row = new DataRowImpl(stringNames);
			rows.add(row);
			return row;
		} catch (Exception e) {
			LOG.error(
					"Exception in createNewRow Method --> " + e.getStackTrace(),
					e);
			throw new RuntimeException(e);
		}
	}

}
