/**
 * 
 */
package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.dpworld.mpcsystem.persistence.dao.ETAServiceMPCDao;
import com.dpworld.mpcsystem.service.ETAServiceMPC;

/**
 * @author Vinculum.Imteyaz
 *
 */
@Service("etaServiceMPC")
public class ETAServiceMPCImpl implements ETAServiceMPC {

	@Autowired
	private ETAServiceMPCDao etaServiceMPCDao;
	@Override
	public List<VesselDetailsDTO> getVesseldetails() {
		return etaServiceMPCDao.getVesseldetails();
	}


}
