package com.dpworld.mpcsystem.persistence.dao;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.common.utility.pojo.GeofenceformView;

public interface GeofencingDataViewDao {

	 List<GeoFenceViewDTO> getGeoFenceDataList(int min, int max, GeofenceformView geofenceformView);
	 
	 int countGeofencingData(GeofenceformView geofenceformView);
}
