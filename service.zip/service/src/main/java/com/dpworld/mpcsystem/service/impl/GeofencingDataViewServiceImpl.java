package com.dpworld.mpcsystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.common.utility.pojo.GeofenceformView;
import com.dpworld.mpcsystem.persistence.dao.GeofencingDataViewDao;
import com.dpworld.mpcsystem.service.GeofencingDataViewService;

@Service("geofenceDataService")
public class GeofencingDataViewServiceImpl implements GeofencingDataViewService{

	@Autowired
	private GeofencingDataViewDao geofencingDataViewDao;
	
	public List<GeoFenceViewDTO> getGeoFenceDataList(int min, int max, GeofenceformView geofenceformView) {
		
		return geofencingDataViewDao.getGeoFenceDataList(min, max, geofenceformView);
	}

	
	public int countGeofencingData(GeofenceformView geofenceformView) {

		return geofencingDataViewDao.countGeofencingData(geofenceformView);
	}

}
