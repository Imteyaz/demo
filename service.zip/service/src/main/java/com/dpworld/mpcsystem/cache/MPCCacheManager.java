package com.dpworld.mpcsystem.cache;
import java.util.List;

import org.infinispan.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.MPCUtil;
import com.dpworld.mpcsystem.common.utility.pojo.MarineJoblistDetailsDTO;
import com.dpworld.mpcsystem.common.utility.pojo.VesselDetailsDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
@Component
public class MPCCacheManager {
	
	private static final Logger logger = LoggerFactory
			.getLogger(MPCCacheManager.class);
	
	private static final MPCCacheManager instance = new MPCCacheManager();
	
	public Cache<String, List<VesselDetailsDTO>> MpcVesselDto = MPCCacheContainer.getCache("VesselDtoCache");
	/*tariq*/
	public Cache<String, List<MarineJoblistDetailsDTO>> MpcMarineJobListDto = MPCCacheContainer.getCache("MarineJobListDtoDtoCache");


	public Cache<String, List<MarineJoblistDetailsDTO>> getMpcMarineJobListDto() {
		return MpcMarineJobListDto;
	}

	

	private MPCCacheManager() {
	}

	public static MPCCacheManager getInstance() {
		return instance;
	}

	public Cache<String, List<VesselDetailsDTO>> getMpcVesselDto() {
		return MpcVesselDto;
	}

	public void setMpcVesselDto() {
		
		Client c = Client.create();
		Gson gson = new Gson();
		WebResource resource = null;
		resource = c.resource(MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL)
				+ "workOrderList");
		String response = resource.get(String.class);
		List<VesselDetailsDTO> list = gson.fromJson(response, new TypeToken<List<VesselDetailsDTO>>() {
		}.getType());
		MpcVesselDto.put("marineWorkListDto", list);
		logger.debug("=============-------**********from MPCCacheManager"+MpcVesselDto.get("marineWorkListDto").toString());
	}
	
	/*tariq*/
	
	/*public void setMpcMarineJobListDto(
			Cache<String, List<VesselDetailsDTO>> mpcMarineJobListDto) {
		MpcMarineJobListDto = mpcMarineJobListDto;
	}*/
	public void setMpcMarineJobListDto() {
		
		Client c = Client.create();
		Gson gson = new Gson();
		WebResource resource = null;
		resource = c.resource(MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL)
				+ "marineJobList");
		String response = resource.get(String.class);
		List<MarineJoblistDetailsDTO> list = gson.fromJson(response, new TypeToken<List<MarineJoblistDetailsDTO>>() {
		}.getType());
		MpcMarineJobListDto.put("marineJobListDto", list);
		
		logger.debug("=============-------**********from MPCCacheManager list size"+list.size()+"==size=="+MpcMarineJobListDto.get("marineJobListDto").size());
	}
	
	
	

	
}
