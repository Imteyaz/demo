package com.dpworld.mpcsystem.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MPC_SCORE_MASTER")
@NamedQuery(name = "MpcScoreMaster.findAll", query = "SELECT m FROM MpcScoreMaster m ORDER BY m.recId DESC")
public class MpcScoreMaster {

	@Id
	@Column(name = "rec_id")
	private long recId;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "rec_date")
	private Date recDate;
	
	@Column(name = "msm_score_type")
	private String msmScoreType;
	
	@Column(name = "msm_crit_type")
	private String msmCritType;
	
	@Column(name = "msm_crit_val")
	private String msmCritVal;
	
	@Column(name = "msm_score")
	private Integer msmScore;
	
	@Column(name = "user_code")
	private String userCode;
	
	@Column(name = "is_valid")
	private Integer isValid;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	
	public long getRecId() {
		return recId;
	}
	public void setRecId(long recId) {
		this.recId = recId;
	}
	public Date getRecDate() {
		return recDate;
	}
	public void setRecDate(Date recDate) {
		this.recDate = recDate;
	}
	public String getMsmScoreType() {
		return msmScoreType;
	}
	public void setMsmScoreType(String msmScoreType) {
		this.msmScoreType = msmScoreType;
	}
	public String getMsmCritType() {
		return msmCritType;
	}
	public void setMsmCritType(String msmCritType) {
		this.msmCritType = msmCritType;
	}
	public String getMsmCritVal() {
		return msmCritVal;
	}
	public void setMsmCritVal(String msmCritVal) {
		this.msmCritVal = msmCritVal;
	}
	public Integer getMsmScore() {
		return msmScore;
	}
	public void setMsmScore(Integer msmScore) {
		this.msmScore = msmScore;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public Integer getIsValid() {
		return isValid;
	}
	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
}
