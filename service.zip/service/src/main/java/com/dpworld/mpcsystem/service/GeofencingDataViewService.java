package com.dpworld.mpcsystem.service;

import java.util.List;

import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceViewDTO;
import com.dpworld.mpcsystem.common.utility.pojo.GeofenceformView;

public interface GeofencingDataViewService {

	 List<GeoFenceViewDTO> getGeoFenceDataList(int min, int max, GeofenceformView geofenceformView);
	 
	 int countGeofencingData(GeofenceformView geofenceformView);
	
}
