package com.dpworld.esb.cxf.ais.integration.util;

public final class AppConstants {

  public static final String APP_CONFIG_FILE = "file:etc/minapro/ais-config.properties";
  public static final Integer WEBSERVICE_MAX_INPUT_LIMIT = 10;
}
