package com.dpworld.esb.cxf.ais.integration.model;

import java.io.Serializable;


public class VesselTrait implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1306212478492172296L;

  private String vesselName;

  private Integer imoNo;


  public String getVesselName() {
    return vesselName;
  }


  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }


  public Integer getImoNo() {
    return imoNo;
  }


  public void setImoNo(Integer imoNo) {
    this.imoNo = imoNo;
  }


  @Override
  public String toString() {
    return "Vessel [vesselName=" + vesselName + ", imoNo=" + imoNo + "]";
  }
  
  


}
