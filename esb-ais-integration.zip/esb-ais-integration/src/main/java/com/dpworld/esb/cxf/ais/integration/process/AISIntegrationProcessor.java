package com.dpworld.esb.cxf.ais.integration.process;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.camel.Exchange;
import org.apache.commons.collections4.ListUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.CollectionUtils;

import com.dpworld.esb.cxf.ais.integration.model.VesselLocation;
import com.dpworld.esb.cxf.ais.integration.model.VesselTrait;
import com.dpworld.esb.cxf.ais.integration.util.AppConstants;

import dpw.gvvmc.cargosmart.ObjectFactory;
import dpw.gvvmc.cargosmart.Query;
import dpw.gvvmc.cargosmart.QueryArray;
import dpw.gvvmc.cargosmart.Vessel;
import dpw.gvvmc.cargosmart.VesselArray;
import dpw.gvvmc.cargosmart.VesselService;

/**
 * AISIntegrationProcessor to fetch the data from AIS WS and push to MPC DB.
 * 
 * @author Srinivas.Gullapali
 * 
 */
/**
 * @author Sapcle.Srinivas
 *
 */
public class AISIntegrationProcessor implements Serializable {

  /**
   * Variable to set the serial version ID.
   */
  private static final long serialVersionUID = 4723219942516648448L;

  private static Logger logger = Logger.getLogger(AISIntegrationProcessor.class);


  static {
    System.setProperty("http.proxyHost", getPropertyFromConfiguration("proxyHost"));
    System.setProperty("http.proxyPort", getPropertyFromConfiguration("proxyPort"));
    System.setProperty("javax.net.ssl.trustStore", getPropertyFromConfiguration("trustStore"));

 /*   if (logger.isDebugEnabled()) {
      logger.debug("--------------------------------------------------------------------");
      logger.debug("---------------SYSTEM PROPERTIES -----------------------------------");
      logger.debug("--------------------------------------------------------------------");
      logger.debug("Proxy Host : " + System.getProperty("http.proxyHost"));
      logger.debug("Proxy Port : " + System.getProperty("http.proxyPort"));
      logger.debug("javax.net.ssl.trustStore : " + System.getProperty("javax.net.ssl.trustStore"));
      logger.debug("--------------------------------------------------------------------");
    }*/
  }


  /**
   * Extract vessel eta from AIS Service.
   * 
   * @param listOfVessels List<VesselTrait>
   * @return VesselLocation
   */
  public List<VesselLocation> extracctVesselEtaFromAISService(List<VesselTrait> listOfVessels) {
    if (logger.isDebugEnabled())
      logger.debug("Inside createInputForAISService API with vessellist: " + listOfVessels);

    VesselService vesselService = new VesselService();
    ObjectFactory fact = new ObjectFactory();
    QueryArray queryArray = null;
    List<VesselLocation> masterVesselList = null;
    if (!CollectionUtils.isEmpty(listOfVessels)) {
       masterVesselList = new ArrayList<VesselLocation>();
      queryArray = fact.createQueryArray();
      if (listOfVessels.size() > AppConstants.WEBSERVICE_MAX_INPUT_LIMIT) {

        if (logger.isDebugEnabled())
          logger.debug("The input list size is: " + listOfVessels.size()
              + "more than 100.Hence partitioning into multiple lists");
   
        List<List<VesselTrait>> partitionedVesselList = ListUtils.partition(listOfVessels,
            AppConstants.WEBSERVICE_MAX_INPUT_LIMIT);

        for (List<VesselTrait> subList : partitionedVesselList) {
          try {
            invokeVesselService(subList, queryArray, vesselService, fact,masterVesselList);
            Thread.sleep(10000);
          } catch (Exception e) {
            logger.error("Exception while invoking webservice:" + e.getMessage());
          }
        }
      } else {
        if (logger.isDebugEnabled())
          logger.debug("Invoking vessel service :");
        try {
          invokeVesselService(listOfVessels, queryArray, vesselService, fact,masterVesselList);
        } catch (Exception e) {
          logger.error("Exception while invoking webservice:" + e.getMessage());
        }

      }
    }
    return masterVesselList;
  }
  

  
  /**
   * Get single vessel details on demand basis by passing vessel name
   * 
   * @param exchange
   * @return
   */
  public List<VesselTrait> getVessel(Exchange exchange)
  {
	  List<VesselTrait> vesseList = new ArrayList<VesselTrait>();
	  VesselTrait vesselData = new VesselTrait();
	  vesselData.setVesselName((String)exchange.getIn().getHeader("vesselName"));
	  vesseList.add(vesselData);
	  return vesseList;
  }

  
  /**
   * Invoking the Vessel Service
   * 
   * @param subList
   * @param queryArray
   * @param vesselService
   * @param fact
   * @return
   */
  public void invokeVesselService(List<VesselTrait> subList,
      QueryArray queryArray,
      VesselService vesselService,
      ObjectFactory fact,List<VesselLocation> masterVesselList) throws Exception {
    try {
     Query query = null;
      VesselArray vesselArray = null;
      for (VesselTrait vessel : subList) {
          if (logger.isDebugEnabled())
              logger.debug(" Input vessel details are : " + " Vessel Name : " + vessel
                  );
        query = new Query();
        query.setVesselName(vessel.getVesselName().trim());
      //  query.setImo(null);
        queryArray.getQuery().add(query);
      }
      vesselArray = vesselService.getDPWVessel().getVessel(queryArray);
      if (vesselArray != null && vesselArray.getVessel().size() > 0){
    	  for(Vessel vessel: vesselArray.getVessel())
    	  {
    		  logger.debug("\n"+"VESSEL DETAILS  FROM AIS : ["+" vesselName="+vessel.getVesselName()+" predictedETA="+vessel.getPredictedETA()+" departFrom="+vessel.getDepartFrom()
    				  +" soLatestETA="+vessel.getSoLatestETA()+" avgSpeed="+vessel.getAvgSpeed()+" inScope="+vessel.getInScope()+" imo="+vessel.getIMO()+" atd="+vessel.getATD()
    				  +" nextPortOfCall="+vessel.getNextPortOfCall()+" so="+vessel.getSO()+" refCode="+vessel.getRefCode()+" recordUpdateTime="+vessel.getRecordUpdateTime()
    				  +" location="+vessel.getLocation()+" withinPortArea="+vessel.getWithinPortArea()+" remainingDistance="+vessel.getRemainingDistance()+" ]");
    	  }
        masterVesselList.addAll(convertToModel(vesselArray.getVessel()));
      }
      if (logger.isInfoEnabled() && vesselArray != null)
        logger.info(" AIS Service Result Vessel Size" + vesselArray.getVessel().size());
    } catch (Exception e) {
      logger.error("Exception is : " + e.getMessage(), e);
      throw e;
    }
  }

  /**
   * @param listOfVessels
   * @return listOfVesselLocation objects.
   */
  public List<VesselLocation> convertToModel(List<dpw.gvvmc.cargosmart.Vessel> listOfVessels) {
    if (logger.isDebugEnabled())
      logger.debug("Inside convertToModel API -");
    List<VesselLocation> vesselLocationList = new ArrayList<VesselLocation>();
    if (logger.isDebugEnabled())
    logger.debug("list of vesselLocationList-->"+vesselLocationList);
    for (dpw.gvvmc.cargosmart.Vessel vessel : listOfVessels) {

      JAXBElement<dpw.gvvmc.cargosmart.Vessel> jaxbElement = new JAXBElement<Vessel>(new QName(
          dpw.gvvmc.cargosmart.Vessel.class.getSimpleName()), dpw.gvvmc.cargosmart.Vessel.class,
          vessel);
      VesselLocation vesselLocation = new VesselLocation();
      Vessel vesselObj = jaxbElement.getValue();
      BeanUtils.copyProperties(vesselObj, vesselLocation);
      vesselLocation.setSrcSys("AIS"); // hard coded because only data being
                                       // fetched from AIS.
      vesselLocation.setIsValid(1);
      // RefCode
      vesselLocationList.add(vesselLocation);
      if(logger.isDebugEnabled())
      logger.debug("vessel details after model conversion -->"+vesselLocation);
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Successfully Converted to required model : ");
    }
    return vesselLocationList;
  }

  /**
   * getPropertyFromConfiguration
   * 
   * @return
   */
  private static String getPropertyFromConfiguration(String key) {
    Properties prop = new Properties();
    InputStream input = null;
    Resource resource = null;
    try {
      logger.debug("Inside getProperty API for key :" + key);
      resource = new UrlResource(AppConstants.APP_CONFIG_FILE);
      input = resource.getInputStream();
      if (input == null) {
        throw new IllegalStateException("No file found");
      }
      if (key == null || "".equals(key)) {
        throw new IllegalArgumentException("Invalid source system");
      }
      prop.load(input);
      StringBuffer sb = new StringBuffer((String) prop.get(key));
      logger.debug(" value for  key :" + key + " is : " + sb.toString());
      return sb.toString();
    } catch (IOException ex) {
      logger.error(ex.getMessage(), ex);
      throw new IllegalStateException("--Invliad Proerties files--");
    } finally {
      if (input != null) {
        try {
          input.close();
        } catch (IOException e) {
          logger.error(e.getMessage(), e);
        }
      }
    }
  }

}
