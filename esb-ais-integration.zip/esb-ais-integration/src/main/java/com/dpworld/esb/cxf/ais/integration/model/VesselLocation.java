/**
 * 
 */
package com.dpworld.esb.cxf.ais.integration.model;

import java.io.Serializable;
import java.util.Date;


/**
 * @author Srinivas.Mandadi
 * 
 */
public class VesselLocation implements Serializable {


  /**
   * 
   */
  private static final long serialVersionUID = 5966044215753701529L;

  private Long trasactionId;
  private Date transactionDate;
  private String soLatestETA;
  private String avgSpeed;
  private String vesselName;
  private String so;
  private String recordUpdateTime;
  private String imo;
  private String predictedETA;
  private String atd;
  private String remainingDistance;
  private String nextPortOfCall;
  private String departFrom;
  private String inScope;
  private String withInPortArea;
  private String location;
  private String refCode;
  private String longitude;
  private String latitude;
  private Integer isValid;
  private String srcSys;


  public String getSrcSys() {
    return srcSys;
  }


  public void setSrcSys(String srcSys) {
    this.srcSys = srcSys;
  }

  public Integer getIsValid() {
    return isValid;
  }

  public void setIsValid(Integer isValid) {
    this.isValid = isValid;
  }

  public String getLongitude() {
    return longitude;
  }


  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }


  public String getLatitude() {
    return latitude;
  }


  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getSoLatestETA() {
    return soLatestETA;
  }


  public void setSoLatestETA(String soLatestETA) {
    this.soLatestETA = soLatestETA;
  }


  public String getAvgSpeed() {
    return avgSpeed;
  }


  public void setAvgSpeed(String avgSpeed) {
    this.avgSpeed = avgSpeed;
  }


  public String getSo() {
    return so;
  }


  public void setSo(String so) {
    this.so = so;
  }


  public String getRecordUpdateTime() {
    return recordUpdateTime;
  }


  public void setRecordUpdateTime(String recordUpdateTime) {
    this.recordUpdateTime = recordUpdateTime;
  }


  public String getPredictedETA() {
    return predictedETA;
  }


  public void setPredictedETA(String predictedETA) {
    this.predictedETA = predictedETA;
  }


  public String getAtd() {
    return atd;
  }


  public void setAtd(String atd) {
    this.atd = atd;
  }


  public String getRemainingDistance() {
    return remainingDistance;
  }


  public void setRemainingDistance(String remainingDistance) {
    this.remainingDistance = remainingDistance;
  }


  public String getNextPortOfCall() {
    return nextPortOfCall;
  }


  public void setNextPortOfCall(String nextPortOfCall) {
    this.nextPortOfCall = nextPortOfCall;
  }


  public String getDepartFrom() {
    return departFrom;
  }


  public void setDepartFrom(String departFrom) {
    this.departFrom = departFrom;
  }


  public String getInScope() {
    return inScope;
  }


  public void setInScope(String inScope) {
    this.inScope = inScope;
  }


  public String getWithInPortArea() {
    return withInPortArea;
  }


  public void setWithInPortArea(String withInPortArea) {
    this.withInPortArea = withInPortArea;
  }


  public String getLocation() {
    return location;
  }


  public void setLocation(String location) {
    this.location = location;
  }


  public String getRefCode() {
    return refCode;
  }


  public void setRefCode(String refCode) {
    this.refCode = refCode;
  }

  public Long getTrasactionId() {
    return trasactionId;
  }

  public void setTrasactionId(Long trasactionId) {
    this.trasactionId = trasactionId;
  }

  public Date getTransactionDate() {
    return transactionDate;
  }

  public void setTransactionDate(Date transactionDate) {
    this.transactionDate = transactionDate;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoNo() {
    return imo;
  }

  public void setImoNo(String imoNo) {
    this.imo = imoNo;
  }

  @Override
  public String toString() {
    return new StringBuilder().append("VesselLocation [trasactionId=")
        .append(trasactionId)
        .append(", transactionDate=")
        .append(transactionDate)
        .append(", vesselEta=")
        .append(", soLatestETA=")
        .append(soLatestETA)
        .append(", avgSpeed=")
        .append(avgSpeed)
        .append(", vesselName=")
        .append(vesselName)
        .append(", so=")
        .append(so)
        .append(", recordUpdateTime=")
        .append(recordUpdateTime)
        .append(", imoNo=")
        .append(imo)
        .append(", predictedETA=")
        .append(predictedETA)
        .append(", atd=")
        .append(atd)
        .append(", remainingDistance=")
        .append(remainingDistance)
        .append(", nextPortOfCall=")
        .append(nextPortOfCall)
        .append(", departFrom=")
        .append(departFrom)
        .append(", inScope=")
        .append(inScope)
        .append(", withInPortArea=")
        .append(withInPortArea)
        .append(", srcSys=")
        .append(srcSys)
        .append(", location=")
        .append(location)
        .append(", refCode=")
        .append(refCode)
        .append(", list=")
        .append("]")
        .toString();
  }


  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((atd == null) ? 0 : atd.hashCode());
    result = prime * result + ((avgSpeed == null) ? 0 : avgSpeed.hashCode());
    result = prime * result + ((departFrom == null) ? 0 : departFrom.hashCode());
    result = prime * result + ((imo == null) ? 0 : imo.hashCode());
    result = prime * result + ((inScope == null) ? 0 : inScope.hashCode());
    result = prime * result + ((location == null) ? 0 : location.hashCode());
    result = prime * result + ((nextPortOfCall == null) ? 0 : nextPortOfCall.hashCode());
    result = prime * result + ((predictedETA == null) ? 0 : predictedETA.hashCode());
    result = prime * result + ((recordUpdateTime == null) ? 0 : recordUpdateTime.hashCode());
    result = prime * result + ((refCode == null) ? 0 : refCode.hashCode());
    result = prime * result + ((remainingDistance == null) ? 0 : remainingDistance.hashCode());
    result = prime * result + ((so == null) ? 0 : so.hashCode());
    result = prime * result + ((soLatestETA == null) ? 0 : soLatestETA.hashCode());
    result = prime * result + ((transactionDate == null) ? 0 : transactionDate.hashCode());
    result = prime * result + ((trasactionId == null) ? 0 : trasactionId.hashCode());
    result = prime * result + ((vesselName == null) ? 0 : vesselName.hashCode());
    result = prime * result + ((withInPortArea == null) ? 0 : withInPortArea.hashCode());
    return result;
  }


  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    VesselLocation other = (VesselLocation) obj;
    if (atd == null) {
      if (other.atd != null)
        return false;
    } else if (!atd.equals(other.atd))
      return false;
    if (avgSpeed == null) {
      if (other.avgSpeed != null)
        return false;
    } else if (!avgSpeed.equals(other.avgSpeed))
      return false;
    if (departFrom == null) {
      if (other.departFrom != null)
        return false;
    } else if (!departFrom.equals(other.departFrom))
      return false;
    if (imo == null) {
      if (other.imo != null)
        return false;
    } else if (!imo.equals(other.imo))
      return false;
    if (inScope == null) {
      if (other.inScope != null)
        return false;
    } else if (!inScope.equals(other.inScope))
      return false;
    if (location == null) {
      if (other.location != null)
        return false;
    } else if (!location.equals(other.location))
      return false;
    if (nextPortOfCall == null) {
      if (other.nextPortOfCall != null)
        return false;
    } else if (!nextPortOfCall.equals(other.nextPortOfCall))
      return false;
    if (predictedETA == null) {
      if (other.predictedETA != null)
        return false;
    } else if (!predictedETA.equals(other.predictedETA))
      return false;
    if (recordUpdateTime == null) {
      if (other.recordUpdateTime != null)
        return false;
    } else if (!recordUpdateTime.equals(other.recordUpdateTime))
      return false;
    if (refCode == null) {
      if (other.refCode != null)
        return false;
    } else if (!refCode.equals(other.refCode))
      return false;
    if (remainingDistance == null) {
      if (other.remainingDistance != null)
        return false;
    } else if (!remainingDistance.equals(other.remainingDistance))
      return false;
    if (so == null) {
      if (other.so != null)
        return false;
    } else if (!so.equals(other.so))
      return false;
    if (soLatestETA == null) {
      if (other.soLatestETA != null)
        return false;
    } else if (!soLatestETA.equals(other.soLatestETA))
      return false;
    if (transactionDate == null) {
      if (other.transactionDate != null)
        return false;
    } else if (!transactionDate.equals(other.transactionDate))
      return false;
    if (trasactionId == null) {
      if (other.trasactionId != null)
        return false;
    } else if (!trasactionId.equals(other.trasactionId))
      return false;
    if (vesselName == null) {
      if (other.vesselName != null)
        return false;
    } else if (!vesselName.equals(other.vesselName))
      return false;
    if (withInPortArea == null) {
      if (other.withInPortArea != null)
        return false;
    } else if (!withInPortArea.equals(other.withInPortArea))
      return false;
    return true;
  }


}
