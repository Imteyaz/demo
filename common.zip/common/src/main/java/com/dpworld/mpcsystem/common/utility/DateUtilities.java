/**
 * @copyright 2014 DP World. All rights reserved.
 * @Description Date Utils
 * @author    <i>Srinivas mandadi</i>
 * @version 1.0
 *
 */
package com.dpworld.mpcsystem.common.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Minutes;
import org.joda.time.Seconds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.dpworld.mpcsystem.common.constants.MPCConstants;

public class DateUtilities {

	private static final String DATE_FORMAT = "dd-MM-yyyy";
	private static final String DATETIME_FORMAT = "dd-MM-yyyy HH:mm";
	private static final String TIME_FORMAT = "HH:mm";
	public static final String DATETIME_FORMAT1 = "dd-MMM-yy HH:mm";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DateUtilities.class);

	private DateUtilities() {

	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date getFirstHour(Date date) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();

		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	 
	/**
	 * 
	 * @param date
	 * @param hour
	 * @return
	 */
	public static Date setHour(Date date, int hour) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();

		calendar.setTime(date);
		calendar.set(Calendar.HOUR, hour);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date getLastHour(Date date) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param hours
	 * @return
	 */
	public static Date addHoursToDate(Date date, Integer hours) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, hours);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date addDaysToDate(Date date, Integer days) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, days * 24);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getHoursFromDate(Date date) {
		if (date == null) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("H");
		return Integer.valueOf(sdf.format(date));
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getMinutesFromDate(Date date) {
		if (date == null) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("mm");
		return Integer.valueOf(sdf.format(date));
	}

	/**
	 * 
	 * @param date
	 * @param hours
	 * @param minutes
	 * @return
	 */
	public static Date addHoursAndMinutesToDate(Date date, Integer hours,
			Integer minutes) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, hours);
		calendar.add(Calendar.MINUTE, minutes);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param hours
	 * @return
	 */
	public static Date subtractHoursFromDate(Date date, Integer hours) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, -1 * hours);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param months
	 * @return
	 */
	public static Date subtractMonths(Date date, Integer months) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, -1 * months * 30 * 24);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date subtractDays(Date date, Integer days) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, -1 * days);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param minutes
	 * @return
	 */
	public static Date subtractMinutesFromDate(Date date, Integer minutes) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, -1 * minutes);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @param hours
	 * @param minutes
	 * @return
	 */
	public static Date subtractHoursAndMinutesFromDate(Date date,
			Integer hours, Integer minutes) {
		if (date == null) {
			return null;
		}
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR, -1 * hours);
		calendar.add(Calendar.MINUTE, -1 * minutes);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param firstDate
	 * @param secondDate
	 * @return
	 */
	public static double daysBetween2Dates(Date firstDate, Date secondDate) {
		Calendar c1 = GregorianCalendar.getInstance();
		Calendar c2 = GregorianCalendar.getInstance();
		if (firstDate != null && secondDate != null) {
			c1.setTime(firstDate);
			c2.setTime(secondDate);
			return (double) (c2.getTime().getTime() - c1.getTime().getTime())
					/ (24 * 3600 * 1000);
		}
		return 0;
	}

	/**
	 * Difference between two dates in String format
	 * 
	 * @param date1
	 *            Date
	 * @param date2
	 *            Date
	 * @return difference String in words
	 */
	public static String differnceBetween2DatesInWords(Date date1, Date date2) {
		StringBuilder differnce = new StringBuilder();
		if (date1 != null && date2 != null) {
			DateTime dt1 = new DateTime(date1);
			DateTime dt2 = new DateTime(date2);
			Integer diffDays = Days.daysBetween(dt1, dt2).getDays();
			Integer diffHours = Hours.hoursBetween(dt1, dt2).getHours() % 24;
			Integer diffMinutes = Minutes.minutesBetween(dt1, dt2).getMinutes() % 60;
			Integer diffSeconds = Seconds.secondsBetween(dt1, dt2).getSeconds() % 60;

			if (diffDays > 0) {
				differnce.append(diffDays).append(
						diffDays == 1 ? " day " : " days ");
			}
			if (diffHours > 0) {
				differnce.append(diffHours).append(
						diffHours == 1 ? " hour " : " hours ");
			}
			if (diffMinutes > 0) {
				differnce.append(diffMinutes).append(
						diffMinutes == 1 ? " minute " : " minutes ");
			}
			if (diffSeconds > 0) {
				differnce.append(diffSeconds).append(
						diffSeconds == 1 ? " second " : " seconds ");
			}
		}
		return differnce.toString();
	}

	/**
	 * Difference between two dates in Hours
	 * 
	 * @param date1
	 *            Date
	 * @param date2
	 *            Date
	 * @return difference Integer 
	 */
	public static Integer differnceBetween2DatesInHours(Date date1, Date date2) {
		return (date1 != null && date2 != null)? Hours.hoursBetween(new DateTime(date1), new DateTime(date2)).getHours():null;
		//minutesBetween2Dates(firstDate, secondDate)
	}
	
	/**
	 * Difference between two dates in Hours
	 * 
	 * @param date1
	 *            Date
	 * @param date2
	 *            Date
	 * @return difference Integer 
	 */
	public static Integer differnceBetween2DatesInMinutes(Date date1, Date date2) {
		//return (date1 != null && date2 != null)? Hours.hoursBetween(new DateTime(date1), new DateTime(date2)).getHours():null;
		return (date1 != null && date2 != null)? Minutes.minutesBetween(new DateTime(date1), new DateTime(date2)).getMinutes():null;
	
	}

	/**
	 * 
	 * @param firstDate
	 * @param secondDate
	 * @return
	 */
	public static double hoursBetween2Dates(Date firstDate, Date secondDate) {
		Calendar c1 = GregorianCalendar.getInstance();
		Calendar c2 = GregorianCalendar.getInstance();
		c1.setTime(firstDate);
		c2.setTime(secondDate);
		return (double) (c2.getTime().getTime() - c1.getTime().getTime())
				/ (3600 * 1000);
	}

	/**
	 * 
	 * @param firstDate
	 * @param secondDate
	 * @return
	 */
	public static double minutesBetween2Dates(Date firstDate, Date secondDate) {
		Calendar c1 = GregorianCalendar.getInstance();
		Calendar c2 = GregorianCalendar.getInstance();
		c1.setTime(firstDate);
		c2.setTime(secondDate);
		return (double) (c2.getTime().getTime() - c1.getTime().getTime())
				/ (60 * 1000);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static int daysInMonth(Date date) {
		Calendar c1 = GregorianCalendar.getInstance();
		c1.setTime(date);
		int year = c1.get(Calendar.YEAR);
		int[] daysInMonths = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		daysInMonths[1] += DateUtilities.isLeapYear(year) ? 1 : 0;
		return daysInMonths[c1.get(Calendar.MONTH)];
	}

	/**
	 * 
	 * @param year
	 * @return
	 */
	public static boolean isLeapYear(int year) {
		if ((year % 100 != 0) || (year % 400 == 0)) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date parseDate(String date) {
		return parseDate(date, DATE_FORMAT);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date parseTime(String date) {
		return parseDate(date, DATETIME_FORMAT);
	}

	/**
	 * 
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static Date parseDate(String date, String pattern) {
		SimpleDateFormat parser = new SimpleDateFormat(pattern);
		parser.setLenient(false);
		try {

			return parser.parse(date);
		} catch (ParseException e) {
			throw new IllegalArgumentException(e);

		}
	}

	public static boolean isValidDate(String inDate, String format) {
		if (inDate != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			dateFormat.setLenient(false);
			try {
				dateFormat.parse(inDate.trim());
			} catch (ParseException pe) {
				return false;
			}
			return true;
		}
		return false;
	}

	public static Date formatDate(String inputDate) throws Exception {

		Date formatedDate = null;
		SimpleDateFormat sf = new SimpleDateFormat();
		if (DateUtilities.isValidDate(inputDate,
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM)) {
			sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
			formatedDate = sf.parse(inputDate);
			return formatedDate;

		} else if (DateUtilities.isValidDate(inputDate,
				MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM)) {
			sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
			formatedDate = sf.parse(inputDate);
			return formatedDate;

		} else if (DateUtilities.isValidDate(inputDate,
				MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS)) {
			sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
			formatedDate = sf.parse(inputDate);
			return formatedDate;
		} else if (DateUtilities.isValidDate(inputDate,
				MPCConstants.DATETIME_FORMAT_YYYY_MM_DD)) {
			sf.applyPattern(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
			formatedDate = sf.parse(inputDate);
			return formatedDate;
		} else if (DateUtilities.isValidDate(inputDate,
				MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy)) {
			sf.applyPattern(MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy);
			formatedDate = sf.parse(inputDate);
			return formatedDate;
		} else if (determineDateFormat(inputDate) != null) {
			String unknownDateFormat = determineDateFormat(inputDate);
			sf.applyPattern(unknownDateFormat);
			formatedDate = sf.parse(inputDate);
			return formatedDate;
		} else {
			throw new Exception("Date format Exception with : " + inputDate);
		}

	}

/*	public static void main(String[] args) throws Exception {
		
	String dt=null;//"2018-06-24 10:14:00.0"
	//yyyy-MM-dd HH:mm:ss
	
	dt="JUNK";//"25-Jul-2018 19:50";//"2018-07-24 08:04:00.0";//"2018-07-24 08:04:00.0";//"2018-07-17 16:04:01";//"2018-07-17 15:43:00.0";"2018-07-23T19:50:00.000Z";
	//yyyy-MM-dd HH:mm:ss.S
	String aaa=formatToMPCFormatwithnullcheck(dt);
	System.out.println("=======-----------datefromat"+aaa);
	if (dt != null && DateUtilities.formatToMPCFormatwithnullcheck(dt)!=null )
	{
		
		System.out.println("=======-----inside ------date"+aaa);
	}

}*/
	
	public static String formatToMPCFormat(String inputDate) throws Exception {
		if (inputDate != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(
					MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
			Date formatedDate = null;
			SimpleDateFormat sf = new SimpleDateFormat();
			if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			}
			else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATE_FORMAT_VSL_LOC_TBL)) {
				sf.applyPattern(MPCConstants.DATE_FORMAT_VSL_LOC_TBL);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS))

			{
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_YYYY_MM_DD)) {

				sf.applyPattern(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			}
			// determineDateFormat
			else if (inputDate != null && inputDate.trim() != "") {
				String unknownDateFormat = determineDateFormat(inputDate);
				sf.applyPattern(unknownDateFormat);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			} else {
				LOGGER.error("Exception Date : " + inputDate);
				throw new Exception("Date format Exception with : " + inputDate);
			}

		} else {
			LOGGER.debug("Invalid Date : " + inputDate);
			return null;
		}
	}
	
	
	
	

	
	
	public static String formatToMPCFormatwithnullcheck(String inputDate) throws Exception {
		if (inputDate != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(
					MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
			Date formatedDate = null;
			SimpleDateFormat sf = new SimpleDateFormat();
			if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			}
			else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			}
			else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			}			
			else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATE_FORMAT_VSL_LOC_TBL)) {
				sf.applyPattern(MPCConstants.DATE_FORMAT_VSL_LOC_TBL);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS))

			{
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_YYYY_MM_DD)) {

				sf.applyPattern(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			} else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_ddSLSmmSLSyyyy);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
			}/*else if (inputDate != null
					&& inputDate.trim() != ""
					&& DateUtilities.isValidDate(inputDate,
							MPCConstants.DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S)) {
				sf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);

			}*/
			// determineDateFormat
			else if (inputDate != null && inputDate.trim() != "") {
				LOGGER.debug("Invalid Date as null : " + inputDate);
				String unknownDateFormat = determineDateFormat(inputDate);
				LOGGER.debug("Invalid Date as unknownDateFormat : " + unknownDateFormat);
				if(unknownDateFormat!=null){
				sf.applyPattern(unknownDateFormat);
				formatedDate = sf.parse(inputDate);
				return sdf.format(formatedDate);
				}else{return null;}
			} else {
				LOGGER.debug("Invalid Date as null : " + inputDate);
				
				return null;
				
			}

		} else {
			LOGGER.debug("Invalid Date : " + inputDate);
			return null;
		}
	}

	/*
	 * public static void main(String args[]) { try {
	 * System.out.println("FORMATED DATE IS : "
	 * +(formatToMPCFormat("31/07/2017 19:39"))); } catch (Exception e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); } }
	 */

	/**
	 * 
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static String formatDate(Date date, String pattern) {
		if (date == null) {
			return null;
		}
		SimpleDateFormat parser = new SimpleDateFormat(pattern);
		parser.setLenient(false);
		return parser.format(date);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDate(Date date) {
		if (date == null) {
			return null;
		}
		SimpleDateFormat parser = new SimpleDateFormat(DATETIME_FORMAT);
		parser.setLenient(false);
		return parser.format(date);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String formatTime(Date date) {
		if (date == null) {
			return null;
		}
		SimpleDateFormat parser = new SimpleDateFormat(TIME_FORMAT);
		parser.setLenient(false);
		return parser.format(date);
	}

	/**
	 * 
	 * @param date
	 * @param firstDate
	 * @param secondDate
	 * @return
	 */
	public static boolean isBetweenDates(Date date, Date firstDate,
			Date secondDate) {
		if (date == null) {
			return false;
		}
		return firstDate.equals(date) || secondDate.equals(date)
				|| (firstDate.before(date) && secondDate.after(date));
	}

	/**
	 * 
	 * @param date
	 * @param minutes
	 * @return
	 */
	public static Date setMinutes(Date date, Integer minutes) {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.MINUTE, minutes);
		return calendar.getTime();
	}

	/**
	 * 
	 * @param firstDate
	 * @return
	 */
	public static Date getNextDate(Date firstDate) {

		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(firstDate);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}

	/**
	 * 
	 * @param firstDate
	 * @return
	 */
	public static Date getNextDate(String firstDate) {
		Date d1 = parseDate(firstDate);
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(d1);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}

	/**
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public static Date[] getAllDates(String fromDate, String toDate) {

		Date d1 = parseDate(fromDate);
		Date d2 = parseDate(toDate);

		int length = (int) (daysBetween2Dates(d1, d2)) + 1;
		Date[] dateArray = new Date[length];

		Date currentDate = d1;
		dateArray[0] = d1;
		for (int i = 1; i < length; i++) {
			currentDate = getNextDate(currentDate);
			dateArray[i] = currentDate;
		}
		return dateArray;
	}

	/**
	 * Compares two dates. If date1 is before date2 it return -1. if date1 is
	 * after date2 it return 1. If date1 is equal to date2 it will return 0.
	 * 
	 * @param date1
	 *            first date
	 * @param date2
	 *            second date
	 * @return int values (1, 0, -1)
	 */
	public static int compare(Date firstDate, Date secondDate) {
		if (firstDate == null && secondDate == null) {
			return 0;
		} else if (firstDate == null || secondDate == null) {
			return -1;
		}

		Calendar c1 = GregorianCalendar.getInstance();
		Calendar c2 = GregorianCalendar.getInstance();
		c1.setTime(firstDate);
		c2.setTime(secondDate);
		return c1.compareTo(c2);
	}

	

	/**
	 * Returns current date as per application default format
	 * 
	 * @return date current date.
	 */
	public static Date getCurrentDate() {
		Calendar c1 = GregorianCalendar.getInstance();
		Date dateType = c1.getTime();
		return DateUtilities.parseDate(DateUtilities.formatDate(dateType),
				DATE_FORMAT);
	}

	/**
	 * Returns Month of the date
	 * 
	 * @param date
	 *            Date
	 * @return date
	 */
	public static int getMonth(Date date) {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.MONTH);
	}

	/**
	 * Returns the year
	 * 
	 * @param date
	 *            Date
	 * @return date
	 */
	public static int getYear(Date date) {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.YEAR);
	}

	/**
	 * Returns Next Month start date from given date.
	 * 
	 * @param date
	 *            Date
	 * @return Date
	 */
	public static Date getNextMonthStartDate(Date date) {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, 1);
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		return cal.getTime();
	}

	/**
	 * Get date part only by truncating time
	 * 
	 * @param date
	 *            Date
	 * @return Date without time.
	 */
	public static Date getDateOnly(Date date) {
		if (date == null) {
			return null;
		}
		String strDate = DateUtilities.formatDate(date, DATE_FORMAT);
		return DateUtilities.parseDate(strDate, DATE_FORMAT);
	}

	/**
	 * Getting the max date from two dates.
	 * 
	 * @param date1
	 *            Date
	 * @param date2
	 *            Date
	 * @return Date max date
	 */
	public static Date getMaxDate(Date date1, Date date2) {
		if (date1 != null && date2 != null) {
			if (compare(date1, date2) > 0) {
				return date1;
			} else {
				return date2;
			}
		} else if (date2 != null) {
			return date2;
		}
		return date1;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String convertDateFormat(String date, String sourceFormat,
			String destinationFormat) {
		if (StringUtils.isEmpty(date)) {
			return date;
		}
		return formatDate(parseDate(date, sourceFormat), destinationFormat);
	}

	public static Date convertUtilDateToMPCFormat(Date date)
			throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		if (StringUtils.isEmpty(date)) {
			return null;
		}
		return sdf.parse(sdf.format(date));
	}

	public int convertHoursToMillis(String hours) {
		if (hours != null) {
			double input = Double.parseDouble(hours);
			return (int) input * 3600000;
		}
		return 0;

	}

	public static String determineDateFormat(String dateString) {
		for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
			if (dateString.toLowerCase().matches(regexp)) {
				return DATE_FORMAT_REGEXPS.get(regexp);
			}
		}
		return null; // Unknown format.
	}

	public static Map<String, String> loadDateFormatsFromPropertiesFile() {
		Map<String, String> map = new HashMap<String, String>();
		Properties properties = new Properties();
		File f = null;
		FileInputStream fStream = null;
		try {
			String fileName = System.getProperty("jboss.server.config.dir")
					+ MPCConstants.MPC_CONFIG_PROPERTIES2;

			f = new File(fileName);
			fStream = new FileInputStream(f);
			properties.load(fStream);

			Enumeration<?> propertyNames = properties.propertyNames();
			while (propertyNames.hasMoreElements()) {
				String key = (String) propertyNames.nextElement();
				map.put(key, (String) properties.getProperty(key));
			}
			return map;
		} catch (Exception e) {
			if (fStream != null) {
				try {
					fStream.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}
			e.printStackTrace();
		} finally {
			if (fStream != null) {
				try {
					fStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	private static Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {
		{
			put("^\\d{8}$", "yyyyMMdd");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
			put("^\\d{12}$", "yyyyMMddHHmm");
			put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$",
					"dd-MM-yyyy HH:mm");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$",
					"yyyy-MM-dd HH:mm");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$",
					"MM/dd/yyyy HH:mm");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$",
					"yyyy/MM/dd HH:mm");
			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$",
					"dd MMM yyyy HH:mm");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$",
					"dd MMMM yyyy HH:mm");
			put("^\\d{14}$", "yyyyMMddHHmmss");
			put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"dd-MM-yyyy HH:mm:ss");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"yyyy-MM-dd HH:mm:ss");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"MM/dd/yyyy HH:mm:ss");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"yyyy/MM/dd HH:mm:ss");
			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"dd MMM yyyy HH:mm:ss");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$",
					"dd MMMM yyyy HH:mm:ss");
			Map<String, String> propertiesMap = loadDateFormatsFromPropertiesFile();
			if (propertiesMap != null)
				putAll(propertiesMap);
		}
	};

}
