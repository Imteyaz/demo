package com.dpworld.mpcsystem.common.constants;

public class MPCConstants {

	private MPCConstants() {
	}

	public static final String SEQUENCE_NAME = "mygen";
	public static final String CUSTOM_SEQUENCE_GENERATOR = "com.dpworld.mpcsystem.persistence.common.CustomSequenceGenerator";
	public static final String SEQ_MPC_ENTITIES = "SEQ_MPC_SQ1";

	public static final String MPC_CONFIG_PROPERTIES = "/mpc-config.properties";
	public static final String MPC_CONFIG_PROPERTIES2 = "/mpc-date.properties";

	public static final String PAGE_MAP_DISPLAY = "map_disply";
	public static final String PAGE_WORKORDER_LIST = "worklist_disply";
	public static final String PAGE_VESSEL_LIST = "vessel_list";
	public static final String PAGE_MARINE_JOB_LIST = "marine_joblist";
	
	public static final String PAGE_DASHBOARD_DISPLAY = "dashboard_disply";
	public static final String MPC_FUSE_URL = "fuseurl";
    public static final String MPC_ENV_SERVER = "envserver";	// MPC constants for purging tables.
    public static final String MPC_APP_VERSION = "version";
	public static final String MPC_INT_VSL_PLAN = "MPC_INT_VSL_PLAN";
	public static final String MPC_VSL_LOCS = "MPC_VSL_LOCS";
	public static final String MPC_INT_VSL = "MPC_INT_VSL";
	public static final String MPC_INT_VSL_QC = "MPC_INT_VSL_QC";
	public static final String MPC_GEOFENCE_DATA = "MPC_GEOFENCE_DATA";
	// Phase 2 purging tables;
	public static final String MPC_CONVERSATIONS = "MPC_CONVERSATIONS";
	public static final String MPC_CONVERSATIONS_HIST = "MPC_CONVERSATIONS_HIST";
	public static final String MPC_CONV_SUSBCR = "MPC_CONV_SUBSCR";
	public static final String MPC_CONV_SUBSCR_HIST = "MPC_CONV_SUBSCR_HIST";
	public static final String MPC_ALERT_MASTER = "MPC_ALERT_MASTER";
	// MPC Phase 2 Constants
	public static final String PAGE_MPC_SCORE_LIST = "maintain_score";
	public static final String PAGE_SYSPARAM = "sysParam_list";
	public static final String ACTIVE = "Active";
	public static final String INACTIVE = "Inactive";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String STATUS_SLA = "SLA";
	public static final String STATUS_NONSLA = "NONSLA";
	public static final String ANCHORAGE_COORDINATE_ONE = "ACH1";
	public static final String ANCHORAGE_COORDINATE_TWO = "ACH2";
	public static final String ANCHORAGE_COORDINATE_THREE = "ACH3";
	public static final String ANCHORAGE_COORDINATE_FOUR = "ACH4";
	public static final String BREAK_WATER = "BREAK WATER";
	public static final String PILOT_STATION_1 = "P_S_ONE";
	public static final String PILOT_STATION_2 = "P_S_TWO";
	public static final String TWO_HOURS = "2HRS";
	public static final String FOUR_HOURS = "4HRS";
	public static final String SIX_HOURS = "6HRS";
	public static final String EIGHT_HOURS = "8HRS";
	public static final String BREAK_WATER_TWO = "B_W_2";
	public static final String BREAK_WATER_ONE = "B_W_1";
	public static final String EMPTY_STRING = "";
	public static final String DATE_TIME_FORMAT = "dd/MM/yyyy HH:mm:ss";
	public static final String SEMICOLON = ";";
	public static final String OPERATING = "OPERATING";
	public static final String COMPLETED = "COMPLETED";
	public static final String SAILING = "SAILING";
	public static final String SHIFTING = "SHIFTING";
	public static final String INCOMING = "INCOMING";
	public static final String DIRECT = "DIRECT";
	//for marinejoblist  Berthing Expected
	//2[Berthing Expected, Berthing Expected Eta.Exp]
	
	public static final String BERTHING_EXPECTED ="Berthing Expected" ;
	public static final String BERTHING_EXPECTED_ETA_EXP ="Berthing Expected Eta.Exp" ;
	public static final String SAILING_EXPECTED ="Sailing Expected";
	
	public static final String SHIFTING_EXPECTED="Shifting Expected"; 
	
	public static final String SHIFTING_IN_PROGRESS ="Shifting In Progress";

	public static final String SAILED="Sailed";
	

	// GeoFense Status
	public static final String VSL_STATUS_IN_PROGRESS = "ALONGSIDE,BERTHING,OPERATING,COMPLETED";
	public static final String VSL_STATUS_PLAN_PROGRESS = "INCOMING,SAILING,SHIFTING";

	// Web Service URL
	public static final String CODE_WS_URL = "codewsurl";
	public static final String VESSEL_TYPE = "VESSEL%20TYPE";
	public static final String SERVICE_TYPE = "SERVICE%20TYPE";
	public static final String USER_WS_URL = "userlisturl";
	public static final String ROLE_WS_URL = "rolelisturl";

	// Vessel List/ Work List Filter
	public static final String VESSEL_STATUS = "VESSEL_STATUS";
	public static final String VESSEL_STATUS_M = "VESSEL_STATUS_M";
	
	public static final String TERMINAL = "TERMINAL";
	public static final String GEOFENCE_CODE = "GF_CODE";
	public static final String DUAL_CALL = "DUAL_CALL";

	public static final String SOURCE_SYS = "MPC";

	public static final String PAGE_GEOFENCE_MASTER = "manage_geofence_master";
	public static final String PAGE_GEOFENCE_VIEW = "geofence_view";
	public static final String PAGE_ALERT_COMMUNICATION = "alertsCommunication";
	public static final String PAGE_ALERT_TRENDINGTOPICS = "trendingTopics";
	public static final String PAGE_SUBSCRIBED_USERS = "subscribedUsers";
	// For MPC MAP VIEW
	public static final String TERMINAL1 = "Terminal 1";
	public static final String TERMINAL2 = "Terminal 2";
	public static final String TERMINAL3 = "Terminal 3";
	public static final String T1 = "T1";
	public static final String T2 = "T2";
	public static final String T3 = "T3";
	public static final String T4 = "T4";
	public static final String GC = "GC";

	// For MPC PIE CHARTS
	public static final String TWOHR = "2HRS";
	public static final String FOURHR = "4HRS";
	public static final String SIXHR = "6HRS";
	public static final String EIGHTHR = "8HRS";
	public static final String HIGH_SEA = "HIGH SEA";
	public static final String BERTHED = "BERTHED";
	public static final String ALONGSIDE = "ALONGSIDE";
	public static final String ANCHOR = "ANCHORAGE";
	public static final String BASIN = "BASIN";
	public static final String CHANNEL = "CHANNEL";
	// New Status for color selection
	public static final String PARAMCATEGORY = "COLOR_VSL_STATUS";
	public static final String DEFAULT_COLOR = "DEFAULT_VSL_COLOR";
	public static final String DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String DATETIME_FORMAT_YYYY_MM_DD_HH_MM_SS_S = "yyyy-MM-dd HH:mm:ss.S";//tariq
	public static final String DATETIME_FORMAT_DD_MM_YYYY_HH_MM = "dd-MM-yyyy HH:mm";
	public static final String DATETIME_FORMAT_DD_MMM_YYYY_HH_MM = "dd-MMM-yyyy HH:mm";
	public static final String DATETIME_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATETIME_FORMAT_ddSLSmmSLSyyyy = "dd/MM/yyyy HH:mm";
	public static final String DATE_FORMAT_VSL_LOC_TBL = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	public static final String PAGE_ALERT_MASTER = "alert_master";
	public static final String PAGE_CONVERSATION_HISTORY = "view_conversation_history";
	public static final String PAGE_DELAYED_VESSEL = "delayed_vessel";
	public static final String PAGE_BERTHING_VESSEL = "berthing_vessel";
	public static final String PAGE_ETA_REPORT = "eta_Report";
	public static final String PAGE_SAILING_VESSEL = "sailing_vessel";
	// Dash Board Refresh Query Constants
	public static final String DASHBOARD_PARAM_GRP = "DASHBOARD";
	public static final String MINUTES = "MINUTES";

	// RECENT ALERT Refresh Query Constants
	public static final String AUTOREFRESH = "AUTOREFRESH";
	public static final String RALERT_PARAM_GRP = "RECENTALERTS";

	public static final String BERTHING = "Berthing";
	public static final String MANEUVER_BUFFTER_TIME = "MNU_BUFFER_TIME";
	public static final String ETB_BUFFER_TIME = "ETB_BUFFER_TIME";
	public static final String ETB = "ETB";
	public static final String SWAP = "SWAP";
	public static final String SWAP_BUFFER_TIME = "SWAP_BUFFER_TIME";
	public static final String DA = "DA";
	public static final String DA_BUFFER_TIME = "DA_BUFFER_TIME";
	public static final String DISPATCHED = "Dispatched";
	public static final String IMMINENT = "Imminent";
	public static final String IN_PROGRESS = "Inprogress";
	public static final String PAGE_COLOR_PICKER = "color_picker";

	// Sailed WebService Url
	public static final String SAILED_WS_URL = "sailedwsurl";
	public static final String SAILED_ROTN_WS_URL = "sailedrotnwsurl";

	public static final String CONV_TYPE_ALERT = "A";
	public static final String CONV_TYPE_CONV = "C";
	public static final int DATA_VALID_FLAG = 1;

	public static final String SUBSCRP_STATUS_ACTIVE = "1";
	public static final String SUBSCRP_STATUS_INACTIVE = "0";
	public static final String SRC_SYSYTEM_MPC = "MPC";
	public static final String COMMA = ",";
	public static final String UNKNOWN = "UNKNOWN";

	public static final String SORT_CONVLIST_DESC = "DESC";
	public static final String SORT_CONVLIST_ASC = "ASC";
	public static final String paramCategory = "COLOR_VSL_STATUS";
	
    //Dash Board Refresh Query Constants
    public static final String RALERT_PARAM_CATG = "AUTOREFRESH";
    public static final String DASHBOARD_PARAM_CATG = "AUTOREFRESH";
    public static final String DASHBOARD_PARAM_CODE = "MINUTES";
    public static final String RALERT_PARAM_CODE = "SECOND";
    
    public static final String BUFFER_PARAMS = "BUFFER_PARAMS";
    public static final String MNU_ETB = "MNU_ETB";
    public static final String MNU_ETC = "MNU_ETC";
    public static final String TIMEDIFF = "TIMEDIFF";
    public static final String ADJ_ETC ="ADJ_ETC";
    public static final String TWO_HRS_TO_T1 = "TWO_HRS_TO_T1";
    public static final String TWO_HRS_TO_T2 = "TWO_HRS_TO_T2";
    public static final String TWO_HRS_TO_T3 = "TWO_HRS_TO_T3";
    public static final String TWO_HRS_TO_T4 = "TWO_HRS_TO_T4";
    public static final String TWO_HRS_TO_GC = "TWO_HRS_TO_GC";
    
    public static final String FOUR_HRS_TO_T1 = "FOUR_HRS_TO_T1";
    public static final String FOUR_HRS_TO_T2 = "FOUR_HRS_TO_T2";
    public static final String FOUR_HRS_TO_T3 = "FOUR_HRS_TO_T3";
    public static final String FOUR_HRS_TO_T4 = "FOUR_HRS_TO_T4";
    public static final String FOUR_HRS_TO_GC = "FOUR_HRS_TO_GC";
    
    public static final String SIX_HRS_TO_T1 = "SIX_HRS_TO_T1";
    public static final String SIX_HRS_TO_T2 = "SIX_HRS_TO_T2";
    public static final String SIX_HRS_TO_T3 = "SIX_HRS_TO_T3";
    public static final String SIX_HRS_TO_T4 = "SIX_HRS_TO_T4";
    public static final String SIX_HRS_TO_GC = "SIX_HRS_TO_GC";
    
    public static final String EIGHT_HRS_TO_T1 = "EIGHT_HRS_TO_T1";
    public static final String EIGHT_HRS_TO_T2 = "EIGHT_HRS_TO_T2";
    public static final String EIGHT_HRS_TO_T3 = "EIGHT_HRS_TO_T3";
    public static final String EIGHT_HRS_TO_T4 = "EIGHT_HRS_TO_T4";
    public static final String EIGHT_HRS_TO_GC = "EIGHT_HRS_TO_GC";
    
    public static final String ANCHOR_TO_T1 = "ANCHOR_TO_T1";
    public static final String ANCHOR_TO_T2 = "ANCHOR_TO_T2";
    public static final String ANCHOR_TO_T3 = "ANCHOR_TO_T3";
    public static final String ANCHOR_TO_T4 = "ANCHOR_TO_T4";
    public static final String ANCHOR_TO_GC = "ANCHOR_TO_GC";
    
    public static final String CHANNEL_TO_T1 = "CHANNEL_TO_T1";
    public static final String CHANNEL_TO_T2 = "CHANNEL_TO_T2";
    public static final String CHANNEL_TO_T3 = "CHANNEL_TO_T3";
    public static final String CHANNEL_TO_T4 = "CHANNEL_TO_T4";
    public static final String CHANNEL_TO_GC = "CHANNEL_TO_GC";
    
    public static final String PILOT_STATION1_TO_T1 = "PILOT_STATION1_TO_T1";
    public static final String PILOT_STATION1_TO_T2 = "PILOT_STATION1_TO_T2";
    public static final String PILOT_STATION1_TO_T3 = "PILOT_STATION1_TO_T3";
    public static final String PILOT_STATION1_TO_T4 = "PILOT_STATION1_TO_T4";
    public static final String PILOT_STATION1_TO_GC = "PILOT_STATION1_TO_GC";
    
    public static final String PILOT_STATION2_TO_T1 = "PILOT_STATION2_TO_T1";
    public static final String PILOT_STATION2_TO_T2 = "PILOT_STATION2_TO_T2";
    public static final String PILOT_STATION2_TO_T3 = "PILOT_STATION2_TO_T3";
    public static final String PILOT_STATION2_TO_T4 = "PILOT_STATION2_TO_T4";
    public static final String PILOT_STATION2_TO_GC = "PILOT_STATION2_TO_GC";
    
    public static final String BASIN_TO_T1 = "BASIN_TO_T1";
    public static final String BASIN_TO_T2 = "BASIN_TO_T2";
    public static final String BASIN_TO_T3 = "BASIN_TO_T3";
    public static final String BASIN_TO_T4 = "BASIN_TO_T4";
    public static final String BASIN_TO_GC = "BASIN_TO_GC";
    
    public static final String ALERT = "ALERT";
    public static final String  VDELAY = "VDELAY";
    public static final String THRESHOLD ="THRESHOLD";
    public static final String SHOWALERT ="SHOWALERT";
    public static final String DURATIONHRS = "DURATIONHRS";
    
   
}
