package com.dpworld.mpcsystem.common.utility.mapping;

/**
 * 
 * @author Rahul Singh
 * 
 * @param <T>
 * @param <S>
 * @Usage Interface to implement the method @embedRequest() in different ways
 *        inside the template method.
 * 
 */

public interface PayloadEntity<T, S> {

	T embedRequest(T target, S source);

}
