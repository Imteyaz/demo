package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.DateUtilities;

public class VesselDetailsDTO implements Serializable{
	private static final long serialVersionUID = -686365770233878584L;
	private long rotationNumber;
	private String vesselName;
	private String vesselType;
	private String vesselDescription;
	private String serviceType;
	private String serviceTypeDesc;
	private String loa;
	private String draft;
	private String type;
	private String line;
	private String callSign;
	private String currStatus;
	private String currLocation;
	private String orgETA;
	private String orgETD;
	private String dualCall;
	private String newETA;
	private String etb;
	private String etc;
	private String currentPOS;
	private String nextPOS;
	private String berthingPOS;
	private String fromBollard;
	private String toBollard;
	private String noOfQcAllc;
	private String noOfQcWkng;
	private String containerNumber;
	private String terminal;
	private String portCode;
	private String rotation;
	private String berthPosition;
	private String craneAssigned;
	private String berth;
	private String berthCode;
	private String fromMetermark;
	private String toMetermark;
	private String vesselMovesTogo;
	private String longCraneNo;
	private String longCranemovesToGo;
	private String noOfCranes;

	private String berthDate;
	private String sailDate;
	private String status;
	private String etaDate;
	private String etbDate;
	private String etdDate;
	private String anchorageDate;
	private String voyageNumber;
	private String outvoyageNumber;
	private String voyageRoute;
	private String voyageType;
	private String arrFm;
	private String callReason;
	private String callType;
	private String callDescr;
	private String lineCode;
	private String inVesselService;
	private String arrDraft;
	private String sailDraft;
	private String dualBerth;
	private String terminalId;
	private String loadTerminalId;
	private String imoCode;
	private String sourceSystem;
	private String mvdusergroup;
	private String userorder;
	private String userorderinternal;
	private String port;
	private String agentEta;
	private String vtsEta;
/*	String rotation;
	String vesselName;
	String vesselType;*/
	/* String aisEta;
	String berthDate;
	String sailDate;
	String dualBerth;*/
	
	/*String terminal;*/
	
	public String getUserorderinternal() {
		return userorderinternal;
	}

	public void setUserorderinternal(String userorderinternal) {
		this.userorderinternal = userorderinternal;
	}

	private int order;
	private String priority;
	private String description;
	private String maneuverStatus;
	private String et;
	private String fromLocation;
	private String toLocation;
	private String swap;

	private Long ttMTG;
	private Long qcAlloc;
	private Long qcWorking;
	private Long hhMTG;
	private String hhCrane;

	private String qc;
	private Long movesToGo;
	private Long planMoves;
	private Long doneMoves;
	private String remarks;

	private List<TerminalVisit> terminalVisitList;
	private List<String> dropDownTypes;
	private String slaStatus;
	private String proforma;

	// ais details
	private String aisVslOprEta;
	private String aisAvgSpeed;
	private String aisVesselOperator;
	private String aisUpdateTime;
	private String aisEta;
	private String aisPreviousAtd;
	private String aisDistanceToNextPort;
	private String aisNextPort;
	private String aisPrevPort;
	// New Added
	private String aisLocation;
	private String aisError;

	private Date etaDate1;

	private Date etcDateObject;
	private String vesselLocation;
	private String nextLocation;
	private String longitude;
	private String latitude;
	private String plannedBerth;
	private String currentBerth;
	private String geofenceLoc;
	private String vesselArrivalDirectOrAnchorage;
	private Long sort_date;
	private String pilotDispatchTime;
	private String newEtb;	
	private String marineManeuver;
	private String etm;
	
	// New Added By Himanshu
	  private String geofenceData;
	  private String alertFlag;
	  private String topicValue;
	 

	public String getEtm() {
		return etm;
	}

	public void setEtm(String etm) {
		this.etm = etm;
	}

	public String getMarineManeuver() {
		return marineManeuver;
	}

	public void setMarineManeuver(String marineManeuver) {
		this.marineManeuver = marineManeuver;
	}

	public String getNewEtb() {
		return newEtb;
	}

	public void setNewEtb(String newEtb) {
		this.newEtb = newEtb;
	}

	public String getPilotDispatchTime() {
		return pilotDispatchTime;
	}

	public void setPilotDispatchTime(String pilotDispatchTime) {
		this.pilotDispatchTime = pilotDispatchTime;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getPlannedBerth() {
		return plannedBerth;
	}

	public void setPlannedBerth(String plannedBerth) {
		this.plannedBerth = plannedBerth;
	}

	public String getCurrentBerth() {
		return currentBerth;
	}

	public void setCurrentBerth(String currentBerth) {
		this.currentBerth = currentBerth;
	}

	public String getGeofenceLoc() {
		return geofenceLoc;
	}

	public void setGeofenceLoc(String geofenceLoc) {
		this.geofenceLoc = geofenceLoc;
	}

	public String getVesselArrivalDirectOrAnchorage() {
		return vesselArrivalDirectOrAnchorage;
	}

	public void setVesselArrivalDirectOrAnchorage(
			String vesselArrivalDirectOrAnchorage) {
		this.vesselArrivalDirectOrAnchorage = vesselArrivalDirectOrAnchorage;
	}

	public Long getSort_date() {
		return sort_date;
	}

	public void setSort_date(Long sort_date) {
		this.sort_date = sort_date;
	}

	public String getVesselDescription() {
		return vesselDescription;
	}

	public void setVesselDescription(String vesselDescription) {
		this.vesselDescription = vesselDescription;
	}

	public String getNextLocation() {
		return nextLocation;
	}

	public void setNextLocation(String nextLocation) {
		this.nextLocation = nextLocation;
	}

	
	public String getVesselLocation() {
		return vesselLocation;
	}

	public void setVesselLocation(String vesselLocation) {
		this.vesselLocation = vesselLocation;
	}

	public List<String> getDropDownTypes() {
		return dropDownTypes;
	}

	public void setDropDownTypes(List<String> dropDownTypes) {
		this.dropDownTypes = dropDownTypes;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public long getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(long rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getVesselType() {
		return vesselType;
	}

	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceTypeDesc() {
		return serviceTypeDesc;
	}

	public void setServiceTypeDesc(String serviceTypeDesc) {
		this.serviceTypeDesc = serviceTypeDesc;
	}

	public String getLoa() {
		return loa;
	}

	public void setLoa(String loa) {
		this.loa = loa;
	}

	public String getDraft() {
		return draft;
	}

	public void setDraft(String draft) {
		this.draft = draft;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getCallSign() {
		return callSign;
	}

	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}

	public String getCurrStatus() {
		return currStatus;
	}

	public void setCurrStatus(String currStatus) {
		this.currStatus = currStatus;
	}

	public String getCurrLocation() {
		return currLocation;
	}

	public void setCurrLocation(String currLocation) {
		this.currLocation = currLocation;
	}

	public String getOrgETA() {
		return orgETA;
	}

	public void setOrgETA(String orgETA) {
		this.orgETA = orgETA;
	}

	public String getOrgETD() {
		return orgETD;
	}

	public void setOrgETD(String orgETD) {
		this.orgETD = orgETD;
	}

	public String getDualCall() {
		return dualCall;
	}

	public void setDualCall(String dualCall) {
		this.dualCall = dualCall;
	}

	public String getNewETA() {
		return  newETA;
	}

	public void setNewETA(String newETA) {
		this.newETA = newETA;
	}

	public String getEtb() {
		return etb;
	}

	public void setEtb(String etb) {
		this.etb = etb;
	}

	public String getEtc() {
		return etc;
	}

	public void setEtc(String etc) {
		this.etc = etc;
	}

	public String getCurrentPOS() {
		return currentPOS;
	}

	public void setCurrentPOS(String currentPOS) {
		this.currentPOS = currentPOS;
	}

	public String getNextPOS() {
		return nextPOS;
	}

	public void setNextPOS(String nextPOS) {
		this.nextPOS = nextPOS;
	}

	public String getBerthingPOS() {
		return berthingPOS;
	}

	public void setBerthingPOS(String berthingPOS) {
		this.berthingPOS = berthingPOS;
	}

	public String getFromBollard() {
		return fromBollard;
	}

	public void setFromBollard(String fromBollard) {
		this.fromBollard = fromBollard;
	}

	public String getToBollard() {
		return toBollard;
	}

	public void setToBollard(String toBollard) {
		this.toBollard = toBollard;
	}

	public String getNoOfQcAllc() {
		return noOfQcAllc;
	}

	public void setNoOfQcAllc(String noOfQcAllc) {
		this.noOfQcAllc = noOfQcAllc;
	}

	public String getNoOfQcWkng() {
		return noOfQcWkng;
	}

	public void setNoOfQcWkng(String noOfQcWkng) {
		this.noOfQcWkng = noOfQcWkng;
	}

	public String getContainerNumber() {
		return containerNumber;
	}

	public void setContainerNumber(String containerNumber) {
		this.containerNumber = containerNumber;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public Long getTtMTG() {
		return ttMTG;
	}

	public void setTtMTG(Long ttMTG) {
		this.ttMTG = ttMTG;
	}

	public Long getQcAlloc() {
		return qcAlloc;
	}

	public void setQcAlloc(Long qcAlloc) {
		this.qcAlloc = qcAlloc;
	}

	public Long getQcWorking() {
		return qcWorking;
	}

	public void setQcWorking(Long qcWorking) {
		this.qcWorking = qcWorking;
	}

	public Long getHhMTG() {
		return hhMTG;
	}

	public void setHhMTG(Long hhMTG) {
		this.hhMTG = hhMTG;
	}

	public String getHhCrane() {
		return hhCrane;
	}

	public void setHhCrane(String hhCrane) {
		this.hhCrane = hhCrane;
	}

	public String getQc() {
		return qc;
	}

	public void setQc(String qc) {
		this.qc = qc;
	}

	public Long getMovesToGo() {
		return movesToGo;
	}

	public void setMovesToGo(Long movesToGo) {
		this.movesToGo = movesToGo;
	}

	public Long getPlanMoves() {
		return planMoves;
	}

	public void setPlanMoves(Long planMoves) {
		this.planMoves = planMoves;
	}

	public Long getDoneMoves() {
		return doneMoves;
	}

	public void setDoneMoves(Long doneMoves) {
		this.doneMoves = doneMoves;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getRotation() {
		return rotation;
	}

	public void setRotation(String rotation) {
		this.rotation = rotation;
	}

	public String getBerthPosition() {
		return berthPosition;
	}

	public void setBerthPosition(String berthPosition) {
		this.berthPosition = berthPosition;
	}

	public String getCraneAssigned() {
		return craneAssigned;
	}

	public void setCraneAssigned(String craneAssigned) {
		this.craneAssigned = craneAssigned;
	}

	public String getBerth() {
		return berth;
	}

	public void setBerth(String berth) {
		this.berth = berth;
	}

	public String getBerthCode() {
		return berthCode;
	}

	public void setBerthCode(String berthCode) {
		this.berthCode = berthCode;
	}

	public String getFromMetermark() {
		return fromMetermark;
	}

	public void setFromMetermark(String fromMetermark) {
		this.fromMetermark = fromMetermark;
	}

	public String getToMetermark() {
		return toMetermark;
	}

	public void setToMetermark(String toMetermark) {
		this.toMetermark = toMetermark;
	}

	public String getVesselMovesTogo() {
		return vesselMovesTogo;
	}

	public void setVesselMovesTogo(String vesselMovesTogo) {
		this.vesselMovesTogo = vesselMovesTogo;
	}

	public String getLongCraneNo() {
		return longCraneNo;
	}

	public void setLongCraneNo(String longCraneNo) {
		this.longCraneNo = longCraneNo;
	}

	public String getLongCranemovesToGo() {
		return longCranemovesToGo;
	}

	public void setLongCranemovesToGo(String longCranemovesToGo) {
		this.longCranemovesToGo = longCranemovesToGo;
	}

	public String getNoOfCranes() {
		return noOfCranes;
	}

	public void setNoOfCranes(String noOfCranes) {
		this.noOfCranes = noOfCranes;
	}

	public String getBerthDate() {
		return berthDate;
	}

	public void setBerthDate(String berthDate) {
		this.berthDate = berthDate;
	}

	public String getSailDate() {
		return sailDate;
	}

	public void setSailDate(String sailDate) {
		this.sailDate = sailDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEtaDate() {
		return etaDate;
	}

	public void setEtaDate(String etaDate) {
		this.etaDate = etaDate;
	}

	public String getEtbDate() {
		return etbDate;
	}

	public void setEtbDate(String etbDate) {
		this.etbDate = etbDate;
	}

	public String getEtdDate() {
		return etdDate;
	}

	public void setEtdDate(String etdDate) {
		this.etdDate = etdDate;
	}

	public String getAnchorageDate() {
		return anchorageDate;
	}

	public void setAnchorageDate(String anchorageDate) {
		this.anchorageDate = anchorageDate;
	}

	public String getVoyageNumber() {
		return voyageNumber;
	}

	public void setVoyageNumber(String voyageNumber) {
		this.voyageNumber = voyageNumber;
	}

	public String getOutvoyageNumber() {
		return outvoyageNumber;
	}

	public void setOutvoyageNumber(String outvoyageNumber) {
		this.outvoyageNumber = outvoyageNumber;
	}

	public String getVoyageRoute() {
		return voyageRoute;
	}

	public void setVoyageRoute(String voyageRoute) {
		this.voyageRoute = voyageRoute;
	}

	public String getVoyageType() {
		return voyageType;
	}

	public void setVoyageType(String voyageType) {
		this.voyageType = voyageType;
	}

	public String getArrFm() {
		return arrFm;
	}

	public void setArrFm(String arrFm) {
		this.arrFm = arrFm;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getCallDescr() {
		return callDescr;
	}

	public void setCallDescr(String callDescr) {
		this.callDescr = callDescr;
	}

	public String getLineCode() {
		return lineCode;
	}

	public void setLineCode(String lineCode) {
		this.lineCode = lineCode;
	}

	public String getInVesselService() {
		return inVesselService;
	}

	public void setInVesselService(String inVesselService) {
		this.inVesselService = inVesselService;
	}

	public String getArrDraft() {
		return arrDraft;
	}

	public void setArrDraft(String arrDraft) {
		this.arrDraft = arrDraft;
	}

	public String getSailDraft() {
		return sailDraft;
	}

	public void setSailDraft(String sailDraft) {
		this.sailDraft = sailDraft;
	}

	public String getDualBerth() {
		return dualBerth;
	}

	public void setDualBerth(String dualBerth) {
		this.dualBerth = dualBerth;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getLoadTerminalId() {
		return loadTerminalId;
	}

	public void setLoadTerminalId(String loadTerminalId) {
		this.loadTerminalId = loadTerminalId;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getImoCode() {
		return imoCode;
	}

	public void setImoCode(String imoCode) {
		this.imoCode = imoCode;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getManeuverStatus() {
		return maneuverStatus;
	}

	public void setManeuverStatus(String maneuverStatus) {
		this.maneuverStatus = maneuverStatus;
	}

	public String getEt() {
		return et;
	}

	public void setEt(String et) {
		this.et = et;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getSwap() {
		return swap;
	}

	public void setSwap(String swap) {
		this.swap = swap;
	}

	public List<TerminalVisit> getTerminalVisitList() {
		return terminalVisitList;
	}

	public void setTerminalVisitList(List<TerminalVisit> terminalVisitList) {
		this.terminalVisitList = terminalVisitList;
	}

	public String getSlaStatus() {
		return slaStatus;
	}

	public void setSlaStatus(String slaStatus) {
		this.slaStatus = slaStatus;
	}

	public String getProforma() {
		return proforma;
	}

	public void setProforma(String proforma) {
		this.proforma = proforma;
	}

	public String getAisVslOprEta() {
		return aisVslOprEta;
	}

	public void setAisVslOprEta(String aisVslOprEta) {
		this.aisVslOprEta = aisVslOprEta;
	}

	public String getAisAvgSpeed() {
		return aisAvgSpeed;
	}

	public void setAisAvgSpeed(String aisAvgSpeed) {
		this.aisAvgSpeed = aisAvgSpeed;
	}

	public String getAisVesselOperator() {
		return aisVesselOperator;
	}

	public void setAisVesselOperator(String aisVesselOperator) {
		this.aisVesselOperator = aisVesselOperator;
	}

	public String getAisUpdateTime() {
		return aisUpdateTime;
	}

	public void setAisUpdateTime(String aisUpdateTime) {
		this.aisUpdateTime = aisUpdateTime;
	}

	public String getAisEta() {
		return aisEta;
	}

	public void setAisEta(String aisEta) {
		this.aisEta = aisEta;
	}

	public String getAisPreviousAtd() {
		return aisPreviousAtd;
	}

	public void setAisPreviousAtd(String aisPreviousAtd) {
		this.aisPreviousAtd = aisPreviousAtd;
	}

	public String getAisDistanceToNextPort() {
		return aisDistanceToNextPort;
	}

	public void setAisDistanceToNextPort(String aisDistanceToNextPort) {
		this.aisDistanceToNextPort = aisDistanceToNextPort;
	}

	public String getAisNextPort() {
		return aisNextPort;
	}

	public void setAisNextPort(String aisNextPort) {
		this.aisNextPort = aisNextPort;
	}

	public String getAisPrevPort() {
		return aisPrevPort;
	}

	public void setAisPrevPort(String aisPrevPort) {
		this.aisPrevPort = aisPrevPort;
	}

	public String getAisLocation() {
		return aisLocation;
	}

	public void setAisLocation(String aisLocation) {
		this.aisLocation = aisLocation;
	}

	public String getAisError() {
		return aisError;
	}

	public void setAisError(String aisError) {
		this.aisError = aisError;
	}

	public Date getEtaDate1() {
		return etaDate != null ? DateUtilities.parseDate(etaDate,
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM) : null;
	}

	public void setEtaDate1(Date etaDate1) {
		this.etaDate1 = etaDate1;
	}

	public Date getEtcDateObject() {
		return etc != null ? DateUtilities.parseDate(etc, MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM) : null;
				
	}

	public void setEtcDateObject(Date etcDateObject) {
		this.etcDateObject = etcDateObject;
	}
	
	public String getGeofenceData() {
		return geofenceData;
	}

	public void setGeofenceData(String geofenceData) {
		this.geofenceData = geofenceData;
	}

	public String getAlertFlag() {
		return alertFlag;
	}

	public void setAlertFlag(String alertFlag) {
		this.alertFlag = alertFlag;
	}

	public String getTopicValue() {
		return topicValue;
	}

	public void setTopicValue(String topicValue) {
		this.topicValue = topicValue;
	}
	
	public String getMvdusergroup() {
		return mvdusergroup;
	}

	public void setMvdusergroup(String mvdusergroup) {
		this.mvdusergroup = mvdusergroup;
	}
	public String getUserorder() {
		return userorder;
	}

	public void setUserorder(String userorder) {
		this.userorder = userorder;
	}
	
	@Override
	public String toString() {
		return "VesselDetailsDTO [rotationNumber=" + rotationNumber + ", vesselName=" + vesselName + ", vesselType="
				+ vesselType + ", vesselDescription=" + vesselDescription + ", serviceType=" + serviceType
				+ ", serviceTypeDesc=" + serviceTypeDesc + ", loa=" + loa + ", draft=" + draft + ", type=" + type
				+ ", line=" + line + ", callSign=" + callSign + ", currStatus=" + currStatus + ", currLocation="
				+ currLocation + ", orgETA=" + orgETA + ", orgETD=" + orgETD + ", dualCall=" + dualCall + ", newETA="
				+ newETA + ", etb=" + etb + ", etc=" + etc + ", currentPOS=" + currentPOS + ", nextPOS=" + nextPOS
				+ ", berthingPOS=" + berthingPOS + ", fromBollard=" + fromBollard + ", toBollard=" + toBollard
				+ ", noOfQcAllc=" + noOfQcAllc + ", noOfQcWkng=" + noOfQcWkng + ", containerNumber=" + containerNumber
				+ ", terminal=" + terminal + ", portCode=" + portCode + ", rotation=" + rotation + ", berthPosition="
				+ berthPosition + ", craneAssigned=" + craneAssigned + ", berth=" + berth + ", berthCode=" + berthCode
				+ ", fromMetermark=" + fromMetermark + ", toMetermark=" + toMetermark + ", vesselMovesTogo="
				+ vesselMovesTogo + ", longCraneNo=" + longCraneNo + ", longCranemovesToGo=" + longCranemovesToGo
				+ ", noOfCranes=" + noOfCranes + ", berthDate=" + berthDate + ", sailDate=" + sailDate + ", status="
				+ status + ", etaDate=" + etaDate + ", etbDate=" + etbDate + ", etdDate=" + etdDate + ", anchorageDate="
				+ anchorageDate + ", voyageNumber=" + voyageNumber + ", outvoyageNumber=" + outvoyageNumber
				+ ", voyageRoute=" + voyageRoute + ", voyageType=" + voyageType + ", arrFm=" + arrFm + ", callReason="
				+ callReason + ", callType=" + callType + ", callDescr=" + callDescr + ", lineCode=" + lineCode
				+ ", inVesselService=" + inVesselService + ", arrDraft=" + arrDraft + ", sailDraft=" + sailDraft
				+ ", dualBerth=" + dualBerth + ", terminalId=" + terminalId + ", loadTerminalId=" + loadTerminalId
				+ ", imoCode=" + imoCode + ", sourceSystem=" + sourceSystem + ", mvdusergroup=" + mvdusergroup
				+ ", userorder=" + userorder + ", userorderinternal=" + userorderinternal + ", port=" + port
				+ ", agentEta=" + agentEta + ", vtsEta=" + vtsEta + ", order=" + order + ", priority=" + priority
				+ ", description=" + description + ", maneuverStatus=" + maneuverStatus + ", et=" + et
				+ ", fromLocation=" + fromLocation + ", toLocation=" + toLocation + ", swap=" + swap + ", ttMTG="
				+ ttMTG + ", qcAlloc=" + qcAlloc + ", qcWorking=" + qcWorking + ", hhMTG=" + hhMTG + ", hhCrane="
				+ hhCrane + ", qc=" + qc + ", movesToGo=" + movesToGo + ", planMoves=" + planMoves + ", doneMoves="
				+ doneMoves + ", remarks=" + remarks + ", terminalVisitList=" + terminalVisitList + ", dropDownTypes="
				+ dropDownTypes + ", slaStatus=" + slaStatus + ", proforma=" + proforma + ", aisVslOprEta="
				+ aisVslOprEta + ", aisAvgSpeed=" + aisAvgSpeed + ", aisVesselOperator=" + aisVesselOperator
				+ ", aisUpdateTime=" + aisUpdateTime + ", aisEta=" + aisEta + ", aisPreviousAtd=" + aisPreviousAtd
				+ ", aisDistanceToNextPort=" + aisDistanceToNextPort + ", aisNextPort=" + aisNextPort + ", aisPrevPort="
				+ aisPrevPort + ", aisLocation=" + aisLocation + ", aisError=" + aisError + ", etaDate1=" + etaDate1
				+ ", etcDateObject=" + etcDateObject + ", vesselLocation=" + vesselLocation + ", nextLocation="
				+ nextLocation + ", longitude=" + longitude + ", latitude=" + latitude + ", plannedBerth="
				+ plannedBerth + ", currentBerth=" + currentBerth + ", geofenceLoc=" + geofenceLoc
				+ ", vesselArrivalDirectOrAnchorage=" + vesselArrivalDirectOrAnchorage + ", sort_date=" + sort_date
				+ ", pilotDispatchTime=" + pilotDispatchTime + ", newEtb=" + newEtb + ", marineManeuver="
				+ marineManeuver + ", etm=" + etm + ", geofenceData=" + geofenceData + ", alertFlag=" + alertFlag
				+ ", topicValue=" + topicValue + "]";
	}
	
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!(obj instanceof VesselDetailsDTO)) {
			return false;
		}
		VesselDetailsDTO other = (VesselDetailsDTO) obj;
		return this.vesselName.equals(other.vesselName);
	}
	
	public int hashCode() {
        return vesselName.hashCode();
    }

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getAgentEta() {
		return agentEta;
	}

	public void setAgentEta(String agentEta) {
		this.agentEta = agentEta;
	}

	public String getVtsEta() {
		return vtsEta;
	}

	public void setVtsEta(String vtsEta) {
		this.vtsEta = vtsEta;
	}

}
