package com.dpworld.mpcsystem.common.utility.mapping;

/**
 * 
 * @author Rahul Singh
 * 
 * @param <T>
 * @param <S>
 * @Usage Implementation class to implement Template class into template pattern
 * 
 */

public class PayloadEntityMappingProcessor<T, S> {

	protected T execute(T target, S source,
			PayloadEntityMappingTemplate<T, S> template) {
		return template.invoke(target, source);
	}

}
