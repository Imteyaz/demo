package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class BPADataRecord implements Serializable {

	private static final long serialVersionUID = 1L;
	private String vesselName;
	private String rotationNumber;
	private String terminalId;
	private String quay;
	private String berthingSide;
	private String status;

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getQuay() {
		return quay;
	}

	public void setQuay(String quay) {
		this.quay = quay;
	}

	public String getBerthingSide() {
		return berthingSide;
	}

	public void setBerthingSide(String berthingSide) {
		this.berthingSide = berthingSide;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "BPADataRecord [vesselName=" + vesselName + ", rotationNumber="
				+ rotationNumber + ", terminalId=" + terminalId + ", quay="
				+ quay + ", berthingSide=" + berthingSide + ", status="
				+ status + "]";
	}

}
