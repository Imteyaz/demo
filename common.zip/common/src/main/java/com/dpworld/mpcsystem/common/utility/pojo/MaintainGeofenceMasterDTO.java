package com.dpworld.mpcsystem.common.utility.pojo;


public class MaintainGeofenceMasterDTO { 
	private String mgmRecId;
	private String mgmRecDate;
	private String terminalId;
	private String mgmGFCode;
	private String mgmGFLat;
	private String mgmGFLong;
	private String mgmGFSeqNo;
	private String isValid;
	private String srcSys;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	
	// New added
	private String geofenceCodeSearch;
	private String terminalSearch;
	private String statusSearch;
	private String longitudeSearch;
	private String latitudeSearch;
	private String seqNoSearch;
	
	public String getMgmRecId() {
		return mgmRecId;
	}
	public void setMgmRecId(String mgmRecId) {
		this.mgmRecId = mgmRecId;
	}
	public String getMgmRecDate() {
		return mgmRecDate;
	}
	public void setMgmRecDate(String mgmRecDate) {
		this.mgmRecDate = mgmRecDate;
	}
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	public String getMgmGFCode() {
		return mgmGFCode;
	}
	public void setMgmGFCode(String mgmGFCode) {
		this.mgmGFCode = mgmGFCode;
	}
	public String getMgmGFLat() {
		return mgmGFLat;
	}
	public void setMgmGFLat(String mgmGFLat) {
		this.mgmGFLat = mgmGFLat;
	}
	public String getMgmGFLong() {
		return mgmGFLong;
	}
	public void setMgmGFLong(String mgmGFLong) {
		this.mgmGFLong = mgmGFLong;
	}
	public String getMgmGFSeqNo() {
		return mgmGFSeqNo;
	}
	public void setMgmGFSeqNo(String mgmGFSeqNo) {
		this.mgmGFSeqNo = mgmGFSeqNo;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getSrcSys() {
		return srcSys;
	}
	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getGeofenceCodeSearch() {
		return geofenceCodeSearch;
	}
	public void setGeofenceCodeSearch(String geofenceCodeSearch) {
		this.geofenceCodeSearch = geofenceCodeSearch;
	}
	public String getTerminalSearch() {
		return terminalSearch;
	}
	public void setTerminalSearch(String terminalSearch) {
		this.terminalSearch = terminalSearch;
	}
	public String getStatusSearch() {
		return statusSearch;
	}
	public void setStatusSearch(String statusSearch) {
		this.statusSearch = statusSearch;
	}
	public String getLongitudeSearch() {
		return longitudeSearch;
	}
	public void setLongitudeSearch(String longitudeSearch) {
		this.longitudeSearch = longitudeSearch;
	}
	public String getLatitudeSearch() {
		return latitudeSearch;
	}
	public void setLatitudeSearch(String latitudeSearch) {
		this.latitudeSearch = latitudeSearch;
	}
	public String getSeqNoSearch() {
		return seqNoSearch;
	}
	public void setSeqNoSearch(String seqNoSearch) {
		this.seqNoSearch = seqNoSearch;
	}
	
	
	

}
