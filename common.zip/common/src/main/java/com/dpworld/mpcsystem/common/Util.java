package com.dpworld.mpcsystem.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.dpworld.mpcsystem.common.constants.MPCConstants;

/**
 * This class contains all the utility method
 * 
 * @author 902256
 * 
 */
public class Util {

	private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(Util.class);
	private static final String dateParsingError= "Unable to parse the date";

	/**
	 * This method used to validate numeric fields
	 * 
	 * @param fieldName
	 * @param fieldValue
	 * @param invalidValueBuilder
	 */
	public void validateNumeric(String fieldName, String fieldValue,
			StringBuilder invalidValueBuilder) {
		boolean isValid = StringUtils.isNumeric(fieldValue);
		if (!isValid) {
			invalidValueBuilder.append(fieldName + MPCConstants.COMMA);
		}
	}

	/**
	 * This method used to validate input field content
	 * 
	 * @param fieldName
	 * @param element
	 * @param list
	 * @param invalidValueBuilder
	 */
	public <E extends Object> void validateInputFieldContent(String fieldName,
			E element, List<E> list, StringBuilder invalidValueBuilder) {
		if (element == null) {
			return;
		}
		boolean isValid = list.contains(element);
		if (!isValid) {
			invalidValueBuilder.append(fieldName + MPCConstants.COMMA);
		}
	}

	/**
	 * This method used to validate input field content
	 * 
	 * @param fieldName
	 * @param element
	 * @param list
	 * @param invalidValueBuilder
	 */
	public <E extends Object> boolean validateInputFieldContentForUpdateMsgs(
			String fieldName, E element, List<E> list,
			StringBuilder invalidValueBuilder) {
		boolean isValid = list.contains(element);
		if (!isValid) {
			invalidValueBuilder.append(fieldName + MPCConstants.COMMA);
		}
		return isValid;
	}

	/**
	 * This method used to validate all string type values
	 * 
	 * @param fieldName
	 * @param value
	 * @param reasonCodeDescBuilder
	 */
	public void validateEmptyValues(String fieldName, String value,
			StringBuilder reasonCodeDescBuilder) {
		if (StringUtils.isBlank(value)) {
			reasonCodeDescBuilder.append(fieldName + MPCConstants.COMMA);
		}
	}

	/**
	 * Convert date to XMLGregorianCalendar format.
	 * 
	 * @param date
	 * @return
	 */

	public static XMLGregorianCalendar convertDatetoGregorianCal(Date date) {
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		XMLGregorianCalendar createDate = null;

		try {

			DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();

			gregorianCalendar.setTimeInMillis(date.getTime());
			createDate = datatypeFactory
					.newXMLGregorianCalendar(gregorianCalendar);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("Date formate exception", e);
		} catch (NullPointerException ne) {
			LOGGER.error("Date is null", ne);
		}
		return createDate;

	}

	/**
	 * This method converts XMLGregorianDate to util date format in format
	 * acceptable to ESB('yyyy-mm-dd').
	 * 
	 * @param XMLGregorianCalendar
	 */
	public static Date convertGregorianDateToUtilDate(
			XMLGregorianCalendar xmlGregorianDate) {
		DateFormat dateFormat = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
		GregorianCalendar gregorianCalendar = xmlGregorianDate
				.toGregorianCalendar();
		Date date = gregorianCalendar.getTime();
		String reportDate = dateFormat.format(date);
		Date formatDate = null;
		try {
			formatDate = dateFormat.parse(reportDate);
		} catch (ParseException e) {
			LOGGER.error(dateParsingError, e);
		}
		return formatDate;
	}

	/**
	 * This method converts XMLGregorianDate to string format in format.
	 * 
	 * @param XMLGregorianCalendar
	 */
	public static String convertGregorianDateToString(
			XMLGregorianCalendar xmlGregorianDate) {
		String reportDate = null;
		if (xmlGregorianDate != null) {
			DateFormat dateFormat = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
			GregorianCalendar gregorianCalendar = xmlGregorianDate
					.toGregorianCalendar();
			Date date = gregorianCalendar.getTime();
			reportDate = dateFormat.format(date);
		}
		return reportDate;
	}

	/**
	 * This method converts the Date format into yyyy-MM-dd.
	 * 
	 * @param java
	 *            .util.Date
	 * @return Date
	 */
	public static Date formatDate(Date utildate) {
		DateFormat dateFormat = new SimpleDateFormat(MPCConstants.DATETIME_FORMAT_YYYY_MM_DD);
		Date formatDate = null;
		try {
			String reportDate = dateFormat.format(utildate);
			formatDate = dateFormat.parse(reportDate);
		} catch (ParseException e) {
			LOGGER.error(dateParsingError, e);
		}
		return formatDate;
	}

}
