package com.dpworld.mpcsystem.common;

/*
 *

 * Purpose of this class is to handle exceptions
 * 
 */
public class GenericException extends Exception {

	/**
     * 
     */
	private static final long serialVersionUID = 1L;

}
