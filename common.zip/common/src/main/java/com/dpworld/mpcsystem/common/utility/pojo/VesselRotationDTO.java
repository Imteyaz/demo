package com.dpworld.mpcsystem.common.utility.pojo;

public class VesselRotationDTO {

	
	private String vesselName;
	private String rotationNumber;
	private String vesselTopicValue;
	private String vesselTopicType;
	
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	public String getRotationNumber() {
		return rotationNumber;
	}
	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}
	public String getVesselTopicValue() {
		return vesselTopicValue;
	}
	public void setVesselTopicValue(String vesselTopicValue) {
		this.vesselTopicValue = vesselTopicValue;
	}
	public String getVesselTopicType() {
		return vesselTopicType;
	}
	public void setVesselTopicType(String vesselTopicType) {
		this.vesselTopicType = vesselTopicType;
	}
	
	
	
	
}
