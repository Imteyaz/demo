package com.dpworld.mpcsystem.common.utility.pojo;


public class SubscribedUserDTO {
	
	private String convId;
	private String convTopicType;
	private String convTopicVal;
	private String convSubTopicType;
	private String convSubTopicVal;
	private String altId;
    private String altCode;
	private String createdOn;
	private String userSubscribed;
    private String recId;
    private String subsStatus;
    private String recDate;
	public String getConvId() {
		return convId;
	}
	public void setConvId(String convId) {
		this.convId = convId;
	}
	public String getConvTopicType() {
		return convTopicType;
	}
	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}
	public String getConvTopicVal() {
		return convTopicVal;
	}
	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}
	public String getConvSubTopicType() {
		return convSubTopicType;
	}
	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}
	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}
	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}
	public String getAltId() {
		return altId;
	}
	public void setAltId(String altId) {
		this.altId = altId;
	}
	public String getAltCode() {
		return altCode;
	}
	public void setAltCode(String altCode) {
		this.altCode = altCode;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getUserSubscribed() {
		return userSubscribed;
	}
	public void setUserSubscribed(String userSubscribed) {
		this.userSubscribed = userSubscribed;
	}
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getSubsStatus() {
		return subsStatus;
	}
	public void setSubsStatus(String subsStatus) {
		this.subsStatus = subsStatus;
	}
	public String getRecDate() {
		return recDate;
	}
	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}
	@Override
	public String toString() {
		return "SubscribedUserDTO [convId=" + convId + ", convTopicType="
				+ convTopicType + ", convTopicVal=" + convTopicVal
				+ ", convSubTopicType=" + convSubTopicType
				+ ", convSubTopicVal=" + convSubTopicVal + ", altId=" + altId
				+ ", altCode=" + altCode + ", createdOn=" + createdOn
				+ ", userSubscribed=" + userSubscribed + ", recId=" + recId
				+ ", subsStatus=" + subsStatus + ", recDate=" + recDate + "]";
	}
    
}