package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class VesselInfo implements Serializable {


  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;

  private Float lat;
  private Float lng;
  private String vesselName = "";
  private String imoNumber = "";
  private String eta = "";
  private String vesselSourceName = "";
  private String vesselDestinationName = "";
  private String bpaDataAvailble = "N";
  // private BPADataRecord bpaDataRecord;
  private String rotationNumber = "";
  private String terminalId = "";
  private String quay = "";
  private String berthingSide = "";
  private String status = "";
  private String berthedTerminalGeocode = "";
  private String vesselType = "";
  private String currentLocation = "";
  private String lastRecord = "";
  private String source = "";
  private String speed = "";
  private String etb = "";
  private String etc = "";
  private String etm = "";
  private String fromBollard = "";
  private String toBollard = "";
  private String loa;
  private String geofenceArea;
  private String degrees;
  private String heading;
  private String nextLocation;

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

public String getBerthedTerminalGeocode() {
    return berthedTerminalGeocode;
  }

  public void setBerthedTerminalGeocode(String berthedTerminalGeocode) {
    this.berthedTerminalGeocode = berthedTerminalGeocode;
  }

  public String getRotationNumber() {
    return rotationNumber;
  }

  public void setRotationNumber(String rotationNumber) {
    this.rotationNumber = rotationNumber;
  }

  public String getTerminalId() {
    return terminalId;
  }

  public void setTerminalId(String terminalId) {
    this.terminalId = terminalId;
  }

  public String getQuay() {
    return quay;
  }

  public void setQuay(String quay) {
    this.quay = quay;
  }

  public String getBerthingSide() {
    return berthingSide;
  }

  public void setBerthingSide(String berthingSide) {
    this.berthingSide = berthingSide;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  /*
   * public BPADataRecord getBpaDataRecord() { return bpaDataRecord; } public
   * void setBpaDataRecord(BPADataRecord bpaDataRecord) { this.bpaDataRecord =
   * bpaDataRecord; }
   */
  public String getBpaDataAvailble() {
    return bpaDataAvailble;
  }

  public void setBpaDataAvailble(String bpaDataAvailble) {
    this.bpaDataAvailble = bpaDataAvailble;
  }

  public Float getLat() {
    return lat;
  }

  public void setLat(Float lat) {
    this.lat = lat;
  }

  public Float getLng() {
    return lng;
  }

  public void setLng(Float lng) {
    this.lng = lng;
  }

  public String getVesselName() {
    return vesselName;
  }

  public void setVesselName(String vesselName) {
    this.vesselName = vesselName;
  }

  public String getImoNumber() {
    return imoNumber;
  }

  public void setImoNumber(String imoNumber) {
    this.imoNumber = imoNumber;
  }

  public String getEta() {
    return eta;
  }

  public void setEta(String eta) {
    this.eta = eta;
  }

  public String getVesselSourceName() {
    return vesselSourceName;
  }

  public void setVesselSourceName(String vesselSourceName) {
    this.vesselSourceName = vesselSourceName;
  }

  public String getVesselDestinationName() {
    return vesselDestinationName;
  }

  public void setVesselDestinationName(String vesselDestinationName) {
    this.vesselDestinationName = vesselDestinationName;
  }

  public String getVesselType() {
    return vesselType;
  }

  public void setVesselType(String vesselType) {
    this.vesselType = vesselType;
  }

  public String getCurrentLocation() {
    return currentLocation;
  }

  public void setCurrentLocation(String currentLocation) {
    this.currentLocation = currentLocation;
  }

  public String getLastRecord() {
    return lastRecord;
  }

  public void setLastRecord(String lastRecord) {
    this.lastRecord = lastRecord;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getSpeed() {
    return speed;
  }

  public void setSpeed(String speed) {
    this.speed = speed;
  }

  public String getEtb() {
    return etb;
  }

  public void setEtb(String etb) {
    this.etb = etb;
  }

  public String getEtc() {
    return etc;
  }

  public void setEtc(String etc) {
    this.etc = etc;
  }

  public String getEtm() {
    return etm;
  }

  public void setEtm(String etm) {
    this.etm = etm;
  }

  public String getFromBollard() {
    return fromBollard;
  }

  public void setFromBollard(String fromBollard) {
    this.fromBollard = fromBollard;
  }

  public String getToBollard() {
    return toBollard;
  }

  public void setToBollard(String toBollard) {
    this.toBollard = toBollard;
  }

  public String getLoa() {
    return loa;
  }

  public void setLoa(String loa) {
    this.loa = loa;
  }


  public String getGeofenceArea() {
    return geofenceArea;
  }

  public void setGeofenceArea(String geofenceArea) {
    this.geofenceArea = geofenceArea;
  }

  public String getDegrees() {
    return degrees;
  }
  
  public void setDegrees(String degrees) {
    this.degrees = degrees;
  }
  
  public String getNextLocation() {
		return nextLocation;
	}

	public void setNextLocation(String nextLocation) {
		this.nextLocation = nextLocation;
	}
  
  @Override
public String toString() {
	return "VesselInfo [lat=" + lat + ", lng=" + lng + ", vesselName=" + vesselName + ", imoNumber=" + imoNumber
			+ ", eta=" + eta + ", vesselSourceName=" + vesselSourceName + ", vesselDestinationName="
			+ vesselDestinationName + ", bpaDataAvailble=" + bpaDataAvailble + ", rotationNumber=" + rotationNumber
			+ ", terminalId=" + terminalId + ", quay=" + quay + ", berthingSide=" + berthingSide + ", status=" + status
			+ ", berthedTerminalGeocode=" + berthedTerminalGeocode + ", vesselType=" + vesselType + ", currentLocation="
			+ currentLocation + ", lastRecord=" + lastRecord + ", source=" + source + ", speed=" + speed + ", etb="
			+ etb + ", etc=" + etc + ", etm=" + etm + ", fromBollard=" + fromBollard + ", toBollard=" + toBollard
			+ ", loa=" + loa + ", geofenceArea=" + geofenceArea + ", degrees=" + degrees + ", heading=" + heading
			+ ", nextLocation=" + nextLocation + "]";
}


}
