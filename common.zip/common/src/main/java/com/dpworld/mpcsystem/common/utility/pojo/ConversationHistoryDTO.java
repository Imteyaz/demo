package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class ConversationHistoryDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String recId;
	private String recDate;
	private String convType;
	private String altId;
	private String convId;
	private String convTopicType;
	private String convTopicVal;
	private String convSubTopicType;
	private String convSubTopicVal;
	private String convText;
	private String convUser;
	private String isValid;
	private String srcSys;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	private String userCode;
	private String subscrStatus;
	
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getRecDate() {
		return recDate;
	}
	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}
	public String getConvType() {
		return convType;
	}
	public void setConvType(String convType) {
		this.convType = convType;
	}
	public String getAltId() {
		return altId;
	}
	public void setAltId(String altId) {
		this.altId = altId;
	}
	public String getConvId() {
		return convId;
	}
	public void setConvId(String convId) {
		this.convId = convId;
	}
	public String getConvTopicType() {
		return convTopicType;
	}
	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}
	public String getConvTopicVal() {
		return convTopicVal;
	}
	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}
	public String getConvSubTopicType() {
		return convSubTopicType;
	}
	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}
	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}
	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}
	public String getConvText() {
		return convText;
	}
	public void setConvText(String convText) {
		this.convText = convText;
	}
	public String getConvUser() {
		return convUser;
	}
	public void setConvUser(String convUser) {
		this.convUser = convUser;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getSrcSys() {
		return srcSys;
	}
	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getSubscrStatus() {
		return subscrStatus;
	}
	public void setSubscrStatus(String subscrStatus) {
		this.subscrStatus = subscrStatus;
	}
	@Override
	public String toString() {
		return "ConversationHistoryDTO [recId=" + recId + ", recDate="
				+ recDate + ", convType=" + convType + ", altId=" + altId
				+ ", convId=" + convId + ", convTopicType=" + convTopicType
				+ ", convTopicVal=" + convTopicVal + ", convSubTopicType="
				+ convSubTopicType + ", convSubTopicVal=" + convSubTopicVal
				+ ", convText=" + convText + ", convUser=" + convUser
				+ ", isValid=" + isValid + ", srcSys=" + srcSys
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy
				+ ", userCode=" + userCode + ", subscrStatus=" + subscrStatus
				+ "]";
	}
}
