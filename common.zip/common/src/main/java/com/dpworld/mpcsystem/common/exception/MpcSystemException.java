
package com.dpworld.mpcsystem.common.exception;

/**
 * @author Vinculum.Imteyaz
 *
 */
public class MpcSystemException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MpcSystemException() {
		super();
	}

	public MpcSystemException(String message) {
		super(message);

	}

	public MpcSystemException(Throwable cause) {
		super(cause);

	}

	public MpcSystemException(String message, Throwable cause) {
		super(message, cause);

	}

}
