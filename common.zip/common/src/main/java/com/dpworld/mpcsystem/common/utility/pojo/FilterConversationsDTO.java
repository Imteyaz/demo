package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.List;

public class FilterConversationsDTO 
{
	
	private String filterTopic;
	private String filterUsers;
	private String filterFromTime;
	private String filterToTime;
	private String filterSrcSystem;
	private String sessionName;
	private String roleName;
	private List<String> filterConvTypeList;
	
	public String getFilterTopic() {
		return filterTopic;
	}
	public void setFilterTopic(String filterTopic) {
		this.filterTopic = filterTopic;
	}
	public String getFilterUsers() {
		return filterUsers;
	}
	public void setFilterUsers(String filterUsers) {
		this.filterUsers = filterUsers;
	}
	public String getFilterFromTime() {
		return filterFromTime;
	}
	public void setFilterFromTime(String filterFromTime) {
		this.filterFromTime = filterFromTime;
	}
	public String getFilterSrcSystem() {
		return filterSrcSystem;
	}
	public void setFilterSrcSystem(String filterSrcSystem) {
		this.filterSrcSystem = filterSrcSystem;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public String getFilterToTime() {
		return filterToTime;
	}
	public void setFilterToTime(String filterToTime) {
		this.filterToTime = filterToTime;
	}
	public List<String> getFilterConvTypeList() {
		return filterConvTypeList;
	}
	public void setFilterConvTypeList(List<String> filterConvTypeList) {
		this.filterConvTypeList = filterConvTypeList;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	
	

}
