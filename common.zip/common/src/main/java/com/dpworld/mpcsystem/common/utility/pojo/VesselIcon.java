package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class VesselIcon implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double lat;
	private double lng;

	public VesselIcon(double lat, double lng) {
		this.lat = lat;
		this.lng = lng;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

}
