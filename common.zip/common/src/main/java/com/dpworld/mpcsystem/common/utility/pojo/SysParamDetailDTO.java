package com.dpworld.mpcsystem.common.utility.pojo;

public class SysParamDetailDTO {
	@Override
	public String toString() {
		return "SysParamDetailDTO [recId=" + recId + ", mspParamCatg="
				+ mspParamCatg + ", mspParamGroup=" + mspParamGroup
				+ ", mspParamCode=" + mspParamCode + ", mspVal1=" + mspVal1
				+ ", isValid=" + isValid + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy
				+ ", modifiedOn=" + modifiedOn + ", mspChar1=" + mspChar1
				+ ", mspChar2=" + mspChar2 + ", mspNum1=" + mspNum1
				+ ", mspNum2=" + mspNum2 + ", mspDate1=" + mspDate1
				+ ", mspDate2=" + mspDate2 + ", mspVal2=" + mspVal2
				+ ", mspVal3=" + mspVal3 + ", srcSys=" + srcSys + "]";
	}

	private String recId;
	private String mspParamCatg;
	private String mspParamGroup;
	private String mspParamCode;
	private String mspVal1;
	private String isValid;
	private String createdBy;
	private String createdOn;
	private String modifiedBy;
	private String modifiedOn;

	private String mspChar1;
	private String mspChar2;
	private String mspNum1;
	private String mspNum2;
	private String mspDate1;
	private String mspDate2;
	private String mspVal2;
	private String mspVal3;
	private String srcSys;

	public String getRecId() {
		return recId;
	}

	public void setRecId(String recId) {
		this.recId = recId;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getMspParamCatg() {
		return mspParamCatg;
	}

	public void setMspParamCatg(String mspParamCatg) {
		this.mspParamCatg = mspParamCatg;
	}

	public String getMspParamGroup() {
		return mspParamGroup;
	}

	public void setMspParamGroup(String mspParamGroup) {
		this.mspParamGroup = mspParamGroup;
	}

	public String getMspParamCode() {
		return mspParamCode;
	}

	public void setMspParamCode(String mspParamCode) {
		this.mspParamCode = mspParamCode;
	}

	public String getMspVal1() {
		return mspVal1;
	}

	public void setMspVal1(String mspVal1) {
		this.mspVal1 = mspVal1;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getMspChar1() {
		return mspChar1;
	}

	public void setMspChar1(String mspChar1) {
		this.mspChar1 = mspChar1;
	}

	public String getMspChar2() {
		return mspChar2;
	}

	public void setMspChar2(String mspChar2) {
		this.mspChar2 = mspChar2;
	}

	public String getMspNum1() {
		return mspNum1;
	}

	public void setMspNum1(String mspNum1) {
		this.mspNum1 = mspNum1;
	}

	public String getMspDate1() {
		return mspDate1;
	}

	public void setMspDate1(String mspDate1) {
		this.mspDate1 = mspDate1;
	}

	public String getMspDate2() {
		return mspDate2;
	}

	public void setMspDate2(String mspDate2) {
		this.mspDate2 = mspDate2;
	}

	public String getMspVal2() {
		return mspVal2;
	}

	public void setMspVal2(String mspVal2) {
		this.mspVal2 = mspVal2;
	}

	public String getMspVal3() {
		return mspVal3;
	}

	public void setMspVal3(String mspVal3) {
		this.mspVal3 = mspVal3;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getMspNum2() {
		return mspNum2;
	}

	public void setMspNum2(String mspNum2) {
		this.mspNum2 = mspNum2;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
