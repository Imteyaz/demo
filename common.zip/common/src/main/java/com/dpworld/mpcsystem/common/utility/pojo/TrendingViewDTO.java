package com.dpworld.mpcsystem.common.utility.pojo;


public class TrendingViewDTO {
	
	private String convId;
	private String convTopicType;
	private String convTopicVal;
	private String convSubTopicType;
	private String convSubTopicVal;
	private String createdOn;
    private String count;
    private String isSubscribed;
    private String followedOn;
    private String recId;
    private String subsStatus;
    private String recDate;
    private String altId;
    
    
	public String getConvId() {
		return convId;
	}
	public void setConvId(String convId) {
		this.convId = convId;
	}
	public String getConvTopicType() {
		return convTopicType;
	}
	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}
	public String getConvTopicVal() {
		return convTopicVal;
	}
	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}
	public String getConvSubTopicType() {
		return convSubTopicType;
	}
	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}
	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}
	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getIsSubscribed() {
		return isSubscribed;
	}
	public void setIsSubscribed(String isSubscribed) {
		this.isSubscribed = isSubscribed;
	}
	public String getFollowedOn() {
		return followedOn;
	}
	public void setFollowedOn(String foolowedOn) {
		this.followedOn = foolowedOn;
	}
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getSubsStatus() {
		return subsStatus;
	}
	public void setSubsStatus(String subsStatus) {
		this.subsStatus = subsStatus;
	}
	public String getRecDate() {
		return recDate;
	}
	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}
	public String getAltId() {
		return altId;
	}
	public void setAltId(String altId) {
		this.altId = altId;
	}
	@Override
	public String toString() {
		return "TrendingViewDTO [convId=" + convId + ", convTopicType="
				+ convTopicType + ", convTopicVal=" + convTopicVal
				+ ", convSubTopicType=" + convSubTopicType
				+ ", convSubTopicVal=" + convSubTopicVal + ", createdOn="
				+ createdOn + ", count=" + count + ", isSubscribed="
				+ isSubscribed + ", followedOn=" + followedOn + ", recId="
				+ recId + ", subsStatus=" + subsStatus + ", recDate=" + recDate
				+ ", altId=" + altId + "]";
	}
	
	
}