package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ConversationDTO {
	
	private String recId;
	private String recDate;
	private String convId;
	private String convTopicType;
	private String convSubTopicVal;
	private String convText;
	private String createdBy;
	private String converUser;
	private String status;
	
	private String altId;
	private String convTopicVal;
	private String convSubTopicType;
	private String convUser;
	private String isValid;
	private String srcSys;
	private String createdOn;
	private String modifiedOn;
	private String modifiedBy;
	private String convType;
	
	private List<ConversationSubDTO> conversationSubDTO = new ArrayList<ConversationSubDTO>();
	
	private List<String> userlist;
	
	private HashMap<String, String> userRoleMap;
	
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getRecDate() {
		return recDate;
	}
	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}
	public String getConvId() {
		return convId;
	}
	public void setConvId(String convId) {
		this.convId = convId;
	}
	public String getConvTopicType() {
		return convTopicType;
	}
	public void setConvTopicType(String convTopicType) {
		this.convTopicType = convTopicType;
	}
	public String getConvText() {
		return convText;
	}
	public void setConvText(String convText) {
		this.convText = convText;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public List<ConversationSubDTO> getConversationSubDTO() {
		return conversationSubDTO;
	}
	public void setConversationSubDTO(List<ConversationSubDTO> conversationSubDTO) {
		this.conversationSubDTO = conversationSubDTO;
	}
	public String getConverUser() {
		return converUser;
	}
	public void setConverUser(String converUser) {
		this.converUser = converUser;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getConvSubTopicVal() {
		return convSubTopicVal;
	}
	public void setConvSubTopicVal(String convSubTopicVal) {
		this.convSubTopicVal = convSubTopicVal;
	}
	public String getAltId() {
		return altId;
	}
	public void setAltId(String altId) {
		this.altId = altId;
	}
	public String getConvTopicVal() {
		return convTopicVal;
	}
	public void setConvTopicVal(String convTopicVal) {
		this.convTopicVal = convTopicVal;
	}
	public String getConvSubTopicType() {
		return convSubTopicType;
	}
	public void setConvSubTopicType(String convSubTopicType) {
		this.convSubTopicType = convSubTopicType;
	}
	public String getConvUser() {
		return convUser;
	}
	public void setConvUser(String convUser) {
		this.convUser = convUser;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getSrcSys() {
		return srcSys;
	}
	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getConvType() {
		return convType;
	}
	public void setConvType(String convType) {
		this.convType = convType;
	}
	public List<String> getUserlist() {
		return userlist;
	}
	public void setUserlist(List<String> userlist) {
		this.userlist = userlist;
	}
	public HashMap<String, String> getUserRoleMap() {
		return userRoleMap;
	}
	public void setUserRoleMap(HashMap<String, String> userRoleMap) {
		this.userRoleMap = userRoleMap;
	}
	
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!(obj instanceof ConversationDTO)) {
			return false;
		}
		ConversationDTO other = (ConversationDTO) obj;
		return this.convText.equals(other.convText);
	}
	
	public int hashCode() {
        return convText.hashCode();
    }

	
	@Override
	public String toString() {
		return "ConversationDTO [recId=" + recId + ", recDate=" + recDate
				+ ", convId=" + convId + ", convTopicType=" + convTopicType
				+ ", convSubTopicVal=" + convSubTopicVal + ", convText="
				+ convText + ", createdBy=" + createdBy + ", converUser="
				+ converUser + ", status=" + status + ", conversationSubDTO="
				+ conversationSubDTO + ", altId = "+altId+", convTopicVal = "
				+convTopicVal+", convSubTopicType = "+convSubTopicType+", convUser = "
				+convUser+", isValid = "+isValid+", srcSys = "+srcSys+", createdOn = "
				+createdOn+", modifiedOn = "+modifiedOn+", modifiedBy = "+modifiedBy+""
				+ ", convType = "+convType+", userlist = "+userlist+", userRoleMap = "+userRoleMap+" ]";
	}
}