package com.dpworld.mpcsystem.common.utility.mapping;

/**
 * 
 * @author Rahul Singh
 *
 * @param <T>
 * @param <S>
 * @Usage Implementation class of template method
 * 
 */
import java.beans.PropertyDescriptor;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.converters.BooleanConverter;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.StringConverter;
import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

public class PayloadEntityMappingRepository<T, S> implements
		PayloadEntity<T, S> {

	private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(PayloadEntityMappingRepository.class);
	Map<String, PropertyDescriptor> targetPropMapper = new HashMap<String, PropertyDescriptor>();
	private static final String CONTEXT = "context";
	private static final String DIFF_IN_PROPERTY = "DIFF_IN_PROPERTY";
	private NullAwareBeanUtilsBean<T, S> nullAwareBeanUtilsBean;
	private static Map<String, Converter> convertors = new HashMap<String, Converter>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			put("Date", new DateConverter(null));
			put("Timestamp", new DateConverter(null));
			put("XMLGregorianCalendar", new DateConverter(null));
			put("Integer", new IntegerConverter());
			put("String", new StringConverter());
			put("Boolean", new BooleanConverter());

		}
	};

	public PayloadEntityMappingRepository(
			NullAwareBeanUtilsBean<T, S> nullAwareBeanUtilsBean) {
		nullAwareBeanUtilsBean
				.mapTargetBeanPropertyDescriptor(nullAwareBeanUtilsBean
						.getTarget());
		nullAwareBeanUtilsBean
				.setSourceBeanPropertyDescriptor(nullAwareBeanUtilsBean
						.getSource());
		nullAwareBeanUtilsBean
				.mapTargetBeanPropertyDescriptor(nullAwareBeanUtilsBean
						.getTarget());
		this.nullAwareBeanUtilsBean = nullAwareBeanUtilsBean;
		this.nullAwareBeanUtilsBean.register(convertors);
		if (!MapUtils.isEmpty(nullAwareBeanUtilsBean.getDiffPropT2S())) {
			this.nullAwareBeanUtilsBean.setDiffProperty(DIFF_IN_PROPERTY);
		}

	}

	public NullAwareBeanUtilsBean<T, S> getNullAwareBeanUtilsBean() {
		return nullAwareBeanUtilsBean;
	}

	/**
	 * @method embedRequest
	 * @param bean
	 *            target and source,Map
	 * @usage coping the property into target object from source object
	 * 
	 * **/
	public T embedRequest(T target, S source) {
		return new PayloadEntityMappingProcessor<T, S>().execute(target,
				source, new PayloadEntityMappingTemplate<T, S>() {
					public T transformer(T target, S source) {
						try {
							nullAwareBeanUtilsBean
									.targetBeanWritePropertyInviker(source,
											target);

						} catch (Exception e) {
							LOGGER.error(CONTEXT, e);
						}
						return target;
					}
				});

	}

}
