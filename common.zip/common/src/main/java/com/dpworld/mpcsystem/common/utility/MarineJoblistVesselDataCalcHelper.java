package com.dpworld.mpcsystem.common.utility;

import static com.dpworld.mpcsystem.common.constants.MPCConstants.ANCHOR;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.ANCHORAGE_COORDINATE_FOUR;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.ANCHORAGE_COORDINATE_ONE;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.ANCHORAGE_COORDINATE_THREE;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.ANCHORAGE_COORDINATE_TWO;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.BREAK_WATER;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.BREAK_WATER_ONE;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.BREAK_WATER_TWO;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.DATE_TIME_FORMAT;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.EIGHT_HOURS;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.EMPTY_STRING;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.FOUR_HOURS;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.HIGH_SEA;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.PILOT_STATION_1;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.PILOT_STATION_2;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.SIX_HOURS;
import static com.dpworld.mpcsystem.common.constants.MPCConstants.TWO_HOURS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.pojo.GeoFenceData;
import com.dpworld.mpcsystem.common.utility.pojo.PilotVesselDataDTO;
import com.dpworld.mpcsystem.common.utility.pojo.SysParamDetailDTO;
import com.dpworld.mpcsystem.common.utility.pojo.TerminalVisit;
import com.dpworld.mpcsystem.common.utility.pojo.TimeDetails;
import com.dpworld.mpcsystem.common.utility.pojo.MarineJoblistDetailsDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

/**
 * @author Sapcle.Srinivas
 *
 */
public class MarineJoblistVesselDataCalcHelper {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(MarineJoblistVesselDataCalcHelper.class);
	
	public Integer computeDistanceForETB(List<SysParamDetailDTO> inputList,MarineJoblistDetailsDTO dto)
 {

		LOGGER.debug(" the given input distance is  : "
				+ dto.getVesselLocation() + " for vessel : "
				+ dto.getVesselName() + "with terminal id : "
				+ dto.getTerminalId() + "terminal :" + dto.getTerminal());
		Integer distance = null;
		switch (dto.getVesselLocation().trim()) {
		case MPCConstants.TWO_HOURS: {
			LOGGER.debug("In two hours switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId().equalsIgnoreCase(MPCConstants.T1)) 
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.TWO_HRS_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.TWO_HRS_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.TWO_HRS_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.TWO_HRS_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.TWO_HRS_TO_GC);
			  LOGGER.debug(" 2HRS Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.FOUR_HOURS: {
			LOGGER.debug("In four hours switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.FOUR_HRS_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.FOUR_HRS_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.FOUR_HRS_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.FOUR_HRS_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.FOUR_HRS_TO_GC);
			  LOGGER.debug(" 4HRS Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.SIX_HOURS: {
			LOGGER.debug("In  six switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.SIX_HRS_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.SIX_HRS_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.SIX_HRS_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase(MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.SIX_HRS_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.SIX_HRS_TO_GC);
			  LOGGER.debug(" 6HRS Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.EIGHT_HOURS: {
			LOGGER.debug("In  eight switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId().equalsIgnoreCase(MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.EIGHT_HRS_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId().equalsIgnoreCase(MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.EIGHT_HRS_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.EIGHT_HRS_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId().equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.EIGHT_HRS_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId().equalsIgnoreCase(MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.EIGHT_HRS_TO_GC);
			  LOGGER.debug(" 8HRS Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.ANCHOR: {
			LOGGER.debug("In anchor switch block for vessel : "
					+ dto.getVesselName());
			 if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.ANCHOR_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.ANCHOR_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.ANCHOR_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.ANCHOR_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.ANCHOR_TO_GC);
			  LOGGER.debug(" ANCHOR Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.CHANNEL: {
			LOGGER.debug("In channel switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.CHANNEL_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.CHANNEL_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.CHANNEL_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.CHANNEL_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.CHANNEL_TO_GC);
			 LOGGER.debug(" channel Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}

		case MPCConstants.BASIN: {
			LOGGER.debug("In basin switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.BASIN_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.BASIN_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.BASIN_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.BASIN_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.BASIN_TO_GC);
			 LOGGER.debug(" BASIN Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}
		case MPCConstants.PILOT_STATION_1: {
			LOGGER.debug("IN pilot station 1 switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION1_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION1_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION1_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION1_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION1_TO_GC);
			 LOGGER.debug(" PS1 Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}
		case MPCConstants.PILOT_STATION_2: {
			LOGGER.debug("IN pilot station 2 switch block for vessel : "
					+ dto.getVesselName());
			if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T1))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION2_TO_T1);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T2))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION2_TO_T2);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T3))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION2_TO_T3);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.T4))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION2_TO_T4);
			else if (dto.getTerminalId() != null
					&& dto.getTerminalId() .equalsIgnoreCase( MPCConstants.GC))
				distance = getParamBasedOnCategory(inputList, MPCConstants.ETB,
						MPCConstants.PILOT_STATION2_TO_GC);
			 LOGGER.debug(" PS2 Assigned with the distance : "+distance+" FOR VESSEL : "+dto.getVesselName());
			break;
		}
		default:
			LOGGER.debug("In default switch block for vessel : "
					+ dto.getVesselName() + " with the location : "
					+ dto.getVesselLocation());
			distance = null;
			break;
		}
		return distance;
	}
	
	public Integer getParamBasedOnCategory(List<SysParamDetailDTO> inputParams, final String paramGroup,final String paramCode)
 {
		if(inputParams !=null){
			LOGGER.debug("input list size is : "+inputParams.size());
		SysParamDetailDTO dto = (SysParamDetailDTO) CollectionUtils.find(
				inputParams, new Predicate() {

					@Override
					public boolean evaluate(Object object) {
						SysParamDetailDTO dto = (SysParamDetailDTO) object;
						LOGGER.debug("current iterated object with paramcode : "+dto.getMspParamCode()+"  and ParamGroup is : "+dto.getMspParamGroup());
						LOGGER.debug("given input details param code is  : "+paramCode+" and Param group is : "+paramGroup);
						return (
								dto.getMspParamCode() != null
								&&  dto.getMspParamCode().equalsIgnoreCase(paramCode));
								/*&& dto.getMspParamGroup() !=null
								&& dto.getMspParamGroup().equalsIgnoreCase(paramGroup));*/
					}
				});
		if(dto !=null && dto.getMspVal1() !=null){
		LOGGER.debug("The calculated param category value  : "+dto.getMspVal1());
		return (Integer.parseInt(dto.getMspVal1()));
		}
		else
		{
			LOGGER.debug("no match hence return zerop for param group : "+paramGroup +" with paramCode : "+paramCode);
		  return 0;
		}
		
		}
		return 0;
		
	}
	
	/*
	   COMPUTATION LOGIC FOR ETB
	   1.	Get buffer time for each Quay from the Geofence and compute the ETB.   E.G. 8 hour geofence = 8+2 = 10 hours.
	   
		2.	Then get the ETC of alongside vessels with same berth and add buffer time. 
		 
		3.	The greatest of Geofence + buffer on Incoming vessel and ETC + buffer of Alongside vessel = ETB of Incoming Vessel.
		
		4.	If ETC not available, Geofence + buffer will be ETB.
		
		5.	The requirement for adjusting the ETB based on other Incoming vessels on the same berth will be taken as ERF after go-live.

		For computing Direct Arrival Flag, the system should maintain Geofence + buffer time as internal ETB.

	 */
	public String computeVesselETB(MarineJoblistDetailsDTO currentVessel,
			List<MarineJoblistDetailsDTO> vesselDetailsDTOs,
			List<SysParamDetailDTO> inputParams) {
		LOGGER.debug("[computeVesselETB] Inside the computeVesselETB API for vessel :[ "
				+ currentVessel.getVesselName() + " ]");
		if (currentVessel.getStatus() != null
				&& currentVessel.getStatus().matches(
						"(?i)" + MPCConstants.OPERATING + "|"
								+ MPCConstants.COMPLETED + "|"
								+ MPCConstants.SAILING + "|"
								+ MPCConstants.ALONGSIDE)) {
			LOGGER.debug("[computeVesselETB] Returning ETB as NULL as status is : ["
					+ currentVessel.getVesselName()
					+ "]"
					+ " for vessel : ["
					+ currentVessel.getVesselName() + "]");
			return null;
		}
		Date etbBasedOnGFLocation = null, etbBasedOnAlongsideETC = null, mpcEtb = null;
		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		Integer bufferTime = 0;
		if (inputParams != null) {
			bufferTime = this.getParamBasedOnCategory(inputParams,
					MPCConstants.ETB, MPCConstants.ETB_BUFFER_TIME);
			LOGGER.debug("[computeVesselETB] The given buffer time : ["
					+ bufferTime + "]");
		}
		String alongsideVesselETC = retrieveAlongSideVesselETC(currentVessel,
				vesselDetailsDTOs);

		if (alongsideVesselETC != null && bufferTime != null) {
			Date etc = null;
			try {
				LOGGER.debug("[computeVesselETB] Vessel Alongside ETC is : "
						+ alongsideVesselETC+" ]");
				etc = (Date) sdf.parse(DateUtilities.formatToMPCFormat(alongsideVesselETC));
			} catch (ParseException e) {
				LOGGER.error("[computeVesselETB]"+e.getMessage());
			} catch (Exception e) {
				LOGGER.debug("[computeVesselETB] Exception while parsing alongside Vessel ETC : "+e);
			}
			etbBasedOnAlongsideETC = new Date(etc.getTime()
					+ TimeUnit.HOURS.toMillis(bufferTime));
			LOGGER.debug("[computeVesselETB] ETB based on Alongside ETC is : "
					+ etbBasedOnAlongsideETC+"]");

		}
		if (currentVessel.getVesselLocation() != null
				&& currentVessel.getStatus() != null
				&& currentVessel.getStatus().equalsIgnoreCase(
						MPCConstants.INCOMING)
				&& currentVessel.getVesselLocation().matches(
						"(?i)" + MPCConstants.TWO_HOURS + "|"
								+ MPCConstants.FOUR_HOURS + "|"
								+ MPCConstants.SIX_HOURS + "|"
								+ MPCConstants.EIGHT_HOURS + "|"
								+ MPCConstants.ANCHOR + "|"
								+ MPCConstants.BREAK_WATER_ONE + "|"
								+ MPCConstants.BREAK_WATER_TWO + "|"
								+ MPCConstants.PILOT_STATION_1 + "|"
								+ MPCConstants.PILOT_STATION_2 + "|"
								+ "CHA(.*)")) {
			Date date = new Date();
			try {
				date = DateUtilities.convertUtilDateToMPCFormat(date);
			} catch (ParseException e) {
				LOGGER.error("[computeVesselETB] Exception while converting date to MPC format : "
						+ e.getMessage());
			}
			Integer timeToAdd = 0;
			timeToAdd = computeDistanceForETB(inputParams, currentVessel);
			if (timeToAdd != null) {
				bufferTime += timeToAdd;
				LOGGER.debug("[computeVesselETB] time to add is : [" + timeToAdd
						+ "] for vessel : [" + currentVessel.getVesselName()+"]");
			} else {
				LOGGER.debug("[computeVesselETB] time to add  is null for vessel [: "
						+ currentVessel.getVesselName()
						+ " ]with time to add : ["
						+ timeToAdd
						+ " ]with current location : ["
						+ currentVessel.getVesselLocation()
						+ " ]with current status : [" + currentVessel.getStatus()+"]");
			}
			etbBasedOnGFLocation = new Date(date.getTime()
					+ TimeUnit.HOURS.toMillis(bufferTime));
			LOGGER.debug("[computeVesselETB] etb based on gf location is :["
					+ etbBasedOnGFLocation + "] For Vessel : ["
					+ "] with Time to Add : [" + timeToAdd + "]");
		}

		if (etbBasedOnGFLocation != null && etbBasedOnAlongsideETC != null
				&& etbBasedOnGFLocation.after(etbBasedOnAlongsideETC)) {
			mpcEtb = etbBasedOnGFLocation;
			LOGGER.debug("[computeVesselETB] etb based on gf location is :["
					+ etbBasedOnGFLocation
					+ "] is after etbBasedOnAlongsideETC : ["
					+ etbBasedOnAlongsideETC+"] Hence returning gf based ETB ");
			return sdf.format(mpcEtb);
		} else if (etbBasedOnGFLocation != null
				&& etbBasedOnAlongsideETC != null
				&& etbBasedOnAlongsideETC.after(etbBasedOnGFLocation)) {
			mpcEtb = etbBasedOnAlongsideETC;
			LOGGER.debug("[computeVesselETB] etb based on alongside vessel  is :["
					+ etbBasedOnAlongsideETC
					+ "] is after etbBasedOnGFLocation : ["
					+ etbBasedOnGFLocation+"] Hence returning alongsideETC");
			return sdf.format(mpcEtb);
		}

		if (etbBasedOnGFLocation != null && etbBasedOnAlongsideETC == null) {
			mpcEtb = etbBasedOnGFLocation;
			LOGGER.debug("[computeVesselETB] alongside ETC and GF based ETC is NULL hence setting etb based on GF location");
			return sdf.format(etbBasedOnGFLocation);
		} else {
			return null;
		}
	}

	/**
	 * @param currentVessel
	 * @param vesselDetailsDTOs
	 * @return
	 */
	public String retrieveAlongSideVesselETC(MarineJoblistDetailsDTO currentVessel,
			List<MarineJoblistDetailsDTO> vesselDetailsDTOs) {
		for (MarineJoblistDetailsDTO dto : vesselDetailsDTOs) {

			if ((dto.getStatus() != null)
					&& (dto.getStatus().equalsIgnoreCase(MPCConstants.COMPLETED) || dto
					.getStatus().equalsIgnoreCase(MPCConstants.OPERATING))
					&& isTwoVesselsAssignedWithSameBerth(currentVessel, dto)
					&& (!currentVessel.getRotation().trim()
							.equalsIgnoreCase(dto.getRotation().trim()))) {
				if (dto.getEtc() != null) {
					LOGGER.debug("Alongside Vessels ETC for current Vessel : "
							+ dto.getEtc());
					return dto.getEtc();
				} else {
					if (dto.getEtdDate() != null) {
						LOGGER.debug("Alongside Vessels ETC for current Vessel : "
								+ dto.getEtdDate());
						return dto.getEtdDate();
					}
				}

			}
		}
		LOGGER.debug("along side vessel etc for current vessel is null : ");
		return null;
	}

	public boolean isTwoVesselsAssignedWithSameBerth(MarineJoblistDetailsDTO dtoOne,
			MarineJoblistDetailsDTO dtoTwo) {
		if (dtoOne.getFromBollard() != null && dtoTwo.getFromBollard() != null) {
			String vesselOneFromBollard = dtoOne.getFromBollard();
			String vesselOneBerthUsingFromBollard = vesselOneFromBollard
					.split("\\*")[0];
			String vesselTwoFromBollard = dtoTwo.getFromBollard();
			String vesselTwoBerthUsingFromBollard = vesselTwoFromBollard
					.split("\\*")[0];
			if (vesselOneBerthUsingFromBollard.trim().equalsIgnoreCase(
					vesselTwoBerthUsingFromBollard.trim())) {
				return true;
			}
		}
		if (dtoOne.getToBollard() != null && dtoTwo.getToBollard() != null) {
			String vesselOneToBollard = dtoOne.getToBollard();
			String vesselOneBerthUsingToBollard = vesselOneToBollard.split("\\*")[0];
			String vesselTwoToBollard = dtoTwo.getToBollard();
			String vesselTwoBerthUsingToBollard = vesselTwoToBollard.split("\\*")[0];

			if (vesselOneBerthUsingToBollard
					.equalsIgnoreCase(vesselTwoBerthUsingToBollard)) {
				LOGGER.debug(" vessel one : " + dtoOne.getVesselName()
						+ " is in match with vessel two : "
						+ dtoTwo.getVesselName());
				return true;
			}

		}
		return false;
	}

	public enum VesselStatus {
		ALONGSIDE("ALONGSIDE"), OPERATING("OPERATING"), COMPLETED("COMPLETED"), SHIFTING(
				"SHIFTING"), INCOMING("INCOMING"), ANCHORAGE("ANCHORAGE"), SAILING(
				"SAILING");

		private String value;

		VesselStatus(final String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

		@Override
		public String toString() {
			return this.getValue();
		}
	}

	public String computeETM(MarineJoblistDetailsDTO dto,Integer bufferTime)
			throws ParseException {
		LOGGER.debug("[computeETM] Inside the computETM API for vessel  [: "
				+ dto.getVesselName() + " ]");
		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		String etm = null;
		Date etc = null;
		Date etb = null;
		if (dto != null
				&& dto.getMarineManeuver() != null
				&& dto.getMarineManeuver().equalsIgnoreCase(
						MPCConstants.BERTHING)) {
				if(dto.getNewEtb()!=null&&!dto.getNewEtb().isEmpty()){
					 try {
						etb= (Date)sdf.parse(DateUtilities.formatToMPCFormat(dto.getNewEtb()));
					} catch (Exception e) {
						LOGGER.debug("Exception while parsing MPC ETB : "+e);
					}
				}else if(dto.getEtbDate()!=null && !dto.getEtbDate().isEmpty()){
					LOGGER.debug("vessel Name :"+dto.getVesselName()+" Promis ETB "+dto.getEtbDate());
					String promisEtb =null;
					try {
						promisEtb = DateUtilities.formatToMPCFormat(dto.getEtbDate());
					} catch (Exception e) {
						LOGGER.error("Exception while parsing MPC ETM : "+e);
						
						//e.printStackTrace();
					}
					 etb= (Date)sdf.parse(promisEtb);
				}
			if (etb != null) {
				etm = sdf.format(DateUtils.addHours(etb, -bufferTime));
			}
			LOGGER.debug("[computeETM] The calculated ETM :[ " + etm
					+ " ] with Marine new ETB :[ " + dto.getNewEtb()
					+ "] with Marine Maneuver Status :[ "
					+ dto.getMarineManeuver() + " ] and with bufferTime : ["
					+ bufferTime + "]");
			return etm;
		}

		if (dto != null
				&& dto.getMarineManeuver() != null
				&& dto.getEtc() != null
				&& dto.getMarineManeuver() != null
				&& (dto.getMarineManeuver().equalsIgnoreCase(
						MPCConstants.SHIFTING) || dto.getMarineManeuver()
						.equalsIgnoreCase(MPCConstants.SAILING))
				&& bufferTime != null) {
			try {
				etc = (Date) sdf.parse(DateUtilities.formatToMPCFormat(dto.getEtc()));
			} catch (Exception e) {
				LOGGER.debug("Exception while parsing MPC ETC : "+e);
			}

			etm = sdf.format(etc.getTime()
					+ TimeUnit.HOURS.toMillis(bufferTime));
			LOGGER.debug("[computeETM] The calculated ETM :[ " + etm
					+ " ] with Marine new ETB :[ " + dto.getNewEtb()
					+ "] with Marine Maneuver Status :[ "
					+ dto.getMarineManeuver() + " ] and with bufferTime : ["
					+ bufferTime + "]");
			return etm;
		}
		LOGGER.debug("[computeETM] Returing ETM as NULL ");
		return etm;
	}
	
	public String getParamValue(List<SysParamDetailDTO> sysParamDetailDTO,String paramCategory,String paramGroup,String paramCode)
	{
		//LOGGER.debug("Given TOTAL SYS PARAM SIZE IS : "+sysParamDetailDTO.size());
		for(SysParamDetailDTO dto:sysParamDetailDTO)
		{
		//	LOGGER.debug("Given curernt sysParam : "+dto);
			
			if (dto.getMspParamCatg() != null 
					&& dto.getMspParamGroup() != null
					&& dto.getMspParamCode() != null 
					&& dto.getMspParamCatg().trim().equalsIgnoreCase(paramCategory.trim())
					&& dto.getMspParamGroup().trim().equalsIgnoreCase(paramGroup.trim())
					&& dto.getMspParamCode().trim().equalsIgnoreCase(paramCode.trim()))
			{
				LOGGER.debug("For Given Param Category :"+paramCategory+" and Param Group :"+paramGroup+" and Param Code : "+paramCode+" the value is : "+dto.getMspVal1());
				return dto.getMspVal1();
			}
		}
		LOGGER.debug("For Given Param Category :"+paramCategory+" and Param Group :"+paramGroup+" and Param Code : "+paramGroup+" there is no valued configured !!");
		return null;
	}

/*	Possible Values are  Berthing, Shifting, Sailing
	Assumption: Maneuver data required when the vessel hits 8hour geofence

	If Vessel Status = ‘INCOMING’ 
	1.	Get MPC ETB of the Vessel
	a.	If MPC ETB is not found, get AIS ETA
	b.	If AIS ETA not found, get PROMIS ETB
	c.	If PROMIS ETB not found, get AGENT ETA
	2.	Get time difference between Current Time and ETB
	3.	If time difference is less than x hours (8 hours), Marine Maneuver = BERTHING
	4.	If time difference is more than x hours (8 hours), Marine Maneuver = BLANK

	If Vessel Status in ‘SAILING’, ‘SHIFTING’
	1.	Get DUAL_FLAG of the Vessel
	2.	Get ETC of the Vessel
	3.	If ETC is not available get AGENT_ETD 
	4.	Get x hours (from MPC_SYS_PARAMS)
	5.	Deduct x hours from ETC
	6.	Get time difference between CURRENT TIME and adjusted ETC
	7.	If time difference is less than y hours (6 hours) and DUAL_FLAG = N, MARINE_MANEUVER = SAILING
	8.	If time difference is less than y hours (6 hours) and DUAL_FLAG = Y, MARINE_MANEUVER = SHIFTING
	9.	If time difference is more than y hours (6 hours), Marine Maneuver = BLANK

	Note : X and Y are two different parameters and   must retrieve from database.

	X should be separately configured for MARINE MANEUVER.*/

	public String computeMarineManeuver(List<MarineJoblistDetailsDTO> list,
			MarineJoblistDetailsDTO dto,
 Map<String, String> codeMap,
			List<SysParamDetailDTO> sysParamDetailDTO) throws ParseException {
		LOGGER.debug("[computeMarineManeuver] : inside computeMarineManeuver for vessel : "
				+ dto.getVesselName());
		if (dto.getStatus().equalsIgnoreCase(MPCConstants.INCOMING)
				&& dto.getVesselLocation() != null
				&& !dto.getVesselLocation().matches(
						"(?i)" + "8HRS" + "|" + "6HRS" + "|" + "4HRS" + "|"
								+ "CHA" + "|"	+ "2HRS" + "|" + "P_S_ONE(.*)" + "|"
								+ "P_S_TWO(.*)" + "|" + "BREAK(.*)" + "|"
								+ "CHAR(.*)" + "|" + "PILOT(.*)" + "T1(.*)"
								+ "|" + "T2(.*)" +"|" + "ANCH(.*)"+ "|" + "T3(.*)" + "|"
								+ "T4(.*)")) {

			LOGGER.debug("[computeMarineManeuver] : Returning NULL as the result for vessel : "
					+ dto.getVesselName()
					+ " with location :"
					+ dto.getVesselLocation()
					+ " with status : "
					+ dto.getStatus());

			return null;
		}
		Integer bufferTimeForIncoming = null;
		Integer bufferTimeForSailOrShiftForDeductedEtc = null;
		Integer bufferTimeForSailOrShiftDiff = null;
		if (this.getParamValue(sysParamDetailDTO, MPCConstants.BUFFER_PARAMS,
				MPCConstants.MNU_ETB, MPCConstants.TIMEDIFF) != null) {
			bufferTimeForIncoming = Integer.parseInt(this.getParamValue(
					sysParamDetailDTO, MPCConstants.BUFFER_PARAMS,
					MPCConstants.MNU_ETB, MPCConstants.TIMEDIFF));
		}
		if (this.getParamValue(sysParamDetailDTO, MPCConstants.BUFFER_PARAMS,
				MPCConstants.MNU_ETC, MPCConstants.ADJ_ETC) != null) {
			bufferTimeForSailOrShiftForDeductedEtc = Integer.parseInt(this
					.getParamValue(sysParamDetailDTO,
							MPCConstants.BUFFER_PARAMS, MPCConstants.MNU_ETC,
							MPCConstants.ADJ_ETC));
		}
		if (this.getParamValue(sysParamDetailDTO, MPCConstants.BUFFER_PARAMS,
				MPCConstants.MNU_ETC, MPCConstants.TIMEDIFF) != null) {
			bufferTimeForSailOrShiftDiff = Integer.parseInt(this.getParamValue(
					sysParamDetailDTO, MPCConstants.BUFFER_PARAMS,
					MPCConstants.MNU_ETC, MPCConstants.TIMEDIFF));
		}

		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		Date calculatedEtb = null;
		Date currentDate = new Date();
		currentDate = DateUtilities.convertUtilDateToMPCFormat(currentDate);

		// System will consider MPC ETB first,
		if (dto != null && dto.getNewEtb() != null) {
			LOGGER.debug("[computeMarineManeuver] : dto.getNewEtb() : "
					+ dto.getNewEtb());
			try {
				calculatedEtb = (Date) sdf.parse(DateUtilities.formatToMPCFormat(dto.getNewEtb()));
			} catch (Exception e) {
				LOGGER.error("[computeMarineManeuver] : Exception while parsing MPC ETB : "+e);
			}
			LOGGER.debug("[computeMarineManeuver] : Caluculated Maneuver MPC ETB :  "
					+ calculatedEtb + " is for vessel : " + dto.getVesselName());
		}
		// take AIS eta if MPC ETB is null
		else if (dto != null && dto.getAisEta() != null) {
			LOGGER.debug("[computeMarineManeuver] : dto.getAisEta() :"
					+ dto.getAisEta());
			try {
				calculatedEtb = (Date) sdf.parse(DateUtilities.formatToMPCFormat(dto.getAisEta()));
			} catch (Exception e) {
				LOGGER.error("[computeMarineManeuver] : Exception while parsing AIS ETA : "+e);
			}
			LOGGER.debug("[computeMarineManeuver] : MPC ETB is NULL Hence chosen Maneuver ETB as per AIS :  "
					+ calculatedEtb + " is for vessel : " + dto.getVesselName());
		}
		// if MPC ETB not available then PROMIS ETB,
		else if (dto != null && dto.getEtbDate() != null) {
			LOGGER.debug("[computeMarineManeuver] : dto.getEtbDate() : "
					+ dto.getEtbDate());
			try {
				calculatedEtb = (Date) sdf.parse(DateUtilities.formatToMPCFormat(dto.getEtbDate()));
			} catch (Exception e) {
				LOGGER.error("[computeMarineManeuver] : Exception while parsing promis ETB : "+e);
			}
			LOGGER.debug("MPC ETB and AIS Etb is NULL Hence chosen Maneuver ETB as per PROMIS :  "
					+ calculatedEtb + " is for vessel : " + dto.getVesselName());
		}
		// if MPC ETB and BPA ETB not available then Agents ETA as per Berth
		// Booking.
		else if (dto != null && dto.getEtaDate() != null) {
			LOGGER.debug("[computeMarineManeuver] : dto.getEtaDate() : "
					+ dto.getEtaDate());
			LOGGER.debug("[computeMarineManeuver] :  MPC ETB and AIS Etb and Promis ETB is NULL Hence chosen Maneuver ETB as per Agents ETA : "
					+ dto.getEtaDate()
					+ " is for vessel : "
					+ dto.getVesselName());
			try {
				calculatedEtb = (Date) sdf.parse(DateUtilities.formatToMPCFormat(dto.getEtaDate()));
			} catch (Exception e) {
				LOGGER.error("[computeMarineManeuver] : Exception while parsing Agent ETA : "+e);
			}
		}
		if (calculatedEtb != null)
			LOGGER.debug("[computeMarineManeuver] :  ETB Date after Maneuver Computation for Vessel : "
					+ dto.getVesselName()
					+ " ETB : ["
					+ calculatedEtb
					+ " ] Status : [" + dto.getStatus()+"]");
		else {
			LOGGER.debug("[computeMarineManeuver] :  calculated etb is null in maneuver is null for vessel :[ "
					+ dto.getVesselName()
					+ "] and the status is [: "
					+ dto.getStatus()+"]");
		}

		LOGGER.debug("[computeMarineManeuver] :   Maneuver Computation Current Time : "
				+ currentDate.getTime());
		LOGGER.debug(" [computeMarineManeuver] :  Maneuver Computation calculatedEtb Time : "
				+ calculatedEtb.getTime());

		if (calculatedEtb != null && bufferTimeForIncoming != null)
			LOGGER.debug("[computeMarineManeuver] :  Maneuver exression ->    for vessel : ["
					+ dto.getVesselName()
					+ "] is : ["
					+ TimeUnit.MILLISECONDS.toHours(Math.abs(calculatedEtb
							.getTime() - currentDate.getTime()))
					+ " <= "
					+ bufferTimeForIncoming
					+ " is : "
					+ (TimeUnit.MILLISECONDS.toHours(Math.abs(calculatedEtb
							.getTime() - currentDate.getTime())) <= bufferTimeForIncoming)
					+ "]");

		if (dto.getStatus() != null
				&& calculatedEtb != null
				&& bufferTimeForIncoming != null
				&& dto.getStatus().equalsIgnoreCase(
						codeMap.get(MPCConstants.INCOMING))
				&& TimeUnit.MILLISECONDS.toHours(Math.abs(calculatedEtb
						.getTime() - currentDate.getTime())) <= bufferTimeForIncoming) {
			LOGGER.debug("[computeMarineManeuver] :  Calculated Marine Maneuver is : ["
					+ MPCConstants.BERTHING
					+ "] with calculateEtb : ["
					+ calculatedEtb
					+ "] bufferTimeForIncoming :["
					+ bufferTimeForIncoming
					+ "] with status : ["
					+ dto.getStatus()
					+ "] with time difference of calculated Etb and current time : ["
					+ TimeUnit.MILLISECONDS.toHours(Math.abs(calculatedEtb
							.getTime() - currentDate.getTime()))+"]");
			return MPCConstants.BERTHING;

		} else
			LOGGER.debug("[computeMarineManeuver] :  Berthing logic not match  for vessel : ["
					+dto.getVesselName()
					+ "] with calculateEtb [: "
					+ calculatedEtb
					+ "] bufferTimeForIncoming :["
					+ bufferTimeForIncoming
					+ "] with status : ["
					+ dto.getStatus()
					+ "] with time difference of calculated Etb and current time : ["
					+ TimeUnit.MILLISECONDS.toHours(Math.abs(calculatedEtb
							.getTime() - currentDate.getTime()))+"]");
		Date vesselEtc = null;
		Date deductedEtc = null;
		try {
			if (dto.getEtc() != null)
				vesselEtc = DateUtilities.formatDate(dto.getEtc());
			else if (dto.getEtdDate() != null) {
				vesselEtc = DateUtilities.formatDate(dto.getEtdDate());
			}
		} catch (Exception e) {
			LOGGER.error("[computeMarineManeuver] :  Invalid Eta date format Issue with vessel : "
					+ dto.getVesselName() + " : " + e.getMessage());
		}
		if (bufferTimeForSailOrShiftForDeductedEtc != null && vesselEtc != null) {
			Integer buffer = -bufferTimeForSailOrShiftForDeductedEtc;
			deductedEtc = DateUtils.addHours(vesselEtc, buffer);
			LOGGER.debug("[computeMarineManeuver] :  Actual ETC : " + vesselEtc
					+ " Deducted ETC " + deductedEtc + " for Vessel : "
					+ dto.getVesselName() + " with buffer time : " + buffer);
		}

		Long timeDiff = null;
		Date currentTime = new Date();
		currentTime = DateUtilities.convertUtilDateToMPCFormat(currentTime);
		if (deductedEtc != null) {
			timeDiff = TimeUnit.MILLISECONDS.toHours(Math.abs(deductedEtc
					.getTime() - currentTime.getTime()));
			LOGGER.debug("[computeMarineManeuver] :  Time Difference for vessel : "
					+ dto.getVesselName()
					+ " is : "
					+ timeDiff
					+ " and the bufferTimeForSailOrShiftDiff : "
					+ bufferTimeForSailOrShiftDiff);
		}

		if (dto.getStatus() != null
				&& (!dto.getStatus().equalsIgnoreCase(
						codeMap.get(MPCConstants.INCOMING)))
				&& dto.getDualBerth() != null
				&& bufferTimeForSailOrShiftDiff != null
				&& dto.getDualBerth().equalsIgnoreCase("Y") && timeDiff != null
				&& timeDiff < bufferTimeForSailOrShiftDiff) {
			LOGGER.debug("[computeMarineManeuver] :  Matching  with shifting logic [:"
					+ dto.getVesselName()
					+ "] with status :["
					+ dto.getStatus()
					+ "] with DualBerth : ["
					+ dto.getDualBerth()
					+ "] with bufferTimeForSailOrShiftDiff :["
					+ bufferTimeForSailOrShiftDiff
					+ " ] with timeDiff : ["
					+ timeDiff+"]");
			return codeMap.get(MPCConstants.SHIFTING);
		} else {
			LOGGER.debug("[computeMarineManeuver] :  not matching  with shifting logic :["
					+ dto.getVesselName()
					+ "] with status :["
					+ dto.getStatus()
					+ "] with DualBerth :[ "
					+ dto.getDualBerth()
					+ "] with bufferTimeForSailOrShiftDiff :["
					+ bufferTimeForSailOrShiftDiff
					+ "] with timeDiff : ["
					+ timeDiff+"]");
		}
		if (dto.getStatus() != null
				&& bufferTimeForSailOrShiftDiff != null
				&& (!dto.getStatus().equalsIgnoreCase(
						codeMap.get(MPCConstants.INCOMING)))
				&& dto.getDualBerth() != null
				&& dto.getDualBerth().equalsIgnoreCase("N") && timeDiff != null
				&& timeDiff < bufferTimeForSailOrShiftDiff) {
			LOGGER.debug("[computeMarineManeuver] : Matching  with sailing logic :["
					+ dto.getVesselName()
					+ "] with status :["
					+ dto.getStatus()
					+ "] with DualBerth : ["
					+ dto.getDualBerth()
					+ "] with bufferTimeForSailOrShiftDiff :["
					+ bufferTimeForSailOrShiftDiff
					+ "] with timeDiff : ["
					+ timeDiff);
			return codeMap.get(MPCConstants.SAILING);
		} else {
			LOGGER.debug("[computeMarineManeuver] :  not matching  with sailing logic :["
					+ dto.getVesselName()
					+ "] with status :["
					+ dto.getStatus()
					+ "] with DualBerth : ["
					+ dto.getDualBerth()
					+ "] with bufferTimeForSailOrShiftDiff :["
					+ bufferTimeForSailOrShiftDiff
					+ " ]with timeDiff : ["
					+ timeDiff+"]");
		}
		return null;

	}
	
	

	public String computeMarineManeuverStatus(List<MarineJoblistDetailsDTO> dtoList,
			MarineJoblistDetailsDTO dto, Map<String, String> codeMap,
			List<PilotVesselDataDTO> pilotDtoList ,Integer bufferTime) {
		
		String status = null;
		if (dto.getMarineManeuver() == null) {
			return status;
		}
		if(MPCConstants.BERTHING.equalsIgnoreCase(dto.getMarineManeuver())){
			String rotn = dto.getRotation();
			Client c = Client.create();
			Gson gson = new Gson();
			WebResource resource = null;
			String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);

			resource = c.resource(url + "getTimeDetails" + "?rotationNumber="
					+ rotn);

			String response = resource.get(String.class);
			List<TimeDetails> list = gson.fromJson(response,
					new TypeToken<List<TimeDetails>>() {
					}.getType());
			
			if (list != null) {
				Date currentDate = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat(
						MPCConstants.DATETIME_FORMAT_DD_MM_YYYY_HH_MM_SS);
				if (MPCConstants.ANCHOR.equalsIgnoreCase(dto
						.getVesselLocation())) {
					for (TimeDetails timeDetails : list) {
						if (timeDetails != null) {
							String heaveUpTime = timeDetails
									.getHeaveupNoticeTime();
							if (heaveUpTime != null) {
								try {
									currentDate=DateUtilities.convertUtilDateToMPCFormat(currentDate);
									Date heaveUpTimeDate = sdf
											.parse(heaveUpTime);
									if (heaveUpTimeDate.getTime() <= currentDate
											.getTime()) {
										return MPCConstants.IMMINENT;
									}
								} catch (ParseException e) {
									LOGGER.error(e.getMessage());
								}
							}
						}
					}
				}

				if ("Y".equalsIgnoreCase(dto
						.getVesselArrivalDirectOrAnchorage())) {
					for (TimeDetails timeDetails : list) {
						if (timeDetails != null) {
							String portArrivalDate = timeDetails
									.getPortArrivalDate();
							if (portArrivalDate != null) {
								try {
									Date portArrivalDateVal = sdf
											.parse(portArrivalDate);
									currentDate=DateUtilities.convertUtilDateToMPCFormat(currentDate);
									if (portArrivalDateVal.getTime() <= currentDate
											.getTime()) {
										return MPCConstants.IMMINENT;
									}
								} catch (ParseException e) {
									LOGGER.error(e.getMessage());
								}
							}
						}
					}
				}

			}
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		String etc = dto.getEtc();
		Date currentDate = new Date();

		String etcmpc = null;
		Date etcDate = null;

		if (etc != null) {
			try {
				currentDate = DateUtilities
						.convertUtilDateToMPCFormat(currentDate);
				etcmpc = DateUtilities.formatToMPCFormat(etc);
				etcDate = sdf.parse(etcmpc);
			} catch (ParseException e) {
				LOGGER.error(e.getMessage());
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			
			long diffInMillies = Math.abs(etcDate.getTime()
					- currentDate.getTime());
			long bufferInMillis = TimeUnit.HOURS.toMillis(bufferTime);

			if ((dto.getMarineManeuver().equalsIgnoreCase(MPCConstants.SAILING) || dto
					.getMarineManeuver()
					.equalsIgnoreCase(MPCConstants.SHIFTING))
					&& diffInMillies <= bufferInMillis) {
				return MPCConstants.IMMINENT;
			}else{
				status = MPCConstants.IN_PROGRESS;
			}
		}else{
			status = MPCConstants.IN_PROGRESS;
		}
		
		if (pilotDtoList != null && !pilotDtoList.isEmpty()) {
			for (PilotVesselDataDTO dtoObj : pilotDtoList) {
				LOGGER.debug("input pilot dispatch dto is : "+dtoObj);
				if(dtoObj.getVesselName() !=null)
					LOGGER.debug("pilot dispatch dto's vessel name : "+dtoObj.getVesselName()+" with the rotation : "+dtoObj.getRotationNo());
				if (dtoObj != null && dtoObj.getVesselName()!= null && dtoObj.getVesselName().equalsIgnoreCase(dto.getVesselName()) 
						&& dtoObj.getDispatchTime() != null) {
					return MPCConstants.DISPATCHED;

				}else{
					return MPCConstants.IN_PROGRESS;
				}
			}
		}
		
		return status;
	}
			
			
			
		
		


	public String isVesselArrivalDirectOnBerth(MarineJoblistDetailsDTO vesselDtoOne,
			List<MarineJoblistDetailsDTO> vesselDtoList,List<SysParamDetailDTO> inputParams) {
		if (MPCConstants.ANCHOR.equalsIgnoreCase(vesselDtoOne
				.getVesselLocation())) {
			return "N";
		}
		for (MarineJoblistDetailsDTO vesselDtoTwo : vesselDtoList) {
			if (isTwoVesselsAssignedWithSameBerth(vesselDtoOne, vesselDtoTwo)) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat();
					sdf.applyPattern(DATE_TIME_FORMAT);
					String vDtoOneEtb = vesselDtoOne.getEtb();
					String vDtoTwoEtc = vesselDtoTwo.getEtc();
						if ((vDtoOneEtb != null && !vDtoOneEtb.trim().isEmpty())
								&& (vDtoTwoEtc != null && !vDtoTwoEtc.trim().isEmpty())) {
							Date vesselDtoOneEtb = sdf.parse(vesselDtoOne.getEtb());
							Date vesselDtoTwoEtc = sdf.parse(vesselDtoTwo.getEtc());
							Integer bufferTime = 0;
							if (inputParams != null
									) {
								bufferTime = this.getParamBasedOnCategory(inputParams, MPCConstants.DA, MPCConstants.DA_BUFFER_TIME);
							}
							bufferTime = bufferTime != null ? bufferTime : 0;
							Date vesselDtoOneEtbWithBuffer = DateUtils.addHours(vesselDtoOneEtb, bufferTime);
							
							if (vesselDtoOneEtbWithBuffer.before(vesselDtoTwoEtc)){
								return "N";
							} else {
								return "Y";
							}

						}
					
				} catch (ParseException p) {
					LOGGER.error(p.getMessage());
				}
			
			}
		}
		return "Y";
	}

	

	/**
	 * @param vesselDetailsDTO
	 * @return
	 */
	public String computeVesselStatus(MarineJoblistDetailsDTO vesselDetailsDTO) {
		SimpleDateFormat sdf = new SimpleDateFormat(
				MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
		Date date = new Date();
		Date berthTime = null;
		String status = null;
		LOGGER.debug("Inside the compute vessel status API for vessel :"
				+ vesselDetailsDTO.getVesselName());
		try {
			date = DateUtilities.convertUtilDateToMPCFormat(date);
			String mpcDateFormat = null;
			if (vesselDetailsDTO != null
					&& vesselDetailsDTO.getBerthDate() != null
					&& DateUtilities.formatToMPCFormat(vesselDetailsDTO
							.getBerthDate()) != null) {
				mpcDateFormat = DateUtilities
						.formatToMPCFormat(vesselDetailsDTO.getBerthDate());
			}
			if (mpcDateFormat != null) {
				berthTime = sdf.parse(mpcDateFormat);
				LOGGER.debug("Berth Date  for vessel : "
						+ vesselDetailsDTO.getVesselName() + " is : "
						+ berthTime);
			}
		} catch (ParseException e1) {
			LOGGER.error("Error while parsing the berth date : "
					+ e1.getMessage());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			LOGGER.error("Error while parsing  date : "
					+ e1.getMessage());
		}
		String sailDate = null;
		if (vesselDetailsDTO.getSailDate() != null) {
			sailDate = vesselDetailsDTO.getSailDate();
			LOGGER.debug("Sail Date for vessel : "
					+ vesselDetailsDTO.getVesselName() + " is : " + sailDate);
		}
		String dualcall = null;
		if (vesselDetailsDTO.getDualBerth() != null)
			dualcall = vesselDetailsDTO.getDualBerth();
		Date etcDateFromDB = null;
		String expectedTimeOfComplete = null;
		Long movesToGo = null;
		Long doneMoves = null;
		if (sailDate != null) {
			status = VesselStatus.SAILING.getValue();
			LOGGER.debug("Vessel Status is  : " + status);
			return status;
		}
		if (berthTime != null) {
			if (vesselDetailsDTO.getTtMTG() != null) {
				movesToGo = vesselDetailsDTO.getTtMTG();
			} else {
				movesToGo = 0L;
			}

			if (vesselDetailsDTO.getDoneMoves() != null) {
				doneMoves = vesselDetailsDTO.getDoneMoves();
			} else {
				doneMoves = 0L;
			}

			if (vesselDetailsDTO.getEtc() != null) {
				expectedTimeOfComplete = vesselDetailsDTO.getEtc();
			}
			try {
				if (expectedTimeOfComplete != null
						&& DateUtilities
								.formatToMPCFormat(expectedTimeOfComplete) != null)
					etcDateFromDB = (Date) sdf.parse(DateUtilities
							.formatToMPCFormat(expectedTimeOfComplete));
			} catch (ParseException e) {
				LOGGER.error(e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Error while parsing etc in compute vessel status API "
						+ e.getMessage());
			}
			if (doneMoves != null && movesToGo != null && doneMoves > 0
					&& movesToGo > 0) {
				status = VesselStatus.OPERATING.getValue();
				return status;
			}
			if (dualcall != null && dualcall.equalsIgnoreCase("Y")
					&& movesToGo != null && movesToGo < 1) {
				status = VesselStatus.SHIFTING.getValue();
				return status;
			}
			if (movesToGo != null
					&& movesToGo < 1
					|| (etcDateFromDB != null && etcDateFromDB.compareTo(date) < 0)) {
				status = VesselStatus.COMPLETED.getValue();
				return status;
			}
			if (doneMoves != null
					&& doneMoves < 1
					|| vesselDetailsDTO.getVesselLocation() != null
					&& vesselDetailsDTO.getVesselLocation().matches(
							"(?i)" + "T1Q(.*)" + "|" + "T2Q(.*)" + "|"
									+ "T3Q(.*)")) {
				status = VesselStatus.ALONGSIDE.getValue();
				return status;
			}
		} else {
			status = MPCConstants.INCOMING;
			//if(vesselDetailsDTO.getAisEta())
			
			LOGGER.debug("Setting status as : " + status);
			return status;
		}
		status = MPCConstants.INCOMING;
		return status;
	}

	/**
	 * @param status
	 * @return
	 */
	public String returnStatus(String status) {
		return status;
	}

	/**
	 * @param geofenceMasterData
	 * @param vesslatitude
	 * @param vessLongitude
	 * @return
	 */
	public String getVesselGeoLocation(
			Map<String, List<GeoFenceData>> geofenceMasterData,
			Double vesslatitude, Double vessLongitude) {

		List<GeoFenceData> geofenceData = new ArrayList<GeoFenceData>();

		Iterator<Entry<String, List<GeoFenceData>>> it = geofenceMasterData
				.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, List<GeoFenceData>> pair = (Map.Entry<String, List<GeoFenceData>>) it
					.next();
			geofenceData.addAll((List<GeoFenceData>) pair.getValue());
		}
		String[] geoCodeArray = { TWO_HOURS, FOUR_HOURS, SIX_HOURS,
				EIGHT_HOURS, PILOT_STATION_1, PILOT_STATION_2, BREAK_WATER_ONE,
				BREAK_WATER_TWO, ANCHORAGE_COORDINATE_ONE,
				ANCHORAGE_COORDINATE_TWO, ANCHORAGE_COORDINATE_THREE,
				ANCHORAGE_COORDINATE_FOUR };

		for (GeoFenceData data : geofenceData) {
			if (Arrays.asList(geoCodeArray).contains(data.getGeoCode())) {
				Double distance = VesselLocationCalculator.computeGeoDistance(
						data.getLat(), data.getLng(), vesslatitude,
						vessLongitude);
				if (distance >= 80) {
					return HIGH_SEA;
				}
				if (distance < 80 && distance > 60) {
					return EIGHT_HOURS;
				}
				if (distance <= 60 && distance > 40) {
					return SIX_HOURS;
				}
				if (distance <= 40 && distance > 20) {
					return FOUR_HOURS;
				}
				if (distance <= 20 && distance > 4.3) {
					return TWO_HOURS;
				}
				if (VesselLocationCalculator.isVesselExistInAnchorage(
						geofenceData, vesslatitude, vessLongitude)) {
					return ANCHOR;
				}
				if (VesselLocationCalculator.isVesselExistInBreakWater(
						geofenceData, vesslatitude, vessLongitude)) {
					return BREAK_WATER;
				}
				if (distance <= 1.5) {
					return PILOT_STATION_1;
				}
				if (distance <= 4.3) {
					return PILOT_STATION_2;
				}

			}
		}
		return null;
	}

	/**
	 * @param vesselDtoOne
	 * @param vesselDtoList
	 * @return
	 * @throws ParseException
	 */
	public String computeSwapValue(MarineJoblistDetailsDTO vesselDtoOne,
			List<MarineJoblistDetailsDTO> vesselDtoList) throws ParseException {
		String swapValue = EMPTY_STRING;
		for (MarineJoblistDetailsDTO vesselDtoTwo : vesselDtoList) {
			if (((vesselDtoOne.getVesselName() != null && vesselDtoTwo
					.getVesselName() != null) && !vesselDtoOne.getVesselName()
					.equalsIgnoreCase(vesselDtoTwo.getVesselName()))) {
				if (isTwoVesselsAssignedWithSameBerth(vesselDtoOne,
						vesselDtoTwo)) {
					/* && vesselDtoTwoEtc.before(vesselDtoOneEtb) */// commented
																	// on 17th
																	// April
																	// 2017

					swapValue = vesselDtoTwo.getRotation();
					return swapValue;
				}
			}
		}
		return swapValue;
	}

	/**
	 * @param vesselDtoOne
	 * @param vesselDtoList
	 * @return
	 * @throws ParseException
	 */
	public String computeSwapValueMarineWorkOrderList(MarineJoblistDetailsDTO vesselDtoOne,
			List<MarineJoblistDetailsDTO> vesselDtoList,List<SysParamDetailDTO> inputParams) throws ParseException {
		String swapValue =   EMPTY_STRING;
		String dtoOneStatus = vesselDtoOne.getMarineManeuver();
		if(MPCConstants.BERTHING.equalsIgnoreCase(dtoOneStatus) || MPCConstants.SHIFTING.equalsIgnoreCase(dtoOneStatus)){
		for (MarineJoblistDetailsDTO vesselDtoTwo : vesselDtoList) {
			SimpleDateFormat sdf = new SimpleDateFormat();
			sdf.applyPattern(MPCConstants.DATETIME_FORMAT_DD_MMM_YYYY_HH_MM);
			String vDtoOneEtm = vesselDtoOne.getEtm();
			String vDtoTwoEtm = vesselDtoTwo.getEtm();
			String dtoTwoStatus = vesselDtoTwo.getMarineManeuver();
			if(MPCConstants.SAILING.equalsIgnoreCase(dtoTwoStatus)||MPCConstants.SHIFTING.equalsIgnoreCase(dtoTwoStatus)){
			if (((vesselDtoOne.getVesselName() != null && vesselDtoTwo
					.getVesselName() != null) && !vesselDtoOne.getVesselName()
					.equalsIgnoreCase(vesselDtoTwo.getVesselName()))) {
				if ((vDtoOneEtm != null && !vDtoOneEtm.trim().isEmpty())
						&& (vDtoTwoEtm != null && !vDtoTwoEtm.trim().isEmpty())) {
					Date vesselDtoOneEtm = sdf.parse(vDtoOneEtm);
					Date vesselDtoTwoEtm = sdf.parse(vDtoTwoEtm);
					long diffInMillies = Math.abs(vesselDtoOneEtm.getTime() - vesselDtoTwoEtm.getTime());
					long diffinMinutes= TimeUnit.MILLISECONDS.toMinutes(diffInMillies);
					Integer bufferTime = 0;
					if (inputParams != null
							) {
						bufferTime = this.getParamBasedOnCategory(inputParams, MPCConstants.SWAP, MPCConstants.SWAP_BUFFER_TIME);
					}
					bufferTime = bufferTime != null && bufferTime!=0 ? bufferTime : 1;
				if (isTwoVesselsAssignedWithSameBerth(vesselDtoOne,vesselDtoTwo) && diffinMinutes <=(bufferTime*60)){
					swapValue = String.valueOf(vesselDtoTwo.getOrder());
					return swapValue;
				}
				}
			
			}
		}
		}
		}
		return swapValue;
	}

	public void currentNextLocation(MarineJoblistDetailsDTO vesselDto,
			List<MarineJoblistDetailsDTO> vesselDtoList,List<SysParamDetailDTO> sysParamsList) {
		if (vesselDto.getVesselLocation() != null
				&& !vesselDto.getVesselLocation().trim().isEmpty()) {
			String[] arr = { "T1Q1", "T1Q2", "T1Q3", "T1Q4", "T1Q5", "T1Q6",
					"T1Q7", "T2Q1", "T3Q1" };
			String fromBollard = vesselDto.getFromBollard();
			String vLocation = fromBollard != null ? fromBollard.split("/")[0]
					: MPCConstants.EMPTY_STRING;
			switch (vesselDto.getVesselLocation()) {
			case HIGH_SEA:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				vesselDto.setNextLocation(EIGHT_HOURS);
				break;
			case EIGHT_HOURS:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				vesselDto.setNextLocation(SIX_HOURS);
				break;
			case SIX_HOURS:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				vesselDto.setNextLocation(FOUR_HOURS);
				break;
			case FOUR_HOURS:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				boolean flag = vesselPostion(vesselDto, vesselDtoList,sysParamsList);
				if(flag){
					vesselDto.setNextLocation(TWO_HOURS);
				}else{
					vesselDto.setNextLocation(ANCHOR);
				}
				break;
			case TWO_HOURS:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				vesselDto.setNextLocation(vLocation);
				break;
			case ANCHOR:
				vesselDto.setCurrLocation(vesselDto.getVesselLocation());
				vesselDto.setNextLocation(vLocation);
				break;
			default:
				if (Arrays.asList(arr).contains(vesselDto.getVesselLocation())) {
					vesselDto.setCurrLocation(vLocation);
					String dualBerth = vesselDto.getDualBerth();
					if (dualBerth != null && !dualBerth.trim().isEmpty()) {
						if ("Y".equalsIgnoreCase(dualBerth))
							vesselPositionForBerthedVessel(vesselDto);
					} else {
						vesselDto.setNextLocation(TWO_HOURS);
					}
				}
				break;
			}
		}

	}

	private void vesselPositionForBerthedVessel(MarineJoblistDetailsDTO vesselDtoOne) {
		String terminalId = vesselDtoOne.getTerminalId();
		String rotationNumber = vesselDtoOne.getRotation();
		Map<String, Integer> terminalVisitSeq = new HashMap<>();
		Map<Integer, String> visitSeqTerminal = new HashMap<>();
		Client c = Client.create();
		Gson gson = new Gson();
		WebResource resource = null;
		String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);

		resource = c.resource(url + "cbbsData" + "?rotationNumber="
				+ rotationNumber);

		String response = resource.get(String.class);
		List<MarineJoblistDetailsDTO> list = gson.fromJson("[" + response + "]",
				new TypeToken<List<MarineJoblistDetailsDTO>>() {
				}.getType());
		if (list != null && !list.isEmpty()) {
			for (MarineJoblistDetailsDTO dto : list) {
				List<TerminalVisit> terminalVisitList = dto
						.getTerminalVisitList();
				if (terminalVisitList != null && !terminalVisitList.isEmpty()) {
					for (TerminalVisit terminalVisit : terminalVisitList) {
						String visitTerminalId = terminalVisit.getTerminal();
						if (terminalId != null && visitTerminalId != null) {
							terminalVisitSeq.put(visitTerminalId,
									terminalVisit.getVisitSeq());
							visitSeqTerminal.put(terminalVisit.getVisitSeq(),
									visitTerminalId);
						}
					}
				}
			}
		}
		if (terminalVisitSeq.get(terminalId) != null) {
			int visitSeq = terminalVisitSeq.get(terminalId);
			String nextTerminal = visitSeqTerminal.get((visitSeq + 1));
			if (nextTerminal != null && !nextTerminal.isEmpty()) {
				vesselDtoOne.setNextLocation(nextTerminal);
			} else {
				vesselDtoOne.setNextLocation(TWO_HOURS);
			}
		} else {
			vesselDtoOne.setNextLocation(TWO_HOURS);
		}
	}

	private boolean vesselPostion(MarineJoblistDetailsDTO vesselDtoOne,
			List<MarineJoblistDetailsDTO> vesselDtoList,List<SysParamDetailDTO> inputParams) {
		for (MarineJoblistDetailsDTO vesselDtoTwo : vesselDtoList) {
			if (isTwoVesselsAssignedWithSameBerth(vesselDtoOne, vesselDtoTwo)) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat();
					sdf.applyPattern(DATE_TIME_FORMAT);
					String vDtoOneEtb = vesselDtoOne.getEtb();
					String vDtoTwoEtc = vesselDtoTwo.getEtc();
						if ((vDtoOneEtb != null && !vDtoOneEtb.trim().isEmpty())
								&& (vDtoTwoEtc != null && !vDtoTwoEtc.trim().isEmpty())) {
							Date vesselDtoOneEtb = sdf.parse(vesselDtoOne.getEtb());
							Date vesselDtoTwoEtc = sdf.parse(vesselDtoTwo.getEtc());
							Integer bufferTime = 0;
							if (inputParams != null
									) {
								bufferTime = this.getParamBasedOnCategory(inputParams, MPCConstants.DA, MPCConstants.DA_BUFFER_TIME);
							}
							bufferTime = bufferTime != null ? bufferTime : 0;
							Date vesselDtoOneEtbWithBuffer = DateUtils.addHours(vesselDtoOneEtb, bufferTime);
							
							if (vesselDtoOneEtbWithBuffer.before(vesselDtoTwoEtc)){
								return false;
							} else {
								return true;
							}

						}
					
				} catch (ParseException p) {
					LOGGER.error(p.getMessage());
				}
			
			}
		}
		return true;
	}

}
