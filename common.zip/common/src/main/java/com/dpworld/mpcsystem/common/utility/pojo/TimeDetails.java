
package com.dpworld.mpcsystem.common.utility.pojo;

public class TimeDetails {
	
	private String portArrivalDate;
	private String heaveupNoticeTime;
	private String atub;
	public String getPortArrivalDate() {
		return portArrivalDate;
	}
	public void setPortArrivalDate(String portArrivalDate) {
		this.portArrivalDate = portArrivalDate;
	}
	public String getHeaveupNoticeTime() {
		return heaveupNoticeTime;
	}
	public void setHeaveupNoticeTime(String heaveupNoticeTime) {
		this.heaveupNoticeTime = heaveupNoticeTime;
	}
	public String getAtub() {
		return atub;
	}
	public void setAtub(String atub) {
		this.atub = atub;
	}
	@Override
	public String toString() {
		return "TimeDetails [portArrivalDate=" + portArrivalDate
				+ ", heaveupNoticeTime=" + heaveupNoticeTime + ", atub=" + atub
				+ "]";
	}

}
