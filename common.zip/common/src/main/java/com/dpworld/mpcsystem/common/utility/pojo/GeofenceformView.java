package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class GeofenceformView implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -552415673605888836L;
	private String gfCode;
	private String objName;
	private String isValid;
	private String terminal;
	private String objectVal;
	private String status;
	
	public String getGfCode() {
		return gfCode;
	}
	public void setGfCode(String gfCode) {
		this.gfCode = gfCode;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getObjectVal() {
		return objectVal;
	}
	public void setObjectVal(String objectVal) {
		this.objectVal = objectVal;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
