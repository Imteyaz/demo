package com.dpworld.mpcsystem.common.utility.pojo;

public class VesselGeofenceData {

	private String vesselName;
	private String geofencingCode;
	private boolean entry;
	private boolean exit;

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getGeofencingCode() {
		return geofencingCode;
	}

	public void setGeofencingCode(String geofencingCode) {
		this.geofencingCode = geofencingCode;
	}

	public boolean isEntry() {
		return entry;
	}

	public void setEntry(boolean entry) {
		this.entry = entry;
	}

	public boolean isExit() {
		return exit;
	}

	public void setExit(boolean exit) {
		this.exit = exit;
	}

	@Override
	public String toString() {
		return "VesselGeofenceData [vesselName=" + vesselName + ", geofencingCode=" + geofencingCode + ", entry="
				+ entry + ", exit=" + exit + "]";
	}

}
