package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.List;

public class VesselReportDTO {
   
	private String statusBy;
	private List<String> rotation;
	private List<String> terminal;
	private List<String> vesselTypes;
	private List<String> vesselTypesCode;
	private String sailingRotation;
	
	private String fromETA;
	private String toETA;
	private String fromETC;
	private String toETC;
	
	private String fromATB;
	private String toATB;
	private String fromETCATUB;
	private String toETCATUB;
	
	private String tempRotation;
	private String tempTerminal;
	private String tempVesselType;
	private String tempFromETA;
	
	private String tempToETA;
	private String tempFromETC;
	private String tempToETC;
	private String tempFromATB;
	private String tempToATB;
	private String tempFromETCATUB;
	private String tempToETCATUB;
	
	
	public String getStatusBy() {
		return statusBy;
	}
	public void setStatusBy(String statusBy) {
		this.statusBy = statusBy;
	}
	public List<String> getRotation() {
		return rotation;
	}
	public void setRotation(List<String> rotation) {
		this.rotation = rotation;
	}
	public List<String> getTerminal() {
		return terminal;
	}
	public void setTerminal(List<String> terminal) {
		this.terminal = terminal;
	}
	public List<String> getVesselTypes() {
		return vesselTypes;
	}
	public void setVesselTypes(List<String> vesselTypes) {
		this.vesselTypes = vesselTypes;
	}
	
	public List<String> getVesselTypesCode() {
		return vesselTypesCode;
	}
	public void setVesselTypesCode(List<String> vesselTypesCode) {
		this.vesselTypesCode = vesselTypesCode;
	}
	public String getFromETA() {
		return fromETA;
	}
	public void setFromETA(String fromETA) {
		this.fromETA = fromETA;
	}
	public String getToETA() {
		return toETA;
	}
	public void setToETA(String toETA) {
		this.toETA = toETA;
	}
	public String getFromETC() {
		return fromETC;
	}
	public void setFromETC(String fromETC) {
		this.fromETC = fromETC;
	}
	public String getToETC() {
		return toETC;
	}
	public void setToETC(String toETC) {
		this.toETC = toETC;
	}
	public String getFromATB() {
		return fromATB;
	}
	public void setFromATB(String fromATB) {
		this.fromATB = fromATB;
	}
	public String getToATB() {
		return toATB;
	}
	public void setToATB(String toATB) {
		this.toATB = toATB;
	}
	public String getFromETCATUB() {
		return fromETCATUB;
	}
	public void setFromETCATUB(String fromETCATUB) {
		this.fromETCATUB = fromETCATUB;
	}
	public String getToETCATUB() {
		return toETCATUB;
	}
	public void setToETCATUB(String toETCATUB) {
		this.toETCATUB = toETCATUB;
	}
	public String getTempRotation() {
		return tempRotation;
	}
	public void setTempRotation(String tempRotation) {
		this.tempRotation = tempRotation;
	}
	public String getTempTerminal() {
		return tempTerminal;
	}
	public void setTempTerminal(String tempTerminal) {
		this.tempTerminal = tempTerminal;
	}
	public String getTempVesselType() {
		return tempVesselType;
	}
	public void setTempVesselType(String tempVesselType) {
		this.tempVesselType = tempVesselType;
	}
	public String getTempFromETA() {
		return tempFromETA;
	}
	public void setTempFromETA(String tempFromETA) {
		this.tempFromETA = tempFromETA;
	}
	public String getTempToETA() {
		return tempToETA;
	}
	public void setTempToETA(String tempToETA) {
		this.tempToETA = tempToETA;
	}
	public String getTempFromETC() {
		return tempFromETC;
	}
	public void setTempFromETC(String tempFromETC) {
		this.tempFromETC = tempFromETC;
	}
	public String getTempToETC() {
		return tempToETC;
	}
	public void setTempToETC(String tempToETC) {
		this.tempToETC = tempToETC;
	}
	public String getTempFromATB() {
		return tempFromATB;
	}
	public void setTempFromATB(String tempFromATB) {
		this.tempFromATB = tempFromATB;
	}
	public String getTempToATB() {
		return tempToATB;
	}
	public void setTempToATB(String tempToATB) {
		this.tempToATB = tempToATB;
	}
	public String getTempFromETCATUB() {
		return tempFromETCATUB;
	}
	public void setTempFromETCATUB(String tempFromETCATUB) {
		this.tempFromETCATUB = tempFromETCATUB;
	}
	public String getTempToETCATUB() {
		return tempToETCATUB;
	}
	public void setTempToETCATUB(String tempToETCATUB) {
		this.tempToETCATUB = tempToETCATUB;
	}
	public String getSailingRotation() {
		return sailingRotation;
	}
	public void setSailingRotation(String sailingRotation) {
		this.sailingRotation = sailingRotation;
	}
	@Override
	public String toString() {
		return "VesselReportDTO [statusBy=" + statusBy + ", rotation=" + rotation + ", terminal=" + terminal
				+ ", vesselTypes=" + vesselTypes + ", vesselTypesCode=" + vesselTypesCode + ", sailingRotation="
				+ sailingRotation + ", fromETA=" + fromETA + ", toETA=" + toETA + ", fromETC=" + fromETC + ", toETC="
				+ toETC + ", fromATB=" + fromATB + ", toATB=" + toATB + ", fromETCATUB=" + fromETCATUB + ", toETCATUB="
				+ toETCATUB + ", tempRotation=" + tempRotation + ", tempTerminal=" + tempTerminal + ", tempVesselType="
				+ tempVesselType + ", tempFromETA=" + tempFromETA + ", tempToETA=" + tempToETA + ", tempFromETC="
				+ tempFromETC + ", tempToETC=" + tempToETC + ", tempFromATB=" + tempFromATB + ", tempToATB=" + tempToATB
				+ ", tempFromETCATUB=" + tempFromETCATUB + ", tempToETCATUB=" + tempToETCATUB + "]";
	}
	
	
	
	
	
	
}
