package com.dpworld.mpcsystem.common;

public class HibernateRollbackException extends RuntimeException {

}
