package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VesselIconsPointsHolder {
	
	private VesselIconsPointsHolder(){}

	static List<VesselIcon> t1q1v0 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;
		{
			add(new VesselIcon(24.994863449453053, 55.05598783493042));
			add(new VesselIcon(24.995592749847976, 55.05680859088897));
			add(new VesselIcon(24.99569971354196, 55.05724310874939));
			add(new VesselIcon(24.995276720208206, 55.05703926086426));
			add(new VesselIcon(24.994557141996655, 55.05615949630737));
		}
	};

	// ------

	static List<VesselIcon> t1q1v1 = new ArrayList<VesselIcon>() {
		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.995913640650677, 55.05720555782318));
			add(new VesselIcon(24.99553440597564, 55.057371854782104));
			add(new VesselIcon(24.996336631792214, 55.05829453468323));
			add(new VesselIcon(24.99669155427042, 55.05844473838806));
			add(new VesselIcon(24.9966380728667, 55.05806922912598));
		}
	};
	// -------

	static List<VesselIcon> t1q1v2 = new ArrayList<VesselIcon>() {
		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.99696868480782, 55.05839645862579));
			add(new VesselIcon(24.99659431533723, 55.058589577674866));
			add(new VesselIcon(24.997328467380186, 55.059437155723565));
			add(new VesselIcon(24.997712558423277, 55.05956590175629));
			add(new VesselIcon(24.997727144135453, 55.05928158760071));
		}
	};
	// -----

	static List<VesselIcon> t1q1v3 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{

			add(new VesselIcon(24.99888427178284, 55.060590505599976));
			add(new VesselIcon(24.99891344292725, 55.06097674369812));
			add(new VesselIcon(24.998349466241233, 55.06078362464905));
			add(new VesselIcon(24.99743542956343, 55.05965709686279));
			add(new VesselIcon(24.997863277365404, 55.05945324897766));
		}
	};
	// ----

	static List<VesselIcon> t1q1v4 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.999088469648342, 55.06085872650146));
			add(new VesselIcon(24.998733554093032, 55.061073303222656));
			add(new VesselIcon(24.999506588028407, 55.061915516853325));
			add(new VesselIcon(24.999851777711843, 55.06203353404999));
			add(new VesselIcon(24.999827468610942, 55.06167948246002));
		}
	};
	// -----

	static List<VesselIcon> t1q1v5 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.000080283025177, 55.0619637966156));
			add(new VesselIcon(24.999701061208768, 55.06219446659088));
			add(new VesselIcon(25.000600495664184, 55.06321370601654));
			add(new VesselIcon(25.00097971470463, 55.063342452049255));
			add(new VesselIcon(25.000926235167256, 55.06294548511505));
		}
	};
	// -----

	static List<VesselIcon> t1q1v6 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00118877085464, 55.06325125694275));
			add(new VesselIcon(25.000838723146767, 55.06349802017212));
			add(new VesselIcon(25.00169439356087, 55.06444752216339));
			add(new VesselIcon(25.002078470956686, 55.064565539360046));
			add(new VesselIcon(25.00204443883086, 55.06419539451599));
		}
	};
	// ------

	static List<VesselIcon> t1q1v7 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.002282663513718, 55.06451189517975));
			add(new VesselIcon(25.00193748065972, 55.06472647190094));
			add(new VesselIcon(25.002705632730827, 55.065616965293884));
			add(new VesselIcon(25.0031140154208, 55.0657993555069));
			add(new VesselIcon(25.003094568656834, 55.06543457508087));
		}
	};
	// -----

	static List<VesselIcon> t1q1v8 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00333765298529, 55.06574034690857));
			add(new VesselIcon(25.00299733479075, 55.06596028804779));
			add(new VesselIcon(25.00381895853667, 55.066882967948914));
			add(new VesselIcon(25.00421761423226, 55.06701171398162));
			add(new VesselIcon(25.004154412805832, 55.06664156913757));
		}
	};
	// -----

	static List<VesselIcon> t1q1v9 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.0040571797786, 55.066571831703186));
			add(new VesselIcon(25.00364880022389, 55.066834688186646));
			add(new VesselIcon(25.00454820577908, 55.067929029464715));
			add(new VesselIcon(25.005019783357664, 55.06805777549744));
			add(new VesselIcon(25.004976028813157, 55.067601799964905));
		}
	};
	// -----

	static List<VesselIcon> t1q1v10 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00574902347161, 55.06854057312012));
			add(new VesselIcon(25.00520452459597, 55.06892144680023));
			add(new VesselIcon(25.006225458007947, 55.07002115249634));
			add(new VesselIcon(25.00680884471939, 55.07020354270934));
			add(new VesselIcon(25.00677967544962, 55.06967782974243));
		}
	};
	// -----

	static List<VesselIcon> t1q1v11 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00709567550316, 55.070090889930725));
			add(new VesselIcon(25.006633828996886, 55.07042348384857));
			add(new VesselIcon(25.007635304484303, 55.07152318954467));
			add(new VesselIcon(25.008257576402205, 55.07171630859375));
			add(new VesselIcon(25.008116593197038, 55.071206688880920));
		}
	};

	static List<List<VesselIcon>> t1q1PortSideIcons = new ArrayList<List<VesselIcon>>() {
		private static final long serialVersionUID = 1L;
		{
			add(t1q1v0);
			add(t1q1v1);
			add(t1q1v2);
			add(t1q1v3);
			add(t1q1v4);
			add(t1q1v5);
			add(t1q1v6);
			add(t1q1v7);
			add(t1q1v8);
			add(t1q1v9);
			add(t1q1v10);
			add(t1q1v11);
		}
	};

	static List<VesselIcon> t1q1vs0 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.008515234945285, 55.07167339324951));
			add(new VesselIcon(25.00797074833173, 55.07218301296234));
			add(new VesselIcon(25.006565767259687, 55.070562958717346));
			add(new VesselIcon(25.006303243062884, 55.06977438926697));
			add(new VesselIcon(25.00714429082384, 55.07005333900451));
		}
	};

	static List<VesselIcon> t1q1vs1 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00729499819572, 55.07027328014374));
			add(new VesselIcon(25.007003306340827, 55.07063269615173));
			add(new VesselIcon(25.006099057188603, 55.06963491439819));
			add(new VesselIcon(25.006001825700604, 55.06924331188202));
			add(new VesselIcon(25.006512290153985, 55.069355964660645));
		}
	};

	static List<VesselIcon> t1q1vs2 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.006167119184397, 55.06899118423462));
			add(new VesselIcon(25.005787916156084, 55.06929695606232));
			add(new VesselIcon(25.00486421157306, 55.06829380989075));
			add(new VesselIcon(25.00482531859613, 55.067918300628655));
			add(new VesselIcon(25.00531634152628, 55.06800949573516));
		}
	};

	static List<VesselIcon> t1q1vs3 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00457737557873, 55.0679987668991));
			add(new VesselIcon(25.00365366189324, 55.066899061203));
			add(new VesselIcon(25.00360504519108, 55.066437721252434));
			add(new VesselIcon(25.004144689506568, 55.066614747047424));
			add(new VesselIcon(25.004976028813157, 55.06764471530914));
		}
	};

	static List<VesselIcon> t1q1vs4 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00373631024274, 55.066174864768975));
			add(new VesselIcon(25.003269589421816, 55.066566467285156));
			add(new VesselIcon(25.002000683226647, 55.065187811851494));
			add(new VesselIcon(25.00189372501744, 55.06462454795837));
			add(new VesselIcon(25.002559781441153, 55.06480693817139));
		}
	};

	static List<VesselIcon> t1q1vs5 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00210764134278, 55.06431341171265));
			add(new VesselIcon(25.00157771158257, 55.06471574306487));
			add(new VesselIcon(25.000381714916152, 55.06344974040985));
			add(new VesselIcon(25.00030392611185, 55.06292402744293));
			add(new VesselIcon(25.001072088396175, 55.063106417655945));
		}
	};

	static List<VesselIcon> t1q1vs6 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(25.00054701596175, 55.06251096725464));
			add(new VesselIcon(24.999978184958987, 55.06298840045929));
			add(new VesselIcon(24.99871896850034, 55.06164729595184));
			add(new VesselIcon(24.99874813968399, 55.0611537694931));
			add(new VesselIcon(24.999462831520383, 55.06125569343567));
		}
	};

	static List<VesselIcon> t1q1vs7 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.999117640744284, 55.060869455337524));
			add(new VesselIcon(24.99839808502302, 55.06130933761597));
			add(new VesselIcon(24.997216643179968, 55.05989849567413));
			add(new VesselIcon(24.997187471632742, 55.05928158760071));
			add(new VesselIcon(24.99794592960999, 55.059458613395684));
		}
	};

	static List<VesselIcon> t1q1vs8 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.997469462965828, 55.05897581577301));
			add(new VesselIcon(24.996856860280204, 55.05946934223175));
			add(new VesselIcon(24.99561705978661, 55.05804777145385));
			add(new VesselIcon(24.995398270165825, 55.05742013454437));
			add(new VesselIcon(24.99621508276268, 55.05751669406891));
		}
	};

	static List<VesselIcon> t1q1vs9 = new ArrayList<VesselIcon>() {

		private static final long serialVersionUID = 1L;

		{
			add(new VesselIcon(24.995758057335827, 55.05702316761017));
			add(new VesselIcon(24.995184342160012, 55.05743622779846));
			add(new VesselIcon(24.99441614306965, 55.05645453929901));
			add(new VesselIcon(24.99440641899975, 55.055864453315735));
			add(new VesselIcon(24.994912069614028, 55.05598247051238));
		}
	};

	static List<List<VesselIcon>> t1q1StarboatSideIcons = new ArrayList<List<VesselIcon>>() {
		private static final long serialVersionUID = 1L;
		{
			add(t1q1vs0);
			add(t1q1vs1);
			add(t1q1vs2);
			add(t1q1vs3);
			add(t1q1vs4);
			add(t1q1vs5);
			add(t1q1vs6);
			add(t1q1vs7);
			add(t1q1vs8);
			add(t1q1vs9);
		}
	};

	static Map<String, List<List<VesselIcon>>> iconsMap = new HashMap<String, List<List<VesselIcon>>>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{

			put("T1Q1P", t1q1PortSideIcons);
			put("T1Q1S", t1q1StarboatSideIcons);

		}
	};

	public static Map<String, List<List<VesselIcon>>> getVesselGeoCodePolygonPoints() {
		return iconsMap;
	}

	public static boolean isPointInsidePolygon(float lat, float lng,
			List<GeoFenceData> polyPoints) {
		float x = lat;
		float y = lng;
		boolean inside = false;
		for (int i = 0, j = polyPoints.size() - 1; i < polyPoints.size(); j = i++) {
			float xi = polyPoints.get(i).getLat();
			float yi = polyPoints.get(i).getLng();
			float xj = polyPoints.get(j).getLat();
			float yj = polyPoints.get(j).getLng();
			boolean intersect = ((yi > y) != (yj > y))
					&& (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
			if (intersect){
				inside = !inside;}
		}
		return inside;
	}

	public static boolean isPointInsidePolygonVesselIcon(float lat, float lng,
			List<VesselIcon> polyPoints) {
		float x = lat;
		float y = lng;
		boolean inside = false;
		for (int i = 0, j = polyPoints.size() - 1; i < polyPoints.size(); j = i++) {
			float xi = (float) polyPoints.get(i).getLat();
			float yi = (float) polyPoints.get(i).getLng();
			float xj = (float) polyPoints.get(j).getLat();
			float yj = (float) polyPoints.get(j).getLng();
			boolean intersect = ((yi > y) != (yj > y))
					&& (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
			if (intersect)
				inside = !inside;
		}
		return inside;
	}

	public static String getVesselGeofence(
			Map<String, List<GeoFenceData>> data, float lat, float lng) {

		for (Map.Entry<String, List<GeoFenceData>> entry : data.entrySet()) {
			String loctation = entry.getKey();
			if (!"ANCHOR".equals(loctation)) {
				List<GeoFenceData> shape = entry.getValue();
				if (isPointInsidePolygon(lat, lng, shape)) {
					return loctation;
				}
			}
		}

		return "";
	}
}
