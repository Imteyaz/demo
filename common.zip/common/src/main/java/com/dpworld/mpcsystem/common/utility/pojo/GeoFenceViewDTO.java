package com.dpworld.mpcsystem.common.utility.pojo;

public class GeoFenceViewDTO {

	private String mgdRecId;
	private String mgdRecDate;
	private String mgmGfCode;
	private String mgdObjType;
	private String mgdObjName;
	private String mgdObjCode;
	private String mgdObjId;
	private String mgdObjEntry;
	private String mgdObjExit;
	private String isValid;
	private String srcSys;
	private String createdBy;
	private String createdDate;
	private String modifiedBy;
	private String modifiedDate;
	
	public String getMgdRecId() {
		return mgdRecId;
	}
	public void setMgdRecId(String mgdRecId) {
		this.mgdRecId = mgdRecId;
	}
	public String getMgdRecDate() {
		return mgdRecDate;
	}
	public void setMgdRecDate(String mgdRecDate) {
		this.mgdRecDate = mgdRecDate;
	}
	public String getMgmGfCode() {
		return mgmGfCode;
	}
	public void setMgmGfCode(String mgmGfCode) {
		this.mgmGfCode = mgmGfCode;
	}
	public String getMgdObjType() {
		return mgdObjType;
	}
	public void setMgdObjType(String mgdObjType) {
		this.mgdObjType = mgdObjType;
	}
	public String getMgdObjName() {
		return mgdObjName;
	}
	public void setMgdObjName(String mgdObjName) {
		this.mgdObjName = mgdObjName;
	}
	public String getMgdObjCode() {
		return mgdObjCode;
	}
	public void setMgdObjCode(String mgdObjCode) {
		this.mgdObjCode = mgdObjCode;
	}
	public String getMgdObjId() {
		return mgdObjId;
	}
	public void setMgdObjId(String mgdObjId) {
		this.mgdObjId = mgdObjId;
	}
	public String getMgdObjEntry() {
		return mgdObjEntry;
	}
	public void setMgdObjEntry(String mgdObjEntry) {
		this.mgdObjEntry = mgdObjEntry;
	}
	public String getMgdObjExit() {
		return mgdObjExit;
	}
	public void setMgdObjExit(String mgdObjExit) {
		this.mgdObjExit = mgdObjExit;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getSrcSys() {
		return srcSys;
	}
	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	
	
	
}
