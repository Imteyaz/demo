package com.dpworld.mpcsystem.common.utility.pojo;

public class ColorPickerDTO {
	
	private String mspParamCatg;
	private String mspParamGroup;
	private String status;
	private String user;
	private String color;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	private String tempId;
	private String tempRecId;
	
	public String getMspParamCatg() {
		return mspParamCatg;
	}
	public void setMspParamCatg(String mspParamCatg) {
		this.mspParamCatg = mspParamCatg;
	}
	public String getMspParamGroup() {
		return mspParamGroup;
	}
	public void setMspParamGroup(String mspParamGroup) {
		this.mspParamGroup = mspParamGroup;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getTempId() {
		return tempId;
	}
	public void setTempId(String tempId) {
		this.tempId = tempId;
	}
	public String getTempRecId() {
		return tempRecId;
	}
	public void setTempRecId(String tempRecId) {
		this.tempRecId = tempRecId;
	}
	
	
	
	
	

}
