package com.dpworld.mpcsystem.common.utility.pojo;


public class VesselDashboardInfo {
	
	private String rotation;
	private String vesselName;
	private String status;
	private String serviceType;
	private String serviceTypeDesc;
	

	

	public String getRotation() {
		return rotation;
	}

	public void setRotation(String rotation) {
		this.rotation = rotation;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	public String getServiceTypeDesc() {
		return serviceTypeDesc;
	}

	public void setServiceTypeDesc(String serviceTypeDesc) {
		this.serviceTypeDesc = serviceTypeDesc;
	}

	@Override
	public String toString() {
		return "VesselDashboardInfo [rotation=" + rotation + ", vesselName=" + vesselName + ",status=" + status + ",serviceType=" + serviceType + ",serviceTypeDesc=" + serviceTypeDesc + "]";
	}
}
