package com.dpworld.mpcsystem.common.utility.pojo;
import java.util.List;
public class CommonDTO {

	private List<MpcGeofenceDTO> vesselInfoList;

	public List<MpcGeofenceDTO> getVesselInfoList() {
		return vesselInfoList;
	}

	public void setVesselInfoList(List<MpcGeofenceDTO> vesselInfoList) {
		this.vesselInfoList = vesselInfoList;
	}
	
}
