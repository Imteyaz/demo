package com.dpworld.mpcsystem.common.utility;

import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.model.ConfigCode;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

@Service
public class CodeServiceUtil {


  
  private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(CodeServiceUtil.class);
  public List<ConfigCode> getListCodes(String codeType) {
    //webservice call to get codes from PROMIS1
    List<ConfigCode> list = null;
    try{
    Client c = Client.create();
	Gson gson = new Gson();
	WebResource resource = null;
    resource = c.resource(MPCUtil.getFuseUrl(MPCConstants.CODE_WS_URL)+"="+codeType);

	String response = resource.get(String.class);
	list = gson.fromJson(response,
			new TypeToken<List<ConfigCode>>() {
	}.getType());
	


    }
    catch(Exception er){
    	LOGGER.error(er.getStackTrace());
    }
    
    return list;
  }

  public ConfigCode getConfigCode(String codeType, String codeCode) {

	  ConfigCode configCode = new ConfigCode();
	  List<ConfigCode> list = null;
	    try{
	    Client c = Client.create();
		Gson gson = new Gson();
		WebResource resource = null;
	    resource = c.resource(MPCUtil.getFuseUrl(MPCConstants.CODE_WS_URL)+"="+codeType+"&codeCode="+codeCode);

		String response = resource.get(String.class);
		list = gson.fromJson(response,
				new TypeToken<List<ConfigCode>>() {
		}.getType());
		 
	    configCode = list.get(0);
	  
	    }
	    catch(Exception er){
	    	LOGGER.error(er.getStackTrace());
	    }
	  
    return configCode;
  }

  public String getCodeDescription(String codeType, String codeCode) {
    return getConfigCode(codeType, codeCode).getCodeDescription1();

  }

}
