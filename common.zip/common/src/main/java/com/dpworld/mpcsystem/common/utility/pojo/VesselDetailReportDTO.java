package com.dpworld.mpcsystem.common.utility.pojo;

import java.io.Serializable;

public class VesselDetailReportDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String rotation;

	public String getRotation() {
		return rotation;
	}

	public void setRotation(String rotation) {
		this.rotation = rotation;
	}
	
	
}
