package com.dpworld.mpcsystem.common.utility.pojo;

public class AlertMasterDTO {

	private String altId;
	private String altCode;
	private String altText;
	private String altSeverity;
	private String altValidity;
	private String altType;
	private String altGroup;
	private String altCatg;
	private String isValid;
	private String srcSys;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	
	public String getAltId() {
		return altId;
	}
	public void setAltId(String altId) {
		this.altId = altId;
	}
	public String getAltCode() {
		return altCode;
	}
	public void setAltCode(String altCode) {
		this.altCode = altCode;
	}
	public String getAltText() {
		return altText;
	}
	public void setAltText(String altText) {
		this.altText = altText;
	}
	public String getAltSeverity() {
		return altSeverity;
	}
	public void setAltSeverity(String altSeverity) {
		this.altSeverity = altSeverity;
	}
	public String getAltValidity() {
		return altValidity;
	}
	public void setAltValidity(String altValidity) {
		this.altValidity = altValidity;
	}
	public String getAltType() {
		return altType;
	}
	public void setAltType(String altType) {
		this.altType = altType;
	}
	public String getAltGroup() {
		return altGroup;
	}
	public void setAltGroup(String altGroup) {
		this.altGroup = altGroup;
	}
	public String getAltCatg() {
		return altCatg;
	}
	public void setAltCatg(String altCatg) {
		this.altCatg = altCatg;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getSrcSys() {
		return srcSys;
	}
	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	@Override
	public String toString() {
		return "AlertMasterDTO [altId=" + altId + ", altCode=" + altCode
				+ ", altText=" + altText + ", altSeverity=" + altSeverity
				+ ", altValidity=" + altValidity + ", altType=" + altType
				+ ", altGroup=" + altGroup + ", altCatg=" + altCatg
				+ ", isValid=" + isValid + ", srcSys=" + srcSys
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy
				+ "]";
	}
	
}
