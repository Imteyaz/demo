package com.dpworld.mpcsystem.common.utility.pojo;

public class MaintainScoreDTO {

	private String recId;
	private String recDate;
	private String msmScoreType;
	private String msmCritType;
	private String msmCritVal;
	private String msmScore;
	private String userCode;
	private String isValid;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;

	public String getRecId() {
		return recId;
	}

	public void setRecId(String recId) {
		this.recId = recId;
	}

	public String getRecDate() {
		return recDate;
	}

	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}

	public String getMsmScoreType() {
		return msmScoreType;
	}

	public void setMsmScoreType(String msmScoreType) {
		this.msmScoreType = msmScoreType;
	}

	public String getMsmCritType() {
		return msmCritType;
	}

	public void setMsmCritType(String msmCritType) {
		this.msmCritType = msmCritType;
	}

	public String getMsmCritVal() {
		return msmCritVal;
	}

	public void setMsmCritVal(String msmCritVal) {
		this.msmCritVal = msmCritVal;
	}

	public String getMsmScore() {
		return msmScore;
	}

	public void setMsmScore(String msmScore) {
		this.msmScore = msmScore;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
