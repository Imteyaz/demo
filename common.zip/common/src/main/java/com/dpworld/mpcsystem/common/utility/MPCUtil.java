package com.dpworld.mpcsystem.common.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.dpworld.mpcsystem.common.constants.MPCConstants;

public class MPCUtil {
	
	private static final Logger logger = LoggerFactory
			.getLogger(MPCUtil.class);
	private static Properties properties = new Properties();
	private static String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
	private static String DATE_FORMAT_DD_MMM_YY_HH_MM= "dd-MMM-yy HH:mm";
	private MPCUtil(){}

	/**
	 * getPropertyFromConfiguration
	 * 
	 * @return
	 */
	public static String getFuseUrl(String key) {

		File f = null;
		FileInputStream fStream = null;
		try {
			String fileName = System.getProperty("jboss.server.config.dir")
					+ MPCConstants.MPC_CONFIG_PROPERTIES;

			f = new File(fileName);
			fStream = new FileInputStream(f);
			properties.load(fStream);
			return (String) properties.get(key);
		} catch (Exception e) {
			if (fStream != null) {
				try {
					fStream.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}
			e.printStackTrace();
		} finally {
			if (fStream != null) {
				try {
					fStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/*
	 *  Get Year in YY Format
	 */
	public static String getCurrentYear(Date currentDate) {

		String year = null;
		try {
			DateFormat format = new SimpleDateFormat("yy");
			year = format.format(currentDate);
		} catch (Exception er) {
			er.printStackTrace();
		}
		return year;
	}

	/*
	 *  Change Date Format From YY-MM-DD to MM/DD/YYYY
	 * 
	 */
	public static String changeDateFormat(String myDate) {
		String changedDate = null;
		try {
			DateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
			Date date2 = (Date) parser.parse(myDate);

			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			changedDate = formatter.format(date2);
		} catch (Exception er) {
			er.printStackTrace();
		}
		return changedDate;
	}

	/*
	 *  Convert String to Date		
	 */
	public static Date convertStringToDate(String strDate) {
		Date initDate = null;

		try {
			initDate = new SimpleDateFormat("MM/dd/yyyy").parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return initDate;
	}

	/*
	 *  Convert dd-MMM-yy HH:mm to Date util
	 */
	public static Date changeStringToNewDateFormat(String strDate){
		
		Date initDate = null;
		try {
			initDate = new SimpleDateFormat("dd-MMM-yy HH:mm").parse(strDate);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return initDate;
	}
	


	/*
	 * Convert Date util to dd-MMM-yy HH:mm
	 */
    public static String changeNewDateToStringFormat(Date initDate){
		
    	String changedDate = null;
		try {

			DateFormat formatter = new SimpleDateFormat("dd-MMM-yy HH:mm");
			changedDate = formatter.format(initDate);
			
		} catch (Exception er) {
			er.printStackTrace();
		}
		
		return changedDate;
	}
    
    /*
     * Get Date in YYYY Format
     */
    public static String getCurrentYearYYYYMMDDFormat(Date currentDate) {

		String year = null;
		try {
			DateFormat format = new SimpleDateFormat("yyMMdd");
			year = format.format(currentDate);
		} catch (Exception er) {
			er.printStackTrace();
		}
		return year;
	}
    
    public static String getOnlyCurrentDate(){
    	
    	Date initDate = new Date();
    	String changedDate = null;
    	
    	try 
    	{
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		changedDate = formatter.format(initDate);
    	} catch (Exception er) {
			er.printStackTrace();
		}
    	return changedDate;
    }
    
    public static String getTimeFromDate(String date){
    	String time = null;
    	{
    		try {
				Date initDate = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(date);
				 SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm");
		         time = localDateFormat.format(initDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 	
    	
    	}
    	return time;
    }
    
    /**
     * Converts Strings to list based on specified delimiter
     * 
     * @param strngToList the string to list
     * @param delimiter Any kind of delimiter
     * @return listString
     * 
     */
    public static List<String> convertStringToList(String strngToList, String delimiter) {
      List<String> listString = new ArrayList<>();
      StringTokenizer st = new StringTokenizer(strngToList, StringUtils.isEmpty(delimiter)? "," : delimiter);
      while (st.hasMoreTokens()) {
        listString.add(st.nextToken().trim());
      }

      return listString;
    }
    
    /**
     * 
     * @param list
     * @param delimiter
     * @return
     */
    
  
    
    public static String convertListToString(List<String> list, String delimiter) {
      StringBuilder data = new StringBuilder();
      if (!CollectionUtils.isEmpty(list)) {
        for (String str : list) {
          if(data.length() > 0) {
            data.append(delimiter);
          }
          if(!StringUtils.isEmpty(str) && !str.trim().equalsIgnoreCase("null")) {
            data.append(str.trim());
          }
        }
      }
      return data.toString();
    }
}