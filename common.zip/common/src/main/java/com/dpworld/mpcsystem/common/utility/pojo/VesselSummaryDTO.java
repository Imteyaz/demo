package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.List;

public class VesselSummaryDTO {
	
	private List<VesselDashboardInfo> anchorList;
	private List<VesselDashboardInfo> incomingList;
	private List<VesselDashboardInfo> sailingList;
	private List<VesselDashboardInfo> alongsideList;
	private List<VesselDashboardInfo> shiftingList;
	private List<VesselDashboardInfo> geofenceTwoList;
	private List<VesselDashboardInfo> geofenceFourList;
	private List<VesselDashboardInfo> geofenceSixList;
	private List<VesselDashboardInfo> geofenceEightList;
	private List<VesselDashboardInfo> geofenceTwelveList;
	private List<VesselDashboardInfo> geofenceTwoFourList;
	private List<VesselDashboardInfo> highseaList;
	private List<VesselDetailsDTO> VesselDtlsList;
	
	public List<VesselDetailsDTO> getVesselDtlsList() {
		return VesselDtlsList;
	}
	public void setVesselDtlsList(List<VesselDetailsDTO> vesselDtlsList) {
		VesselDtlsList = vesselDtlsList;
	}
	public List<VesselDashboardInfo> getAnchorList() {
		return anchorList;
	}
	public void setAnchorList(List<VesselDashboardInfo> anchorList) {
		this.anchorList = anchorList;
	}
	public List<VesselDashboardInfo> getIncomingList() {
		return incomingList;
	}
	public void setIncomingList(List<VesselDashboardInfo> incomingList) {
		this.incomingList = incomingList;
	}
	public List<VesselDashboardInfo> getSailingList() {
		return sailingList;
	}
	public void setSailingList(List<VesselDashboardInfo> sailingList) {
		this.sailingList = sailingList;
	}
	public List<VesselDashboardInfo> getAlongsideList() {
		return alongsideList;
	}
	public void setAlongsideList(List<VesselDashboardInfo> alongsideList) {
		this.alongsideList = alongsideList;
	}
	public List<VesselDashboardInfo> getShiftingList() {
		return shiftingList;
	}
	public void setShiftingList(List<VesselDashboardInfo> shiftingList) {
		this.shiftingList = shiftingList;
	}
	public List<VesselDashboardInfo> getGeofenceTwoList() {
		return geofenceTwoList;
	}
	public void setGeofenceTwoList(List<VesselDashboardInfo> geofenceTwoList) {
		this.geofenceTwoList = geofenceTwoList;
	}
	public List<VesselDashboardInfo> getGeofenceFourList() {
		return geofenceFourList;
	}
	public void setGeofenceFourList(List<VesselDashboardInfo> geofenceFourList) {
		this.geofenceFourList = geofenceFourList;
	}
	public List<VesselDashboardInfo> getGeofenceSixList() {
		return geofenceSixList;
	}
	public void setGeofenceSixList(List<VesselDashboardInfo> geofenceSixList) {
		this.geofenceSixList = geofenceSixList;
	}
	public List<VesselDashboardInfo> getGeofenceEightList() {
		return geofenceEightList;
	}
	public void setGeofenceEightList(List<VesselDashboardInfo> geofenceEightList) {
		this.geofenceEightList = geofenceEightList;
	}
	public List<VesselDashboardInfo> getGeofenceTwelveList() {
		return geofenceTwelveList;
	}
	public void setGeofenceTwelveList(List<VesselDashboardInfo> geofenceTwelveList) {
		this.geofenceTwelveList = geofenceTwelveList;
	}
	public List<VesselDashboardInfo> getGeofenceTwoFourList() {
		return geofenceTwoFourList;
	}
	public void setGeofenceTwoFourList(List<VesselDashboardInfo> geofenceTwoFourList) {
		this.geofenceTwoFourList = geofenceTwoFourList;
	}
	public List<VesselDashboardInfo> getHighseaList() {
		return highseaList;
	}
	public void setHighseaList(List<VesselDashboardInfo> highseaList) {
		this.highseaList = highseaList;
	}
	@Override
	public String toString() {
		return "VesselSummaryDTO [anchorList=" + anchorList + ", incomingList="
				+ incomingList + ", sailingList=" + sailingList
				+ ", alongsideList=" + alongsideList + ", shiftingList="
				+ shiftingList + ", geofenceTwoList=" + geofenceTwoList
				+ ", geofenceFourList=" + geofenceFourList
				+ ", geofenceSixList=" + geofenceSixList
				+ ", geofenceEightList=" + geofenceEightList
				+ ", geofenceTwelveList=" + geofenceTwelveList
				+ ", geofenceTwoFourList=" + geofenceTwoFourList
				+ ", highseaList=" + highseaList + "]";
	}	
}
