package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.Date;

public class PilotVesselDataDTO {

	@Override
	public String toString() {
		return "PilotVesselDataDTO [recId=" + recId + ", vesselName="
				+ vesselName + ", pilotDispatchTime=" + pilotDispatchTime
				+ ", imoNo=" + imoNo + ", rotationNo=" + rotationNo
				+ ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
				+ ", status=" + status + ", dispatchTime=" + dispatchTime
				+ ", userOrderNo=" + userOrderNo + ", mvdgroup=" + mvdgroup
				+ "]";
	}
	private String recId;
	private String vesselName;
	private String pilotDispatchTime;
	private String imoNo;
	private String rotationNo;
	private String createdBy;
	private String modifiedBy;
	private String status;
	private Date dispatchTime;
	private String userOrderNo;
	private String mvdgroup;
	
	public String getMvdgroup() {
		return mvdgroup;
	}
	public void setMvdgroup(String mvdgroup) {
		this.mvdgroup = mvdgroup;
	}
	public String getUserOrderNo() {
		return userOrderNo;
	}
	public void setUserOrderNo(String userOrderNo) {
		this.userOrderNo = userOrderNo;
	}
	public Date getDispatchTime() {
		return dispatchTime;
	}
	public void setDispatchTime(Date dispatchTime) {
		this.dispatchTime = dispatchTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	public String getPilotDispatchTime() {
		return pilotDispatchTime;
	}
	public void setPilotDispatchTime(String pilotDispatchTime) {
		this.pilotDispatchTime = pilotDispatchTime;
	}
	public String getImoNo() {
		return imoNo;
	}
	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}
	public String getRotationNo() {
		return rotationNo;
	}
	public void setRotationNo(String rotationNo) {
		this.rotationNo = rotationNo;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
	
	
}
