package com.dpworld.mpcsystem.common.utility.mapping;

/**
 * 
 * @author Rahul Singh
 * 
 * @param <T>
 * @param <S>
 * @Usage Helper abstract class with transform() method to implement Template
 *        pattern for copy beans properties to each other
 * 
 */

public abstract class PayloadEntityMappingTemplate<T, S> {

	public final T invoke(T target, S source) {
		return transformer(target, source);
	}

	public abstract T transformer(T target, S source);
}
