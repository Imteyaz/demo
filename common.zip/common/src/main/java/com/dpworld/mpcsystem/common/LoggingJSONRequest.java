package com.dpworld.mpcsystem.common;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**

 *
 */
public class LoggingJSONRequest {
	private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(LoggingJSONRequest.class);

	/**
	 * logJSONRequest is responsible for logging the json request for channel
	 * interface
	 * 
	 * @param payload
	 * @return
	 */
	public Object logJSONRequest(Object payload) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			LOGGER.debug(" In method logJSONRequest : Logging the JSON Request");
			LOGGER.debug(mapper.writeValueAsString(payload));
		} catch (JsonProcessingException jpe) {
			LOGGER.debug(
					"Catch the JsonProcessingException in method logJSONRequest",
					jpe);
		}
		return payload;
	}

}
