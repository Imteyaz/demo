package com.dpworld.mpcsystem.common.utility.mapping;

/**
 *@author Rahul Singh
 *@Usage bean properties coping tasks done in this class
 * 
 */
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class NullAwareBeanUtilsBean<T, S> {

	private static org.apache.log4j.Logger LOGGER = Logger
			.getLogger(NullAwareBeanUtilsBean.class);
	private static final String CONTEXT = "context";
	private Map<String, PropertyDescriptor> targetBeanPropertyDescriptor = new HashMap<String, PropertyDescriptor>();
	private PropertyDescriptor[] sourceBeanPropertyDescriptor;
	private Map<String, String> diffPropT2S = new HashMap<String, String>();
	private Map<String, Converter> convertors = new HashMap<String, Converter>();
	private Class<?> source;
	private Class<?> target;
	private String diffProperty = "NO_DIFF_IN_PROPERTY";
	private static final String CLASS = "class";

	public NullAwareBeanUtilsBean(Class<?> target, Class<?> source,
			Map<String, String> diffPropT2S) {
		this.target = target;
		this.source = source;
		this.diffPropT2S = diffPropT2S;
	}

	public String getDiffProperty() {
		return diffProperty;
	}

	public void setDiffProperty(String diffProperty) {
		this.diffProperty = diffProperty;
	}

	public Class<?> getSource() {
		return source;
	}

	public Class<?> getTarget() {
		return target;
	}

	public Map<String, String> getDiffPropT2S() {
		return diffPropT2S;
	}

	public void setDiffPropT2S(Map<String, String> diffPropT2S) {
		this.diffPropT2S = diffPropT2S;
	}

	public void register(Map<String, Converter> convertors) {
		this.convertors = convertors;
	}

	/**
	 * @method generic method for creating Map<String,PropertyDescriptor>,
	 *         <property name,property descriptor>
	 * @param beanClass
	 *            <T>
	 * @return Map<String,PropertyDescriptor>
	 */
	public Map<String, PropertyDescriptor> mapTargetBeanPropertyDescriptor(
			Class<?> beanClass) {
		try {
			BeanInfo beanInfoTarget = Introspector.getBeanInfo(beanClass);
			PropertyDescriptor[] pdsTarget = beanInfoTarget
					.getPropertyDescriptors();
			for (PropertyDescriptor p : pdsTarget) {
				targetBeanPropertyDescriptor.put(p.getName(), p);
			}
			targetBeanPropertyDescriptor.remove(CLASS);
		} catch (Exception e) {
			LOGGER.error(CONTEXT, e);
		}
		return targetBeanPropertyDescriptor;
	}

	/**
	 * @method generic method for creating Map<String,Object> of source object
	 *         properties values with property name
	 * @param source
	 * @return
	 */
	private Map<String, Object> sourceBeanReadPropertyInvoker(Object source) {
		Map<String, Object> sourceBeanPropertyInvoker = new HashMap<String, Object>();
		try {
			PropertyDescriptor[] sourceBeanPropertiesDescriptor = getSourceBeanPropertyDescriptor();
			Object[] parm = null;
			for (PropertyDescriptor p : sourceBeanPropertiesDescriptor) {

				Method readMethod = p.getReadMethod();
				if (readMethod != null) {
					Object returned = p.getReadMethod().invoke(source, parm);
					if (returned != null
							&& !StringUtils.isEmpty(returned.toString())) {
						sourceBeanPropertyInvoker.put(p.getName(), returned);
					}
				}

			}
			sourceBeanPropertyInvoker.remove(CLASS);
		} catch (Exception e) {
			LOGGER.error(CONTEXT, e);
		}
		return sourceBeanPropertyInvoker;
	}

	/**
	 * @method write not null properties values of source bean into target bean
	 *         of same name properties
	 * @param source
	 * @param target
	 */
	@SuppressWarnings("unchecked")
	public void targetBeanWritePropertyInviker(Object source, Object target) {

		Map<String, Object> sourceBeanPropertyInvoker = sourceBeanReadPropertyInvoker(source);
		for (Map.Entry<String, Object> ent : sourceBeanPropertyInvoker
				.entrySet()) {
			PropertyDescriptor ptarget = targetBeanPropertyDescriptor.get(ent
					.getKey());
			if (ptarget != null) {
				try {
					if (ent.getValue() != null
							&& !ptarget.getPropertyType().equals(
									ent.getValue().getClass())) {
						Converter converter = convertors.get(ptarget
								.getPropertyType().getSimpleName());
						ptarget.getWriteMethod().invoke(
								target,
								converter.convert(ptarget.getPropertyType(),
										ent.getValue()));

					} else {
						ptarget.getWriteMethod().invoke(target, ent.getValue());
					}

				} catch (Exception e) {
					LOGGER.error(CONTEXT, e);
				}
			}
		}
		DffPropertyCaller.getDffPropertyCaller(getDiffProperty()).diffProperty(
				target, sourceBeanPropertyInvoker,
				(NullAwareBeanUtilsBean<Object, Object>) this);
	}

	public PropertyDescriptor[] getSourceBeanPropertyDescriptor() {
		return sourceBeanPropertyDescriptor;
	}

	/**
	 * @method setting the source bean properties descriptor
	 * @param sourceBeanClass
	 */
	public void setSourceBeanPropertyDescriptor(Class<?> sourceBeanClass) {
		try {
			BeanInfo infoSource = Introspector.getBeanInfo(sourceBeanClass);
			PropertyDescriptor[] pdsSource = infoSource
					.getPropertyDescriptors();
			this.sourceBeanPropertyDescriptor = pdsSource;
		} catch (Exception e) {
			LOGGER.error(CONTEXT, e);
		}
	}

	/**
	 * @method write not null properties values of source bean into target bean
	 *         of different named properties
	 * @param target
	 * @param sourceBeanPropertyInvoker
	 */
	private void setDiffPropertiesInSource(Object target,
			Map<String, Object> sourceBeanPropertyInvoker) {
		for (Map.Entry<String, String> entry : diffPropT2S.entrySet()) {
			try {
				String tPropName = entry.getKey();
				String sPropName = entry.getValue();

				Object returned = sourceBeanPropertyInvoker.get(sPropName);
				PropertyDescriptor ptarget = targetBeanPropertyDescriptor
						.get(tPropName);
				if (returned != null && ptarget != null) {
					if (!ptarget.getPropertyType().equals(returned.getClass())) {
						Converter converter = convertors.get(ptarget
								.getPropertyType().getSimpleName());
						ptarget.getWriteMethod().invoke(
								target,
								converter.convert(ptarget.getPropertyType(),
										returned));
					} else {
						ptarget.getWriteMethod().invoke(target, returned);
					}
				}
			} catch (Exception e) {
				LOGGER.error(CONTEXT, e);
			}
		}

	}

	private interface DffProperty {
		void diffProperty(Object target,
				Map<String, Object> sourceBeanPropertyInvoker,
				NullAwareBeanUtilsBean<Object, Object> nullAwareBeanUtilsBean);
	}

	/**
	 * 
	 * @author Rahul Singh
	 * @usage enum for calling the implementation at run time there are some
	 *        difference in property or not
	 * 
	 */
	private enum DffPropertyCaller implements DffProperty {
		DIFF_IN_PROPERTY {
			public void diffProperty(
					Object target,
					Map<String, Object> sourceBeanPropertyInvoker,
					NullAwareBeanUtilsBean<Object, Object> nullAwareBeanUtilsBean) {
				nullAwareBeanUtilsBean.setDiffPropertiesInSource(target,
						sourceBeanPropertyInvoker);
				return;
			}
		},
		NO_DIFF_IN_PROPERTY {
			public void diffProperty(
					Object target,
					Map<String, Object> sourceBeanPropertyInvoker,
					NullAwareBeanUtilsBean<Object, Object> nullAwareBeanUtilsBean) {
				return;
			}
		};

		public static DffPropertyCaller getDffPropertyCaller(String defaultValue) {
			try {
				return DffPropertyCaller.valueOf(defaultValue);
			} catch (Exception e) {
				LOGGER.error(CONTEXT, e);
				return DffPropertyCaller.valueOf("NO_DIFF_IN_PROPERTY");

			}
		}
	}

}
