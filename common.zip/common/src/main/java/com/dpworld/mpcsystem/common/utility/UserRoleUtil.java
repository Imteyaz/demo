package com.dpworld.mpcsystem.common.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dpworld.mpcsystem.common.constants.MPCConstants;
import com.dpworld.mpcsystem.common.utility.pojo.RoleDtlDTO;
import com.dpworld.mpcsystem.common.utility.pojo.UserRoleInfoDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class UserRoleUtil {
	private UserRoleUtil(){
		
	}

	// Get User role List
	public static List<UserRoleInfoDTO> getUserRoleList(String sessionName) {

		// New Code start
		List<UserRoleInfoDTO> userList = new ArrayList<UserRoleInfoDTO>();

		// webservice call to get codes from PROMIS1
		// List<UserRoleInfoDTO> list = null;
		try {
			Client c = Client.create();
			Gson gson = new Gson();
			WebResource resource = null;
			String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);

			resource = c.resource(url + "userList");

			String response = resource.get(String.class);

			// String response =
			// "[{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'341431082016','employeeNumber':'566565','empName':'Srinivas Mandadi','firstName':'Srinivas','middleName':null,'lastName':'Mandadi','domainId':'Srinivas.Mandadi','emailId':'Srinivas.Mandadi@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'374618102016','employeeNumber':'V12345','empName':'Ashok Vinc Ashok Vinc','firstName':'Ashok Vinc','middleName':null,'lastName':'Ashok Vinc','domainId':'Vinculum.Ashok','emailId':'Vinculum.Ashok@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381327102016','employeeNumber':'100','empName':'Himanshu Himanshu','firstName':'Himanshu','middleName':null,'lastName':'Himanshu','domainId':'vinculum.himanshu','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381627102016','employeeNumber':'102','empName':'vinNaman vinculum','firstName':'vinNaman','middleName':null,'lastName':'vinculum','domainId':'vinculum.naman','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381527102016','employeeNumber':'101','empName':'vinPriti vinculum','firstName':'vinPriti','middleName':null,'lastName':'vinculum','domainId':'vinculum.priti','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'341901092016','employeeNumber':'700173','empName':'Manasi Govilkar','firstName':'Manasi','middleName':null,'lastName':'Govilkar','domainId':'Paraminfo.Manasi','emailId':'Paraminfo.Manasi@dpworld.com','phoneNo':'0557269949','preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'472010012017','employeeNumber':'125656','empName':'Sanghamitra.Dehury Sanghamitra.Dehury','firstName':'Sanghamitra.Dehury','middleName':null,'lastName':'Sanghamitra.Dehury','domainId':'Sanghamitra.Dehury','emailId':'Sanghamitra.Dehury@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'472512012017','employeeNumber':'454545','empName':'Rabah.ElAwwar Rabah.ElAwwar','firstName':'Rabah.ElAwwar','middleName':null,'lastName':'Rabah.ElAwwar','domainId':'Rabah.ElAwwar','emailId':'Rabah.ElAwwar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'223425042016','employeeNumber':'23445','empName':'Rabah  Aawar','firstName':'Rabah ','middleName':'El ','lastName':'Aawar','domainId':'Rabah.ElAawar','emailId':'Rabah.ElAawar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'223525042016','employeeNumber':'324323','empName':'Sandip  Das','firstName':'Sandip ','middleName':null,'lastName':'Das','domainId':'Sandip.Das','emailId':'Sandip.Das@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'440114122016','employeeNumber':'423698','empName':'Raja Sekharan','firstName':'Raja','middleName':null,'lastName':'Sekharan','domainId':'Raja.Sekharan','emailId':'Raja.Sekharan@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'415022112016','employeeNumber':'41','empName':'vinGAUTAM GAUTAM','firstName':'vinGAUTAM','middleName':null,'lastName':'GAUTAM','domainId':'vinculum.gautam','emailId':'gau@gau.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'435729112016','employeeNumber':'200','empName':'sapSRINIVAS Gullapalli','firstName':'sapSRINIVAS','middleName':null,'lastName':'Gullapalli','domainId':'sapcle.srinivas','emailId':'spsp@spsp.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'160719012016','employeeNumber':'112345','empName':'Tushar Rahatekar','firstName':'Tushar','middleName':null,'lastName':'Rahatekar','domainId':'tushar.rahatekar','emailId':'tushar.rahatekar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381930102016','employeeNumber':'13266','empName':'Chaithanya Chaithanya','firstName':'Chaithanya','middleName':null,'lastName':'Chaithanya','domainId':'Vinculum.Chaithanya','emailId':'Vinculum.Chaithanya@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'439914122016','employeeNumber':'756666','empName':'Venkata Prasad','firstName':'Venkata','middleName':null,'lastName':'Prasad','domainId':'Venkata.Prasad','emailId':'Venkata.Prasad@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_ALL_ROLES','userId':'502927022017','employeeNumber':'4484788','empName':'mpcadmin mpcadmin','firstName':'mpcadmin','middleName':null,'lastName':'mpcadmin','domainId':'mpcadmin','emailId':'GTFS.Moosa@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_ALL_ROLES','userId':'494914022017','employeeNumber':'44444','empName':'Vinculum.Imteyaz Vinculum.Imteyaz','firstName':'Vinculum.Imteyaz','middleName':null,'lastName':'Vinculum.Imteyaz','domainId':'Vinculum.Imteyaz','emailId':'vinculum.imteyaz@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_R_USER','userId':'503828022017','employeeNumber':'232323','empName':'mpcadminr mpcadminr','firstName':'mpcadminr','middleName':null,'lastName':'mpcadminr','domainId':'mpcadminr','emailId':'GTFS.Moosa@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'495014022017','employeeNumber':'444','empName':'sapcle.mohammed sapcle.mohammed','firstName':'sapcle.mohammed','middleName':null,'lastName':'sapcle.mohammed','domainId':'sapcle.mohammed','emailId':'sapcle.mohammed@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null}]";

			userList = gson.fromJson(response,
					new TypeToken<List<UserRoleInfoDTO>>() {
					}.getType());

		} catch (Exception er) {
			er.printStackTrace();
		}

		return userList;
	}

	public static List<RoleDtlDTO> getRoleList() {
		// webservice call to get codes from PROMIS1
		List<RoleDtlDTO> list = null;
		try {
			Client c = Client.create();
			Gson gson = new Gson();
			WebResource resource = null;
			String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);

			resource = c.resource(url + "roleList");

			String response = resource.get(String.class);
			// String response =
			// "[{'roleName':'MPC_RW_USER','domainId':null},{'roleName':'SuperUser','domainId':null},{'roleName':'MPC_R_USER','domainId':null},{'roleName':'MPC_ALL_ROLES','domainId':null}]";

			list = gson.fromJson(response, new TypeToken<List<RoleDtlDTO>>() {
			}.getType());

		} catch (Exception er) {
			er.printStackTrace();
		}

		return list;
	}

	public static HashMap<String, List<UserRoleInfoDTO>> getUserRoleMap() {
		// webservice call to get codes from PROMIS1
		List<RoleDtlDTO> rolelist = getRoleList();
		List<UserRoleInfoDTO> userRoleList = getUserRoleList("test");
		HashMap<String, List<UserRoleInfoDTO>> roleMap = new HashMap<String, List<UserRoleInfoDTO>>();
		ArrayList<UserRoleInfoDTO> userList = null;
		try {
			for (RoleDtlDTO rlDto : rolelist) {
				userList = new ArrayList<UserRoleInfoDTO>();
				for (UserRoleInfoDTO urIDto : userRoleList) {
					if (rlDto.getRoleName().equalsIgnoreCase(
							urIDto.getRoleName())) {
						userList.add(urIDto);
					}
				}
				roleMap.put(rlDto.getRoleName(), userList);
			}
		} catch (Exception er) {
			er.printStackTrace();
		}

		return roleMap;
	}

	public static HashMap<String, String> getRoleNameByUserName() {

		HashMap<String, String> roleUserMap = new HashMap<String, String>();
		// New Code start
		List<UserRoleInfoDTO> userRoleList = new ArrayList<UserRoleInfoDTO>();
		try {
			Client c = Client.create();
			Gson gson = new Gson();
			WebResource resource = null;
			String url = MPCUtil.getFuseUrl(MPCConstants.MPC_FUSE_URL);
            
			resource = c.resource(url + "userList");

			 String response = resource.get(String.class);

	//		String response = "[{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'341431082016','employeeNumber':'566565','empName':'Srinivas Mandadi','firstName':'Srinivas','middleName':null,'lastName':'Mandadi','domainId':'Srinivas.Mandadi','emailId':'Srinivas.Mandadi@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'374618102016','employeeNumber':'V12345','empName':'Ashok Vinc Ashok Vinc','firstName':'Ashok Vinc','middleName':null,'lastName':'Ashok Vinc','domainId':'Vinculum.Ashok','emailId':'Vinculum.Ashok@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381327102016','employeeNumber':'100','empName':'Himanshu Himanshu','firstName':'Himanshu','middleName':null,'lastName':'Himanshu','domainId':'vinculum.himanshu','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381627102016','employeeNumber':'102','empName':'vinNaman vinculum','firstName':'vinNaman','middleName':null,'lastName':'vinculum','domainId':'vinculum.naman','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381527102016','employeeNumber':'101','empName':'vinPriti vinculum','firstName':'vinPriti','middleName':null,'lastName':'vinculum','domainId':'vinculum.priti','emailId':'vin@abc.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'341901092016','employeeNumber':'700173','empName':'Manasi Govilkar','firstName':'Manasi','middleName':null,'lastName':'Govilkar','domainId':'Paraminfo.Manasi','emailId':'Paraminfo.Manasi@dpworld.com','phoneNo':'0557269949','preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'472010012017','employeeNumber':'125656','empName':'Sanghamitra.Dehury Sanghamitra.Dehury','firstName':'Sanghamitra.Dehury','middleName':null,'lastName':'Sanghamitra.Dehury','domainId':'Sanghamitra.Dehury','emailId':'Sanghamitra.Dehury@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'472512012017','employeeNumber':'454545','empName':'Rabah.ElAwwar Rabah.ElAwwar','firstName':'Rabah.ElAwwar','middleName':null,'lastName':'Rabah.ElAwwar','domainId':'Rabah.ElAwwar','emailId':'Rabah.ElAwwar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'223425042016','employeeNumber':'23445','empName':'Rabah  Aawar','firstName':'Rabah ','middleName':'El ','lastName':'Aawar','domainId':'Rabah.ElAawar','emailId':'Rabah.ElAawar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'223525042016','employeeNumber':'324323','empName':'Sandip  Das','firstName':'Sandip ','middleName':null,'lastName':'Das','domainId':'Sandip.Das','emailId':'Sandip.Das@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'440114122016','employeeNumber':'423698','empName':'Raja Sekharan','firstName':'Raja','middleName':null,'lastName':'Sekharan','domainId':'Raja.Sekharan','emailId':'Raja.Sekharan@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'415022112016','employeeNumber':'41','empName':'vinGAUTAM GAUTAM','firstName':'vinGAUTAM','middleName':null,'lastName':'GAUTAM','domainId':'vinculum.gautam','emailId':'gau@gau.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'435729112016','employeeNumber':'200','empName':'sapSRINIVAS Gullapalli','firstName':'sapSRINIVAS','middleName':null,'lastName':'Gullapalli','domainId':'sapcle.srinivas','emailId':'spsp@spsp.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'160719012016','employeeNumber':'112345','empName':'Tushar Rahatekar','firstName':'Tushar','middleName':null,'lastName':'Rahatekar','domainId':'tushar.rahatekar','emailId':'tushar.rahatekar@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'381930102016','employeeNumber':'13266','empName':'Chaithanya Chaithanya','firstName':'Chaithanya','middleName':null,'lastName':'Chaithanya','domainId':'Vinculum.Chaithanya','emailId':'Vinculum.Chaithanya@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'439914122016','employeeNumber':'756666','empName':'Venkata Prasad','firstName':'Venkata','middleName':null,'lastName':'Prasad','domainId':'Venkata.Prasad','emailId':'Venkata.Prasad@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_ALL_ROLES','userId':'502927022017','employeeNumber':'4484788','empName':'mpcadmin mpcadmin','firstName':'mpcadmin','middleName':null,'lastName':'mpcadmin','domainId':'mpcadmin','emailId':'GTFS.Moosa@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_ALL_ROLES','userId':'494914022017','employeeNumber':'44444','empName':'Vinculum.Imteyaz Vinculum.Imteyaz','firstName':'Vinculum.Imteyaz','middleName':null,'lastName':'Vinculum.Imteyaz','domainId':'Vinculum.Imteyaz','emailId':'vinculum.imteyaz@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'MPC_R_USER','userId':'503828022017','employeeNumber':'232323','empName':'mpcadminr mpcadminr','firstName':'mpcadminr','middleName':null,'lastName':'mpcadminr','domainId':'mpcadminr','emailId':'GTFS.Moosa@dpworld.ae','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null},{'terminalCode':'T3','portCode':'J','roleName':'SuperUser','userId':'495014022017','employeeNumber':'444','empName':'sapcle.mohammed sapcle.mohammed','firstName':'sapcle.mohammed','middleName':null,'lastName':'sapcle.mohammed','domainId':'sapcle.mohammed','emailId':'sapcle.mohammed@dpworld.com','phoneNo':null,'preferredTerminalId':'T3','appDescription':'Marine Planning Console','description':null}]";

			userRoleList = gson.fromJson(response,
					new TypeToken<List<UserRoleInfoDTO>>() {
					}.getType());

			if (userRoleList != null && userRoleList.size() > 0) {
				for (UserRoleInfoDTO userRoleInfo : userRoleList) {
					roleUserMap.put(userRoleInfo.getDomainId(),
							userRoleInfo.getRoleName());
				}
			}

		} catch (Exception er) {
			er.printStackTrace();
		}

		return roleUserMap;
	}

}
