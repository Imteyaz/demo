package com.dpworld.mpcsystem.common.utility.pojo;

public class MpcGeofenceDTO {
	private String mgmGfCode;
	private String mgdObjName;
	private String serviceType;
	private String status;
	private String vesselType;
	private String rotation;
	private String serviceTypeDesc;
	
	public String getServiceTypeDesc() {
		return serviceTypeDesc;
	}
	public void setServiceTypeDesc(String serviceTypeDesc) {
		this.serviceTypeDesc = serviceTypeDesc;
	}
	public String getRotation() {
		return rotation;
	}
	public void setRotation(String rotation) {
		this.rotation = rotation;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVesselType() {
		return vesselType;
	}
	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}
	public String getMgmGfCode() {
		return mgmGfCode;
	}
	public void setMgmGfCode(String mgmGfCode) {
		this.mgmGfCode = mgmGfCode;
	}
	public String getMgdObjName() {
		return mgdObjName;
	}
	public void setMgdObjName(String mgdObjName) {
		this.mgdObjName = mgdObjName;
	}
	
	
}
