package com.dpworld.mpcsystem.common.utility.pojo;

import java.util.List;

public class VesselListFilterDTO {

	private List<String> status;
	private List<String> terminal;
	private List<String> terminalCurrentt;

	private List<String> location;
	private List<String> dualCall;
	private List<String> serviceType;
	private List<String> vesselTypes;
	private String tempStatus;
	private String tempTerminal;
	private String tempTerminalcurrent;

	private String tempLocation;
	private String tempDualCall;
	private String tempServiceType;
	private String tempVesselType;
	
	private String fromETA;
	private String toETA;
	private String tempFromETA;
	private String tempToETA;
	private List<String> vesselTypesCode;
	
	public String getTempTerminalcurrent() {
		return tempTerminalcurrent;
	}
	public void setTempTerminalcurrent(String tempTerminalcurrent) {
		this.tempTerminalcurrent = tempTerminalcurrent;
	}
	public List<String> getStatus() {
		return status;
	}
	public void setStatus(List<String> status) {
		this.status = status;
	}
	public List<String> getTerminal() {
		return terminal;
	}
	public void setTerminal(List<String> terminal) {
		this.terminal = terminal;
	}
	
	public List<String> getTerminalCurrentt() {
		return terminalCurrentt;
	}
	public void setTerminalCurrentt(List<String> terminalCurrentt) {
		this.terminalCurrentt = terminalCurrentt;
	}
	public List<String> getLocation() {
		return location;
	}
	public void setLocation(List<String> location) {
		this.location = location;
	}
	public List<String> getDualCall() {
		return dualCall;
	}
	public void setDualCall(List<String> dualCall) {
		this.dualCall = dualCall;
	}
	public List<String> getServiceType() {
		return serviceType;
	}
	public void setServiceType(List<String> serviceType) {
		this.serviceType = serviceType;
	}
	public List<String> getVesselTypes() {
		return vesselTypes;
	}
	public void setVesselTypes(List<String> vesselTypes) {
		this.vesselTypes = vesselTypes;
	}
	public String getTempStatus() {
		return tempStatus;
	}
	public void setTempStatus(String tempStatus) {
		this.tempStatus = tempStatus;
	}
	public String getTempTerminal() {
		return tempTerminal;
	}
	public void setTempTerminal(String tempTerminal) {
		this.tempTerminal = tempTerminal;
	}
	public String getTempLocation() {
		return tempLocation;
	}
	public void setTempLocation(String tempLocation) {
		this.tempLocation = tempLocation;
	}
	public String getTempDualCall() {
		return tempDualCall;
	}
	public void setTempDualCall(String tempDualCall) {
		this.tempDualCall = tempDualCall;
	}
	public String getTempServiceType() {
		return tempServiceType;
	}
	public void setTempServiceType(String tempServiceType) {
		this.tempServiceType = tempServiceType;
	}
	public String getTempVesselType() {
		return tempVesselType;
	}
	public void setTempVesselType(String tempVesselType) {
		this.tempVesselType = tempVesselType;
	}
	public String getFromETA() {
		return fromETA;
	}
	public void setFromETA(String fromETA) {
		this.fromETA = fromETA;
	}
	public String getToETA() {
		return toETA;
	}
	public void setToETA(String toETA) {
		this.toETA = toETA;
	}
	public List<String> getVesselTypesCode() {
		return vesselTypesCode;
	}
	public void setVesselTypesCode(List<String> vesselTypesCode) {
		this.vesselTypesCode = vesselTypesCode;
	}
	@Override
	public String toString() {
		return "VesselListFilterDTO [status=" + status + ", terminal=" + terminal + ", location=" + location
				+ ", dualCall=" + dualCall + ", serviceType=" + serviceType + ", vesselTypes=" + vesselTypes
				+ ", tempStatus=" + tempStatus + ", tempTerminal=" + tempTerminal + ", tempLocation=" + tempLocation
				+ ", tempDualCall=" + tempDualCall + ", tempServiceType=" + tempServiceType + ", tempVesselType="
				+ tempVesselType + ", fromETA=" + fromETA + ", toETA=" + toETA + ", tempFromETA=" + tempFromETA
				+ ", tempToETA=" + tempToETA + ", vesselTypesCode=" + vesselTypesCode + "]";
	}
	public String getTempFromETA() {
		return tempFromETA;
	}
	public void setTempFromETA(String tempFromETA) {
		this.tempFromETA = tempFromETA;
	}
	public String getTempToETA() {
		return tempToETA;
	}
	public void setTempToETA(String tempToETA) {
		this.tempToETA = tempToETA;
	}
	
	
	
}
