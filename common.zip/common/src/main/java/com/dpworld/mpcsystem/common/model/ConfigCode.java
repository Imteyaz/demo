package com.dpworld.mpcsystem.common.model;

import java.io.Serializable;


public class ConfigCode implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 2062202892364604114L;

  private String codeCode;
  private String codeType;
  private String codeDescription1;
  private String codeDescription2;
  private Double codeNum;
  private String codeGroup;
  private String teminalId;
  
  public String getCodeCode() {
    return codeCode;
  }
  
  public void setCodeCode(String codeCode) {
    this.codeCode = codeCode;
  }
  
  public String getCodeType() {
    return codeType;
  }
  
  public void setCodeType(String codeType) {
    this.codeType = codeType;
  }
  
  public String getCodeDescription1() {
    return codeDescription1;
  }
  
  public void setCodeDescription1(String codeDescription1) {
    this.codeDescription1 = codeDescription1;
  }
  
  public String getCodeDescription2() {
    return codeDescription2;
  }
  
  public void setCodeDescription2(String codeDescription2) {
    this.codeDescription2 = codeDescription2;
  }
  
  public Double getCodeNum() {
    return codeNum;
  }
  
  public void setCodeNum(Double codeNum) {
    this.codeNum = codeNum;
  }
  
  public String getCodeGroup() {
    return codeGroup;
  }
  
  public void setCodeGroup(String codeGroup) {
    this.codeGroup = codeGroup;
  }
  
  public String getTeminalId() {
    return teminalId;
  }
  
  public void setTeminalId(String teminalId) {
    this.teminalId = teminalId;
  }

  

}
